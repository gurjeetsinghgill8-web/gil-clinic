"""Queue domain entities."""
