"""Queue domain events."""
