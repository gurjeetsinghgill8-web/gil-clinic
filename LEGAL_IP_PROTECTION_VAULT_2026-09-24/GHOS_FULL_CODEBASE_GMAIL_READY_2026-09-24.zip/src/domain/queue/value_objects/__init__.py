"""Queue domain value objects."""
