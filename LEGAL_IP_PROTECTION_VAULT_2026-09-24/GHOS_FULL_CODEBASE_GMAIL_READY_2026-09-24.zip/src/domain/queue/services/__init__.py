"""Queue domain services."""
