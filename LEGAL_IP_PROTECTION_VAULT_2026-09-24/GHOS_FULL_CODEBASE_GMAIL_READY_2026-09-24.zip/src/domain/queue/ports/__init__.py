"""Queue domain ports (interfaces)."""
