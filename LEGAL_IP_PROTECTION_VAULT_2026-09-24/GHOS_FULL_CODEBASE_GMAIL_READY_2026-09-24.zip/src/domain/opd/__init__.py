"""OPD domain layer."""
