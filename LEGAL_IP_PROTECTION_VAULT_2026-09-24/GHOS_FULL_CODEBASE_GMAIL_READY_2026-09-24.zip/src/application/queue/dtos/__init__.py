"""Queue application DTOs package."""
