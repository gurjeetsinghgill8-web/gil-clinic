import re
import time

import requests

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)

r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

cases = [
    ("CASE 1 - chest pain + cough + SOB lying down", {
        "patient_name": "Acpt1", "vitals": "130/80, 88/min, 98%",
        "complaints": "chest pain, cough, shortness of breath while lying down, better when upright",
        "past_context": "", "doctor_medicines": "", "allow_suggest_drugs": False,
        "include_investigations": True,
    }),
    ("CASE 2 - fever + headache + bodyache", {
        "patient_name": "Acpt2", "vitals": "100.4F, 96/min",
        "complaints": "fever 2 din se, headache, bodyache",
        "past_context": "", "doctor_medicines": "", "allow_suggest_drugs": False,
        "include_investigations": True,
    }),
    ("CASE 3 - acidity after Dolo 650", {
        "patient_name": "Acpt3", "vitals": "",
        "complaints": "pet mein jalan, acidity - Dolo 650 kha raha tha 2 din se",
        "past_context": "", "doctor_medicines": "Dolo 650 TDS", "allow_suggest_drugs": False,
        "include_investigations": True,
    }),
]

for label, body in cases:
    print("=" * 70)
    print(label)
    r2 = s.post(BASE + "/opd/api/generate-rx", json=body, timeout=180)
    data = r2.json()
    if data.get("ok"):
        rx = data.get("prescription", "")
        m = re.search(r"Diagnosis[:\s]*\n?([\s\S]*?)(?=\n\s*(?:Treatment|Management|Drugs|Investigations|Advice|Follow-up|$)|$)", rx)
        print("DIAGNOSIS OUTPUT:")
        print((m.group(1).strip() if m else rx[:400]).encode("ascii", "replace").decode())
    else:
        print("FAIL:", str(data)[:300].encode("ascii", "replace").decode())
