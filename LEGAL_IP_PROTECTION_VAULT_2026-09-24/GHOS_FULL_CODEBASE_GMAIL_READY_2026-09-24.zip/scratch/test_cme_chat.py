import time

import requests

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

r2 = s.post(BASE + "/opd/api/cme-chat", json={
    "topic": "new ESC heart failure guidelines",
    "question": "HFimpEF ka matlab kya hai aur iska treatment HFrEF se alag kaise hai?",
    "history": "",
}, timeout=180)
d = r2.json()
print("cme-chat ok:", d.get("ok"), "| provider:", d.get("provider"))
a = d.get("answer") or d.get("error") or ""
print("ANSWER:", a[:400].encode("ascii", "replace").decode())
t = a.lower()
print("HFimpEF mention:", "hfimpef" in t or "improved" in t)
print("verify mention:", "verify" in t or "esc 2026" in t)
