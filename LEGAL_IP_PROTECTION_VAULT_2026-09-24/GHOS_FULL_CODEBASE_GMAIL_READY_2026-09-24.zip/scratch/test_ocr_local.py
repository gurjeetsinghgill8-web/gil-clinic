import base64
import io

import requests
from PIL import Image, ImageDraw

# synthetic "handwritten" Rx image
img = Image.new("RGB", (900, 500), "white")
d = ImageDraw.Draw(img)
d.text((30, 40), "Patient: Test OCR", fill="black")
d.text((30, 90), "Diagnosis: Viral Fever", fill="black")
d.text((30, 140), "Treatment:", fill="black")
d.text((60, 180), "1. Dolo 650 TDS after food x 5 days", fill="black")
d.text((30, 230), "Advice: Rest, plenty of fluids", fill="black")
d.text((30, 280), "Investigations: CBC", fill="black")
buf = io.BytesIO()
img.save(buf, format="PNG")
b64 = base64.b64encode(buf.getvalue()).decode()

BASE = "http://localhost:8000"
s = requests.Session()
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

r2 = s.post(
    BASE + "/opd/api/handwriting-ocr",
    json={"image": "data:image/png;base64," + b64},
    timeout=180,
)
print("handwriting-ocr:", r2.status_code)
print(r2.text[:700].encode("ascii", "replace").decode())
