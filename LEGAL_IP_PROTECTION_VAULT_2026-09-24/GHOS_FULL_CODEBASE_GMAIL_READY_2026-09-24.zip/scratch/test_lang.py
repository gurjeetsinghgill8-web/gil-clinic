import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import cme_chat_prompt
from src.ai_engine.provider_router import route_chat

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}

for q in ["What is HFimpEF and how is it treated?", "HFimpEF ka matlab kya hai aur ilaj kya hai?"]:
    r = route_chat(settings, [cme_chat_prompt("heart failure", "", q)], feature="cme-chat", temp=0.3, max_tokens=1200)
    text = r.get("text") or ""
    hindi = any(0x0900 <= ord(c) <= 0x097F for c in text)
    print("Q:", q)
    print("  hindi chars:", hindi, "| head:", text[:120].encode("ascii", "replace").decode())
