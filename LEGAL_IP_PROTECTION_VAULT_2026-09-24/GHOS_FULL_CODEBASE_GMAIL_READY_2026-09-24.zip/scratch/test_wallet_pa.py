import requests

BASE = "https://gillhopitalsoftware1.pythonanywhere.com"
s = requests.Session()
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)
st = s.get(BASE + "/opd/api/wallet/status", timeout=30).json()
print("STATUS:", {k: st[k] for k in ("balance_paise", "upi_id", "margin", "is_owner")})

r3 = s.post(BASE + "/opd/api/wallet/recharge-request", json={"amount_paise": 5000, "utr": "PATEST0001"}, timeout=30).json()
print("RECHARGE:", {k: r3.get(k) for k in ("ok", "id", "error")})

s2 = requests.Session()
s2.post(BASE + "/opd/login", data={"pin": "1010"}, allow_redirects=False, timeout=30)
r4 = s2.post(BASE + "/opd/api/wallet/approve", json={"id": r3.get("id"), "action": "approve"}, timeout=30).json()
print("APPROVE:", r4)

st2 = s.get(BASE + "/opd/api/wallet/status", timeout=30).json()
print("STATUS after:", {k: st2[k] for k in ("balance_paise", "total_recharged_paise")})

qr = s.get(BASE + "/opd/api/wallet/upi-qr?amount=5000", timeout=30)
print("QR:", qr.status_code, qr.headers.get("content-type"), len(qr.content), "bytes")
