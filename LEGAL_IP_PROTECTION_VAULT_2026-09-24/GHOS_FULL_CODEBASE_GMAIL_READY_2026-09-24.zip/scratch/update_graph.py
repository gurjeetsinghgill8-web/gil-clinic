content = open("ghos_memory/GRAPH_MEMORY.md", encoding="utf-8").read()
content = content.replace(
    "## v3 · 30-Aug-2026 · C1+C2+C3+C5+D1+D2+D3A shipped · Live system state",
    "## v4 · 30-Aug-2026 · C/D/E2 + GIL AI Wallet shipped · Live system state",
)
anchor = '    D3A["✅ D3A: 2-stage deep reasoning<br/>(hidden analysis → working diagnosis)"]'
addition = anchor + '\n    WALLET["✅ GIL AI Wallet: UPI recharge, margin 2x,\\n    per-feature pricing, owner approve (Puter = primary)"]'
content = content.replace(anchor, addition)
content = content.replace(
    "    D12 --> SAVE",
    "    D12 --> SAVE\n    WALLET -.->|mode: gilwallet (sasta backup)| GEN",
)
open("ghos_memory/GRAPH_MEMORY.md", "w", encoding="utf-8").write(content)
print("graph updated")
