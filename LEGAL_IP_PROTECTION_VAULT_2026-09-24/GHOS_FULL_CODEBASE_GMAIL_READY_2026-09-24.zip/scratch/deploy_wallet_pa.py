import requests

h = {"Authorization": "Token " + open("pa_token.txt").read().strip()}
base = "https://www.pythonanywhere.com/api/v0/user/gillhopitalsoftware1/files/path/home/gillhopitalsoftware1/gil-clinic/"

# 1) upload code files
for f in [
    "src/ai_engine/provider_router.py",
    "src/presentation/opd/routes/opd_routes.py",
    "main_v2.py",
    "src/infrastructure/opd/models/ai_wallet_model.py",
    "templates/opd/dashboard.html",
    "secret.txt",
]:
    with open(f, "rb") as fh:
        data = fh.read()
    r = requests.post(base + f, headers=h, files={"content": data}, timeout=120)
    print("upload", f, r.status_code, len(data))

# 2) update PA .env - append wallet vars (keep existing content intact)
r = requests.get(base + ".env", headers=h, timeout=60)
env = r.content.decode("utf-8", "replace") if r.status_code == 200 else ""
if "AI_WALLET_UPI_ID" not in env:
    env = env.rstrip() + "\n\n# GIL AI Wallet (sasta backup - owner earns margin)\nAI_WALLET_UPI_ID=gillclinic@upi\nAI_WALLET_MARGIN=2.0\n"
    r2 = requests.post(base + ".env", headers=h, files={"content": env.encode("utf-8")}, timeout=60)
    print("PA .env update:", r2.status_code)
else:
    print("PA .env already has wallet vars")
