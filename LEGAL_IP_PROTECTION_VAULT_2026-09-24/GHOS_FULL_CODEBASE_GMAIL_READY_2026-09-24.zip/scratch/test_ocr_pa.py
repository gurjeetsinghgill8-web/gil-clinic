import base64
import io

import requests
from PIL import Image, ImageDraw

img = Image.new("RGB", (400, 300), "white")
d = ImageDraw.Draw(img)
d.text((20, 40), "Dolo 650 TDS", fill="black")
buf = io.BytesIO()
img.save(buf, format="PNG")
b64 = base64.b64encode(buf.getvalue()).decode()

BASE = "https://gillhopitalsoftware1.pythonanywhere.com"
s = requests.Session()
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)
r2 = s.post(
    BASE + "/opd/api/handwriting-ocr",
    json={"image": "data:image/png;base64," + b64},
    timeout=60,
)
print("PA handwriting-ocr:", r2.status_code)
print(r2.text[:300].encode("ascii", "replace").decode())
