import requests

s = requests.Session()
r = s.post("https://gillhopitalsoftware1.pythonanywhere.com/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)
r2 = s.get("https://gillhopitalsoftware1.pythonanywhere.com/opd/api/ai-config", timeout=30)
print("ai-config:", r2.json())
