import sys
import time

import requests

sys.path.insert(0, ".")
from src.utils.pdf_generator import safe_str  # noqa: E402

# safe_str unit test
sample = "🥗 Clinical Rx — ₹500 'quote' 50% 🍚 Rice"
clean = safe_str(sample)
print("safe_str:", clean.encode("ascii", "replace").decode())
assert "?" not in clean, "safe_str still leaves '?'"
print("safe_str OK: koi '?' nahi\n")

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)

r = s.post(BASE + "/staff/login", data={"role": "Dietitian", "pin": "1234"}, allow_redirects=False, timeout=30)
print("staff login:", r.status_code)

body = {
    "patient_name": "Ggd", "age": "25", "gender": "Male",
    "weight": "99", "height": "150", "bmi": "44.0",
    "conditions": "Hypertension", "goal": "Weight loss", "diet_type": "Regular",
}
r2 = s.post(BASE + "/staff/api/diet-plan", json=body, timeout=240)
d = r2.json()
plan = d.get("diet_plan", "")
print("diet-plan ok:", d.get("ok"))
head = plan[:1200].encode("ascii", "replace").decode()
print("--- plan head ---")
print(head)
print("--- checks ---")
print("GIL CLINIC present:", "GIL CLINIC" in plan)
print("reconfirm line present:", "reconfirm" in plan.lower())
print("emojis present:", any(ord(c) > 0x1F600 and ord(c) < 0x1F9FF for c in plan))
import re
m = re.search(r"CALORIES:\s*(\d+)", plan)
print("CALORIES:", m.group(1) if m else "NOT FOUND")
m2 = re.search(r"DEFICIT:\s*([\d\s-]+)", plan)
print("DEFICIT line:", m2.group(0) if m2 else "NOT FOUND")

# PDF
r3 = s.post(BASE + "/staff/api/diet-pdf", json={**body, "diet_plan": plan}, timeout=120)
print("diet-pdf:", r3.status_code, r3.headers.get("content-type"), len(r3.content), "bytes")
print("pdf bytes have no '?' spam:", r3.content.count(b"?") < 200)
