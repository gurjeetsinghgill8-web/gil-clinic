import time

import requests

BASE = "http://localhost:8000"

s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)

# doctor session (chief)
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

# 1) wallet status (balance 0)
st = s.get(BASE + "/opd/api/wallet/status", timeout=30).json()
print("STATUS:", {k: st[k] for k in ("balance_paise", "upi_id", "margin", "is_owner")})

# 2) generate-rx with 0 balance -> wallet_low error
r2 = s.post(BASE + "/opd/api/generate-rx", json={
    "patient_name": "WalletTest", "vitals": "120/80", "complaints": "fever cough",
    "past_context": "", "doctor_medicines": "", "allow_suggest_drugs": False, "include_investigations": True,
}, timeout=60).json()
print("GENERATE (0 balance):", str({k: r2[k] for k in ("ok", "error") if k in r2}).encode("ascii", "replace").decode())

# 3) recharge request (as doctor) + approve (as admin PIN 1010)
r3 = s.post(BASE + "/opd/api/wallet/recharge-request", json={"amount_paise": 10000, "utr": "4182TEST0001"}, timeout=30).json()
print("RECHARGE REQUEST:", str({k: r3.get(k) for k in ("ok", "id", "message")}).encode("ascii", "replace").decode())

s2 = requests.Session()
s2.post(BASE + "/opd/login", data={"pin": "1010"}, allow_redirects=False, timeout=30)
r4 = s2.post(BASE + "/opd/api/wallet/approve", json={"id": r3.get("id"), "action": "approve"}, timeout=30).json()
print("APPROVE:", r4)

st2 = s.get(BASE + "/opd/api/wallet/status", timeout=30).json()
print("STATUS after approve:", {k: st2[k] for k in ("balance_paise", "total_recharged_paise")})

# 4) generate-rx now -> success + deduction (cost 200*2=400 paise)
r5 = s.post(BASE + "/opd/api/generate-rx", json={
    "patient_name": "WalletTest", "vitals": "120/80", "complaints": "fever cough",
    "past_context": "", "doctor_medicines": "", "allow_suggest_drugs": False, "include_investigations": True,
}, timeout=180).json()
print("GENERATE (with balance): ok =", r5.get("ok"), "| provider:", r5.get("provider"))

st3 = s.get(BASE + "/opd/api/wallet/status", timeout=30).json()
print("STATUS after generate:", {k: st3[k] for k in ("balance_paise", "total_spent_paise")})

# 5) UPI QR endpoint
qr = s.get(BASE + "/opd/api/wallet/upi-qr?amount=10000", timeout=30)
print("QR:", qr.status_code, qr.headers.get("content-type"), len(qr.content), "bytes")
