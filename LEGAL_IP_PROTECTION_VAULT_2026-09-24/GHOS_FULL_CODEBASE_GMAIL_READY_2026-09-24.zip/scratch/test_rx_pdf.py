import time

import requests

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

r2 = s.post(BASE + "/opd/api/pdf-rx", json={
    "patient_name": "Rahul1",
    "vitals": "130/80, 72/min",
    "prescription": "zifi 200 BD before food",
    "investigations": "CBC",
    "complaints": "chest pain, shortness of breath since 3 days",
    "patient_id": "OPD-20260830-ABCD",
}, timeout=120)
print("pdf-rx:", r2.status_code, r2.headers.get("content-type"), len(r2.content), "bytes")
b = r2.content
print("has 'Complaints:':", b"Complaints:" in b)
print("has 'Patient No:':", b"Patient No:" in b)
print("has 'Track:':", b"Track:" in b)
print("has '?':", b"?" in b)
