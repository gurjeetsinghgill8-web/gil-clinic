import time

import requests

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

body = {
    "patient_name": "SrvParse", "vitals": "190/70",
    "complaints": "chest pain, shortness of breath when lying, sweating, decreased urine",
    "past_context": "", "doctor_medicines": "", "allow_suggest_drugs": False,
    "include_investigations": True,
}
r2 = s.post(BASE + "/opd/api/generate-rx", json=body, timeout=180)
data = r2.json()
print("ok:", data.get("ok"))
print("DIAGNOSIS FIELD:", (data.get("diagnosis") or "")[:250].encode("ascii", "replace").decode())
print("ADVICE FIELD:", (data.get("advice") or "")[:150].encode("ascii", "replace").decode())
print("has prescription:", bool(data.get("prescription")))
