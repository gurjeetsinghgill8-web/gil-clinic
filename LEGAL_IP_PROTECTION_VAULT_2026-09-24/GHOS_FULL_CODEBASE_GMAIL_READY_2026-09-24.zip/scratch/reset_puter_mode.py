import sqlite3

con = sqlite3.connect("ghos_dev.db")
con.execute("UPDATE opd_settings SET ai_mode='puter' WHERE doctor_id='clinic_default'")
con.commit()
print("local ai_mode:", con.execute("SELECT ai_mode FROM opd_settings WHERE doctor_id='clinic_default'").fetchone())
con.close()
