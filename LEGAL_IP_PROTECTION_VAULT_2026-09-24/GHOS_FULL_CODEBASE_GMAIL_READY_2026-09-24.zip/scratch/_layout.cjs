/** Layout sanity: overflow, overlap, cramped elements — jo aankh se dikhta hai. */
const { chromium } = require('playwright');
const path = require('path');

const B = 'https://gillhopitalsoftware1.pythonanywhere.com';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

(async () => {
  const browser = await chromium.launch();
  for (const vp of [{ w: 1440, h: 1000, tag: 'desktop' }, { w: 820, h: 1180, tag: 'tablet' }]) {
    const ctx = await browser.newContext({ viewport: { width: vp.w, height: vp.h } });
    const p = await ctx.newPage();
    await p.goto(B + '/opd/login', { waitUntil: 'domcontentloaded' });
    await p.locator('input[name="pin"]').fill('5554');
    await p.locator('button[type="submit"]').first().click();
    await p.waitForSelector('text=New Prescription', { timeout: 45000 });
    await sleep(2500);

    console.log(`\n========== ${vp.tag} (${vp.w}x${vp.h}) ==========`);
    const res = await p.evaluate(() => {
      const de = document.documentElement;
      const out = {
        docScrollW: de.scrollWidth, docClientW: de.clientWidth,
        horizOverflow: de.scrollWidth - de.clientWidth,
        overflowing: [],
      };
      const vw = de.clientWidth;
      document.querySelectorAll('body *').forEach((el) => {
        const r = el.getBoundingClientRect();
        if (r.width === 0 || r.height === 0) return;
        if (r.right > vw + 2 && r.width < vw * 3) {
          const id = el.id ? '#' + el.id : '';
          const cls = el.className && typeof el.className === 'string' ? '.' + el.className.split(' ').filter(Boolean).join('.') : '';
          out.overflowing.push({ sel: el.tagName.toLowerCase() + id + cls, right: Math.round(r.right), w: Math.round(r.width) });
        }
      });
      out.overflowing = out.overflowing.slice(0, 12);
      return out;
    });
    console.log('doc scrollW/clientW:', res.docScrollW, '/', res.docClientW, '| horiz overflow:', res.horizOverflow, res.horizOverflow > 4 ? '  <-- !!' : '  (ok)');
    console.log('elements crossing right edge:', res.overflowing.length);
    res.overflowing.forEach((o) => console.log('   ', o.sel, 'right=' + o.right, 'w=' + o.w));

    // med-row field sizes (cramped?)
    await p.evaluate(() => { const m = document.getElementById('med-library-modal'); if (m) m.style.display = 'none'; });
    const rowInfo = await p.locator('#medicines-container .med-row').first().evaluate((row) => {
      const kids = [...row.children].map((c) => {
        const r = c.getBoundingClientRect();
        return { cls: (typeof c.className === 'string' ? c.className : c.tagName).slice(0, 22), w: Math.round(r.width), h: Math.round(r.height) };
      });
      return { rowW: Math.round(row.getBoundingClientRect().width), kids };
    }).catch(() => null);
    if (rowInfo) {
      console.log('medicine row width:', rowInfo.rowW, '| fields:');
      rowInfo.kids.forEach((k) => console.log(`    ${k.cls.padEnd(24)} w=${k.w} h=${k.h}`));
    }

    // Puter status text as the doctor sees it
    const puterTxt = await p.locator('#puter-status').first().innerText().catch(() => '(n/a)');
    console.log('Settings #puter-status shows:', JSON.stringify(puterTxt));

    await ctx.close();
  }
  await browser.close();
})();
