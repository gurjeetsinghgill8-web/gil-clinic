import re
import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import diet_plan_prompt
from src.ai_engine.provider_router import route_chat

prompt = diet_plan_prompt(
    patient_name="Ggd", age="25", gender="Male",
    weight="99", height="150", bmi="44.0",
    conditions="Hypertension", allergies="", goal="Weight loss",
    diet_type="Regular", meals_per_day="", restrictions="",
    target_calories="", protein_ratio="1.0",
)

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}
r = route_chat(settings, [prompt], feature="diet-plan", temp=0.3, max_tokens=4000)
text = r.get("text") or ""
err = r.get("error") or ""
print("ok:", bool(text), "| provider:", r.get("provider"), "| err:", err[:120])
if text:
    print("--- plan head ---")
    print(text[:1400].encode("ascii", "replace").decode())
    print("--- checks ---")
    print("GIL CLINIC present:", "GIL CLINIC" in text)
    print("reconfirm present:", "reconfirm" in text.lower())
    emojis = [c for c in text if 0x1F300 <= ord(c) <= 0x1FAFF]
    print("emojis count:", len(emojis))
    m = re.search(r"CALORIES:\s*(\d+)", text)
    print("CALORIES:", m.group(1) if m else "NOT FOUND")
    m2 = re.search(r"DEFICIT[:\s]*([\d\s-]+)", text)
    print("DEFICIT:", m2.group(1) if m2 else "NOT FOUND")
