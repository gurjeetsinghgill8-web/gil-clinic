import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import cme_prompt
from src.ai_engine.provider_router import route_chat

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}

topics = [
    ("heart failure 2026", ["esc 2026", "hfimpef", "improved ef"]),
    ("type 2 diabetes latest", ["ada 2025", "ada 2026", "weight loss", "glp-1"]),
    ("copd management update", ["gold 2025", "dupilumab", "ensifentrine", "verify"]),
    ("hypertension new guidelines", ["120-139", "elevated bp", "esc 2024"]),
]
for topic, keys in topics:
    print("=" * 60)
    print("TOPIC:", topic)
    r = route_chat(settings, [cme_prompt(topic)], feature="cme", temp=0.3, max_tokens=4000)
    text = r.get("text") or ""
    t = text.lower()
    hits = {k: (k in t) for k in keys}
    print("ok:", bool(text), "| provider:", r.get("provider"), "| checks:", hits)
    print("verify-disclaimer:", ("verify" in t) or ("latest" in t))
