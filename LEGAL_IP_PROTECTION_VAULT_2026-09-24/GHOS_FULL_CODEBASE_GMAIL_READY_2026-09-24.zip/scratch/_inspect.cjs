/**
 * Live dashboard ka TEXT-based deep inspection (screenshots ke bajaye, kyunki
 * output text me chahiye) + real feature test + JS error capture.
 */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const B = 'https://gillhopitalsoftware1.pythonanywhere.com';
const PIN = '5554';
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const out = [];
const say = (s) => { out.push(s); console.log(s); };

(async () => {
  const browser = await chromium.launch();
  const errors = [];
  const consoleErrs = [];
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const p = await ctx.newPage();
  p.setDefaultTimeout(45000);
  p.on('pageerror', (e) => errors.push(String(e && e.message ? e.message : e)));
  p.on('console', (m) => { if (m.type() === 'error') consoleErrs.push(m.text()); });

  await p.goto(B + '/opd/login', { waitUntil: 'domcontentloaded' });
  await p.locator('input[name="pin"]').fill(PIN);
  await p.locator('button[type="submit"]').first().click();
  await p.waitForSelector('text=New Prescription', { timeout: 45000 });
  await sleep(3000);

  say('=== 1. SIDEBAR (footer me BUILD stamp) ===');
  const sb = await p.locator('aside').innerText().catch(() => '(aside not found)');
  say(sb.trim());

  const stampEl = p.locator('#build-stamp').first();
  const stampText = await stampEl.innerText().catch(() => '(missing)');
  const stampColor = await stampEl.evaluate((e) => getComputedStyle(e).color).catch(() => '?');
  say(`\nBUILD-STAMP text: ${JSON.stringify(stampText)}   color: ${stampColor}`);
  const healthBuild = await p.evaluate(async () => {
    try { const r = await fetch('/health'); return (await r.json()).build; } catch (e) { return 'fetch-fail'; }
  });
  say(`/health build   : ${healthBuild}`);
  say(stampText.includes(healthBuild) ? 'OK  footer build == live build (naya code confirm)' : '!!  footer build MISMATCH');

  say('\n=== 2. DRUG BANK autocomplete (asli test: "ol" type karo) ===');
  await p.evaluate(() => { const m = document.getElementById('med-library-modal'); if (m) m.style.display = 'none'; });
  const nameInput = p.locator('#medicines-container .med-name').first();
  await nameInput.scrollIntoViewIfNeeded();
  await nameInput.click();
  await nameInput.fill('ol');
  await sleep(3500);
  const sugg = p.locator('#medicines-container .med-suggest').first();
  const suggVisible = await sugg.isVisible().catch(() => false);
  const suggText = await sugg.innerText().catch(() => '');
  say(`suggest box visible: ${suggVisible}`);
  say(`suggest content    : ${JSON.stringify(suggText.slice(0, 400))}`);

  if (suggVisible) {
    const items = await p.locator('#medicines-container .med-suggest-item').count();
    say(`suggest items      : ${items}`);
    if (items > 0) {
      const before = await p.locator('#medicines-container .med-row').first().evaluate((row) => ({
        name: row.querySelector('.med-name').value,
        dose: row.querySelector('.med-dose').value,
        freq: row.querySelector('.med-freq').value,
        timing: row.querySelector('.med-food').value,
        dur: row.querySelector('.med-duration').value,
      }));
      await p.locator('#medicines-container .med-suggest-item').first().click();
      await sleep(1200);
      const after = await p.locator('#medicines-container .med-row').first().evaluate((row) => ({
        name: row.querySelector('.med-name').value,
        dose: row.querySelector('.med-dose').value,
        freq: row.querySelector('.med-freq').value,
        timing: row.querySelector('.med-food').value,
        dur: row.querySelector('.med-duration').value,
      }));
      say(`AUTO-FILL before: ${JSON.stringify(before)}`);
      say(`AUTO-FILL after : ${JSON.stringify(after)}`);
      say(after.name ? 'OK  dropdown pick ne row auto-fill ki' : '!!  auto-fill nahi hui');
    }
  }

  say('\n=== 3. SETTINGS tab (AI Provider section) ===');
  await p.evaluate(() => { const m = document.getElementById('med-library-modal'); if (m) m.style.display = 'none'; });
  await p.locator('.nav-item[data-tab="settings"]').click({ force: true }).catch(() => {});
  await sleep(3000);
  await p.evaluate(() => { document.querySelectorAll('.tab-content').forEach(t => t.classList.remove('active')); const t = document.getElementById('tab-settings'); if (t) t.classList.add('active'); });
  await sleep(800);

  const settingsText = await p.locator('#tab-settings').innerText().catch(() => '(settings tab not found)');
  const aiStart = settingsText.indexOf('AI Provider');
  say(settingsText.slice(aiStart >= 0 ? aiStart : 0, (aiStart >= 0 ? aiStart : 0) + 2600));

  say('\n=== 4. Element presence/visibility ===');
  const checks = {
    'build-stamp visible': p.locator('#build-stamp').first(),
    'Naya Account banao button': p.locator('button:has-text("Naya Account banao")').first(),
    'Re-login button': p.locator('button:has-text("Re-login")').first(),
    'Connect Puter button': p.locator('button:has-text("Connect Puter")').first(),
    'Test button (deepseek)': p.locator('button[onclick="testAIKey(\'deepseek\')"]').first(),
    'DeepSeek ✅saved badge slot': p.locator('#key-badge-deepseek').first(),
    'PA whitelist warning box': p.locator('text=BYOK keys kaam NAHI karti').first(),
  };
  for (const [k, loc] of Object.entries(checks)) {
    const n = await loc.count().catch(() => 0);
    const vis = n ? await loc.isVisible().catch(() => false) : false;
    say(`  ${vis ? 'OK ' : (n ? '?? ' : '!! ')} ${k}  (count=${n}, visible=${vis})`);
  }

  say('\n=== 5. JS ERRORS ===');
  say('pageerror: ' + (errors.length ? JSON.stringify(errors, null, 2) : 'NONE'));
  say('console.error: ' + (consoleErrs.length ? JSON.stringify(consoleErrs.slice(0, 10), null, 2) : 'NONE'));

  fs.writeFileSync(path.join(__dirname, '_shots', 'inspect.txt'), out.join('\n'), 'utf8');
  await browser.close();
  console.log('\n(also saved to scratch/_shots/inspect.txt)');
})();
