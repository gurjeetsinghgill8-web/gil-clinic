import time

import requests

BASE = "http://localhost:8000"
s = requests.Session()
for _ in range(20):
    try:
        if s.get(BASE + "/health", timeout=5).status_code == 200:
            break
    except Exception:
        time.sleep(2)
r = s.post(BASE + "/opd/login", data={"pin": "5554"}, allow_redirects=False, timeout=30)
print("login:", r.status_code)

# Test 1: complaints only
r2 = s.post(BASE + "/opd/api/generate-diagnosis", json={
    "patient_name": "", "vitals": "", "complaints": "chest pain, sob lying down, sweating, urine kam",
    "doctor_medicines": "",
}, timeout=180)
d = r2.json()
print("T1 ok:", d.get("ok"))
print("T1 DIAGNOSIS:", (d.get("diagnosis") or d.get("error") or "")[:400].encode("ascii", "replace").decode())

# Test 2: nothing filled -> error
r3 = s.post(BASE + "/opd/api/generate-diagnosis", json={"patient_name": "", "vitals": "", "complaints": ""}, timeout=30)
print("T2:", r3.json())
