import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import cme_prompt
from src.ai_engine.provider_router import route_chat

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}

for topic in ["new ESC heart failure guidelines", "MI definition 2026 update"]:
    print("=" * 60)
    print("TOPIC:", topic)
    r = route_chat(settings, [cme_prompt(topic)], feature="cme", temp=0.3, max_tokens=4000)
    text = r.get("text") or ""
    print("ok:", bool(text), "| provider:", r.get("provider"), "| err:", (r.get("error") or "")[:80])
    if text:
        t = text.lower()
        print("mentions ESC 2026:", "esc 2026" in t or "esc 2025" in t)
        print("mentions 5th/universal def:", "5th universal" in t or "fifth universal" in t)
        print("mentions three clinical categories:", "three clinical" in t or "3 clinical" in t)
        print("mentions Type 1/2 MI (old):", "type 1" in t or "type 2" in t)
        print("mentions HFimpEF:", "hfimpef" in t or "improved ef" in t)
        print("mentions disclaimer:", "verify" in t)
        print("--- head ---")
        print(text[:600].encode("ascii", "replace").decode())
