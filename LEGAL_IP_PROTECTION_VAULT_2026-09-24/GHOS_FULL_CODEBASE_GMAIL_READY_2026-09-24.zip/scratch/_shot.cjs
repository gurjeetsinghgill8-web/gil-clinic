/** Live dashboard ke screenshots — doctor khud dekh sake is liye. */
const { chromium } = require('playwright');
const fs = require('fs');
const path = require('path');

const B = 'https://gillhopitalsoftware1.pythonanywhere.com';
const OUT = path.join(__dirname, '_shots');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
const closeModals = (p) => p.evaluate(() => {
  ['med-library-modal', 'med-library-form-modal'].forEach((id) => {
    const m = document.getElementById(id); if (m) m.style.display = 'none';
  });
});

(async () => {
  fs.mkdirSync(OUT, { recursive: true });
  const browser = await chromium.launch();
  const ctx = await browser.newContext({ viewport: { width: 1440, height: 1000 } });
  const p = await ctx.newPage();
  p.setDefaultTimeout(45000);

  await p.goto(B + '/opd/login', { waitUntil: 'domcontentloaded' });
  await p.locator('input[name="pin"]').fill('5554');
  await p.locator('button[type="submit"]').first().click();
  await p.waitForSelector('text=New Prescription', { timeout: 45000 });
  await sleep(3000);

  // 1. Dashboard + medicine row (fixed widths) + sidebar build stamp
  await p.locator('#medicines-container .med-row').first().scrollIntoViewIfNeeded();
  await sleep(500);
  await p.screenshot({ path: path.join(OUT, '1-medicine-row-FIXED.png') });

  // 2. Drug bank dropdown live (type "ol")
  const ni = p.locator('#medicines-container .med-name').first();
  await ni.click(); await ni.fill('ol'); await sleep(3000);
  await p.screenshot({ path: path.join(OUT, '2-drugbank-dropdown.png') });
  // pick first -> auto-fill
  const items = await p.locator('#medicines-container .med-suggest-item').count();
  if (items > 0) { await p.locator('#medicines-container .med-suggest-item').first().click(); await sleep(1200); }
  await p.screenshot({ path: path.join(OUT, '3-autofilled.png') });

  // 4. Medicine Library modal
  await closeModals(p);
  const lib = p.locator('button:has-text("Library")').first();
  if (await lib.count()) { await lib.click({ force: true }); await sleep(2800); await p.screenshot({ path: path.join(OUT, '4-medicine-library.png') }); }
  await closeModals(p);

  // 5. Settings tab -> AI Provider (Puter buttons + key badges + Test buttons + warnings)
  await p.locator('.nav-item[data-tab="settings"]').click({ force: true }).catch(() => {});
  await sleep(2500);
  await p.evaluate(() => {
    document.querySelectorAll('.tab-content').forEach((t) => t.classList.remove('active'));
    const t = document.getElementById('tab-settings'); if (t) t.classList.add('active');
  });
  await sleep(600);
  await p.screenshot({ path: path.join(OUT, '5-settings-ai-provider.png'), fullPage: false });
  const keys = p.locator('text=My own API keys').first();
  if (await keys.count()) { await keys.scrollIntoViewIfNeeded(); await sleep(800); await p.screenshot({ path: path.join(OUT, '6-settings-byok-keys.png') }); }
  const puter = p.locator('text=Puter — Free AI').first();
  if (await puter.count()) { await puter.scrollIntoViewIfNeeded(); await sleep(800); await p.screenshot({ path: path.join(OUT, '7-settings-puter.png') }); }

  const stamp = await p.locator('#build-stamp').innerText().catch(() => '?');
  console.log('BUILD stamp:', stamp);
  console.log('screenshots ->', OUT);
  fs.readdirSync(OUT).filter((f) => f.endsWith('.png')).forEach((f) => console.log('   ', f));

  await browser.close();
})();
