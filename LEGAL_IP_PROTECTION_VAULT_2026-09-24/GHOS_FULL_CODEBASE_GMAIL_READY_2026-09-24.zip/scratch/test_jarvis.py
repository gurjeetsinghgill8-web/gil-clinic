import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import cme_chat_prompt
from src.ai_engine.provider_router import route_chat

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}
r = route_chat(
    settings,
    [cme_chat_prompt("heart failure guidelines", "", "Sir HFimpEF ka matlab kya hai aur iska ilaj kaise kare?")],
    feature="cme-chat", temp=0.3, max_tokens=1500,
)
text = r.get("text") or ""
print("ok:", bool(text), "| provider:", r.get("provider"))
print(text.encode("ascii", "replace").decode()[:600])
t = text
print("--- checks ---")
print("no markdown asterisks:", "**" not in t and "#" not in t)
print("no emojis:", not any(0x1F300 <= ord(c) <= 0x1FAFF for c in t))
print("Hindi present:", any(0x0900 <= ord(c) <= 0x097F for c in t))
print("disclaimer/verify:", "verify" in t.lower())
print("short lines:", max(len(l) for l in t.splitlines()) < 200)
