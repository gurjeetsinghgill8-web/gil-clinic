import sys

sys.path.insert(0, ".")
sys.path.insert(0, "src")

from src.ai_engine.prompts import cme_chat_prompt
from src.ai_engine.provider_router import route_chat

settings = {"ai_mode": "auto", "doctor_id": "clinic_default", "ai_model": ""}

cases = [
    ("What is HFimpEF and how is it treated?", "en"),
    ("HFimpEF ka matlab kya hai aur ilaj kya hai?", "hi"),
]
for q, lang in cases:
    r = route_chat(settings, [cme_chat_prompt("heart failure", "", q, lang=lang)], feature="cme-chat", temp=0.3, max_tokens=1200)
    text = r.get("text") or ""
    hindi = any(0x0900 <= ord(c) <= 0x097F for c in text)
    hinglish = bool(__import__("re").search(r"\b(kya|ka matlab|hai|ilaj)\b", text, __import__("re").I))
    print("lang:", lang, "| devanagari:", hindi, "| hinglish words:", hinglish)
    print("   ", text[:160].encode("ascii", "replace").decode())
