---
file_id: "1102"
module_name: "Monitoring"
version: "2.0"
status: "Draft"
phase: "Phase 11 — DevOps"
dependencies: ["1100_DEPLOYMENT.md"]
related_files: ["1101_CICD.md", "1103_LOGGING.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "monitoring", "prometheus", "grafana", "alerts", "apm"]
---

# GHOS — Monitoring

> **"If it moves, measure it. If it breaks, alert on it. If it's critical, page someone."**
> The GHOS monitoring stack provides complete observability — metrics, traces, alerts, uptime, and on-call — so the team always knows the health of the system and can respond before users notice issues.

---

## 1. MONITORING PHILOSOPHY

GHOS uses the **four golden signals** of monitoring:

1. **Latency** — how long does it take to respond?
2. **Traffic** — how many requests are we handling?
3. **Errors** — how many requests are failing?
4. **Saturation** — how close to capacity are we?

**Architecture overview:**

```
┌─────────────────────────────────────────────────────┐
│                   Services                           │
│  API ──► /metrics  │  Worker ──► /metrics            │
│  WS ──► /metrics   │  PostgreSQL ──► postgres_exporter│
│  Redis ──► redis_exporter  │  Node ──► node_exporter │
└─────────────────────┬───────────────────────────────┘
                      │  scrape (every 15s)
┌─────────────────────v───────────────────────────────┐
│                    Prometheus                         │
│  ┌────────────────────────────────────────────────┐  │
│  │  Rule evaluation ──► AlertManager             │  │
│  │  Recording rules for aggregations              │  │
│  └────────────────────────────────────────────────┘  │
└──┬──────────────────────────────────┬───────────────┘
   │                                  │
   v                                  v
┌────────────┐                 ┌──────────────┐
│  Grafana   │                 │ AlertManager  │
│  Dashboards│                 │ ┌──────────┐  │
│  + Explore │                 │ │ Routes   │  │
└────────────┘                 │ │ Inhibit  │  │
                               │ │ Silence  │  │
                               │ └────┬─────┘  │
                               └──────┼─────────┘
                                      │
                          ┌───────────v────────────┐
                          │  Notification Channels  │
                          │  Slack │ Email │ Pager  │
                          │  WhatsApp │ Webhook    │
                          └────────────────────────┘
```

---

## 2. METRICS CATALOG

### 2.1 Application Metrics (Instrumented in Code)

| Metric Name                        | Type        | Labels                             | Description                            |
|------------------------------------|-------------|------------------------------------|----------------------------------------|
| `api_request_duration_seconds`     | Histogram   | method, endpoint, status           | API request latency (0.1/0.5/1/2/5)    |
| `http_requests_total`              | Counter     | method, endpoint, status_code      | Total HTTP requests                    |
| `http_requests_in_flight`          | Gauge       | method                             | Currently active requests              |
| `queue_enqueue_total`              | Counter     | department, queue_type             | Total appointments enqueued            |
| `queue_call_total`                 | Counter     | department                         | Total patients called                  |
| `queue_complete_total`             | Counter     | department                         | Total appointments completed           |
| `queue_depth`                      | Gauge       | department                         | Current queue depth per department     |
| `queue_wait_duration_seconds`      | Histogram   | department                         | Patient wait time in queue             |
| `websocket_connections`            | Gauge       | department                         | Current active WebSocket connections   |
| `active_users`                     | Gauge       | role                               | Active users in last 5 min             |
| `db_query_duration_seconds`        | Histogram   | query_name, operation              | Database query execution time          |
| `db_connections_active`            | Gauge       | pool_name                          | Active database connections            |
| `db_connections_idle`              | Gauge       | pool_name                          | Idle database connections              |
| `cache_hit_ratio`                  | Gauge       | cache_name                         | Cache hit percentage (0-1)             |
| `cache_memory_usage_bytes`         | Gauge       | cache_name                         | Memory usage of cache                  |
| `worker_tasks_completed_total`     | Counter     | task_name, status                  | Celery tasks completed                 |
| `worker_tasks_running`             | Gauge       | task_name                          | Currently executing tasks              |
| `worker_queue_depth`               | Gauge       | queue_name                         | Celery task queue depth                |
| `auth_login_attempts_total`        | Counter     | status (success/failure)           | Authentication attempts                |
| `push_notifications_sent_total`    | Counter     | platform (fcm/apns)                | Push notifications sent                |

### 2.2 Infrastructure Metrics (Exporters)

| Metric Name                    | Exporter            | Description                        |
|-------------------------------|---------------------|------------------------------------|
| `node_cpu_seconds_total`      | node_exporter       | CPU usage per mode                 |
| `node_memory_MemTotal_bytes`  | node_exporter       | Total memory                       |
| `node_memory_MemAvailable_bytes` | node_exporter    | Available memory                   |
| `node_disk_io_time_seconds_total`| node_exporter    | Disk I/O time                     |
| `node_network_receive_bytes_total`| node_exporter   | Network received bytes             |
| `pg_stat_activity_count`      | postgres_exporter   | Active database sessions           |
| `pg_stat_database_tup_fetched`| postgres_exporter   | Rows fetched                       |
| `redis_memory_used_bytes`     | redis_exporter      | Redis memory usage                 |
| `redis_keyspace_hits_total`   | redis_exporter      | Cache hits                         |

### 2.3 PromQL Queries (Key Dashboards)

**API p99 Latency (last 5 min):**
```promql
histogram_quantile(0.99,
  sum(rate(api_request_duration_seconds_bucket[5m])) by (le, endpoint)
)
```

**Error Rate (%):**
```promql
sum(rate(http_requests_total{status_code=~"5.."}[5m]))
/
sum(rate(http_requests_total[5m]))
* 100
```

**Queue Depth (by department):**
```promql
queue_depth{department=~".+"}
```

**Active Users (5 min window):**
```promql
avg_over_time(active_users[5m])
```

**Cache Hit Ratio:**
```promql
rate(cache_hit_total[5m])
/
(rate(cache_hit_total[5m]) + rate(cache_miss_total[5m]))
```

**DB Connection Utilization:**
```promql
db_connections_active / db_connections_max * 100
```

**Worker Queue Depth:**
```promql
worker_queue_depth{queue_name=~".+"}
```

---

## 3. GRAFANA DASHBOARDS

### 3.1 Dashboard 1 — System Overview

**Purpose:** Infrastructure health at a glance. Useful for SRE and on-call engineers.

| Panel                     | Metric                                 | Visualization   |
|---------------------------|----------------------------------------|-----------------|
| CPU Usage                 | `100 - (avg by(instance)(rate(node_cpu_seconds_total{mode="idle"}[5m])) * 100)` | Time series     |
| Memory Usage              | `(1 - node_memory_MemAvailable_bytes / node_memory_MemTotal_bytes) * 100`       | Time series     |
| Disk Usage                | `(node_filesystem_size_bytes - node_filesystem_free_bytes) / node_filesystem_size_bytes * 100` | Gauge + table |
| Network I/O               | `rate(node_network_receive_bytes_total[5m])` + `rate(node_network_transmit_bytes_total[5m])` | Time series |
| Container CPU/Memory      | `sum(container_memory_usage_bytes) by (name)` / `sum(container_cpu_usage_seconds_total) by (name)` | Table |
| Pod Status                | `kube_pod_status_phase{phase="Running"}` / `kube_pod_status_phase{phase="Pending"}` | Stat + alert |

### 3.2 Dashboard 2 — API Performance

**Purpose:** Detailed API latency, throughput, and error analysis. Useful for backend developers.

| Panel                     | Metric                                 | Visualization   |
|---------------------------|----------------------------------------|-----------------|
| Request Rate (RPS)        | `sum(rate(http_requests_total[5m]))`   | Time series     |
| Error Rate                | `sum(rate(http_requests_total{status_code=~"5.."}[5m])) / sum(rate(http_requests_total[5m])) * 100` | Time series + threshold line |
| p50/p95/p99 Latency       | `histogram_quantile(0.50/0.95/0.99, ...)` | Three time series, colored |
| Status Breakdown          | `sum(rate(http_requests_total[5m])) by (status_code)` | Stacked bar |
| Top 5 Slow Endpoints      | `topk(5, avg by(endpoint)(api_request_duration_seconds_sum / api_request_duration_seconds_count))` | Table |
| Request Heatmap           | `sum(rate(http_requests_total[5m])) by (endpoint, status)` | Heatmap |

### 3.3 Dashboard 3 — Queue Operations

**Purpose:** Real-time queue status, patient flow, and wait times. Useful for clinic operations.

| Panel                     | Metric                                 | Visualization   |
|---------------------------|----------------------------------------|-----------------|
| Queue Depth by Dept       | `queue_depth`                          | Bar chart       |
| Enqueue Rate              | `rate(queue_enqueue_total[5m])` by (department) | Time series |
| Call Rate                 | `rate(queue_call_total[5m])` by (department)    | Time series |
| Avg Wait Time             | `histogram_quantile(0.5/0.95, queue_wait_duration_seconds_bucket)` | Time series |
| Queue Flow (enqueue vs complete) | `rate(queue_enqueue_total[5m]) - rate(queue_complete_total[5m])` | Time series |
| WebSocket Connections     | `websocket_connections`                 | Gauge + stat   |

### 3.4 Dashboard 4 — Business Metrics

**Purpose:** High-level business KPIs. Useful for product managers and leadership.

| Panel                     | Metric                                 | Visualization   |
|---------------------------|----------------------------------------|-----------------|
| Daily Appointments        | `increase(queue_enqueue_total[24h])`   | Stat           |
| Daily Completions         | `increase(queue_complete_total[24h])`  | Stat           |
| Tokens by Department (24h)| `increase(queue_enqueue_total[24h]) by (department)` | Pie chart |
| Peak Hours                | `avg by(hour)(rate(queue_enqueue_total[1h]))` | Time series |
| Appointment Success Rate  | `increase(queue_complete_total[24h]) / increase(queue_enqueue_total[24h]) * 100` | Gauge |
| Active Clinics (24h)      | `count by(clinic_id)(active_users > 0)` | Stat |

### 3.5 Dashboard 5 — User Activity

**Purpose:** Understand user engagement patterns. Useful for UX and product teams.

| Panel                     | Metric                                 | Visualization   |
|---------------------------|----------------------------------------|-----------------|
| Active Users (now)        | `active_users`                         | Stat           |
| Active Users by Role      | `avg(active_users) by (role)`          | Bar chart      |
| New Users (24h)           | `increase(auth_login_attempts_total{status="first_login"}[24h])` | Stat |
| Session Duration          | Average from Grafana Explore (derived)  | Time series    |
| Peak Concurrent Users     | `max_over_time(active_users[24h])`     | Stat           |

---

## 4. ALERT RULES

### 4.1 AlertManager Configuration (`alertmanager.yml`)

```yaml
global:
  resolve_timeout: 5m
  slack_api_url: "https://hooks.slack.com/services/T00/B00/xxx"

route:
  receiver: "default"
  group_by: ["alertname", "severity", "service"]
  group_wait: 30s
  group_interval: 5m
  repeat_interval: 4h
  routes:
    - match:
        severity: critical
      receiver: "pagerduty-critical"
      repeat_interval: 15m
    - match:
        severity: warning
      receiver: "slack-warning"
      repeat_interval: 4h
    - match:
        severity: info
      receiver: "slack-info"
      repeat_interval: 24h

receivers:
  - name: "pagerduty-critical"
    pagerduty_configs:
      - routing_key: "${PAGERDUTY_ROUTING_KEY}"
        severity: critical
        description: "{{ .GroupLabels.alertname }} - {{ .GroupLabels.service }}"
  
  - name: "slack-warning"
    slack_configs:
      - channel: "#alerts-warning"
        title: "{{ .GroupLabels.alertname }}"
        text: "{{ .GroupLabels | toJson }}"
        color: "warning"
  
  - name: "slack-info"
    slack_configs:
      - channel: "#alerts-info"
        title: "{{ .GroupLabels.alertname }}"
        text: "{{ .GroupLabels | toJson }}"
        color: "good"

inhibit_rules:
  - source_match:
      severity: critical
    target_match:
      severity: warning
    equal: ["alertname", "service"]
```

### 4.2 Prometheus Rule Definitions (`prometheus-rules.yml`)

```yaml
groups:
  - name: ghos-api-alerts
    interval: 30s
    rules:
      - alert: APIHighErrorRate
        expr: |
          sum(rate(http_requests_total{status_code=~"5.."}[5m]))
          /
          sum(rate(http_requests_total[5m]))
          * 100 > 1
        for: 2m
        labels:
          severity: critical
          service: api
        annotations:
          summary: "API error rate {{ $value | humanizePercentage }}"
          description: "API 5xx error rate is {{ $value | humanizePercentage }} (threshold: 1%)"

      - alert: APIHighLatency
        expr: |
          histogram_quantile(0.99,
            sum(rate(api_request_duration_seconds_bucket[5m])) by (le)
          ) > 2
        for: 5m
        labels:
          severity: warning
          service: api
        annotations:
          summary: "API p99 latency {{ $value | humanizeDuration }}"
          description: "API p99 latency is {{ $value | humanizeDuration }} (threshold: 2s)"

      - alert: ServiceDown
        expr: up == 0
        for: 1m
        labels:
          severity: critical
        annotations:
          summary: "Service {{ $labels.instance }} is down"
          description: "{{ $labels.instance }} has been unreachable for 1 minute"

  - name: ghos-queue-alerts
    interval: 30s
    rules:
      - alert: QueueDepthWarning
        expr: queue_depth > 50
        for: 5m
        labels:
          severity: warning
          service: queue
        annotations:
          summary: "Queue depth high"
          description: "Queue for {{ $labels.department }} is {{ $value }} (warning at 50)"

      - alert: QueueDepthCritical
        expr: queue_depth > 100
        for: 2m
        labels:
          severity: critical
          service: queue
        annotations:
          summary: "Queue depth critical"
          description: "Queue for {{ $labels.department }} is {{ $value }} (critical at 100)"

  - name: ghos-db-alerts
    interval: 30s
    rules:
      - alert: DBConnectionsHigh
        expr: (sum(db_connections_active) by (pool_name) / 200) * 100 > 80
        for: 5m
        labels:
          severity: warning
          service: database
        annotations:
          summary: "Database connections at {{ $value | humanizePercentage }}"
          description: "Database connection pool is {{ $value | humanizePercentage }} utilized"

      - alert: RedisMemoryHigh
        expr: (redis_memory_used_bytes / redis_config_maxmemory) * 100 > 80
        for: 5m
        labels:
          severity: warning
          service: redis
        annotations:
          summary: "Redis memory usage at {{ $value | humanizePercentage }}"
          description: "Redis is using {{ $value | humanizePercentage }} of maxmemory"

  - name: ghos-cert-alerts
    interval: 6h
    rules:
      - alert: CertificateExpiring
        expr: |
          (certmanager_certificate_expiration_timestamp_seconds - time()) / 86400 < 30
        labels:
          severity: warning
          service: infrastructure
        annotations:
          summary: "SSL certificate expires in {{ $value | humanizeDuration }}"
          description: "Certificate {{ $labels.name }} expires in {{ $value | humanizeDuration }} days"

  - name: ghos-worker-alerts
    interval: 30s
    rules:
      - alert: WorkerQueueBacklog
        expr: worker_queue_depth > 100
        for: 10m
        labels:
          severity: warning
          service: worker
        annotations:
          summary: "Worker queue backlog: {{ $value }} tasks"
          description: "Worker queue {{ $labels.queue_name }} has {{ $value }} pending tasks"
```

### 4.3 Alert Severity Matrix

| Severity | Response Time | Channel     | Example                              |
|----------|---------------|-------------|--------------------------------------|
| S1       | 5 min         | PagerDuty   | API down, DB unavailable, 5xx > 5%   |
| S2       | 15 min        | PagerDuty   | p99 > 5s, queue > 100, errors > 2%   |
| S3       | 1 hr          | Slack       | Queue > 50, Redis > 80%, cert < 30d  |
| S4       | Next business day | Slack   | Disk > 70%, minor warnings           |

---

## 5. APM — SENTRY

### 5.1 Configuration

```python
import sentry_sdk
from sentry_sdk.integrations.fastapi import FastApiIntegration
from sentry_sdk.integrations.sqlalchemy import SqlalchemyIntegration
from sentry_sdk.integrations.redis import RedisIntegration

sentry_sdk.init(
    dsn=settings.SENTRY_DSN,
    environment=settings.environment,
    traces_sample_rate=0.1,          # 10% sampling for performance traces
    profiles_sample_rate=0.1,        # 10% sampling for profiling
    sample_rate=1.0,                  # 100% of errors captured
    send_default_pii=False,           # Never send PII to Sentry
    max_breadcrumbs=50,
    integrations=[
        FastApiIntegration(),
        SqlalchemyIntegration(),
        RedisIntegration(),
    ],
    before_send=lambda event, hint: sanitize_sentry_event(event),
)
```

### 5.2 Error Filtering

```python
def sanitize_sentry_event(event):
    """Remove PII and filter noisy events."""
    # Remove sensitive data from request body
    if "request" in event and "data" in event["request"]:
        data = event["request"]["data"]
        if data:
            for field in ["password", "token", "aadhaar", "phone"]:
                if field in data:
                    data[field] = "***"
    
    # Ignore specific errors in staging/dev
    allowed_environments = ["production", "staging"]
    if event.get("environment") not in allowed_environments:
        return None
    
    return event
```

### 5.3 Performance Tracing Transactions

Sentry captures these transaction types:
- **API requests** — every endpoint call (sampled at 10%)
- **Database queries** — slow queries > 500ms (sampled at 100%)
- **Celery tasks** — long-running tasks > 10s (sampled at 100%)
- **External API calls** — SMS, email, payment gateway (sampled at 100%)

---

## 6. UPTIME MONITORING

### 6.1 External Health Checks

| Check Type        | Interval | Regions                  | Endpoint           |
|-------------------|----------|--------------------------|--------------------|
| HTTP health       | 60s      | Mumbai, Bangalore, Delhi | https://api.ghos.in/health |
| TCP health        | 60s      | Mumbai, Bangalore, Delhi | api.ghos.in:443    |
| SSL certificate   | 6h       | Global                   | api.ghos.in:443    |

**Tool:** Better Uptime or Checkly (free tier supports 3 regions).

### 6.2 Synthetic Transactions

Every 5 minutes, run a full patient flow simulation:

```
1. Login (POST /auth/login) → verify JWT
2. View queue (GET /queue/status/opd) → verify queue data
3. Create token (POST /queue/enqueue) → verify token number
4. Call patient (POST /queue/call/{token}) → verify display update
5. Complete appointment (POST /queue/complete/{token}) → verify completion
6. Check logout (POST /auth/logout) → verify session invalidated
```

**Tool:** Playwright scripts deployed on Checkly or Grafana Synthetic Monitoring.

### 6.3 Status Page

**URL:** `https://status.ghos.in`

Components monitored:
- API Service
- WebSocket Service
- Worker Service
- PostgreSQL Database
- Redis Cache
- Authentication System
- Queue Engine
- Billing Engine
- SMS/Email Notifications

**Tool:** Checkly Status Page or open-source (Upptime / Statping).

---

## 7. ON-CALL & INCIDENT RESPONSE

### 7.1 Escalation Policy

| Level | Role            | Response Time | Action                              |
|-------|-----------------|---------------|-------------------------------------|
| L1    | On-call engineer| S1: 5 min     | Acknowledge, triage, mitigate       |
| L2    | Senior engineer | S1: 15 min    | Deep diagnosis, code fix            |
| L3    | Engineering lead| S1: 30 min    | Cross-team coordination, hotfix     |
| Management | CTO     | S1: 1 hr      | Stakeholder communication           |

### 7.2 Schedule

- **Primary:** Rotating weekly (Mon 9 AM → Mon 9 AM)
- **Secondary:** Rotating weekly (offset by 12 hours)
- **Shadow:** New engineers paired with primary for training
- **Follow-the-sun:** Not applicable at current scale (single timezone)

### 7.3 Incident Response Runbook

**Step 1 — Acknowledge**
- Alert triggers PagerDuty push notification + phone call
- Click "Acknowledge" in PagerDuty (within 5 min for S1)

**Step 2 — Assess**
```
# Check current status
curl -s https://api.ghos.in/health
kubectl get pods --all-namespaces | grep -v Running
kubectl logs -n ghos-api deployment/api --tail=100

# Check metrics in Grafana (open System Overview dashboard)
# Check errors in Sentry (filter: last 15 min, environment: production)
```

**Step 3 — Mitigate**
- **If API down:** Check deployment status, rollback if recent deploy
- **If DB down:** Check RDS console, failover to standby
- **If queue backlog:** Scale worker: `kubectl scale deployment/worker --replicas=10`
- **If memory leak:** Restart pod: `kubectl rollout restart deployment/api`

**Step 4 — Communicate**
```
Slack #incidents:
:red-circle: [S1] API High Error Rate
Detected: 14:23 UTC
Impact: Users unable to create tokens
Action: Rolled back to previous version v1.5.1
Status: Monitoring
ETA: 14:45 UTC
```

**Step 5 — Postmortem**
- Root cause analysis within 48 hours
- Action items tracked in GitHub Issues
- Blameless postmortem culture
