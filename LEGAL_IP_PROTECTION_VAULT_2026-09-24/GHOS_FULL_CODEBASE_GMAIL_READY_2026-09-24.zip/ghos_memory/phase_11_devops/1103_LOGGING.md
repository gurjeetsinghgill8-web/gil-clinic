---
file_id: "1103"
module_name: "Logging"
version: "2.0"
status: "Draft"
phase: "Phase 11 — DevOps"
dependencies: ["1102_MONITORING.md"]
related_files: ["1100_DEPLOYMENT.md", "1101_CICD.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "logging", "centralized", "loki", "structured-logging"]
---

# GHOS — Centralized Logging

> **"Every log line tells a story. Make sure it's a story you can search, filter, and alert on."**
> GHOS uses structured JSON logging everywhere — every service, every environment, every log line. Centralized in Loki, queryable with LogQL, and integrated with Grafana dashboards.

---

## 1. LOGGING PHILOSOPHY

**Structured JSON logging** is the only format allowed in production. No raw console.log, no print statements, no unstructured text.

```
Bad:   "User 42 logged in successfully from clinic 7"
Good:  {"timestamp": "2026-07-09T10:30:00Z", "level": "info", "service": "api", "user_id": 42, "hospital_id": 7, "message": "User logged in"}
```

**Core principles:**
- **Machine-parseable** — every field has a consistent name and type across all services
- **Centralized** — logs flow from every service to a single queryable store (Loki)
- **Queryable** — any engineer can find relevant logs in under 30 seconds using LogQL
- **Privacy-safe** — PII is redacted at the source, never written to disk in raw form
- **No console.log in production** — cannot be emphasized enough

---

## 2. STANDARD LOG ENVELOPE

Every log line emitted by any GHOS service follows this exact JSON schema:

```json
{
  "timestamp": "2026-07-09T10:30:00.123456Z",
  "level": "info",
  "service": "api",
  "environment": "production",
  "trace_id": "abc123def456",
  "span_id": "789ghi012jkl",
  "user_id": 42,
  "hospital_id": 7,
  "request_id": "req-abc123",
  "message": "Appointment created successfully",
  "extra": {
    "appointment_id": 1001,
    "department": "opd",
    "doctor_id": 15,
    "duration_ms": 45
  },
  "error": null,
  "stack_trace": null,
  "duration_ms": 45
}
```

### 2.1 Field Definitions

| Field          | Type   | Required | Description                                    |
|----------------|--------|----------|------------------------------------------------|
| timestamp      | string | Yes      | RFC 3339 with microsecond precision            |
| level          | string | Yes      | debug, info, warning, error, fatal             |
| service        | string | Yes      | Service name: api, worker, websocket, frontend |
| environment    | string | Yes      | development, staging, production               |
| trace_id       | string | No       | OpenTelemetry trace ID (same across services)  |
| span_id        | string | No       | OpenTelemetry span ID                          |
| user_id        | int    | No       | GHOS user ID (if authenticated)                |
| hospital_id    | int    | No       | GHOS hospital/clinic ID (if context exists)    |
| request_id     | string | No       | Unique request identifier (correlation)        |
| message        | string | Yes      | Human-readable description of the event        |
| extra          | object | No       | Event-specific key-value metadata              |
| error          | string | No       | Error message (only on error/fatal levels)     |
| stack_trace    | string | No       | Full traceback (only on fatal level)           |
| duration_ms    | int    | No       | Operation duration in milliseconds             |

---

## 3. LOG LEVELS

| Level   | Numeric | Usage                                                  | Production Filter |
|---------|---------|--------------------------------------------------------|-------------------|
| DEBUG   | 10      | Development-only: SQL queries, variable dumps          | Dropped           |
| INFO    | 20      | Normal operations: user actions, state transitions     | Kept              |
| WARNING | 30      | Unexpected but handled: rate limit hit, retry          | Kept              |
| ERROR   | 40      | Failed operation: DB error, external API failure       | Kept              |
| FATAL   | 50      | Service degradation: startup failure, config error     | Kept              |

**Production:** Log level is `INFO`. DEBUG logs are stripped before shipping.

---

## 4. SERVICE-SIDE LOGGING (Python — structlog)

### 4.1 Configuration

```python
import structlog
import logging
from datetime import datetime, timezone

structlog.configure(
    processors=[
        structlog.contextvars.merge_contextvars,
        structlog.stdlib.filter_by_level,
        structlog.stdlib.add_logger_name,
        structlog.stdlib.add_log_level,
        structlog.stdlib.PositionalArgumentsFormatter(),
        structlog.processors.TimeStamper(fmt="iso", utc=True, key="timestamp"),
        structlog.processors.StackInfoRenderer(),
        structlog.processors.format_exc_info,
        structlog.processors.UnicodeDecoder(),
        add_ghos_context,
        structlog.processors.JSONRenderer(),
    ],
    wrapper_class=structlog.stdlib.BoundLogger,
    context_class=dict,
    logger_factory=structlog.stdlib.LoggerFactory(),
    cache_logger_on_first_use=True,
)

def add_ghos_context(logger, method_name, event_dict):
    """Add GHOS-specific context fields to every log entry."""
    event_dict["service"] = settings.SERVICE_NAME
    event_dict["environment"] = settings.environment
    
    # Add user context if available from request
    from ghos.core.context import ghosc
    if ghosc.user_id:
        event_dict["user_id"] = ghosc.user_id
    if ghosc.hospital_id:
        event_dict["hospital_id"] = ghosc.hospital_id
    if ghosc.request_id:
        event_dict["request_id"] = ghosc.request_id
    
    # Add trace context if available
    if ghosc.trace_id:
        event_dict["trace_id"] = ghosc.trace_id
    if ghosc.span_id:
        event_dict["span_id"] = ghosc.span_id
    
    return event_dict

# Usage
logger = structlog.get_logger()
logger.info("appointment.created", appointment_id=1001, department="opd", doctor_id=15)
logger.error("payment.failed", error="insufficient_balance", amount=500, transaction_id="txn_abc")
```

### 4.2 FastAPI LoggingMiddleware

```python
import time
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
import structlog

logger = structlog.get_logger()

class RequestLoggingMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        start_time = time.monotonic()
        request_id = str(uuid.uuid4())[:8]
        
        # Attach request context
        from ghos.core.context import ghosc
        ghosc.request_id = request_id
        ghosc.trace_id = request.headers.get("X-Trace-ID")
        
        # Log incoming request
        logger.info("request.started",
            method=request.method,
            path=request.url.path,
            query_params=str(request.query_params),
            client_ip=request.client.host,
            user_agent=request.headers.get("user-agent", ""),
        )
        
        try:
            response = await call_next(request)
            duration_ms = int((time.monotonic() - start_time) * 1000)
            
            # Log completed request
            logger.info("request.completed",
                method=request.method,
                path=request.url.path,
                status_code=response.status_code,
                duration_ms=duration_ms,
            )
            
            return response
            
        except Exception as exc:
            duration_ms = int((time.monotonic() - start_time) * 1000)
            logger.error("request.failed",
                method=request.method,
                path=request.url.path,
                duration_ms=duration_ms,
                error=str(exc),
                stack_trace=traceback.format_exc(),
            )
            raise
```

### 4.3 SQL Query Logging

```python
import logging
import time
from sqlalchemy import event

# Log slow queries (> 100ms)
query_logger = structlog.get_logger("sql")

@event.listens_for(engine, "before_cursor_execute")
def before_cursor_execute(conn, cursor, statement, parameters, context, executemany):
    conn.info["query_start_time"] = time.monotonic()

@event.listens_for(engine, "after_cursor_execute")
def after_cursor_execute(conn, cursor, statement, parameters, context, executemany):
    total = int((time.monotonic() - conn.info["query_start_time"]) * 1000)
    
    # Truncate query for logging
    max_len = 500
    truncated = statement[:max_len] + "..." if len(statement) > max_len else statement
    
    log_data = {
        "query": truncated,
        "duration_ms": total,
        "row_count": cursor.rowcount,
    }
    
    if total > 100:  # Slow query threshold
        query_logger.warning("slow.query", **log_data)
    else:
        query_logger.debug("query.executed", **log_data)
```

### 4.4 Celery Task Logging

```python
from celery.signals import task_prerun, task_postrun, task_failure
import structlog

logger = structlog.get_logger()

@task_prerun.connect
def task_prerun_handler(task_id, task, args, kwargs, **kw):
    logger.info("task.started",
        task_name=task.name,
        task_id=task_id,
        args=str(args)[:200],
        kwargs=str(kwargs)[:200],
    )

@task_postrun.connect
def task_postrun_handler(task_id, task, args, kwargs, retval, state, **kw):
    logger.info("task.completed",
        task_name=task.name,
        task_id=task_id,
        state=state,
    )

@task_failure.connect
def task_failure_handler(task_id, exception, traceback, einfo, **kw):
    logger.error("task.failed",
        task_id=task_id,
        error=str(exception),
        stack_trace=str(traceback),
    )
```

---

## 5. CLIENT-SIDE LOGGING (TypeScript/React)

### 5.1 Structured Logging on Frontend

```typescript
// logger.ts
type LogLevel = "debug" | "info" | "warning" | "error";

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  service: string;
  message: string;
  extra?: Record<string, unknown>;
  error?: string;
}

const LOG_LEVELS: Record<LogLevel, number> = {
  debug: 10,
  info: 20,
  warning: 30,
  error: 40,
};

class Logger {
  private level: LogLevel = "info";
  
  constructor(private service: string) {}
  
  private log(level: LogLevel, message: string, extra?: Record<string, unknown>, error?: Error) {
    const entry: LogEntry = {
      timestamp: new Date().toISOString(),
      level,
      service: this.service,
      message,
      extra: {
        ...extra,
        user_agent: navigator.userAgent,
        url: window.location.href,
      },
    };
    
    if (error) {
      entry.error = error.message;
    }
    
    // Send to backend logging endpoint (batched)
    this.sendToBackend(entry);
    
    // Also forward to Sentry for error tracking
    if (level === "error") {
      Sentry.captureException(error || new Error(message), { extra });
    } else if (level === "warning") {
      Sentry.captureMessage(message, "warning");
    }
    
    // Preserve console for development
    if (process.env.NODE_ENV === "development") {
      const consoleFn = level === "error" ? console.error : level === "warning" ? console.warn : console.log;
      consoleFn(`[${level.toUpperCase()}] ${message}`, extra || "");
    }
  }
  
  private sendToBackend(entry: LogEntry) {
    // Batch and send to POST /api/v1/logs
    // With minimal overhead (send every 5s or every 50 entries)
    logQueue.push(entry);
    if (logQueue.length >= 50) {
      this.flush();
    }
    if (!flushTimer) {
      flushTimer = setTimeout(() => this.flush(), 5000);
    }
  }
  
  private flush() {
    if (logQueue.length === 0) return;
    const batch = logQueue.splice(0, logQueue.length);
    navigator.sendBeacon("/api/v1/logs", JSON.stringify(batch));
    flushTimer = null;
  }
  
  debug(message: string, extra?: Record<string, unknown>) { this.log("debug", message, extra); }
  info(message: string, extra?: Record<string, unknown>) { this.log("info", message, extra); }
  warning(message: string, extra?: Record<string, unknown>) { this.log("warning", message, extra); }
  error(message: string, error?: Error, extra?: Record<string, unknown>) { this.log("error", message, extra, error); }
}

export const logger = new Logger("frontend");
```

### 5.2 Axios Interceptor for Network Logging

```typescript
import axios from "axios";
import { logger } from "./logger";

axios.interceptors.request.use((config) => {
  config.metadata = { startTime: Date.now() };
  logger.debug("network.request", {
    method: config.method,
    url: config.url,
    headers: sanitizeHeaders(config.headers),
  });
  return config;
});

axios.interceptors.response.use(
  (response) => {
    const duration = Date.now() - response.config.metadata.startTime;
    logger.info("network.response", {
      method: response.config.method,
      url: response.config.url,
      status: response.status,
      duration_ms: duration,
    });
    return response;
  },
  (error) => {
    const duration = Date.now() - error.config.metadata.startTime;
    logger.error("network.error", error, {
      method: error.config.method,
      url: error.config.url,
      status: error.response?.status,
      duration_ms: duration,
    });
    return Promise.reject(error);
  }
);
```

### 5.3 React Error Boundary

```tsx
import React from "react";
import { logger } from "./logger";

interface Props {
  children: React.ReactNode;
  fallback?: React.ReactNode;
}

interface State {
  hasError: boolean;
}

class ErrorBoundary extends React.Component<Props, State> {
  constructor(props: Props) {
    super(props);
    this.state = { hasError: false };
  }
  
  static getDerivedStateFromError(): State {
    return { hasError: true };
  }
  
  componentDidCatch(error: Error, errorInfo: React.ErrorInfo) {
    logger.error("react.error_boundary", error, {
      component_stack: errorInfo.componentStack,
    });
  }
  
  render() {
    if (this.state.hasError) {
      return this.props.fallback || <h1>Something went wrong.</h1>;
    }
    return this.props.children;
  }
}
```

---

## 6. CENTRALIZED STORAGE — LOKI

### 6.1 Architecture

```
┌──────────┐    ┌───────────┐    ┌────────────────┐
│ Services │───▶│ Promtail  │───▶│     Loki       │
│ (pods)   │    │ (DaemonSet)│    │                │
└──────────┘    └───────────┘    │ ┌────────────┐  │
                                  │ │ Ingester   │  │
┌──────────┐    ┌───────────┐    │ │ Querier    │  │
│ Host Logs│───▶│ Promtail  │───▶│ │ Compactor  │  │
│ (VPS)    │    │ (systemd) │    │ └────────────┘  │
└──────────┘    └───────────┘    └────────────────┘
                                       │
                                ┌──────v──────┐
                                │   Grafana   │
                                │ (Explore)   │
                                └─────────────┘
```

### 6.2 Retention Policy

| Data        | Storage   | Retention | Query Performance |
|-------------|-----------|-----------|-------------------|
| Hot logs    | Loki (SSD)| 30 days   | Full-text search  |
| Cold logs   | S3 bucket | 1 year    | Slower, infrequent queries |
| Archive     | S3 Glacier| 7 years   | Compliance only (manual restore) |

**Loki retention configuration:**
```yaml
# loki-config.yml
auth_enabled: false

server:
  http_listen_port: 3100

ingester:
  chunk_idle_period: 30m
  chunk_retain_period: 1m
  max_chunk_age: 1h
  lifecycler:
    ring:
      kvstore:
        store: inmemory
      replication_factor: 1

storage_config:
  boltdb_shipper:
    active_index_directory: /data/loki/index
    cache_location: /data/loki/cache
    shared_store: s3
  aws:
    s3: s3://ap-south-1/ghos-logs
    s3forcepathstyle: true

compactor:
  working_directory: /data/loki/compactor
  shared_store: s3
  retention_enabled: true

limits_config:
  retention_period: 744h  # 31 days hot
  max_query_lookback: 8760h  # 1 year (cold from S3)
  reject_old_samples: true
  reject_old_samples_max_age: 168h

table_manager:
  retention_deletes_enabled: true
  retention_period: 744h

schema_config:
  configs:
    - from: 2026-01-01
      store: boltdb-shipper
      object_store: s3
      schema: v11
      index:
        prefix: ghos_index_
        period: 24h
```

### 6.3 Promtail Configuration (`promtail-config.yml`)

```yaml
# promtail-config.yml
server:
  http_listen_port: 9080
  grpc_listen_port: 0

positions:
  filename: /var/log/positions.yaml

clients:
  - url: http://loki:3100/loki/api/v1/push

scrape_configs:
  - job_name: kubernetes-pods
    pipeline_stages:
      - json:
          expressions:
            level: level
            service: service
            user_id: user_id
            hospital_id: hospital_id
      - labels:
          level:
          service:
          user_id:
          hospital_id:
    kubernetes_sd_configs:
      - role: pod
    relabel_configs:
      - source_labels: [__meta_kubernetes_pod_label_app]
        target_label: app
      - source_labels: [__meta_kubernetes_namespace]
        target_label: namespace
      - action: replace
        replacement: /var/log/pods/*$1*/*.log
        separator: /
        source_labels:
          - __meta_kubernetes_pod_uid
          - __meta_kubernetes_pod_container_name
        target_label: __path__
  
  - job_name: system
    static_configs:
      - targets: [localhost]
        labels:
          job: system
          service: host
          __path__: /var/log/*.log
```

---

## 7. COMMON LOGQL QUERIES

### 7.1 Operational Queries

**Errors by service (last hour):**
```logql
sum by(service) (count_over_time({level="error"} | logfmt [1h]))
```

**Top 5 slowest API requests:**
```logql
topk(5, max by(path) ({service="api"} | logfmt | duration_ms > 1000 | unwrap duration_ms [1h]))
```

**User activity audit trail (specific user):**
```logql
{user_id="42"} | logfmt
```

**Deployment diff — compare error rates pre/post deploy:**
```logql
# Pre-deploy (30 min before)
sum(rate({service="api", level="error"} | logfmt [30m] offset 1h))
/
sum(rate({service="api"} | logfmt [30m] offset 1h))

# Post-deploy (30 min after deploy time)
sum(rate({service="api", level="error"} | logfmt [30m]))
/
sum(rate({service="api"} | logfmt [30m]))
```

### 7.2 Business Queries

**Active clinics in last 15 min:**
```logql
count by(hospital_id) ({service="api"} | logfmt | message=~"request.started|request.completed" | __error__="" | hospital_id>0 | last_over_time(timestamp[15m]))
```

**Failed payments by reason:**
```logql
sum by(error) ({service="api", level="error"} | logfmt | message="payment.failed" | error=~".+" | unwrap error [24h])
```

### 7.3 Debug Queries

**All logs for a specific request_id:**
```logql
{request_id="req-abc123"} | logfmt
```

**Slow DB queries (> 500ms):**
```logql
{service="api"} | logfmt | message="slow.query" | duration_ms > 500
```

---

## 8. PRIVACY & REDACTION

### 8.1 PII Redaction Pipeline

Redaction happens at the source (in the application), before logs leave the service:

```python
import re
from typing import Any

# Patterns to redact
PII_PATTERNS = {
    "phone": re.compile(r"(\+?91)?[6-9]\d{9}"),
    "email": re.compile(r"[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}"),
    "aadhaar": re.compile(r"\d{4}\s?\d{4}\s?\d{4}"),
    "pan": re.compile(r"[A-Z]{5}[0-9]{4}[A-Z]"),
    "ip_address": re.compile(r"\b(?:\d{1,3}\.){3}\d{1,3}\b"),
}

def redact_pii(value: str) -> str:
    """Redact PII fields from log messages."""
    for name, pattern in PII_PATTERNS.items():
        value = pattern.sub(f"[REDACTED_{name.upper()}]", value)
    return value

def sanitize_log_dict(data: dict[str, Any], depth: int = 0) -> dict[str, Any]:
    """Recursively sanitize a log dictionary."""
    if depth > 10:
        return {"[TRUNCATED]": True}
    
    sanitized = {}
    for key, value in data.items():
        # Never log these fields
        if key.lower() in ("password", "token", "secret", "authorization", "cookie"):
            sanitized[key] = "[REDACTED]"
        elif isinstance(value, str):
            sanitized[key] = redact_pii(value)
        elif isinstance(value, dict):
            sanitized[key] = sanitize_log_dict(value, depth + 1)
        else:
            sanitized[key] = value
    return sanitized
```

### 8.2 Never Log These

- Passwords, tokens, or session secrets
- Full Aadhaar numbers (even masked, log only last 4 digits if absolutely needed)
- Patient medical records (diagnoses, prescriptions — log only IDs)
- API keys or cloud credentials
- Credit card numbers or bank account details

### 8.3 Audit Trail (Exception)

For compliance (DPDP Act 2023), a **separate audit log** may record user actions with limited PII, but this log:
- Lives in a dedicated, access-controlled database table (not in Loki)
- Is encrypted at rest
- Has its own retention policy (7 years)
- Is only queried through the admin panel with explicit justification

---

## 9. ALERTING ON LOGS

Log-based alerts complement metric-based alerts for scenarios that metrics miss:

| Alert Rule                  | LogQL Query                                                     | Severity | Action           |
|-----------------------------|----------------------------------------------------------------|----------|------------------|
| Error rate spike            | `sum(rate({level="error"} | logfmt [5m])) > 50`               | S1       | PagerDuty        |
| Auth failure burst          | `sum(rate({message="auth.failed"} | logfmt [5m])) > 20`       | S2       | Slack + review   |
| Critical SQL errors         | `count_over_time({level="error", message=~".*SQL.*|.*database.*"} | logfmt [5m]) > 5` | S2 | Slack           |
| Repeated crash loops        | `count_over_time({message=~".*restarting.*|.*crash.*"} | logfmt [30m]) > 3` | S1 | PagerDuty    |
| Payment failures (silent)   | `count_over_time({message="payment.failed"} | logfmt [1h]) > 10` | S3       | Slack daily digest |
| Security: multiple 401s     | `count_over_time({status_code="401"} | logfmt [5m]) > 50`     | S2       | Slack + IP block |

**Log-based alert configuration (**AlertManager + Loki rule):
```yaml
groups:
  - name: ghos-log-alerts
    rules:
      - alert: LogAuthFailureBurst
        expr: |
          sum(rate(
            {service="api"} |= "auth.failed" | logfmt
            [5m]
          )) > 20
        for: 2m
        labels:
          severity: s2
        annotations:
          summary: "Authentication failure burst"
          description: "{{ $value }} auth failures per second in last 5 min"
```

---

## 10. DEPLOYMENT & INTEGRATION

### 10.1 Docker Compose (Stage 1)

```yaml
services:
  loki:
    image: grafana/loki:3.0.0
    ports:
      - "3100:3100"
    volumes:
      - ./loki-config.yml:/etc/loki/config.yml:ro
      - loki-data:/data/loki
    command: -config.file=/etc/loki/config.yml

  promtail:
    image: grafana/promtail:3.0.0
    volumes:
      - /var/log:/var/log:ro
      - /var/lib/docker/containers:/var/lib/docker/containers:ro
      - ./promtail-config.yml:/etc/promtail/config.yml:ro
    command: -config.file=/etc/promtail/config.yml

volumes:
  loki-data:
```

### 10.2 Kubernetes (Stage 3)

Deploy via Helm:
```bash
# Loki
helm repo add grafana https://grafana.github.io/helm-charts
helm upgrade --install loki grafana/loki \
  --namespace ghos-monitoring \
  --set persistence.enabled=true \
  --set persistence.size=50Gi \
  --set config.storage_config.aws.s3="s3://ap-south-1/ghos-logs"

# Promtail
helm upgrade --install promtail grafana/promtail \
  --namespace ghos-monitoring \
  --set config.logLevel=info
```

### 10.3 Migration from ELK (if applicable)

If replacing an existing ELK stack:
1. Run both Loki and ELK in parallel for 1 week
2. Validate LogQL parity with existing Kibana queries
3. Migrate dashboards from Kibana to Grafana
4. Decommission ELK after validation
5. Cost savings: ~60% lower storage costs with Loki vs Elasticsearch
