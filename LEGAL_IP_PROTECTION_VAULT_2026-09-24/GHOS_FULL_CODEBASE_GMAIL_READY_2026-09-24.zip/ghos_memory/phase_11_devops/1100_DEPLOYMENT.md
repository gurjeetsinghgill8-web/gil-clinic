---
file_id: "1100"
module_name: "Deployment Architecture"
version: "2.0"
status: "Draft"
phase: "Phase 11 — DevOps"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["1101_CICD.md", "1102_MONITORING.md", "1103_LOGGING.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "deployment", "infrastructure", "hosting", "terraform", "kubernetes"]
---

# GHOS — Deployment Architecture

> **"Ship with confidence. Deploy with zero downtime. Recover in minutes."**
> The GHOS deployment strategy spans three stages of infrastructure maturity — from a single VPS serving 20 clinics to a multi-region Kubernetes cluster serving thousands. Every stage shares the same core application stack but grows in resilience, scalability, and operational complexity.

---

## 1. DEPLOYMENT PHILOSOPHY

GHOS follows a **stage-appropriate architecture** — choose the deployment model that matches your current clinic count, and migrate up as you grow:

```
Stage 1 (1-100 clinics)    ->  Single VPS, Docker Compose
Stage 2 (100-1000 clinics) ->  Managed cloud services, auto-scaled containers
Stage 3 (1000+ clinics)    ->  Kubernetes, multi-region, full auto-scaling
```

**Key principles:**
- **Immutable infrastructure** — never patch a running server; redeploy from a fresh image
- **Infrastructure as Code** — every resource is defined in Terraform/Pulumi and version-controlled
- **Environment parity** — dev, staging, and production run identical stacks (only scale differs)
- **Zero-downtime deploys** — rolling updates or blue-green swaps, never `docker stop && docker start`
- **Cost-awareness** — each stage has a clear budget ceiling; overspend is a design smell

---

## 2. STAGE 1 — SINGLE VPS (Docker Compose)

Target: 1-100 clinics, 20-2000 daily users. Budget: Rs 500-1,500/mo.

### 2.1 Architecture

```
INTERNET
   |
+--v---------+
|   Nginx    |  Port 443 (TLS 1.3), reverse proxy, static file serving
+--+---------+
   |
+--v--------------------------------------+
|            Docker Compose               |
|  +--------+  +--------+  +-----------+  |
|  |  API   |  | Worker |  | WebSocket |  |
|  | (uvicorn)| | (Celery)| | (FastAPI) |  |
|  +----+---+  +----+---+  +-----+-----+  |
|       |           |            |         |
|  +----v-----------v------------v-----+  |
|  |            Redis                   |  |
|  |  Celery broker + session store     |  |
|  +------------------+-----------------+  |
|                     |                    |
|  +------------------v-----------------+  |
|  |          PostgreSQL                |  |
|  |  GHOS main database (10 GB data)   |  |
|  +------------------------------------+  |
+------------------------------------------+
```

### 2.2 Services Breakdown

| Service     | Image                        | CPU  | RAM    | Replicas | Notes                        |
|-------------|------------------------------|------|--------|----------|------------------------------|
| nginx       | nginx:1.25-alpine            | 0.1  | 128 MB | 1        | Reverse proxy, SSL, static   |
| api         | ghos-api:latest              | 1.0  | 512 MB | 2        | FastAPI, uvicorn workers      |
| worker      | ghos-worker:latest           | 0.5  | 512 MB | 1        | Celery, queue processing     |
| websocket   | ghos-ws:latest               | 0.5  | 256 MB | 1        | WebSocket server             |
| redis       | redis:7-alpine               | 0.5  | 256 MB | 1        | Queue broker + session store |
| postgres    | postgres:16-alpine           | 1.0  | 1 GB   | 1        | Primary database              |
| cadvisor    | google/cadvisor:latest       | 0.2  | 128 MB | 1        | Container metrics            |

**Total resource estimate:** ~3.8 GB RAM, ~3.8 CPU shares — fits comfortably on a 4 GB / 2 vCPU VPS.

**Throughput:** ~20 concurrent clinics = ~400 daily appointments, ~40 API req/s peak.

### 2.3 docker-compose.yml (Core Structure)

```yaml
version: "3.9"
services:
  postgres:
    image: postgres:16-alpine
    volumes:
      - pgdata:/var/lib/postgresql/data
      - ./backup:/backup
    environment:
      POSTGRES_DB: ghos
      POSTGRES_USER: ghos_app
      POSTGRES_PASSWORD: ${DB_PASSWORD}
    healthcheck:
      test: ["CMD-SHELL", "pg_isready -U ghos_app -d ghos"]
      interval: 10s
      timeout: 5s
      retries: 5
    deploy:
      resources:
        limits:
          memory: 1G
          cpus: "1.0"

  redis:
    image: redis:7-alpine
    command: redis-server --requirepass ${REDIS_PASSWORD} --maxmemory 256mb --maxmemory-policy allkeys-lru
    volumes:
      - redisdata:/data
    healthcheck:
      test: ["CMD", "redis-cli", "ping"]
      interval: 10s
      timeout: 3s
      retries: 5

  api:
    build:
      context: .
      dockerfile: Dockerfile.api
    depends_on:
      postgres: { condition: service_healthy }
      redis: { condition: service_healthy }
    environment:
      DATABASE_URL: postgresql+asyncpg://ghos_app:${DB_PASSWORD}@postgres:5432/ghos
      REDIS_URL: redis://:${REDIS_PASSWORD}@redis:6379/0
    healthcheck:
      test: ["CMD", "curl", "-f", "http://localhost:8000/health"]
      interval: 30s
      timeout: 10s
      retries: 3
    deploy:
      replicas: 2
      resources:
        limits:
          memory: 512M
          cpus: "1.0"

  nginx:
    image: nginx:1.25-alpine
    volumes:
      - ./nginx/conf.d:/etc/nginx/conf.d:ro
      - ./nginx/ssl:/etc/nginx/ssl:ro
      - staticdata:/static:ro
    ports:
      - "80:80"
      - "443:443"
    depends_on:
      - api
      - websocket

volumes:
  pgdata:
  redisdata:
  staticdata:
```

### 2.4 Backup Strategy

- **Daily:** `pg_dump -Fc ghos > /backup/ghos_$(date +%Y%m%d).dump` via cron in the postgres container
- **Off-site:** Upload dump to S3-compatible storage (MinIO, Backblaze B2, or AWS S3) using `aws s3 cp` or `rclone`
- **Retention:** 7 daily backups on-host, 30 daily backups in S3, 12 monthly backups
- **Point-in-time recovery:** WAL archiving via `archive_command` to S3 (optional in Stage 1)
- **Restore test:** Automated restore to a staging database every Sunday at 2 AM

### 2.5 Backup Cron (Crontab on Host)

```bash
# Daily database dump at 1 AM
0 1 * * * docker exec ghos_postgres_1 pg_dump -Fc -U ghos_app ghos > /backup/ghos_$(date +\%Y\%m\%d).dump

# Upload to S3 at 2 AM
0 2 * * * aws s3 cp /backup/ghos_$(date -d "yesterday" +\%Y\%m\%d).dump s3://ghos-backups/stage1/

# Prune local backups older than 7 days
0 3 * * * find /backup -name "ghos_*.dump" -mtime +7 -delete
```

### 2.6 Monitoring (Stage 1)

- **cAdvisor** for container resource metrics (CPU, memory, network, disk)
- **Prometheus** scrapes cAdvisor and the API's `/metrics` endpoint
- **Grafana** on a sub-path (`/grafana`) with dashboards for system overview
- **AlertManager** sends email/Slack alerts via webhook
- **Uptime Robot** or **Better Uptime** for external health checks (free tier)

### 2.7 Security Hardening (VPS)

- SSH key-only access, disable password auth
- Fail2ban for SSH brute force protection
- UFW firewall: allow 22, 80, 443 only
- Automatic security updates via `unattended-upgrades` (apt)
- Docker daemon in rootless mode
- Regular container image scanning with Trivy (weekly cron)

### 2.8 Cost Breakdown

| Item              | Estimated Cost (Rs/mo) |
|-------------------|------------------------|
| VPS (4 GB, 2 vCPU)| 500 - 1,500            |
| Domain (.in)      | 800/yr (≈ 67/mo)       |
| SSL (Let's Encrypt)| Free                   |
| S3-compatible backup| 100 - 300             |
| Monitoring (Uptime)| Free                   |
| **Total**         | **Rs 667 - 1,867/mo**  |

---

## 3. STAGE 2 — MANAGED CLOUD SERVICES

Target: 100-1,000 clinics, 2,000-20,000 daily users. Budget: Rs 10,000-50,000/mo.

### 3.1 Architecture

```
INTERNET
   |
+--v---------+
| CloudFront |  CDN, WAF, DDoS protection
+--+---------+
   |
+--v--------+
| ALB / NLB |  TLS termination, routing
+--+--------+
   |
+--v------------------------------------------------------+
|                    ECS Fargate (2-10 tasks)              |
|  +-----------------+  +-------------------+             |
|  | API Service     |  | Worker Service    |             |
|  | Auto-scaled     |  | Scaled by queue   |             |
|  | 2-10 tasks      |  | depth (1-5 tasks) |             |
|  +--------+--------+  +--------+----------+             |
+-----------|-------------------|-------------------------+
            |                   |
+-----------v-------------------v-------------------------+
|                    Private Subnet                        |
|  +------------------+  +----------------------------+   |
|  | ElastiCache Redis |  | RDS PostgreSQL (Multi-AZ) |   |
|  | cache.t3.small    |  | db.t3.medium             |   |
|  | 1.37 GB, 2 nodes   |  | 4 GB, 2 vCPU, Multi-AZ  |   |
|  +------------------+  +----------------------------+   |
+--------------------------------------------------------+
```

### 3.2 Managed Services

| Service          | AWS Offering              | Spec                        | Cost (Rs/mo) |
|------------------|---------------------------|-----------------------------|--------------|
| PostgreSQL       | RDS PostgreSQL 16         | db.t3.medium, 4 GB, 20 GB gp3| 6,000        |
| Redis            | ElastiCache for Redis 7   | cache.t3.small, 1.37 GB     | 3,000        |
| Compute (API)    | ECS Fargate               | 2-10 tasks, 1 vCPU, 2 GB   | 5,000-15,000 |
| Compute (Worker) | ECS Fargate               | 1-5 tasks, 0.5 vCPU, 1 GB  | 2,000-5,000  |
| CDN              | CloudFront                | 1 TB transfer               | 1,000        |
| Load Balancer    | ALB                       | 1 GB/hr data                | 1,500        |
| NAT Gateway      | VPC NAT Gateway           | Per AZ                      | 1,500        |
| S3 (backups)     | S3 Standard               | 50 GB                       | 200          |
| **Total**        |                           |                             | **20,000-33,200** |

### 3.3 High Availability

- **RDS Multi-AZ** — automatic failover to standby in a different AZ (60s RTO, <1 min RPO)
- **ElastiCache Multi-AZ** — replica in second AZ, automatic failover
- **ECS tasks spread** — minimum 2 tasks across 2 AZs, never all in one AZ
- **ALB** — routes traffic to healthy targets only; health check every 10s
- **CloudFront** — multi-edge location delivery; origin failover to secondary region (optional)

### 3.4 RDS Configuration for GHOS

```sql
-- PostgreSQL configuration optimized for GHOS workloads
ALTER SYSTEM SET max_connections = 200;           -- 100 clinics x ~2 connection per service
ALTER SYSTEM SET shared_buffers = '1GB';           -- 25% of instance RAM
ALTER SYSTEM SET effective_cache_size = '3GB';      -- 75% of instance RAM
ALTER SYSTEM SET work_mem = '16MB';                 -- 16 MB per sort/hash operation
ALTER SYSTEM SET maintenance_work_mem = '256MB';    -- For VACUUM and index rebuilds
ALTER SYSTEM SET random_page_cost = 1.1;            -- SSD-optimized (default 4.0 is HDD)
ALTER SYSTEM SET effective_io_concurrency = 200;    -- SSD-optimized
ALTER SYSTEM SET wal_buffers = '16MB';              -- Write-ahead log buffer
ALTER SYSTEM SET max_worker_processes = 8;          -- Parallel query workers
ALTER SYSTEM SET max_parallel_workers_per_gather = 4;
ALTER SYSTEM SET max_parallel_workers = 8;
ALTER SYSTEM SET checkpoint_completion_target = 0.9; -- Spread checkpoints over full interval
```

### 3.5 Connection Pooling (PgBouncer)

Each ECS task runs a sidecar PgBouncer container:

```ini
[databases]
ghos = host=rds-endpoint.aws.com port=5432 dbname=ghos

[pgbouncer]
listen_addr = 0.0.0.0
listen_port = 6432
auth_type = scram-sha-256
auth_file = /etc/pgbouncer/userlist.txt
pool_mode = transaction
max_client_conn = 200
default_pool_size = 25
reserve_pool_size = 10
reserve_pool_timeout = 3.0
server_idle_timeout = 300
```

### 3.6 Backup & Disaster Recovery

- **Automated backups** — RDS automated backups (35 day retention)
- **Manual snapshots** — daily snapshot before deploy, retained 7 days
- **Cross-region backup** — copy snapshot to us-west-2 for DR (weekly)
- **pgBackRest** — optional for more advanced backup management (parallel, incremental)
- **RTO:** 15-30 minutes (failover to standby + latest snapshot restore)
- **RPO:** < 1 minute (synchronous replication to Multi-AZ standby)

---

## 4. STAGE 3 — KUBERNETES (EKS)

Target: 1,000+ clinics, 20,000+ daily users. Budget: Rs 50,000+/mo.

### 4.1 Architecture

```
INTERNET
   |
+--v---------+
| CloudFront |  CDN, WAF, edge caching
+--+---------+
   |
+--v---------+
| ALB Ingress|  SSL termination, path-based routing, sticky sessions
+--+---------+
   |
+--v--------------------------------------------+
|              EKS Cluster                       |
|  +--------+  +--------+  +-----------------+  |
|  | API    |  | Worker |  | WebSocket       |  |
|  | HPA    |  | HPA    |  | HPA             |  |
|  | 5-20   |  | 2-10   |  | 2-5 pods        |  |
|  +----+---+  +----+---+  +-------+---------+  |
|       |           |              |             |
|  +----v-----------v--------------v---------+  |
|  |         Redis (ElastiCache)            |  |
|  +------------------+---------------------+  |
|                     |                        |
|  +------------------v---------------------+  |
|  |      RDS PostgreSQL (Multi-AZ)         |  |
|  |      + pgBouncer sidecar               |  |
|  +----------------------------------------+  |
+-----------------------------------------------+
```

### 4.2 EKS Cluster Specifications

| Component          | Configuration                                |
|-------------------|----------------------------------------------|
| Cluster size      | 3-20 nodes (auto-scaled)                     |
| Node type         | t3.medium (2 vCPU, 4 GB) as default          |
| Node groups       | 2: system (t3.small) + application (t3.medium)|
| Karpenter         | Provisioner for fast pod-driven scaling       |
| Kubernetes version| 1.28+ (always 2 versions within upstream)    |
| VPC CNI           | AWS VPC CNI for native pod networking        |
| Storage           | EBS gp3 CSI driver for PVCs                   |

### 4.3 Key Kubernetes Resources

**Namespace layout:**
- `ghos-api` — API service, worker, websocket
- `ghos-data` — PostgreSQL, Redis (if self-hosted)
- `ghos-infra` — Ingress Controller, cert-manager, ExternalDNS, monitoring
- `ghos-system` — Cluster autoscaler, Karpenter, metrics server

**HPA Configuration (API service):**
```yaml
apiVersion: autoscaling/v2
kind: HorizontalPodAutoscaler
metadata:
  name: api-hpa
  namespace: ghos-api
spec:
  scaleTargetRef:
    apiVersion: apps/v1
    kind: Deployment
    name: api
  minReplicas: 5
  maxReplicas: 20
  metrics:
  - type: Resource
    resource:
      name: cpu
      target:
        type: Utilization
        averageUtilization: 70
  - type: Resource
    resource:
      name: memory
      target:
        type: Utilization
        averageUtilization: 80
  - type: Pods
    pods:
      metric:
        name: http_requests_per_second
      target:
        type: AverageValue
        averageValue: 100
  behavior:
    scaleDown:
      stabilizationWindowSeconds: 300
      policies:
      - type: Percent
        value: 10
        periodSeconds: 60
    scaleUp:
      stabilizationWindowSeconds: 0
      policies:
      - type: Percent
        value: 100
        periodSeconds: 15
```

**Pod Disruption Budget:**
```yaml
apiVersion: policy/v1
kind: PodDisruptionBudget
metadata:
  name: api-pdb
  namespace: ghos-api
spec:
  minAvailable: 3
  selector:
    matchLabels:
      app: api
```

### 4.4 cert-manager + Let's Encrypt

```yaml
apiVersion: cert-manager.io/v1
kind: ClusterIssuer
metadata:
  name: letsencrypt-prod
spec:
  acme:
    server: https://acme-v02.api.letsencrypt.org/directory
    email: ops@ghos.in
    privateKeySecretRef:
      name: letsencrypt-prod-account-key
    solvers:
    - selector:
        dnsZones:
        - "ghos.in"
      dns01:
        route53:
          region: ap-south-1
          hostedZoneID: Z1234567890
---
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: ghos-ingress
  namespace: ghos-api
  annotations:
    kubernetes.io/ingress.class: alb
    alb.ingress.kubernetes.io/scheme: internet-facing
    alb.ingress.kubernetes.io/certificate-arn: arn:aws:acm:ap-south-1:xxx:certificate/xxx
    alb.ingress.kubernetes.io/ssl-policy: ELBSecurityPolicy-TLS13-1-2-2021-06
    alb.ingress.kubernetes.io/healthcheck-path: /health
    alb.ingress.kubernetes.io/listen-ports: '[{"HTTP":80,"HTTPS": 443}]'
spec:
  rules:
  - host: api.ghos.in
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: api
            port:
              number: 80
  - host: ws.ghos.in
    http:
      paths:
      - path: /
        pathType: Prefix
        backend:
          service:
            name: websocket
            port:
              number: 80
```

### 4.5 Networking

| Resource           | Purpose                                        |
|--------------------|------------------------------------------------|
| VPC                | 10.0.0.0/16 with public (10.0.1.0/24) and private (10.0.2.0/24) subnets |
| NAT Gateway        | Outbound internet for private subnet resources  |
| Security Groups    | Per-service SG: API allows 443 from ALB, Redis allows 6379 from API only |
| VPC Endpoints      | S3 and DynamoDB Gateway Endpoints (no NAT charge) |
| VPN                | WireGuard for admin SSH/RDP access (no public bastion) |
| WAF                | Rate limiting (100 req/min/IP), SQL injection mitigation, XSS blocking |

**Security Group Rules:**

| SG Name            | Inbound                                | Outbound      |
|--------------------|----------------------------------------|---------------|
| api-sg             | 443 from ALB, 8000 from admin VPN      | All outbound  |
| redis-sg           | 6379 from api-sg, worker-sg            | All outbound  |
| rds-sg             | 5432 from api-sg, worker-sg, pgbouncer | All outbound  |
| websocket-sg       | 443 from ALB, 8001 from admin VPN      | All outbound  |
| admin-vpn-sg       | 51820 from trusted IPs (WireGuard)     | All outbound  |

### 4.6 Infrastructure as Code (Terraform)

**Directory structure:**
```
terraform/
├── modules/
│   ├── vpc/
│   │   ├── main.tf
│   │   ├── variables.tf
│   │   └── outputs.tf
│   ├── rds/
│   ├── redis/
│   ├── eks/
│   └── monitoring/
├── environments/
│   ├── dev/
│   │   ├── main.tf
│   │   ├── terraform.tfvars
│   │   └── backend.tf
│   ├── staging/
│   └── prod/
└── backend.tf
```

**State management:** S3 bucket with DynamoDB locking:
```hcl
terraform {
  backend "s3" {
    bucket         = "ghos-terraform-state"
    key            = "env:/prod/terraform.tfstate"
    region         = "ap-south-1"
    dynamodb_table = "ghos-terraform-locks"
    encrypt        = true
  }
}
```

### 4.7 Cost Breakdown (Stage 3)

| Component              | Estimated Cost (Rs/mo) |
|------------------------|------------------------|
| EKS cluster (control plane)| 5,000              |
| EC2 nodes (10 x t3.medium)| 25,000              |
| RDS (db.r6g.large Multi-AZ)| 15,000              |
| ElastiCache (cache.r6g.large)| 10,000           |
| ALB + NAT Gateway      | 4,000                 |
| CloudFront (2 TB)      | 2,000                 |
| S3 + backups           | 1,000                 |
| Monitoring (Grafana Cloud)| 2,000              |
| **Total**              | **Rs 64,000+/mo**     |

---

## 5. DOMAIN & SSL

### 5.1 DNS Configuration

| Record   | Type  | Value                          | TTL     |
|----------|-------|--------------------------------|---------|
| ghos.in  | A     | <server-ip> (Stage 1) or ALB (Stage 2/3) | 300s |
| api.ghos.in | CNAME | <alb-dns>.amazonaws.com        | 300s    |
| ws.ghos.in  | CNAME | <alb-dns>.amazonaws.com        | 300s    |
| *.ghos.in   | CNAME | <cloudfront-dns>               | 300s    |

### 5.2 Wildcard SSL via Let's Encrypt

```bash
# Initial issuance via DNS challenge (Route53)
certbot certonly \
  --dns-route53 \
  --domain "*.ghos.in" \
  --domain "ghos.in" \
  --email ops@ghos.in \
  --agree-tos \
  --non-interactive

# Auto-renewal (cron: daily at 3 AM)
0 3 * * * certbot renew --quiet --deploy-hook "systemctl reload nginx"
```

### 5.3 Security Headers

```nginx
add_header Strict-Transport-Security "max-age=63072000; includeSubDomains; preload" always;
add_header X-Content-Type-Options "nosniff" always;
add_header X-Frame-Options "DENY" always;
add_header X-XSS-Protection "1; mode=block" always;
add_header Referrer-Policy "strict-origin-when-cross-origin" always;
add_header Permissions-Policy "camera=(), microphone=(), geolocation=()" always;
```

---

## 6. CI/CD INTEGRATION

### 6.1 GitHub Actions Deploy to EKS

```yaml
  - name: Deploy to EKS
    run: |
      aws eks update-kubeconfig --region ap-south-1 --name ghos-prod
      kubectl set image deployment/api api=${{ env.ECR_REGISTRY }}/ghos-api:${{ env.IMAGE_TAG }}
      kubectl rollout status deployment/api --namespace=ghos-api --timeout=5m
```

### 6.2 Blue-Green Deployment (EKS)

Blue-green is managed via Kubernetes Service label selectors:

```yaml
# Blue service (current production)
apiVersion: v1
kind: Service
metadata:
  name: api
  namespace: ghos-api
spec:
  selector:
    app: api
    version: blue
  ports:
    - port: 80
      targetPort: 8000
---
# Green deployment (new version)
apiVersion: apps/v1
kind: Deployment
metadata:
  name: api-green
  namespace: ghos-api
spec:
  replicas: 5
  selector:
    matchLabels:
      app: api
      version: green
  template:
    metadata:
      labels:
        app: api
        version: green
    spec:
      containers:
      - name: api
        image: ${ECR_REGISTRY}/ghos-api:${IMAGE_TAG}
---
# Switch: update service selector from version=blue to version=green
# kubectl patch service api -p '{"spec":{"selector":{"version":"green"}}}'
```

### 6.3 Canary Releases (Critical Services)

For payments and auth services, deploy canary with 10% traffic:

```yaml
apiVersion: networking.k8s.io/v1
kind: Ingress
metadata:
  name: api-canary
  annotations:
    nginx.ingress.kubernetes.io/canary: "true"
    nginx.ingress.kubernetes.io/canary-weight: "10"
spec:
  rules:
  - host: api.ghos.in
    http:
      paths:
      - path: /api/v1/payments
        pathType: Prefix
        backend:
          service:
            name: api-canary
            port:
              number: 80
```

---

## 7. PROVISIONING WORKFLOW (Stage 3 Example)

```
1. Developer commits terraform change to infrastructure/ repo
2. GitHub Actions runs terraform plan
3. Plan is reviewed by team lead
4. Merge to main -> terraform apply (auto)
5. EKS cluster is provisioned/updated (15-20 min)
6. Flux/ArgoCD picks up changes and syncs Kubernetes manifests
7. cert-manager provisions SSL certificates
8. ExternalDNS updates Route53 records
9. Monitoring stack (kube-prometheus-stack) is installed via Helm
10. Team validates and performs smoke tests
```

---

## 8. DISASTER RECOVERY

| Scenario                   | RTO       | RPO       | Action                                    |
|----------------------------|-----------|-----------|-------------------------------------------|
| Single pod crash           | < 30s     | < 1s      | Kubernetes reschedules pod                |
| Single node failure        | < 2 min   | < 1s      | Pods rescheduled to healthy nodes          |
| AZ outage                  | < 5 min   | < 1 min   | RDS Multi-AZ failover, pods shifted to other AZ |
| Region outage              | < 30 min  | < 15 min  | Deploy from DR region (us-west-2) using Terraform |
| Data corruption            | < 1 hr    | < 24 hr   | Point-in-time recovery from RDS snapshot   |
| Full cluster loss          | < 2 hr    | < 24 hr   | Rebuild EKS from Terraform, restore from S3 backup |

```
