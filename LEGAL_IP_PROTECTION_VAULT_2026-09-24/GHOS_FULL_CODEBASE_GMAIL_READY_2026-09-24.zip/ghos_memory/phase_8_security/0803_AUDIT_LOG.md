---
file_id: "0803"
module_name: "Audit Log System"
version: "1.0"
status: "Draft"
phase: "Phase 8 - Security"
dependencies: ["0105_AUTH_ENGINE.md"]
related_files: ["0800_SECURITY.md", "0805_COMPLIANCE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "audit", "logging", "compliance", "immutable"]
---

# GHOS - Audit Log System

> "Every state change leaves a permanent fingerprint. In healthcare, accountability isnt optional - its the law."

---

## 1. AUDIT ARCHITECTURE

```
  +---------------------------------------------------------------------+
  |                       AUDIT PIPELINE                                |
  +-----------+    +----------+    +-----------+    +-------------+
  | App Layer |--->| Auditor  |--->| Buffer   |--->| Append-Only |
  | (Events)  |    | (Enrich) |    | (5s/1K)  |    | Store       |
  +-----------+    +----------+    +-----------+    +------+------+
  |                    +----------+    +-----------+    +------v------+
  |                    | Alert    |<---| Monitor   |<---| TimescaleDB |
  |                    | Engine   |    | (Anomaly) |    | (Hypertable)|
  |                    +----------+    +-----------+    +-------------+
  +---------------------------------------------------------------------+
```

### Design Principles
- **Append-only**: No UPDATE, no DELETE - only INSERT on the audit store
- **Immutable**: Cryptographic chain links each entry to its predecessor
- **Separate Store**: Dedicated database to avoid performance impact
- **Enriched Context**: Each event carries actor, resource, environment metadata
- **Retention-Grade**: Hot (90d fast query), Warm (1yr compressed), Cold (7yr archived)

## 2. AUDIT EVENT SCHEMA

### Event Envelope
```json
{
  "audit_id": "aud_2xK9mN4pQ7rV",
  "timestamp": "2026-07-09T10:30:00.123+05:30",
  "event_type": "patient.created",
  "version": "1.0",
  "severity": "info",
  "actor": {
    "id": "usr_a1b2c3d4",
    "type": "staff",
    "role": "receptionist",
    "ip_address": "192.168.1.42"
  },
  "resource": {
    "type": "patient",
    "id": "pat_e5f6g7h8",
    "action": "create"
  },
  "previous_hash": "0000abc123...",
  "current_hash": "def456789..."
}
```

### Event Categories
| Category | Prefix | Severity Levels | Storage Priority |
|----------|--------|----------------|------------------|
| Authentication | auth. | info, warning, critical | Hot + Alert |
| Patient | patient. | info, warning | Hot |
| Queue | queue. | info | Hot |
| Clinical | clinical. | info, warning | Hot + Warm |
| Billing | billing. | info, warning | Hot + Warm |
| Admin | admin. | info, warning, critical | Hot + Alert |
| Security | security. | warning, critical, emergency | Hot + Alert + Immutable |
| System | system. | info, warning | Hot |

## 3. EVENT TYPES CATALOG

### Authentication Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| auth.login.success | Successful login | Any user | info |
| auth.login.failed | Failed password | Any user | warning |
| auth.login.blocked | Account locked | System | critical |
| auth.logout | Session end | Any user | info |
| auth.otp.sent | OTP generated | System | info |
| auth.otp.verified | OTP successful | Any user | info |
| auth.token.refresh | Token rotation | Any user | info |
| auth.session.expired | Auto-logout | System | info |
| auth.api_key.used | API call via key | Service | info |
| auth.two_factor.setup | 2FA enabled | Staff | info |
| auth.password.changed | Password reset | Staff | warning |

### Patient Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| patient.created | New registration | Receptionist | info |
| patient.updated | Profile edit | Any staff | info |
| patient.merged | Duplicate merge | Admin | warning |
| patient.deleted | Record deletion | Admin | critical |
| patient.consent.given | Consent recorded | Patient | info |
| patient.consent.revoked | Consent withdrawn | Patient | warning |

### Queue Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| queue.enqueued | Patient added to queue | System | info |
| queue.called | Staff called patient | Staff | info |
| queue.skipped | Patient marked skip | Staff | info |
| queue.completed | Service finished | Staff | info |
| queue.transferred | Dept transfer | Doctor | info |
| queue.emergency_priority | Emergency override | Staff | warning |

### Clinical Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| clinical.vital.recorded | Vitals entered | Nurse | info |
| clinical.prescription.written | Rx created | Doctor | info |
| clinical.test.ordered | Lab/radiology ordered | Doctor | info |
| clinical.test.result_added | Result entered | Technician | info |
| clinical.report.viewed | Report accessed | Staff | info |
| clinical.diagnosis.added | Diagnosis coded | Doctor | info |
| clinical.referral.made | Patient referred | Doctor | info |
| clinical.critical_value.alerted | Critical lab result | System | critical |

### Billing Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| billing.invoice.created | Bill generated | Accountant | info |
| billing.payment.received | Payment collected | Accountant | info |
| billing.payment.refunded | Refund processed | Accountant | warning |
| billing.invoice.voided | Invoice cancelled | Admin | critical |
| billing.insurance.claim_filed | Insurance claim | Accountant | info |
| billing.discount.approved | Discount given | Manager | info |

### Admin Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| admin.staff.created | New staff added | Admin | info |
| admin.staff.role_changed | Role modified | Admin | warning |
| admin.staff.deactivated | Staff disabled | Admin | warning |
| admin.settings.changed | Config update | Admin | warning |
| admin.branch.created | New branch | Super admin | info |
| admin.permission.overridden | Custom permission | Admin | warning |
| admin.backup.initiated | Manual backup | Admin | info |

### Security Events
| Event | Trigger | Actor | Severity |
|-------|---------|-------|----------|
| security.brute_force.detected | 5+ failed attempts | System | critical |
| security.suspicious_ip | Unknown geo-location | System | warning |
| security.unauthorized_access | Permission denied | System | warning |
| security.api_abuse | Rate limit exceeded | System | warning |
| security.data_breach.detected | Anomaly match | System | emergency |
| security.certificate.expiring | TLS cert near expiry | System | warning |

## 4. IMMUTABILITY (CRYPTOGRAPHIC CHAIN)

### Hash Chain Structure
```
   Block 1                  Block 2                  Block 3
+----------------+      +----------------+      +----------------+
| audit_id: 001  |      | audit_id: 002  |      | audit_id: 003  |
| timestamp: T1  |      | timestamp: T2  |      | timestamp: T3  |
| event: X       |      | event: Y       |      | event: Z       |
| prev_hash: 0   |----->| prev_hash: H1  |----->| prev_hash: H2  |
| curr_hash: H1  |      | curr_hash: H2  |      | curr_hash: H3  |
+----------------+      +----------------+      +----------------+
```

### Python: AuditChain Class
```python
import hashlib
import json

class AuditChain:
    def __init__(self, db_connection):
        self.db = db_connection

    def append_event(self, event: dict) -> str:
        """Append an event with hash linking"""
        last = self._get_latest_entry()
        prev_hash = last["current_hash"] if last else "0" * 64
        chain_entry = {
            "audit_id": event["audit_id"],
            "timestamp": event["timestamp"],
            "event_type": event["event_type"],
            "previous_hash": prev_hash,
            "current_hash": self._compute_hash(event, prev_hash)
        }
        self._insert_entry(chain_entry)
        return chain_entry["current_hash"]

    def verify_chain(self, from_id=None, to_id=None):
        entries = self._get_chain_segment(from_id, to_id)
        violations = []
        for i, entry in enumerate(entries):
            expected = self._compute_hash_from_entry(entry)
            if entry["current_hash"] != expected:
                violations.append({"audit_id": entry["audit_id"], "reason": "hash_mismatch"})
            if i > 0:
                if entry["previous_hash"] != entries[i-1]["current_hash"]:
                    violations.append({"audit_id": entry["audit_id"], "reason": "chain_break"})
        return violations
```

## 5. STORAGE STRATEGY

### TimescaleDB Hypertable
```sql
CREATE TABLE audit_events (
    audit_id        VARCHAR(30) PRIMARY KEY,
    timestamp       TIMESTAMPTZ NOT NULL,
    event_type      VARCHAR(100) NOT NULL,
    severity        VARCHAR(20) NOT NULL DEFAULT 'info'
                    CHECK (severity IN ('info','warning','critical','emergency')),
    actor_id        VARCHAR(30) NOT NULL,
    actor_type      VARCHAR(20) NOT NULL,
    actor_role      VARCHAR(50),
    ip_address      INET,
    resource_type   VARCHAR(50) NOT NULL,
    resource_id     VARCHAR(30) NOT NULL,
    action          VARCHAR(50) NOT NULL,
    details         JSONB NOT NULL DEFAULT '{}',
    hospital_id     VARCHAR(30) NOT NULL,
    previous_hash   CHAR(64) NOT NULL,
    current_hash    CHAR(64) NOT NULL,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

SELECT create_hypertable('audit_events', 'timestamp',
    chunk_time_interval => interval '1 month');

ALTER TABLE audit_events SET (
    timescaledb.compress,
    timescaledb.compress_segmentby = 'hospital_id, event_type',
    timescaledb.compress_orderby = 'timestamp DESC'
);
SELECT add_compression_policy('audit_events', INTERVAL '90 days');
SELECT add_retention_policy('audit_events', INTERVAL '7 years');
```

### Indexes for Query Performance
```sql
CREATE INDEX idx_audit_timestamp ON audit_events(timestamp DESC);
CREATE INDEX idx_audit_event_type ON audit_events(event_type);
CREATE INDEX idx_audit_actor ON audit_events(actor_id, timestamp DESC);
CREATE INDEX idx_audit_resource ON audit_events(resource_type, resource_id);
CREATE INDEX idx_audit_severity ON audit_events(severity, timestamp DESC);
CREATE INDEX idx_audit_hospital ON audit_events(hospital_id, timestamp DESC);
CREATE INDEX idx_audit_details_gin ON audit_events USING GIN(details jsonb_path_ops);
CREATE INDEX idx_audit_critical ON audit_events(timestamp DESC)
    WHERE severity IN ('critical', 'emergency');
```

## 6. QUERY INTERFACE

```python
class AuditQuery:
    def __init__(self, db):
        self.db = db

    def search(self, filters, page=1, page_size=50):
        query = "SELECT * FROM audit_events WHERE 1=1"
        params = {}
        if 'event_type' in filters:
            query += " AND event_type = :event_type"
            params["event_type"] = filters["event_type"]
        if 'actor_id' in filters:
            query += " AND actor_id = :actor_id"
            params["actor_id"] = filters["actor_id"]
        if 'severity' in filters:
            query += " AND severity = :severity"
            params["severity"] = filters["severity"]
        if 'date_from' in filters:
            query += " AND timestamp >= :date_from"
            params["date_from"] = filters["date_from"]
        if 'date_to' in filters:
            query += " AND timestamp <= :date_to"
            params["date_to"] = filters["date_to"]
        query += " ORDER BY timestamp DESC"
        query += f" LIMIT {page_size} OFFSET {(page-1)*page_size}"
        return self.db.query(query, params)

    def get_patient_audit_trail(self, patient_id):
        return self.db.query(
            "SELECT * FROM audit_events "
            "WHERE resource_type = 'patient' AND resource_id = :pid "
            "ORDER BY timestamp ASC", {"pid": patient_id})
```

## 7. RETENTION AND PURGING

### Retention Policy
```yaml
retention:
  hot_storage:
    duration: 90_days
    storage: NVMe SSD
    compression: none
    query_sla: < 100ms
  warm_storage:
    duration: 1_year
    storage: S3 Standard
    compression: zstd:3
    query_sla: < 500ms
  cold_storage:
    duration: 7_years
    storage: S3 Glacier Deep Archive
    compression: gzip (parquet)
    query_sla: > 1hr (restore required)
  immutable_period:
    duration: 3_years
    policy: No deletion or modification allowed
  legal_hold:
    trigger: Court order or investigation
    override: Overrides all retention/immutable rules
```

## 8. MONITORING AND ALERTS

### Anomaly Detection
```python
class AuditMonitor:
    def check_anomalies(self):
        alerts = []
        # Brute force detection
        brute_force = self.db.query(
            SELECT actor_id, ip_address, count(*) as attempts
            FROM audit_events
            WHERE event_type = 'auth.login.failed'
            AND timestamp > now() - interval '5 minutes'
            GROUP BY actor_id, ip_address
            HAVING count(*) >= 5
        )
        for bf in brute_force:
            alerts.append({"type": "brute_force", "severity": "critical"})
        return alerts
```

## 9. SQL SCHEMA - SUPPORTING TABLES

```sql
CREATE TABLE audit_chain_anchors (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    anchor_time     TIMESTAMPTZ NOT NULL DEFAULT now(),
    last_audit_id   VARCHAR(30) NOT NULL REFERENCES audit_events(audit_id),
    chain_root_hash VARCHAR(64) NOT NULL,
    anchored_to     VARCHAR(100),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE legal_holds (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    resource_type   VARCHAR(50) NOT NULL,
    resource_id     VARCHAR(30) NOT NULL,
    reason          TEXT NOT NULL,
    placed_by       UUID REFERENCES staff(id),
    placed_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    expires_at      TIMESTAMPTZ,
    active          BOOLEAN DEFAULT true,
    case_reference  VARCHAR(100)
);

CREATE TABLE audit_alerts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    alert_type      VARCHAR(50) NOT NULL UNIQUE,
    severity        VARCHAR(20) NOT NULL,
    enabled         BOOLEAN DEFAULT true,
    config          JSONB DEFAULT '{}',
    notification_channels JSONB DEFAULT '["email", "whatsapp"]',
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Separate audit store | TimescaleDB hypertable | Avoids contention with transactional DB |
| Append-only | INSERT only, no UPDATE/DELETE | Immutability guarantee |
| Hash chain | SHA-256 linked list | Tamper evidence, computationally cheap |
| JSONB details | Flexible schema per event type | Different events need different data |
| Compression | TimescaleDB native zstd after 90d | 10x compression, transparent queries |
| Retention | 7 years (90d hot, 1yr warm, 7yr cold) | Indian IT Act minimum |
| Alerting | SQL-based anomaly detection | OSS-friendly, no SIEM license needed |
| Periodic anchoring | Chain root hash published externally | Additional tamper-resistance |
| Legal holds | Override table with case reference | Required for investigations |

---
*Last updated: 2026-07-09*