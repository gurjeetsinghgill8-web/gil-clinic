---
file_id: "0800"
module_name: "Security Overview"
version: "2.0"
status: "Approved"
phase: "Phase 8 - Security"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["0801_ENCRYPTION.md", "0802_BACKUP.md", "0803_AUDIT_LOG.md", "0804_ROLE_PERMISSION.md", "0805_COMPLIANCE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "security", "overview", "policies", "threat-model", "incident-response"]
---

# \U0001f6e1\ufe0f GHOS \u2014 Security Architecture

> **"Patient data is sacred. Treat it as if it\u2019s your own."**
> Security is not optional \u2014 it is built into every layer of the system, from network plumbing to application logic to physical access.

---

## 1. SECURITY PHILOSOPHY

GHOS follows a **defense-in-depth** model with seven concentric security layers:

```
Layer 1:  Physical Security          \u2192 Data center access controls, CCTV, biometric locks
Layer 2:  Network Security           \u2192 VPC isolation, WAF, DDoS protection, VPN
Layer 3:  Infrastructure Security   \u2192 Hardened OS, container scanning, patch management
Layer 4:  Platform Security          \u2192 API Gateway, rate limiting, service mesh mTLS
Layer 5:  Application Security       \u2192 Secure coding, input validation, CSRF/XSS protection
Layer 6:  Data Security              \u2192 Encryption at rest & transit, column-level encryption
Layer 7:  Identity & Access          \u2192 RBAC, MFA, session management, audit logging
```

**Core principles:**
- **Least privilege** \u2014 every user/service gets the minimum access needed
- **Assume breach** \u2014 design for compromise, not just prevention
- **Defense in depth** \u2014 multiple overlapping controls
- **Secure by default** \u2014 opt-out hardening, never opt-in
- **Privacy by design** \u2014 DPDP Act 2023 compliance built into architecture

---

## 2. DEFENSE-IN-DEPTH ARCHITECTURE

```
INTERNET
   |
   v
+---------------------------------------------------+
|             WAF / Cloudflare / DDoS Protection     |
|  +-----------------------------------------------+ |
|  | Bot Management | Geo-Blocking | Rate Throttle | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             API GATEWAY (Traefik / Nginx)          |
|  +-----------------------------------------------+ |
|  | TLS Termination (TLS 1.3)                     | |
|  | Request Validation & Normalization            | |
|  | IP Allow/Block Lists                          | |
|  | Rate Limiting: 100 req/min per IP, 10/s burst | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             AUTH MIDDLEWARE                        |
|  +-----------------------------------------------+ |
|  | JWT Verification (RS256, 15min expiry)        | |
|  | Session Validation (Redis-backed)             | |
|  | RBAC Enforcement (role based access)          | |
|  | MFA Challenge Trigger                         | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             SERVICE MESH (Istio / Linkerd)         |
|  +-----------------------------------------------+ |
|  | mTLS between all services (mutual auth)       | |
|  | Service-to-service authorization policies     | |
|  | Traffic encryption (wire-level)               | |
|  | Access logs per service pair                  | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             MICROSERVICES LAYER                    |
|  +-----------------------------------------------+ |
|  | Input sanitization (HTML escape, param check) | |
|  | Parameterized SQL queries (no raw SQL)        | |
|  | Audit logging for all state mutations         | |
|  | Output encoding (prevent XSS in responses)    | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             DATA LAYER                             |
|  +-----------------------------------------------+ |
|  | PostgreSQL Transparent Data Encryption (TDE)  | |
|  | Column-level encryption (AES-256-GCM)         | |
|  | Encrypted backups (AES-256)                   | |
|  | Database access logging                        | |
|  | Connection pooling with SSL enforced           | |
|  +-----------------------------------------------+ |
+------------------------+--------------------------+
                         |
+------------------------v--------------------------+
|             PHYSICAL / CLOUD INFRASTRUCTURE        |
|  +-----------------------------------------------+ |
|  | VPC with private subnets (no public DB)       | |
|  | Security groups / firewall rules              | |
|  | Hardened base images (CIS benchmarks)         | |
|  | HSM for cryptographic key storage             | |
|  +-----------------------------------------------+ |
+---------------------------------------------------+
```

---

## 3. THREAT MODEL (STRIDE)

We apply the **STRIDE** threat modeling methodology to the GHOS healthcare system.
Each threat category is analyzed for healthcare-specific attack vectors.

```
+----------------+------------------------------------------+-----------------------------------+
| CATEGORY       | HEALTHCARE-SPECIFIC THREAT               | MITIGATION                        |
+----------------+------------------------------------------+-----------------------------------+
| S: Spoofing    | Impersonating doctor to access           | mTLS, JWT with audience claims,   |
|                | patient records or prescribe drugs       | biometric MFA for high-risk ops   |
+----------------+------------------------------------------+-----------------------------------+
| T: Tampering   | Modifying lab results, prescriptions,     | Digital signatures on clinical    |
|                | or billing amounts in transit or at rest  | data, audit trail, immutable log  |
+----------------+------------------------------------------+-----------------------------------+
| R: Repudiation | Doctor denies performing a procedure,     | Comprehensive audit logging,      |
|                | patient denies receiving treatment        | e-signatures with timestamps,     |
|                |                                          | video/audio recording consent     |
+----------------+------------------------------------------+-----------------------------------+
| I: Info        | PHI/PII leakage via API misconfiguration, | Encryption at rest/transit,       |
| Disclosure     | insufficient access controls, or          | column-level encryption,          |
|                | insecure error messages                   | data masking in logs, RBAC        |
+----------------+------------------------------------------+-----------------------------------+
| D: Denial of   | Queue flooding attacks, appointment       | Rate limiting, auto-scaling,      |
| Service        | system DoS, SMS/notification spam         | queue depth limits, CDN caching   |
+----------------+------------------------------------------+-----------------------------------+
| E: Elevation   | Receptionist escalates to admin,          | Strict RBAC with separation of    |
| of Privilege   | patient accesses other patient records    | duties, permission reviews,       |
|                |                                          | session privilege revalidation   |
+----------------+------------------------------------------+-----------------------------------+
```

### 3.1 Risk Acceptance Criteria

| Risk Level | CVSS Range | Response                        | Timeline  |
|------------|------------|---------------------------------|-----------|
| Critical   | 9.0-10.0   | Immediate fix, incident report  | < 24 hrs  |
| High       | 7.0-8.9    | Hotfix or patch within 72 hrs   | < 72 hrs  |
| Medium     | 4.0-6.9    | Scheduled for next sprint       | < 14 days |
| Low        | 0.1-3.9    | Backlog, monitor                | < 90 days |

### 3.2 Attack Surface Map

```
EXTERNAL ATTACK SURFACE
  +-- Web Application (PWA)          -> XSS, CSRF, Session Hijacking
  +-- Mobile App                     -> Reverse Engineering, API Key Extraction
  +-- Public API Endpoints           -> Injection, Broken Auth, Excessive Data
  +-- WhatsApp / SMS Gateway         -> Spoofing, Message Injection
  +-- Email (SMTP)                   -> Phishing, SPF/DKIM Bypass

INTERNAL ATTACK SURFACE
  +-- Admin Dashboard                -> Privilege Escalation, IDOR
  +-- Internal Microservices APIs   -> Service Spoofing, Data Exfiltration
  +-- Database                       -> SQL Injection, Unauthorized Query
  +-- Redis / Cache                  -> Cache Poisoning, Data Leak
  +-- File Storage (S3/MinIO)       -> Bucket Misconfiguration, Unauthorized Access
  +-- AI Service (LLM)              -> Prompt Injection, Data Leakage via Model
```

---

## 4. AUTHENTICATION SECURITY

### 4.1 Session Management

```python
import uuid
import hashlib
from datetime import datetime, timedelta

SESSION_CONFIG = {
    "access_token_ttl": 900,          # 15 minutes
    "refresh_token_ttl": 604800,      # 7 days
    "session_idle_timeout": 1800,     # 30 min inactivity
    "max_concurrent_sessions": 3,     # per user
    "renew_window": 120,              # renew within 2 min of expiry
    "token_storage": "redis",         # Redis with TTL
    "cookie_flags": {
        "HttpOnly": True,
        "Secure": True,
        "SameSite": "Strict",
        "Path": "/"
    }
}

class SessionManager:
    """Manage user sessions with rotation and revocation."""

    def __init__(self, redis_client):
        self.redis = redis_client

    async def create_session(self, user_id: str, roles: list,
                               hospital_id: str) -> dict:
        session_id = str(uuid.uuid4())
        access_token = self._generate_jwt(user_id, roles, hospital_id)
        refresh_token = self._generate_refresh_token()
        await self.redis.setex(
            f"session:{session_id}",
            SESSION_CONFIG["refresh_token_ttl"],
            {"user_id": user_id, "roles": roles,
             "hospital_id": hospital_id,
             "created_at": datetime.utcnow().isoformat()}
        )
        return {"access_token": access_token,
                "refresh_token": refresh_token,
                "session_id": session_id}

    async def revoke_session(self, session_id: str):
        await self.redis.delete(f"session:{session_id}")
        await self.redis.setex(
            f"revoked:{session_id}", 86400, "revoked")

    async def rotate_tokens(self, refresh_token: str) -> dict:
        """Rotate both tokens. Invalidate old refresh token."""
        session_data = await self.redis.get(
            f"refresh:{refresh_token}")
        if not session_data:
            raise SecurityException("Invalid refresh token")
        await self.revoke_session(
            session_data["session_id"])
        return await self.create_session(
            session_data["user_id"],
            session_data["roles"],
            session_data["hospital_id"])
```

### 4.2 Brute Force Protection

```python
class BruteForceProtector:
    """Rate-limit login attempts with exponential backoff."""

    def __init__(self, redis_client):
        self.redis = redis_client

    async def check_login_allowed(self, identifier: str,
                                    ip_address: str) -> bool:
        keys = [
            f"login_attempts:user:{identifier}",
            f"login_attempts:ip:{ip_address}"
        ]
        for key in keys:
            count = await self.redis.get(key) or 0
            if int(count) >= 5:
                ttl = await self.redis.ttl(key)
                raise RateLimitException(
                    f"Too many attempts. Retry in {ttl}s")
        return True

    async def record_failed_attempt(self, identifier: str,
                                     ip_address: str):
        """Increment counters with escalating lockout."""
        for key in [f"login_attempts:user:{identifier}",
                    f"login_attempts:ip:{ip_address}"]:
            count = await self.redis.incr(key)
            if count == 1:
                await self.redis.expire(key, 300)  # 5 min
            elif count >= 5:
                await self.redis.expire(key, 1800)  # 30 min
            elif count >= 10:
                await self.redis.expire(key, 3600)  # 1 hr
            elif count >= 20:
                await self.redis.expire(key, 86400)  # 24 hr

    async def record_success(self, identifier: str,
                              ip_address: str):
        await self.redis.delete(
            f"login_attempts:user:{identifier}")
        await self.redis.delete(
            f"login_attempts:ip:{ip_address}")
```

### 4.3 OWASP Top 10 Mitigations

| OWASP Category          | GHOS Mitigation                                    |
|-------------------------|----------------------------------------------------|
| A01: Broken Access      | RBAC with hierarchical roles, permission checks     |
| Control                 | on every API endpoint                              |
| A02: Crypto Failure     | AES-256-GCM for data, TLS 1.3 for transit,         |
|                         | Argon2id for password hashing                      |
| A03: Injection          | ORM parameterized queries, input validation         |
|                         | library, HTML entity encoding                       |
| A04: Insecure Design    | Threat modeling in design phase, security          |
|                         | review in PR pipeline                               |
| A05: Security Mistake   | Secure defaults, hardened Docker images,           |
|                         | CIS benchmark compliance                            |
| A06: Vulnerable Deps    | Dependabot + OWASP DC scanning in CI/CD            |
| A07: ID & Auth Fail     | MFA for admin, passwordless OTP for patients,      |
|                         | session rotation, brute-force protection            |
| A08: Data Integrity     | Digital signatures on clinical documents,          |
| Failure                 | immutable audit log                                 |
| A09: Security Logging   | Centralized logging (ELK), real-time alerts,       |
| & Monitoring            | SIEM integration                                    |
| A10: SSRF              | URL allowlist, disable internal network access      |
|                         | from public endpoints                               |

---

## 5. API SECURITY

### 5.1 Rate Limiting Configuration

```yaml
# Rate limiting rules per endpoint tier
rate_limits:
  public:
    endpoints: ["/api/v1/queue/track/", "/api/v1/public/"]
    rate: "30/minute"
    burst: 10
  authenticated:
    endpoints: ["/api/v1/patient/", "/api/v1/appointment/"]
    rate: "100/minute"
    burst: 20
  admin:
    endpoints: ["/api/v1/admin/", "/api/v1/reports/"]
    rate: "200/minute"
    burst: 50
  auth:
    endpoints: ["/api/v1/auth/login", "/api/v1/auth/otp"]
    rate: "5/minute"
    burst: 3
  webhook:
    endpoints: ["/api/v1/webhooks/"]
    rate: "50/minute"
    burst: 10
```

### 5.2 Request Validation Pipeline

```python
from pydantic import BaseModel, Field, validator
import re

class RequestValidator:
    """Multi-layer request validation."""

    @staticmethod
    def sanitize_input(value: str) -> str:
        """Strip HTML, escape special chars, trim."""
        import html
        value = html.escape(value, quote=True)
        value = re.sub(r"[<>'\"&]", "", value)
        return value.strip()[:1000]

    @staticmethod
    def validate_mobile(mobile: str) -> bool:
        """India mobile: 10 digits, starting 6-9."""
        return bool(re.match(r"^[6-9]\d{9}$", mobile))

    @staticmethod
    def validate_aadhaar(aadhaar: str) -> bool:
        """12 digits, Verhoeff checksum validation."""
        if not re.match(r"^\d{12}$", aadhaar):
            return False
        return _verhoeff_checksum(aadhaar)

    @staticmethod
    def sanitize_for_sql(value: str) -> str:
        """Strip SQL metacharacters (defense in depth)."""
        dangerous = ["--", ";", "'", "/*", "*/", "xp_"]
        for d in dangerous:
            value = value.replace(d, "")
        return value
```

### 5.3 CORS & CSRF

```python
CORS_CONFIG = {
    "allow_origins": [
        "https://app.ghos.in",
        "https://admin.ghos.in",
        "https://*.ghos.in"
    ],
    "allow_methods": ["GET", "POST", "PUT", "DELETE", "PATCH"],
    "allow_headers": [
        "Authorization", "Content-Type", "X-CSRF-Token",
        "X-Request-ID", "X-API-Key"
    ],
    "expose_headers": ["X-Request-ID", "X-RateLimit-Remaining"],
    "allow_credentials": True,
    "max_age": 3600
}

# CSRF: Double-submit cookie pattern
class CSRFProtection:
    @staticmethod
    def generate_token() -> str:
        return secrets.token_urlsafe(32)

    @staticmethod
    def validate_token(cookie_token: str, header_token: str) -> bool:
        return hmac.compare_digest(cookie_token, header_token)
```

### 5.4 API Key Management

```python
class APIKeyManager:
    """Rotate, validate and revoke API keys for integrations."""

    KEY_PREFIX = "ghos_"
    KEY_LENGTH = 48

    async def generate_key(self, tenant_id: str,
                            permissions: list) -> dict:
        raw_key = self.KEY_PREFIX + secrets.token_urlsafe(self.KEY_LENGTH)
        hashed_key = hashlib.sha3_256(raw_key.encode()).hexdigest()
        key_data = {
            "key_prefix": raw_key[:8],
            "key_hash": hashed_key,
            "tenant_id": tenant_id,
            "permissions": permissions,
            "expires_at": (datetime.utcnow() + timedelta(days=90)).isoformat()
        }
        await self.redis.setex(
            f"apikey:{hashed_key}", 7776000,  # 90 days
            {"tenant_id": tenant_id, "permissions": permissions})
        return raw_key  # Return once, never stored

    async def rotate_key(self, old_key_hash: str):
        await self.revoke_key(old_key_hash)
        old_key_data = await self.redis.get(f"apikey:{old_key_hash}")
        if old_key_data:
            return await self.generate_key(
                old_key_data["tenant_id"], old_key_data["permissions"])
        raise ValueError("Key not found")

    async def revoke_key(self, key_hash: str):
        await self.redis.delete(f"apikey:{key_hash}")

---

## 6. DATA CLASSIFICATION

PHI/PII data is classified into tiers with specific handling rules:

```
+-----------------+----------------------+---------------------+------------------+
| TIER            | DATA TYPES            | ENCRYPTION          | ACCESS CONTROL    |
+-----------------+----------------------+---------------------+------------------+
| CRITICAL (C4)   | Aadhaar, Passport,   | AES-256-GCM at rest | Doctor + Admin    |
|                 | Full medical history, | + column-level      | (explicit grant)  |
|                 | HIV status, Genetics  | + field-level       | Logged always     |
+-----------------+----------------------+---------------------+------------------+
| HIGH (C3)       | Name, Phone, Email,  | AES-256 at rest     | Treating Team     |
|                 | Diagnosis,           | TLS 1.3 in transit  | Role-based        |
|                 | Prescriptions,       |                     | Logged always     |
|                 | Lab reports          |                     |                   |
+-----------------+----------------------+---------------------+------------------+
| MEDIUM (C2)     | Appointment times,   | TLS 1.3 in transit  | Any authenticated |
|                 | Queue status,        | DB-level encryption | staff             |
|                 | Department visits    |                     | Logged on access  |
+-----------------+----------------------+---------------------+------------------+
| PUBLIC (C1)     | Hospital info,       | Standard TLS        | Public            |
|                 | Doctor names/specs,  |                     | No auth required  |
|                 | Timings,            |                     | Not logged        |
+-----------------+----------------------+---------------------+------------------+
```

### 6.1 Handling Rules per Tier

| Rule                    | C4       | C3       | C2       | C1    |
|-------------------------|----------|----------|----------|-------|
| Encryption at rest      | Required | Required | Optional | No    |
| Encryption in transit   | Required | Required | Required | No    |
| Mask in logs            | Required | Required | Optional | No    |
| Mask in UI              | Required | Optional | No       | No    |
| Export allowed          | Never    | With consent | Via API | Yes |
| Retention period        | 10 years | 10 years | 3 years  | N/A   |
| Deletion upon request   | Yes (DPDP)| Yes     | Yes      | N/A   |
| Access audit            | Always   | Always   | On access| No    |
| Breach notification     | 72 hrs   | 72 hrs   | 7 days   | N/A   |

---

## 7. NETWORK SECURITY

```
+---------------------------------------------------+
|                   VPC Architecture                 |
|                                                   |
|  Internet Gateway                                 |
|       |                                            |
|  +----v----+    +-----------+                     |
|  | Public  |    | WAF /     |                     |
|  | ALB     |    | CDN       |                     |
|  +----+----+    +-----------+                     |
|       |                                            |
|  +----v-----------------------------------------+ |
|  |       Application Subnet (Private)            | |
|  |  +-----------------------------------------+ | |
|  |  | API Gateway + Microservices              | | |
|  |  | (Auto-scaling group)                     | | |
|  |  +-----------------------------------------+ | |
|  +-----------------------------------------------+ |
|       |                                            |
|  +----v-----------------------------------------+ |
|  |       Data Subnet (Private - No Internet)      | |
|  |  +-----------------------------------------+ | |
|  |  | PostgreSQL (RDS Multi-AZ)                | | |
|  |  | Redis (ElastiCache)                      | | |
|  |  | S3 VPC Endpoint (Gateway)                | | |
|  |  +-----------------------------------------+ | |
|  +-----------------------------------------------+ |
+---------------------------------------------------+
```

### 7.1 Firewall Rules

```yaml
firewall_rules:
  inbound:
    - port: 443
      source: "0.0.0.0/0"
      description: "HTTPS from internet to ALB"
    - port: 8443
      source: "10.0.0.0/8"
      description: "mTLS between private services"
    - port: 5432
      source: "10.0.1.0/24"
      description: "PostgreSQL from app subnet only"
    - port: 6379
      source: "10.0.1.0/24"
      description: "Redis from app subnet only"

  outbound:
    - destination: "0.0.0.0/0"
      port: 443
      description: "HTTPS egress (WhatsApp, SMS, Email APIs)"
    - destination: "10.0.0.0/8"
      port: "1-65535"
      description: "Internal service communication"

  restricted:
    - SSH access via bastion host only (IP-whitelisted)
    - Database direct access blocked (app layer only)
    - No egress to internet from data subnet
```

### 7.2 VPN for Remote Access

```yaml
vpn_config:
  protocol: "WireGuard"
  auth: "Certificate-based + MFA"
  split_tunnel: True
  idle_timeout: 3600  # 1 hour
  session_limit: 2   # max concurrent sessions per user
  logging: "Full session logging to SIEM"
  allowed_roles: ["admin", "doctor", "support_engineer"]
```

---

## 8. APPLICATION SECURITY

### 8.1 Secure Coding Guidelines

```python
# DO: Parameterized queries via ORM
patient = await Patient.filter(id=patient_id, hospital_id=hospital_id)

# DO NOT: Raw string interpolation
# BAD: cursor.execute(f"SELECT * FROM patients WHERE id={pid}")

# DO: Input validation and sanitization
from pydantic import BaseModel, validator

class PrescriptionCreate(BaseModel):
    medicine_name: str = Field(..., max_length=200)
    dosage: str = Field(..., max_length=50)
    notes: Optional[str] = Field(None, max_length=2000)

    @validator("medicine_name")
    def sanitize_medicine(cls, v):
        return re.sub(r"[<>'\"&;]", "", v.strip())

    @validator("dosage")
    def validate_dosage(cls, v):
        if not re.match(r"^[\d]+\.?\d*\s*(mg|ml|g|mcg|IU)", v):
            raise ValueError("Invalid dosage format")
        return v

# DO: Context-aware output encoding
from markupsafe import escape
safe_name = escape(patient_name)

# DO: Use security headers
SECURITY_HEADERS = {
    "X-Content-Type-Options": "nosniff",
    "X-Frame-Options": "DENY",
    "X-XSS-Protection": "1; mode=block",
    "Strict-Transport-Security": "max-age=31536000; includeSubDomains",
    "Content-Security-Policy": "default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self' wss://*.ghos.in",
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "Permissions-Policy": "camera=(), microphone=(), geolocation=()"
}
```
### 8.2 Dependency Scanning (CI/CD Pipeline)

```yaml
name: Security Scan
on: [push, pull_request]
jobs:
  dependency-scan:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: OWASP Dependency Check
        uses: dependency-check/Dependency-Check_Action@main
        with:
          project: GHOS
          path: .
          format: SARIF
      - name: Python Safety Scan
        run: pip install safety && safety check -r backend/requirements.txt
      - name: NPM Audit
        run: cd frontend && npm audit --audit-level=high
      - name: Trivy Container Scan
        run: trivy image ghos/api:latest --severity=HIGH,CRITICAL
  SAST:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v3
      - name: Bandit (Python SAST)
        run: pip install bandit && bandit -r backend/ -f sarif -o bandit-results.sarif
      - name: CodeQL Analysis
        uses: github/codeql-action/analyze@v2
  DAST:
    runs-on: ubuntu-latest
    steps:
      - name: ZAP Baseline Scan
        uses: zaproxy/action-baseline@v0.7.0
        with:
          target: https://staging.ghos.in
```

## 9. MOBILE SECURITY

### 9.1 App Hardening

```python
MOBILE_SECURITY_CONFIG = {
    "min_app_version": "2.1.0",
    "force_update": True,
    "root_detection": True,
    "jailbreak_detection": True,
    "emulator_detection": True,
    "debugger_detection": True,
    "screen_capture_block": True,
    "clipboard_restrictions": True,
    "app_watermarking": True,
    "integrity_verification": {
        "android": "Google Play Integrity API",
        "ios": "DeviceCheck + AppAttest"
    }
}

class MobileSecurityManager:
    @staticmethod
    def detect_root_access() -> bool:
        root_paths = [
            "/system/app/Superuser.apk", "/sbin/su",
            "/system/bin/su", "/system/xbin/su",
            "/data/local/xbin/su", "/data/local/bin/su",
            "/system/sd/xbin/su", "/system/bin/failsafe/su",
            "/data/local/su"
        ]
        for path in root_paths:
            if os.path.exists(path):
                return True
        try:
            os.execv("/system/xbin/su", ["su"])
            return True
        except Exception:
            pass
        return False

    def check_app_integrity(self, package_name: str, expected_hash: str) -> bool:
        current_hash = self._get_signature_hash(package_name)
        return hmac.compare_digest(current_hash, expected_hash)
```

### 9.2 Certificate Pinning

iOS TrustKit and Android OkHttp CertificatePinner enforce pinned keys for api.ghos.in and cdn.ghos.in.

### 9.3 Secure Key Storage

iOS Keychain and Android EncryptedSharedPreferences store tokens with device-level encryption.

## 10. INCIDENT RESPONSE PLAN

### 10.1 IR Lifecycle (7-Step)

```
  Step 1: PREPARE
    |-- Maintain incident response playbooks
    |-- Conduct tabletop exercises quarterly
    |-- Keep contact rosters updated
    |-- Pre-deploy forensic tooling
    v
  Step 2: DETECT
    |-- SIEM alerts (Wazuh / Splunk)
    |-- IDS/IPS signatures
    |-- Anomaly detection pipeline
    |-- User-reported incidents
    v
  Step 3: ANALYZE
    |-- Triage: determine scope and severity
    |-- Collect forensic evidence (memory, disk, logs)
    |-- Identify IOCs and TTPs
    v
  Step 4: CONTAIN
    |-- Isolate affected systems
    |-- Revoke compromised credentials
    |-- Block malicious IPs at WAF
    |-- Rotate exposed keys/certificates
    v
  Step 5: ERADICATE
    |-- Remove malware / backdoors
    |-- Patch vulnerabilities
    |-- Restore from clean backup
    |-- Verify no persistence mechanisms remain
    v
  Step 6: RECOVER
    |-- Gradually restore services (canary first)
    |-- Monitor for recurrence (48hr watch)
    |-- Communicate restoration to stakeholders
    v
  Step 7: POSTMORTEM
    |-- Root cause analysis (RCA) document
    |-- Lessons learned register
    |-- Control improvements
    |-- Update playbooks
    |-- Legal/regulatory reporting (if required)
```

### 10.2 Severity Matrix

| Severity | Label       | Examples                                    | Response Time |
|----------|-------------|---------------------------------------------|---------------|
| S1       | Critical    | Data breach >10K records, Ransomware,       | < 15 min      |
|          |             | Complete service outage                     |               |
| S2       | High        | Partial data breach, Service degradation,   | < 1 hour      |
|          |             | Unauthorized admin access                   |               |
| S3       | Medium      | Limited data exposure, Non-critical service | < 4 hours     |
|          |             | down, Phishing campaign                     |               |
| S4       | Low         | Attempted intrusion (blocked), Policy       | < 24 hours    |
|          |             | violation, Configuration drift              |               |

### 10.3 Breach Notification Timeline (DPDP Act 2023)

```python
class BreachNotifier:
    DPDP_NOTIFICATION_WINDOW = 72  # hours
    DATA_PROTECTION_OFFICER = "dpo@ghos.in"
    CERT_IN = "incident@cert-in.org.in"

    async def report_breach(self, breach):
        hours_elapsed = (datetime.utcnow() - breach.discovered_at).total_seconds() / 3600
        if hours_elapsed > self.DPDP_NOTIFICATION_WINDOW:
            await self._file_delayed_report(breach)
        await self._notify_internal(breach)
        await self._notify_cert_in(breach)
        if breach.affected_count > 0:
            await self._notify_affected_users(breach)
        if breach.severity in ("S1", "S2"):
            await self._notify_dpdp_authority(breach)
```

## 11. SECURITY MONITORING

### 11.1 SIEM Integration

```yaml
siem_config:
  platform: Wazuh SIEM
  log_sources:
    - type: api_gateway
      format: json
      endpoints: [/var/log/nginx/access.json, /var/log/traefik/access.log]
    - type: application
      format: json
      endpoints: [stdout (container logs -> Fluentd)]
    - type: database
      format: csv
      endpoints: [PostgreSQL audit log (pgaudit)]
    - type: auth
      format: json
      endpoints: [/var/log/auth/auth.log]
    - type: network
      format: pcap
      endpoints: [VPC flow logs -> S3 -> SIEM]
  log_retention:
    hot_storage: 30 days (Elasticsearch)
    warm_storage: 90 days (S3 Glacier)
    cold_storage: 365 days (S3 Glacier Deep Archive)
    compliance: 7 years (encrypted, tamper-proof)
```

### 11.2 Anomaly Detection Pipeline

```python
class ThreatDetector:
    def __init__(self, redis_client, ml_model=None):
        self.redis = redis_client
        self.ml_model = ml_model

    async def check_geo_anomaly(self, user_id: str, ip_address: str) -> bool:
        current_geo = await self._geo_lookup(ip_address)
        last_geo = await self.redis.get(f"last_geo:{user_id}")
        if last_geo and last_geo != current_geo:
            last_time = await self.redis.get(f"last_geo_time:{user_id}")
            distance = haversine(last_geo, current_geo)
            if distance > 500 and (datetime.utcnow() - last_time) < timedelta(hours=1):
                return True  # Impossible travel detected
        return False

class SecurityEventEmitter:
    def __init__(self, kafka_producer):
        self.producer = kafka_producer
        self.topic = "security_events"

    async def emit(self, event_type: str, payload: dict, severity: str = "info"):
        event = {
            "event_id": str(uuid.uuid4()),
            "event_type": event_type,
            "severity": severity,
            "timestamp": datetime.utcnow().isoformat(),
            "source": "ghos-security",
            "payload": payload
        }
        await self.producer.send(self.topic, event)

class IncidentManager:
    async def create_incident(self, event: dict):
        incident = {"event_id": event["event_id"], "severity": event["severity"], "status": "open"}
        return incident

    async def run_postmortem(self, incident_id: str):
        return {"incident_id": incident_id, "status": "postmortem_scheduled"}
```

## 12. COMPLIANCE MAPPING

### 12.1 ISO 27001:2022 Control Mapping

| ISO 27001 Control | Annex A | GHOS Implementation |
|---|---|---|
| Info Security Policies | A.5.1 | GHOS Security Policy, reviewed annually |
| Asset Management | A.5.4 | Asset register, classification (C1-C4) |
| Access Control | A.5.5 | RBAC, MFA, JIT access, quarterly reviews |
| Cryptography | A.5.6 | AES-256, TLS 1.3, Argon2id, key rotation |
| Incident Management | A.5.11 | 7-step IR plan, tabletop exercises |
| Business Continuity | A.5.12 | DR plan, RTO=4hr, RPO=15min |
| Compliance | A.5.13 | DPDP Act, IT Act, ISO 27001 audits |

### 12.2 DPDP Act 2023 Mapping

| Provision | GHOS Compliance |
|---|---|
| Section 4: Notice | Consent flow at registration, Hindi/English |
| Section 5: Consent | Granular consent per purpose, easy withdrawal |
| Section 10: Security Safeguards | Defense-in-depth, encryption, SIEM |
| Section 11: Breach Notification | Automated notification within 72 hours |
| Section 22: Rights of Data Principal | Patient portal for data subject rights |

### 12.3 IT Act 2000 / CERT-In Mapping

| Requirement | GHOS Implementation |
|---|---|
| Section 43: Unauthorized access | Intrusion detection, audit trails |
| Section 66: Computer offenses | Log monitoring, anomaly detection |
| CERT-In Incident Reporting (6hrs) | Automated SIEM alerts, on-call rotation |
| CERT-In KYC Guidelines | Aadhaar/eKYC verification, audit logging |

## 13. DATABASE SCHEMAS

### 13.1 incident_reports

```sql
CREATE TABLE incident_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    incident_id VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(500) NOT NULL,
    description TEXT NOT NULL,
    severity VARCHAR(10) NOT NULL CHECK (severity IN ('S1','S2','S3','S4')),
    status VARCHAR(20) NOT NULL DEFAULT 'open',
    category VARCHAR(50) NOT NULL,
    discovered_at TIMESTAMPTZ NOT NULL,
    reported_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    contained_at TIMESTAMPTZ,
    resolved_at TIMESTAMPTZ,
    affected_records_count INTEGER DEFAULT 0,
    root_cause TEXT,
    remediation_steps TEXT,
    lessons_learned TEXT,
    assigned_to UUID REFERENCES users(id),
    reported_by UUID REFERENCES users(id),
    dpdp_notified BOOLEAN DEFAULT FALSE,
    cert_in_notified BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 13.2 security_policies

```sql
CREATE TABLE security_policies (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    policy_code VARCHAR(20) UNIQUE NOT NULL,
    title VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL,
    version INTEGER NOT NULL DEFAULT 1,
    content TEXT NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    owner_id UUID REFERENCES users(id),
    effective_date DATE NOT NULL,
    next_review_date DATE,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

### 13.3 security_scan_results

```sql
CREATE TABLE security_scan_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    scan_id VARCHAR(50) NOT NULL,
    scan_type VARCHAR(30) NOT NULL,
    scanner_name VARCHAR(100) NOT NULL,
    scan_target VARCHAR(255) NOT NULL,
    severity VARCHAR(10) NOT NULL CHECK (severity IN ('critical','high','medium','low','info')),
    vulnerability_id VARCHAR(100),
    title TEXT NOT NULL,
    description TEXT,
    recommendation TEXT,
    file_path TEXT,
    line_number INTEGER,
    cvss_score DECIMAL(3,1),
    status VARCHAR(20) NOT NULL DEFAULT 'open',
    fix_commit_hash VARCHAR(40),
    assigned_to UUID REFERENCES users(id),
    due_date DATE,
    scan_started_at TIMESTAMPTZ NOT NULL,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

## 14. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|---|---|---|
| Password hashing | Argon2id | Memory-hard, resistant to GPU/ASIC attacks |
| Session tokens | JWT (RS256) | Stateless verification, public/private key pair |
| API authentication | JWT + API Keys | JWT for users, API keys for M2M |
| Rate limiting | Redis sliding window | Distributed, low-latency, per-IP and per-token |
| Encryption at rest | AES-256-GCM | Authenticated encryption prevents tampering |
| Key management | HSM + KMS | Master key in HSM, DEKs in KMS |
| Log monitoring | Wazuh SIEM | Open-source, DPDP compliance features |
| Incident response | Automated runbooks | Reduce MTTR, 72hr DPDP window compliance |

## 15. REFERENCES

- OWASP Top 10 (2021): https://owasp.org/Top10/
- DPDP Act 2023: India Digital Personal Data Protection Act
- IT Act 2000: India Information Technology Act
- ISO 27001:2022: Information Security Management Systems
- CERT-In: Indian Computer Emergency Response Team guidelines
- NIST SP 800-53: Security and Privacy Controls
- HIPAA Security Rule (for reference in international deployments)
- OWASP Dependency Check: https://owasp.org/www-project-dependency-check/
