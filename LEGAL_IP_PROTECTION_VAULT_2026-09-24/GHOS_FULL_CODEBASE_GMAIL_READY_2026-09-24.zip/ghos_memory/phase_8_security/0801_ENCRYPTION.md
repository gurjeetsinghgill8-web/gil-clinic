---
file_id: "0801"
module_name: "Encryption Standards"
version: "2.0"
status: "Approved"
phase: "Phase 8 - Security"
dependencies: ["0800_SECURITY.md"]
related_files: ["0802_BACKUP.md", "0803_AUDIT_LOG.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "encryption", "security", "cryptography", "key-management", "tls", "pii"]
---

# \U0001f512 GHOS \u2014 Encryption Standards

> **"Encryption is the last line of defense. When everything else fails, the data must remain unreadable."**
> Every byte of patient data is encrypted at rest, in transit, and during processing. There are no exceptions.

---

## 1. ENCRYPTION AT REST

### 1.1 Database-Level Encryption (PostgreSQL TDE)

PostgreSQL uses pg_tde extension for transparent data encryption at the tablespace level.

```sql
-- Load pg_tde extension
CREATE EXTENSION IF NOT EXISTS pg_tde;

-- Create encrypted tablespace
SELECT pg_tde_add_key_provider_file('file-vault', '/etc/pg_tde/key_vault');
SELECT pg_tde_set_principal_key('ghos_principal_key', 'file-vault');

CREATE TABLESPACE ghos_encrypted
    OWNER postgres
    LOCATION '/var/lib/postgresql/data/encrypted'
    WITH (encryption = 'aes-256-gcm');

-- Move existing tables to encrypted tablespace
ALTER TABLE patients SET TABLESPACE ghos_encrypted;
ALTER TABLE visits SET TABLESPACE ghos_encrypted;
ALTER TABLE prescriptions SET TABLESPACE ghos_encrypted;
```

### 1.2 Column-Level Encryption

Sensitive PII/PHI fields use column-level encryption with AES-256-GCM and Associated Data (AAD).

```sql
-- Encrypted columns stored as bytea
CREATE TABLE patient_encrypted (
    id UUID PRIMARY KEY REFERENCES patients(id),

    -- Encrypted with AAD = patient_id
    aadhaar_number BYTEA,        -- AES-256-GCM encrypted
    full_name BYTEA,             -- AES-256-GCM encrypted
    mobile_number BYTEA,         -- AES-256-GCM encrypted
    email BYTEA,                 -- AES-256-GCM encrypted
    address_line1 BYTEA,         -- AES-256-GCM encrypted
    emergency_contact BYTEA,     -- AES-256-GCM encrypted

    -- Deterministic encryption for exact-match queries
    aadhaar_hash VARCHAR(64),    -- SHA-256 hash for uniqueness check
    mobile_hash VARCHAR(64),     -- SHA-256 hash for duplicate detection

    -- Non-sensitive fields (plaintext)
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Encrypted index on hashed values
CREATE UNIQUE INDEX idx_patient_aadhaar_hash
    ON patient_encrypted(aadhaar_hash)
    WHERE aadhaar_hash IS NOT NULL;
```

### 1.3 File-Level Encryption (Envelope Encryption)

Uploaded files (reports, images, scans) use envelope encryption:

```python
class FileEncryptionService:
    """Envelope encryption for uploaded files."""

    def __init__(self, kms_client):
        self.kms = kms_client
        self.master_key_id = "arn:kms:region:account:key/ghos-master"

    async def encrypt_file(self, file_data: bytes,
                           patient_id: str) -> dict:
        # 1. Generate random DEK (Data Encryption Key)
        dek = os.urandom(32)  # AES-256 key

        # 2. Encrypt file with DEK (AES-256-GCM)
        nonce = os.urandom(12)
        cipher = AES.new(dek, AES.MODE_GCM, nonce=nonce)
        ciphertext, tag = cipher.encrypt_and_digest(file_data)

        # 3. Encrypt DEK with Master Key (via KMS)
        encrypted_dek = await self.kms.encrypt(
            KeyId=self.master_key_id,
            Plaintext=dek,
            EncryptionContext={"patient_id": patient_id}
        )

        return {
            "ciphertext": ciphertext,
            "nonce": nonce,
            "tag": tag,
            "encrypted_dek": encrypted_dek["CiphertextBlob"],
            "algorithm": "AES-256-GCM",
            "key_id": self.master_key_id
        }

    async def decrypt_file(self, encrypted_package: dict,
                           patient_id: str) -> bytes:
        # 1. Decrypt DEK using KMS
        dek = await self.kms.decrypt(
            CiphertextBlob=encrypted_package["encrypted_dek"],
            EncryptionContext={"patient_id": patient_id}
        )

        # 2. Decrypt file with DEK
        cipher = AES.new(
            dek["Plaintext"],
            AES.MODE_GCM,
            nonce=encrypted_package["nonce"]
        )
        plaintext = cipher.decrypt_and_verify(
            encrypted_package["ciphertext"],
            encrypted_package["tag"]
        )
        return plaintext
```

---

## 2. ENCRYPTION IN TRANSIT

### 2.1 TLS 1.3 Configuration

All external and internal communication uses TLS 1.3 with strong cipher suites.

```yaml
# nginx/traefik TLS configuration
tls:
  version:
    - "TLSv1.3"
    - "!TLSv1.2"       # Disable TLS 1.2 after migration complete
  ciphers:
    - "TLS_AES_256_GCM_SHA384"
    - "TLS_CHACHA20_POLY1305_SHA256"
    - "!TLS_AES_128_GCM_SHA256"  # Minimum 256-bit
  prefer_server_ciphers: true
  session_tickets: false
  ocsp_stapling: true
  ssl_stapling: true
  ssl_stapling_verify: true

# HSTS configuration
hsts:
  max_age: 31536000        # 1 year
  include_subdomains: true
  preload: true
```

### 2.2 mTLS for Internal Services

```yaml
# Istio mTLS configuration
apiVersion: security.istio.io/v1beta1
kind: PeerAuthentication
metadata:
  name: default
  namespace: ghos
spec:
  mtls:
    mode: STRICT  # All services require mTLS
---
apiVersion: security.istio.io/v1beta1
kind: AuthorizationPolicy
metadata:
  name: service-authz
  namespace: ghos
spec:
  selector:
    matchLabels:
      app: queue-engine
  rules:
    - from:
        - source:
            principals: ["cluster.local/ns/ghos/sa/auth-service"]
      to:
        - operation:
            methods: ["POST", "GET"]
```

### 2.3 Certificate Management

```python
class CertificateManager:
    """Automate certificate lifecycle via ACME/cert-manager."""

    ACME_SERVER = "https://acme-v02.api.letsencrypt.org/directory"
    CERT_RENEWAL_DAYS = 60  # Renew 60 days before expiry

    async def provision_certificate(self, domain: str) -> dict:
        """Request new certificate via ACME DNS-01 challenge."""
        cert = await self.acme_client.new_order(
            domains=[domain],
            challenge_type="dns-01"
        )
        # Set DNS TXT record for domain validation
        await self.dns_provider.set_txt_record(
            f"_acme-challenge.{domain}",
            cert.validation_token
        )
        await cert.validate()
        await cert.finalize()
        # Store in Kubernetes secret / vault
        await self.store_certificate(domain, cert)
        return {"domain": domain, "expiry": cert.expiry}

    async def check_renewal(self) -> list:
        """Check all certificates and renew those expiring soon."""
        certs = await self.list_certificates()
        renewals = []
        for cert in certs:
            days_remaining = (cert.expiry - datetime.utcnow()).days
            if days_remaining < self.CERT_RENEWAL_DAYS:
                renewals.append(await self.provision_certificate(cert.domain))
        return renewals
```

### 2.4 WebSocket Security (WSS)

```python
# WebSocket connections use WSS (TLS 1.3 + token auth)
WS_CONFIG = {
    "protocol": "wss",
    "tls_version": "TLSv1.3",
    "auth": "JWT token in query string (expires in 5 min)",
    "rate_limit": "10 connections per user",
    "idle_timeout": 1800,  # 30 min
    "message_size_limit": "64KB",
    "ping_interval": 30,   # seconds
    "ping_timeout": 10     # seconds
}
```

---

## 3. KEY MANAGEMENT

### 3.1 Key Hierarchy

```
+--------------------------------------------------+
|              MASTER KEY (HSM)                     |
|  - Stored in AWS CloudHSM / Azure Dedicated HSM   |
|  - Never leaves HSM boundary                      |
|  - Used only to wrap/unwrap KEKs                  |
|  - Rotation: Every 365 days                       |
+--------------------------------------------------+
                       |
                       v
+--------------------------------------------------+
|              KEY ENCRYPTION KEYS (KEKs)           |
|  - Stored in KMS (AWS KMS / HashiCorp Vault)      |
|  - One KEK per encryption context                 |
|  - Used to encrypt/decrypt DEKs                   |
|  - Rotation: Every 90 days                        |
+--------+-----------------------------------------+
         |
         +------------------+------------------+
         v                  v                  v
+--------+--------+  +-----+--------+  +------+-------+
| DEK - Database  |  | DEK - Files  |  | DEK - Backups|
| AES-256-GCM     |  | AES-256-GCM  |  | AES-256-GCM  |
| Rotate: 30 days |  | Rotate: 90   |  | Rotate: 365  |
+-----------------+  +--------------+  +--------------+
         |                  |                  |
         v                  v                  v
+--------+--------+  +-----+--------+  +------+-------+
| Encrypted Data  |  | Encrypted    |  | Encrypted    |
| in PostgreSQL   |  | Files (S3)   |  | Backups      |
+-----------------+  +--------------+  +--------------+
```

### 3.2 Key Rotation Strategy

```python
class KeyRotationManager:
    """Manage key lifecycle with dual-key reads for zero-downtime rotation."""

    ROTATION_SCHEDULE = {
        "master_key": 365,   # days
        "kek": 90,
        "dek_database": 30,
        "dek_files": 90,
        "dek_backups": 365
    }

    async def rotate_dek(self, context: str) -> dict:
        """Rotate a DEK with zero-downtime dual-key reads."""
        # 1. Generate new DEK
        new_dek = os.urandom(32)
        new_key_id = str(uuid.uuid4())

        # 2. Wrap with current KEK
        encrypted_new_dek = await self.kms.encrypt(
            KeyId=self.current_kek_id,
            Plaintext=new_dek,
            EncryptionContext={"context": context}
        )

        # 3. Store new DEK version (active)
        await KeyVersion.create(
            key_id=new_key_id,
            context=context,
            encrypted_dek=encrypted_new_dek["CiphertextBlob"],
            kek_id=self.current_kek_id,
            status="active",
            created_at=datetime.utcnow()
        )

        # 4. Mark old DEK as "deprecated" (still readable)
        old_version = await KeyVersion.get(
            context=context, status="active")
        if old_version:
            old_version.status = "deprecated"
            await old_version.save()

        # 5. Re-encrypt data in background (lazy re-encryption)
        await self._schedule_reencryption(context, new_key_id)

        return {
            "new_key_id": new_key_id,
            "old_key_id": old_version.key_id if old_version else None,
            "status": "rotated"
        }

    async def decrypt_with_rotation(self, context: str,
                                     encrypted_data: bytes,
                                     key_id: str) -> bytes:
        """Decrypt using the correct key version (supports dual-key)."""
        # Try active key first
        key_version = await KeyVersion.get(key_id=key_id)
        if not key_version:
            raise ValueError(f"Key version {key_id} not found")

        # Decrypt DEK
        dek = await self.kms.decrypt(
            CiphertextBlob=key_version.encrypted_dek,
            EncryptionContext={"context": context}
        )

        # Decrypt data
        return self._aes_decrypt(encrypted_data, dek["Plaintext"])

    async def _schedule_reencryption(self, context: str,
                                      new_key_id: str):
        """Background job to re-encrypt data with new DEK."""
        # Enqueue re-encryption task
        await queue.enqueue("reencrypt_data", {
            "context": context,
            "new_key_id": new_key_id,
            "batch_size": 1000
        })
```

### 3.3 HSM for Critical Keys

```yaml
hsm_config:
  provider: "AWS CloudHSM"  # or "Azure Dedicated HSM"
  cluster_id: "hsm-ghos-production"
  partitions:
    - label: "master-key"
      purpose: "Wrap/unwrap KEKs"
      quorum: 2  # 2-of-3 approval required
    - label: "signing-key"
      purpose: "Digital signatures on clinical documents"
      quorum: 1
    - label: "tls-root"
      purpose: "Internal CA for mTLS certificates"
      quorum: 2
  access:
    - role: "security-admin"
      permission: "manage"
    - role: "crypto-operator"
      permission: "use"
```

---

## 4. FIELD-LEVEL ENCRYPTION

### 4.1 Encrypted PII Fields

| Field           | Algorithm     | Mode       | AAD                | Searchable |
|-----------------|---------------|------------|--------------------|------------|
| Aadhaar Number  | AES-256       | GCM        | patient_id         | Hash index |
| Full Name       | AES-256       | GCM        | patient_id         | No         |
| Mobile Number   | AES-256       | GCM        | patient_id         | Hash index |
| Email           | AES-256       | GCM        | patient_id         | Hash index |
| Address         | AES-256       | GCM        | patient_id         | No         |
| Diagnosis Text  | AES-256       | GCM        | visit_id           | No         |
| Emergency Contact| AES-256      | GCM        | patient_id         | No         |

### 4.2 Searchable Encryption

```python
class SearchableEncryption:
    """Deterministic encryption for exact-match search queries."""

    def __init__(self, master_key: bytes):
        self.master_key = master_key

    def encrypt_deterministic(self, plaintext: str,
                               context: str) -> str:
        """AES-SIV mode for deterministic encryption (exact match)."""
        siv = AES.new(self.master_key, AES.MODE_SIV)
        ciphertext, siv_tag = siv.encrypt_and_digest(
            plaintext.encode(), context.encode())
        return base64.b64encode(ciphertext + siv_tag).decode()

    def decrypt_deterministic(self, ciphertext_b64: str,
                               context: str) -> str:
        raw = base64.b64decode(ciphertext_b64)
        ciphertext = raw[:-16]
        siv_tag = raw[-16:]
        siv = AES.new(self.master_key, AES.MODE_SIV)
        plaintext = siv.decrypt_and_verify(
            ciphertext, siv_tag, context.encode())
        return plaintext.decode()

    def create_blind_index(self, value: str) -> str:
        """Blind index for fuzzy search using HMAC + Bloom filter."""
        hmac_key = self._derive_blind_index_key()
        h = hmac.new(hmac_key, value.encode(), hashlib.sha256)
        return h.hexdigest()[:16]  # Truncate for index size
```

### 4.3 Column Encryption Functions

```python
from cryptography.hazmat.primitives.ciphers.aead import AESGCM
import os, base64

def encrypt_data(plaintext: str, key: bytes,
                 aad: bytes = b"") -> str:
    """Encrypt a single field with AES-256-GCM."""
    aesgcm = AESGCM(key)
    nonce = os.urandom(12)
    ciphertext = aesgcm.encrypt(nonce, plaintext.encode(), aad)
    # Return: nonce + ciphertext, base64 encoded
    return base64.b64encode(nonce + ciphertext).decode()

def decrypt_data(ciphertext_b64: str, key: bytes,
                 aad: bytes = b"") -> str:
    """Decrypt a field encrypted with encrypt_data()."""
    raw = base64.b64decode(ciphertext_b64)
    nonce = raw[:12]
    ciphertext = raw[12:]
    aesgcm = AESGCM(key)
    plaintext = aesgcm.decrypt(nonce, ciphertext, aad)
    return plaintext.decode()
```

---

## 5. PASSWORD HASHING

### 5.1 Argon2id Configuration

```python
from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError

# Global password hasher with secure defaults
ph = PasswordHasher(
    time_cost=3,          # 3 iterations
    memory_cost=65536,    # 64 MB
    parallelism=4,        # 4 threads
    hash_len=32,          # 256-bit output
    salt_len=16,          # 128-bit salt
    type="ID"             # Argon2id (hybrid)
)

def hash_password(password: str) -> str:
    """Hash password with Argon2id. Returns encoded hash string."""
    return ph.hash(password)

def verify_password(password: str, hashed: str) -> bool:
    """Verify password against Argon2id hash."""
    try:
        return ph.verify(hashed, password)
    except VerifyMismatchError:
        return False

def needs_rehash(hashed: str) -> bool:
    """Check if hash uses current parameters."""
    return ph.check_needs_rehash(hashed)
```

### 5.2 Pepper Architecture

```python
class PepperedHasher:
    """Add server-side pepper before Argon2id hashing."""

    def __init__(self, pepper_key: bytes):
        # Pepper is stored in HSM / Vault, never in application config
        self.pepper = pepper_key

    def _apply_pepper(self, password: str) -> bytes:
        """HMAC-SHA256(pepper, password) -> pre-hash."""
        return hmac.new(
            self.pepper,
            password.encode(),
            hashlib.sha256
        ).digest()

    def hash_with_pepper(self, password: str) -> str:
        pre_hash = self._apply_pepper(password)
        return ph.hash(base64.b64encode(pre_hash).decode())

    def verify_with_pepper(self, password: str,
                            hashed: str) -> bool:
        pre_hash = self._apply_pepper(password)
        return verify_password(
            base64.b64encode(pre_hash).decode(), hashed)

    async def rotate_pepper(self, old_pepper: bytes):
        """Re-hash all passwords with new pepper (requires user re-login)."""
        # Old pepper retained until last user with old hash re-logs in
        await self._set_current_pepper(self.pepper)
        await self._archive_pepper(old_pepper)
```

### 5.3 Migration from bcrypt

```python
class PasswordMigration:
    """Gradual migration from bcrypt to Argon2id."""

    async def verify_with_migration(self, password: str,
                                     stored_hash: str) -> bool:
        """Verify and upgrade hash if needed."""
        is_argon2 = stored_hash.startswith("$argon2id$")

        if is_argon2:
            return verify_password(password, stored_hash)

        # bcrypt verification
        if bcrypt.checkpw(password.encode(), stored_hash.encode()):
            # Upgrade to Argon2id on successful login
            new_hash = hash_password(password)
            await self._update_user_hash(stored_hash, new_hash)
            return True

        return False
```

---

==SPLIT2==

## 6. DATABASE ENCRYPTION

### 6.1 pg_tde Tablespace Configuration

```sql
-- Create key provider and principal key
SELECT pg_tde_add_key_provider_file('provider1', '/etc/pg_tde/keys');
SELECT pg_tde_set_principal_key('ghos_prod_key', 'provider1');

-- Create encrypted tablespaces per sensitivity tier
CREATE TABLESPACE ghos_c4_critical
    OWNER postgres LOCATION '/data/pg_tde/c4'
    WITH (encryption = 'aes-256-gcm');

CREATE TABLESPACE ghos_c3_high
    OWNER postgres LOCATION '/data/pg_tde/c3'
    WITH (encryption = 'aes-256-gcm');

-- Assign tables to encrypted tablespaces
ALTER TABLE patient_encrypted SET TABLESPACE ghos_c4_critical;
ALTER TABLE medical_records SET TABLESPACE ghos_c4_critical;
ALTER TABLE prescriptions SET TABLESPACE ghos_c3_high;

-- Enable pgaudit for encryption access logging
CREATE EXTENSION IF NOT EXISTS pgaudit;
ALTER SYSTEM SET pgaudit.log = 'write,read';
ALTER SYSTEM SET pgaudit.log_level = 'notice';
```

### 6.2 Encrypted Columns JSON Schema

```json
{
  "patient_encrypted": {
    "columns": {
      "aadhaar_number": {
        "algorithm": "AES-256-GCM",
        "key_id": "dek_pii_v2",
        "aad": ["patient_id"],
        "searchable": "hash_index",
        "mask_ui": "XXXX-XXXX-{last4}"
      },
      "full_name": {
        "algorithm": "AES-256-GCM",
        "key_id": "dek_pii_v2",
        "aad": ["patient_id"],
        "searchable": false,
        "mask_ui": "{first} {last_initial}."
      },
      "mobile_number": {
        "algorithm": "AES-256-GCM",
        "key_id": "dek_pii_v2",
        "aad": ["patient_id"],
        "searchable": "hash_index",
        "mask_ui": "XXXXXX{last4}"
      },
      "diagnosis": {
        "algorithm": "AES-256-GCM",
        "key_id": "dek_clinical_v1",
        "aad": ["visit_id"],
        "searchable": false,
        "mask_ui": false
      }
    }
  }
}
```

### 6.3 Backup Encryption

```yaml
backup_encryption:
  database_dumps:
    tool: pg_dump --encrypt-key={backup_dek_id}
    algorithm: AES-256-GCM
    storage: S3 with SSE-KMS
    retention:
      daily: 30 days
      weekly: 6 months
      monthly: 3 years
      yearly: 7 years

  wal_archives:
    tool: pg_receivewal
    encryption: TLS 1.3 in transit, AES-256 at rest
    storage: S3 Glacier Deep Archive
    retention: 30 days

  test_restores:
    schedule: Weekly (Sunday 0200 IST)
    process: Restore encrypted backup -> decrypt -> validate -> delete
    auditor: Security team + external auditor (quarterly)

tenant_key_separation:
  single_tenant: true  # Each hospital gets its own DEK
  isolation: |
    KEK per hospital (stored in Vault namespace)
    DEK per hospital per context (database, files, backups)
    Cross-tenant access: IMPOSSIBLE (different encryption keys)
```

---

## 7. FILE ENCRYPTION

### 7.1 Envelope Encryption for Uploaded Files

```python
class FileEncryptionService:
    """Envelope encryption: unique DEK per file."""

    async def encrypt_upload(self, file_stream: BinaryIO,
                              patient_id: str,
                              file_type: str) -> FileRecord:
        # 1. Generate unique DEK for this file
        file_dek = os.urandom(32)

        # 2. Read file and encrypt in chunks
        encrypted_chunks = []
        nonce = os.urandom(12)
        cipher = AES.new(file_dek, AES.MODE_GCM, nonce=nonce)

        while True:
            chunk = file_stream.read(65536)  # 64KB chunks
            if not chunk:
                break
            encrypted_chunks.append(
                cipher.encrypt(chunk))

        # Finalize with authentication tag
        encrypted_chunks.append(cipher.digest())

        # 3. Wrap DEK with KEK
        encrypted_dek = await self.kms.encrypt(
            KeyId=f"kek_{file_type}",
            Plaintext=file_dek,
            EncryptionContext={
                "patient_id": patient_id,
                "file_type": file_type
            }
        )

        # 4. Store file metadata
        file_record = FileRecord(
            patient_id=patient_id,
            file_type=file_type,
            encrypted_dek=encrypted_dek["CiphertextBlob"],
            kek_id=f"kek_{file_type}",
            iv=nonce,
            tag=cipher.digest(),
            algorithm="AES-256-GCM",
            size=sum(len(c) for c in encrypted_chunks),
            uploaded_at=datetime.utcnow()
        )
        await file_record.save()

        # 5. Upload encrypted data to S3/MinIO
        await self.storage.upload(
            bucket="ghos-encrypted-files",
            key=file_record.storage_key,
            data=b"".join(encrypted_chunks)
        )

        return file_record

    async def decrypt_download(self, file_id: UUID) -> BinaryIO:
        file_record = await FileRecord.get(id=file_id)

        # 1. Decrypt DEK
        dek = await self.kms.decrypt(
            CiphertextBlob=file_record.encrypted_dek,
            EncryptionContext={
                "patient_id": str(file_record.patient_id),
                "file_type": file_record.file_type
            }
        )

        # 2. Download encrypted data
        encrypted_data = await self.storage.download(
            bucket="ghos-encrypted-files",
            key=file_record.storage_key
        )

        # 3. Decrypt
        cipher = AES.new(
            dek["Plaintext"], AES.MODE_GCM,
            nonce=file_record.iv
        )
        ciphertext = encrypted_data[:-16]
        tag = encrypted_data[-16:]
        plaintext = cipher.decrypt_and_verify(ciphertext, tag)

        return BytesIO(plaintext)
```

### 7.2 Encrypted CDN Delivery

```yaml
cdn_encryption:
  provider: CloudFront / Cloudflare
  origin: S3 (SSE-KMS encrypted)
  behavior:
    - path: /files/*
      viewer_protocol: https-only
      cache_policy: CachingOptimized
      origin_request_policy: AllViewerExceptHostHeader
  signed_urls:
    enabled: true
    expiration: 3600  # 1 hour
    signer: "cloudfront-keypair"
  geo_restriction:
    type: whitelist
    countries: [IN, US, GB, AE, SG]  # Clinic locations
```

### 7.3 Secure File Purge

```python
class SecureFilePurger:
    """Securely delete files with cryptographic erase."""

    async def purge_file(self, file_id: UUID):
        file_record = await FileRecord.get(id=file_id)

        # 1. Delete DEK first (renders file permanently undecryptable)
        await self.kms.schedule_key_deletion(
            KeyId=file_record.kek_id,
            PendingWindowInDays=7
        )

        # 2. Overwrite storage with zeros
        await self.storage.overwrite(
            bucket="ghos-encrypted-files",
            key=file_record.storage_key,
            data=b"\x00" * 65536 * 10  # Overwrite with zeros
        )

        # 3. Delete file from storage
        await self.storage.delete(
            bucket="ghos-encrypted-files",
            key=file_record.storage_key
        )

        # 4. Delete metadata record
        file_record.status = "purged"
        file_record.purged_at = datetime.utcnow()
        await file_record.save()

        # 5. Log purge audit
        await audit_log.log(
            action="file_purged",
            resource_type="file",
            resource_id=str(file_id),
            details="Cryptographic erase completed"
        )
```

---

## 8. DATABASE SCHEMAS

### 8.1 encryption_keys

```sql
CREATE TABLE encryption_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key_id VARCHAR(100) UNIQUE NOT NULL,
    key_type VARCHAR(20) NOT NULL CHECK (
        key_type IN ('master', 'kek', 'dek', 'signing', 'pepper')),
    algorithm VARCHAR(30) NOT NULL DEFAULT 'AES-256-GCM',
    key_source VARCHAR(50) NOT NULL,
    -- Sources: hsm, kms, file_provider, vault
    encrypted_key_material BYTEA,
    key_hash VARCHAR(64) NOT NULL,
    key_length INTEGER NOT NULL DEFAULT 256,
    context VARCHAR(100),
    -- e.g. 'database_pii', 'files_reports', 'backups'
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'deprecated', 'destroyed', 'compromised')),
    version INTEGER NOT NULL DEFAULT 1,
    created_by UUID REFERENCES users(id),
    activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    expires_at TIMESTAMPTZ,
    destroyed_at TIMESTAMPTZ,
    rotation_due_date TIMESTAMPTZ,
    parent_key_id VARCHAR(100) REFERENCES encryption_keys(key_id),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_ek_type ON encryption_keys(key_type);
CREATE INDEX idx_ek_status ON encryption_keys(status);
CREATE INDEX idx_ek_context ON encryption_keys(context);
CREATE INDEX idx_ek_rotation ON encryption_keys(rotation_due_date);
CREATE INDEX idx_ek_parent ON encryption_keys(parent_key_id);
```

### 8.2 key_versions

```sql
CREATE TABLE key_versions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    key_id VARCHAR(100) NOT NULL REFERENCES encryption_keys(key_id),
    version INTEGER NOT NULL,
    encrypted_dek BYTEA NOT NULL,
    kek_id VARCHAR(100) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active' CHECK (
        status IN ('active', 'deprecated', 'promoted')),
    activated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    deprecated_at TIMESTAMPTZ,
    control_hash VARCHAR(64) NOT NULL,
    -- SHA-256 of (key_id || version || encrypted_dek)
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(key_id, version)
);

CREATE INDEX idx_kv_key ON key_versions(key_id);
CREATE INDEX idx_kv_status ON key_versions(status);
```

### 8.3 data_encryption_config

```sql
CREATE TABLE data_encryption_config (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name VARCHAR(100) NOT NULL,
    column_name VARCHAR(100) NOT NULL,
    data_tier VARCHAR(10) NOT NULL CHECK (
        data_tier IN ('C1', 'C2', 'C3', 'C4')),
    algorithm VARCHAR(30) NOT NULL DEFAULT 'AES-256-GCM',
    key_id VARCHAR(100) NOT NULL REFERENCES encryption_keys(key_id),
    encryption_mode VARCHAR(20) NOT NULL CHECK (
        encryption_mode IN ('deterministic', 'random', 'hash_only')),
    aad_columns TEXT[] DEFAULT '{}',
    searchable BOOLEAN DEFAULT FALSE,
    search_index_type VARCHAR(20),
    -- Types: hash_index, blind_index, encrypted_index
    mask_expression VARCHAR(200),
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    UNIQUE(table_name, column_name)
);

CREATE INDEX idx_dec_tier ON data_encryption_config(data_tier);
CREATE INDEX idx_dec_key ON data_encryption_config(key_id);
```

---

## 9. KEY ROTATION PROTOCOL

### 9.1 Zero-Downtime Key Rotation Procedure

```
PHASE 1: PREPARE (Pre-rotation)
  1. Notify security team: "Rotation scheduled for {key_id}"
  2. Verify KMS/HSM is healthy and has capacity
  3. Ensure dual-key read capability is enabled
  4. Create monitoring dashboard for rotation metrics
  5. Run pre-rotation validation tests

PHASE 2: GENERATE (New key creation)
  1. Generate new key material (source of randomness: HSM)
  2. Wrap new DEK with KEK via KMS
  3. Store in encryption_keys table with status='active'
  4. Update data_encryption_config to point primary to new key
  5. Mark old key as status='deprecated'

PHASE 3: DUAL-KEY READS (Migration window)
  ┌─────────────────────────────┐
  │ READ path:                  │
  │   1. Try new key to decrypt │
  │   2. Fall back to old key   │
  │ WRITE path:                 │
  │   1. Always encrypt with    │
  │      new key                │
  └─────────────────────────────┘
  1. All new data encrypted with new key
  2. Existing data still readable via old key (deprecated)
  3. Monitor error rates: should be 0%

PHASE 4: RE-ENCRYPT (Background migration)
  1. Batch re-encrypt existing data with new key
     - Process: SELECT old data -> decrypt with old key -> encrypt with new key -> UPDATE
     - Batch size: 1000 records
     - Rate limit: 10000 records/min (avoid IO contention)
  2. Verify re-encrypted data integrity (decrypt and compare hash)
  3. Update key_versions table

PHASE 5: RETIRE (Old key removal)
  1. Verify all data re-encrypted (SELECT count WHERE encrypted_with=old_key)
  2. If count > 0: continue PHASE 4
  3. If count == 0:
     a. Set old key status = 'destroyed'
     b. Schedule KMS key deletion (30-day pending window)
     c. Remove from dual-key read path
     d. Archive key material to cold storage (compliance)

PHASE 6: VERIFY (Post-rotation)
  1. Run full encryption health check
  2. Verify all data planes (database, files, backups, logs)
  3. Generate rotation completion report
  4. Schedule next rotation date
```

### 9.2 Rotation Automation Script

```python
class KeyRotationOrchestrator:
    """Orchestrate zero-downtime key rotation across all services."""

    async def rotate_key(self, key_id: str) -> dict:
        """Execute full rotation lifecycle for a key."""
        config = await DataEncryptionConfig.filter(
            key_id=key_id).first()
        if not config:
            raise ValueError(f"No config found for key {key_id}")

        # PHASE 1: Generate new key
        new_key = await self._generate_new_key(config)
        old_key_id = key_id

        # PHASE 2: Enable dual-key reads
        await self._enable_dual_key_reads(old_key_id, new_key.key_id)

        # PHASE 3: Background re-encryption
        reencrypt_job = await self._start_reencryption(
            config.table_name,
            config.column_name,
            old_key_id,
            new_key.key_id
        )

        # PHASE 4: Wait for completion and retire
        while True:
            status = await self._check_reencryption_progress(
                reencrypt_job.job_id)
            if status["remaining"] == 0:
                break
            await asyncio.sleep(60)

        await self._retire_key(old_key_id, new_key.key_id)

        return {
            "old_key_id": old_key_id,
            "new_key_id": new_key.key_id,
            "records_reencrypted": status["processed"],
            "duration_seconds": status["duration"]
        }

    async def _generate_new_key(self, config: dict) -> KeyVersion:
        """Create new key version with fresh material."""
        new_dek = os.urandom(32)
        encrypted_dek = await self.kms.encrypt(
            KeyId=config["kek_id"],
            Plaintext=new_dek
        )
        new_key = await KeyVersion.create(
            key_id=str(uuid.uuid4()),
            version=config["version"] + 1,
            encrypted_dek=encrypted_dek["CiphertextBlob"],
            kek_id=config["kek_id"],
            status="active"
        )
        return new_key

    async def _enable_dual_key_reads(self, old_key_id: str,
                                       new_key_id: str):
        """Configure application layer for dual-key decryption."""
        await self.config_client.set(
            f"encryption/dual_keys/{old_key_id}",
            {"primary": new_key_id, "fallback": old_key_id}
        )
        # Rollout to all service instances
        await self.config_client.publish(
            "encryption/key_rotation",
            {"action": "enable_dual_read",
             "old_key": old_key_id,
             "new_key": new_key_id}
        )

    async def _check_reencryption_progress(self, job_id: str) -> dict:
        """Check background re-encryption job status."""
        job = await ReencryptionJob.get(id=job_id)
        return {
            "total": job.total_records,
            "processed": job.processed_records,
            "remaining": job.total_records - job.processed_records,
            "duration": (datetime.utcnow() - job.started_at).total_seconds()
        }
```

---

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|----------|
| Symmetric algorithm | AES-256-GCM | Authenticated encryption, NIST approved, hardware acceleration |
| Asymmetric algorithm | RSA-4096 / ECDSA P-384 | Key exchange and digital signatures |
| Hash algorithm | SHA-256 / SHA-384 | Sufficient for security, avoids SHA-1 weaknesses |
| KDF | Argon2id | Memory-hard, resistant to GPU/ASIC attacks |
| Key wrapping | AES Key Wrap (RFC 3394) | Standardized, NIST approved |
| TLS version | 1.3 minimum | Forward secrecy, reduced handshake latency |
| Certificate type | ECDSA P-384 | Smaller keys, faster than RSA |
| HSM | AWS CloudHSM | FIPS 140-2 Level 3, automatic key backup |
| KMS | AWS KMS with automatic rotation | Managed service, audit integration |
| DEK per file | Yes | Limits blast radius of a single key compromise |
| Searchable encryption | Hash index + blind index | Privacy-preserving search without decrypting |
| Password hash migration | Gradual (bcrypt -> Argon2id) | Zero user friction, upgrade on login |

---

## 11. REFERENCES

- NIST SP 800-57: Recommendation for Key Management
- NIST SP 800-38D: GCM Mode of Operation
- RFC 5280: Internet X.509 PKI Certificate Profile
- RFC 8446: TLS 1.3 Protocol
- OWASP Cryptographic Storage Cheat Sheet
- Argon2 RFC 9106: Memory-hard password hashing
- pg_tde documentation: https://github.com/Percona-Lab/pg_tde
- AWS KMS Best Practices: https://docs.aws.amazon.com/kms/latest/developerguide/best-practices.html