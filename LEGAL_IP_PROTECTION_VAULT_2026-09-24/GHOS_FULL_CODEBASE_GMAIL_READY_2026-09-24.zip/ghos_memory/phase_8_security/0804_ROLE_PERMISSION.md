---
file_id: "0804"
module_name: "Role Permission Matrix"
version: "1.0"
status: "Draft"
phase: "Phase 8 — Security"
dependencies: ["0106_PERMISSION_ENGINE.md"]
related_files: ["0203_ADMIN_MODULE.md", "0800_SECURITY.md", "0803_AUDIT_LOG.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "roles", "permissions", "rbac", "matrix", "access-control", "abac", "security"]
---

# GHOS — Role Permission Matrix

> **Permissions are the gatekeepers of the system. Every action, every screen, every byte of data flows through a permission check. We deny by default, allow by exception.**

---

## 1. PURPOSE

The Role Permission Matrix defines every role in the GHOS system, every permission each role carries, and the mechanics by which permissions are evaluated at runtime. It is the single source of truth for authorization.

This document covers:
- All 12 system roles and their hierarchy
- The complete permission matrix (12 roles x 20 resource categories)
- Dynamic permission evaluation with the PermissionEngine
- Attribute-Based Access Control (ABAC) extensions
- Role inheritance and permission resolution
- API guards, middleware, and caching
- SQL schemas for persistence
- Audit and suspicious-activity detection

## 2. ROLE HIERARCHY

### 2.1 Role Tree

```
super_admin (GHOS-level, unlimited cross-hospital access)
  |
  +-- hospital_admin (single hospital: all admin + all clinical + all billing)
       |
       +-- branch_manager (branch oversight: reports, staff, inventory)
       |
       +-- doctor (clinical care: diagnose, prescribe, order tests)
       |     +-- senior_doctor (inherits doctor + sign reports, supervise)
       |
       +-- nurse (vitals, clinical assist, patient monitoring)
       |
       +-- receptionist (registration, appointments, queue management)
       |
       +-- lab_technician (lab tests, result entry, equipment)
       |
       +-- pharmacist (dispensing, inventory, verify prescriptions)
       |
       +-- accountant (billing, payments, refunds, settlements)
       |
       +-- patient (self-service: own records, appointments, payments)
       |
       +-- ai_agent (API-only: limited scope, rate-limited, audited)
       |
       +-- auditor (read-only: full system audit, logs, reports)
```

### 2.2 Inheritance Rules

| Role | Inherits From | Key Additional Permissions |
|------|---------------|---------------------------|
| super_admin | (none — explicit all-access) | Cross-hospital *, bypasses all checks |
| hospital_admin | doctor, receptionist, accountant | admin.*, settings, reports, branches |
| branch_manager | receptionist, accountant (partial) | branch.reports, staff.view, inventory.view |
| senior_doctor | doctor | report.sign (all), report.verify |
| doctor | (none) | patient.view/update, queue.call, doctor.prescribe |
| nurse | (none) | nurse.vitals, patient.view (dept-scoped) |
| receptionist | (none) | patient.create, queue.view/call, appointment.* |
| lab_technician | (none) | lab.perform, lab.enter_result, inventory.view |
| pharmacist | (none) | pharmacy.dispense, pharmacy.verify, inventory.adjust |
| accountant | (none) | billing.create, billing.payment, billing.settle |
| patient | (none) | patient.view (self only), appointment.self |
| ai_agent | (none) | patient.view (API), queue.view (API), no PHI write |
| auditor | (none) | *.view (read-only), audit.*, report.* (read) |

---
## 3. RESOURCE CATEGORIES

The GHOS permission system defines 20 resource categories. Each category supports specific actions.

| # | Category | Actions | Description |
|---|----------|---------|-------------|
| 1 | patient | view, create, update, delete, merge, export | Patient demographic and medical records |
| 2 | queue | view, call, skip, complete, transfer, prioritize | Queue management and token workflow |
| 3 | appointment | view, create, update, cancel, reschedule | Appointment scheduling |
| 4 | clinical | diagnose, prescribe, order_test, view_report, sign_report | Clinical workflow |
| 5 | billing | view, create, payment, refund, void, settle, adjust | Financial transactions |
| 6 | pharmacy | dispense, verify, return, adjust_stock, view | Pharmacy and dispensing |
| 7 | lab | view, perform, enter_result, verify_result, view_result | Laboratory operations |
| 8 | inventory | view, add, adjust, transfer, audit, order | Stock and inventory management |
| 9 | report | view, create, export, delete, schedule | System reports and analytics |
| 10 | audit | view, export, archive | Audit log access |
| 11 | admin.staff | view, create, update, deactivate, assign_role | Staff user management |
| 12 | admin.settings | view, update, toggle | Hospital configuration |
| 13 | admin.branch | view, create, update, toggle | Branch management |
| 14 | admin.subscription | view, update, cancel | Subscription and plan management |
| 15 | notification | view, send, template, configure | Communication and notifications |
| 16 | document | view, upload, delete, sign | Document attachment management |
| 17 | consent | view, collect, revoke, audit | Patient consent management |
| 18 | compliance | view, check, report | Compliance checks and reporting |
| 19 | analytics | view, create, export, dashboard | Business intelligence |
| 20 | system | health, config, logs, backup | System administration |

---
## 4. FULL PERMISSION MATRIX

### 4.1 Core Clinical and Operations

```
                    patient            queue              appointment        clinical
                    v  c  u  d  m  |  v  c  s  k  t  |  v  c  u  x  r  |  d  p  o  vr sr

super_admin         A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A
hospital_admin      A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A
branch_manager      A  A  A  -  -  |  A  A  A  A  -  |  A  A  A  A  A  |  -  -  -  A  -
doctor              A  -  A  -  -  |  A  A  -  A  A  |  A  A  A  A  A  |  A  A  A  A  A
senior_doctor       A  -  A  -  -  |  A  A  -  A  A  |  A  A  A  A  A  |  A  A  A  A  A
nurse               A  -  A  -  -  |  A  -  -  -  -  |  A  -  -  -  -  |  -  -  A  A  -
receptionist        A  A  A  -  -  |  A  A  A  A  -  |  A  A  A  A  A  |  -  -  -  -  -
lab_technician      A  -  -  -  -  |  A  A  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -
pharmacist          A  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  A  -
accountant          A  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -
patient             O  -  -  -  -  |  -  -  -  -  -  |  O  O  O  O  O  |  -  -  -  O  -
ai_agent            A  -  -  -  -  |  A  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -
auditor             A  -  -  -  -  |  A  -  -  -  -  |  A  -  -  -  -  |  -  -  -  A  -
```

Legend: A=Allow (global), O=Allow (own/self only), -=Deny
Actions: v=view, c=create, u=update, d=delete, m=merge
         s=skip, k=complete, t=transfer, x=cancel, r=reschedule
         d=diagnose, p=prescribe, o=order_test, vr=view_report, sr=sign_report

### 4.2 Financial and Pharmacy

```
                    billing               pharmacy              lab
                    v  c  p  f  vd st  |  d  v  r  as vw  |  v  p  er vr vrf

super_admin         A  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A
hospital_admin      A  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A  A  A
branch_manager      A  -  -  -  -  -  |  -  -  -  A  A  |  A  -  -  -  -
doctor              -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  A  -
senior_doctor       -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  A  -
nurse               -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  A  A  -
receptionist        -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -
lab_technician      -  -  -  -  -  -  |  -  -  -  -  -  |  A  A  A  A  -
pharmacist          -  -  -  -  -  -  |  A  A  A  A  A  |  -  -  -  -  -
accountant          A  A  A  A  A  A  |  -  -  -  -  -  |  -  -  -  -  -
patient             O  -  A  -  -  -  |  -  -  -  -  -  |  -  -  -  O  -
ai_agent            -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -  -  -
auditor             A  -  -  -  -  -  |  A  -  -  -  -  |  A  -  -  A  -
```

Actions: v=view, c=create, p=payment, f=refund, vd=void, st=settle
         d=dispense, v=verify, r=return, as=adjust_stock, vw=view
         p=perform, er=enter_result, vr=view_result, vrf=verify_result

### 4.3 Inventory, Reports, Audit

```
                    inventory             report               audit
                    v  a  ad tr au or  |  v  c  ex d  s   |  v  ex  ar

super_admin         A  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A
hospital_admin      A  A  A  A  A  A  |  A  A  A  A  A  |  A  A  A
branch_manager      A  A  A  A  -  -  |  A  A  A  -  A  |  A  A  -
doctor              -  -  -  -  -  -  |  A  A  -  -  -  |  -  -  -
senior_doctor       -  -  -  -  -  -  |  A  A  -  -  A  |  -  -  -
nurse               -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -
receptionist        -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -
lab_technician      A  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -
pharmacist          A  A  A  -  -  -  |  -  -  -  -  -  |  -  -  -
accountant          -  -  -  -  -  -  |  A  A  A  -  -  |  -  -  -
patient             -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -
ai_agent            -  -  -  -  -  -  |  -  -  -  -  -  |  -  -  -
auditor             A  -  -  -  -  -  |  A  A  A  -  -  |  A  A  A
```

Actions: v=view, a=add, ad=adjust, tr=transfer, au=audit, or=order
         ex=export, d=delete, s=schedule, ar=archive

### 4.4 Admin Functions

```
                    admin.staff           admin.settings        admin.branch
                    v  c  u  d  ar  |  v  up to  |  v  c  u  t

super_admin         A  A  A  A  A  |  A  A  A  |  A  A  A  A
hospital_admin      A  A  A  A  A  |  A  A  A  |  A  A  A  A
branch_manager      A  -  -  -  -  |  -  -  -  |  A  -  -  -
doctor              -  -  -  -  -  |  -  -  -  |  -  -  -  -
nurse               -  -  -  -  -  |  -  -  -  |  -  -  -  -
receptionist        -  -  -  -  -  |  -  -  -  |  -  -  -  -
lab_technician      -  -  -  -  -  |  -  -  -  |  -  -  -  -
pharmacist          -  -  -  -  -  |  -  -  -  |  -  -  -  -
accountant          -  -  -  -  -  |  -  -  -  |  -  -  -  -
patient             -  -  -  -  -  |  -  -  -  |  -  -  -  -
ai_agent            -  -  -  -  -  |  -  -  -  |  -  -  -  -
auditor             A  -  -  -  -  |  A  -  -  |  A  -  -  -
```

Actions: v=view, c=create, u=update, d=deactivate, ar=assign_role
         up=update, to=toggle, t=toggle

### 4.5 Notification, Document, Consent, Analytics, System

```
                    notif              document             consent           analytics          system
                    v  s  t  cf  |  v  u  d  sg  |  v  c  r  ad  |  v  c  e  d  |  h  cf l  bk

super_admin         A  A  A  A  |  A  A  A  A  |  A  A  A  A  |  A  A  A  A  |  A  A  A  A
hospital_admin      A  A  A  A  |  A  A  A  A  |  A  A  A  A  |  A  A  A  A  |  A  A  A  A
branch_manager      A  A  -  -  |  A  A  -  -  |  -  -  -  -  |  A  A  -  -  |  -  -  -  -
doctor              A  -  -  -  |  A  -  -  A  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -
nurse               -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -
receptionist        A  -  -  -  |  A  A  -  -  |  A  A  -  -  |  -  -  -  -  |  -  -  -  -
lab_technician      -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -
pharmacist          -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -
accountant          A  -  -  -  |  A  -  -  -  |  A  -  -  -  |  A  A  -  -  |  -  -  -  -
patient             -  -  -  -  |  O  -  -  -  |  O  O  O  -  |  -  -  -  -  |  -  -  -  -
ai_agent            A  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -  |  -  -  -  -
auditor             A  -  -  -  |  A  -  -  -  |  A  -  -  A  |  A  -  -  -  |  A  -  -  -
```

Actions: v=view, s=send, t=template, cf=configure
         u=upload, d=delete, sg=sign
         c=collect, r=revoke, ad=audit
         e=export
         h=health, cf=config, l=logs, bk=backup

---
## 5. DATABASE SCHEMA

```sql
-- ============================================================
-- ROLES TABLE
-- ============================================================
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID REFERENCES hospitals(id),          -- NULL = system-level role
    name VARCHAR(50) NOT NULL,
    slug VARCHAR(50) UNIQUE NOT NULL,                    -- 'doctor', 'hospital_admin'
    description VARCHAR(500),
    parent_role_id UUID REFERENCES roles(id),            -- Inheritance parent
    is_system BOOLEAN DEFAULT FALSE,                     -- System roles protected from deletion
    is_custom BOOLEAN DEFAULT FALSE,                     -- Hospital-created custom role
    priority INTEGER DEFAULT 0,                          -- Higher priority wins on conflict
    max_users INTEGER DEFAULT NULL,                      -- Limit for custom roles
    created_by UUID REFERENCES staff_users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- PERMISSIONS (atomic actions)
-- ============================================================
CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) UNIQUE NOT NULL,                   -- 'patient.view', 'queue.call'
    name VARCHAR(200) NOT NULL,
    description VARCHAR(500),
    domain VARCHAR(50) NOT NULL,                         -- patient, queue, billing, etc.
    action VARCHAR(50) NOT NULL,                         -- view, create, update, delete, call, sign
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- ROLE-PERMISSION MAPPING
-- ============================================================
CREATE TABLE role_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    allowed BOOLEAN DEFAULT TRUE,                        -- TRUE=allow, FALSE=explicit deny
    conditions JSONB DEFAULT NULL,                        -- ABAC conditions (see section 7)
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(role_id, permission_id)
);

-- ============================================================
-- USER-ROLE ASSIGNMENTS
-- ============================================================
CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,                                -- staff_user.id or patient.id
    user_type VARCHAR(20) NOT NULL CHECK (user_type IN ('staff', 'patient', 'ai_agent')),
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    branch_id UUID REFERENCES branches(id),               -- Scope: optional branch restriction
    department_id UUID REFERENCES departments(id),        -- Scope: optional department restriction
    granted_by UUID REFERENCES staff_users(id),
    granted_at TIMESTAMP DEFAULT NOW(),
    expires_at TIMESTAMP,                                 -- Temporary role (e.g., locum doctor)
    is_active BOOLEAN DEFAULT TRUE,
    UNIQUE(user_id, user_type, role_id, hospital_id)
);

-- ============================================================
-- CUSTOM ROLES (hospital-defined)
-- ============================================================
CREATE TABLE custom_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
    name VARCHAR(50) NOT NULL,
    description VARCHAR(500),
    base_role_id UUID REFERENCES roles(id),               -- Inherit from a system role
    permission_ids UUID[] NOT NULL DEFAULT '{}',          -- Explicit permission list
    is_active BOOLEAN DEFAULT TRUE,
    max_assignees INTEGER DEFAULT 10,
    created_by UUID REFERENCES staff_users(id),
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- PERMISSION AUDIT LOG
-- ============================================================
CREATE TABLE permission_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID REFERENCES hospitals(id),
    actor_id UUID NOT NULL,
    actor_type VARCHAR(20) NOT NULL DEFAULT 'staff',
    action VARCHAR(20) NOT NULL,                          -- granted, revoked, denied, changed
    permission_code VARCHAR(100),
    role_name VARCHAR(50),
    resource_type VARCHAR(50),
    resource_id UUID,
    reason VARCHAR(500),
    ip_address VARCHAR(45),
    user_agent TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- ============================================================
-- UNUSED PERMISSION DETECTION (materialized view)
-- ============================================================
CREATE MATERIALIZED VIEW unused_permissions AS
SELECT p.code, p.domain, p.action,
       COUNT(rp.id) AS role_count,
       COUNT(pa.id) AS access_count_30d
FROM permissions p
LEFT JOIN role_permissions rp ON rp.permission_id = p.id
LEFT JOIN permission_audit pa ON pa.permission_code = p.code
    AND pa.created_at >= NOW() - INTERVAL '30 days'
GROUP BY p.id
HAVING COUNT(pa.id) = 0;

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_roles_hospital ON roles(hospital_id);
CREATE INDEX idx_roles_slug ON roles(slug);
CREATE INDEX idx_permissions_code ON permissions(code);
CREATE INDEX idx_permissions_domain ON permissions(domain, action);
CREATE INDEX idx_role_perms_role ON role_permissions(role_id);
CREATE INDEX idx_role_perms_perm ON role_permissions(permission_id);
CREATE INDEX idx_user_roles_user ON user_roles(user_id, user_type);
CREATE INDEX idx_user_roles_role ON user_roles(role_id);
CREATE INDEX idx_user_roles_hospital ON user_roles(hospital_id);
CREATE INDEX idx_user_roles_active ON user_roles(is_active) WHERE is_active = TRUE;
CREATE INDEX idx_custom_roles_hospital ON custom_roles(hospital_id);
CREATE INDEX idx_perm_audit_actor ON permission_audit(actor_id, created_at);
CREATE INDEX idx_perm_audit_action ON permission_audit(action, created_at DESC);
CREATE INDEX idx_perm_audit_hospital ON permission_audit(hospital_id, created_at);
```

---
## 6. DYNAMIC PERMISSION EVALUATION

The PermissionEngine is the runtime authorization kernel. It evaluates every permission check using this algorithm:

1. **Super admin check** — Fast-path bypass for super_admin role
2. **Redis cache lookup** — Return cached decision if available (5-min TTL)
3. **Load user roles** — Fetch active role assignments with inheritance chain
4. **Collect all permissions** — Aggregate allows, denies, and ABAC conditions
5. **Explicit deny wins** — If any role has an explicit deny for this permission, reject
6. **Explicit allow check** — Evaluate conditions; if met, allow
7. **Default deny** — No matching rule means denied. Log the denial.

```python
import functools
from datetime import datetime, timedelta
from uuid import UUID


class PermissionEngine:
    """Core permission checking engine with Redis caching."""

    def __init__(self, redis_client=None):
        self.redis = redis_client
        self.cache_ttl = 300  # 5 minutes

    async def check_permission(
        self, user_id: UUID, permission_code: str,
        user_type: str = "staff", resource: dict = None
    ) -> bool:
        """Check if a user has a specific permission on a resource."""
        # 1. Super admin fast-path
        if await self._is_super_admin(user_id):
            return True

        # 2. Redis cache check
        cache_key = f"ghos:perm:{user_id}:{permission_code}"
        cached = await self.redis.get(cache_key)
        if cached is not None:
            return cached == "1"

        # 3. Load user roles (cached)
        roles = await self._get_user_roles(user_id, user_type)
        if not roles:
            await self.redis.set(cache_key, "0", ex=self.cache_ttl)
            return False

        # 4. Collect all permissions (cached)
        perms = await self._get_effective_permissions(roles)

        # 5. Explicit deny wins
        if permission_code in perms.get("deny", set()):
            await self.redis.set(cache_key, "0", ex=self.cache_ttl)
            await self._log_denied(user_id, permission_code, "explicit_deny")
            return False

        # 6. Check allow with conditions
        code_conditions = perms.get("conditions", {}).get(permission_code, [])
        if permission_code in perms.get("allow", set()):
            if self._evaluate_conditions(code_conditions, user_id, resource):
                await self.redis.set(cache_key, "1", ex=self.cache_ttl)
                return True

        # 7. Default deny
        await self.redis.set(cache_key, "0", ex=self.cache_ttl)
        await self._log_denied(user_id, permission_code, "default_deny")
        return False

    async def get_user_permissions(self, user_id: UUID, user_type: str = "staff") -> list:
        """Get all allowed permission codes for UI rendering."""
        cache_key = f"ghos:userperms:{user_id}"
        cached = await self.redis.get(cache_key)
        if cached:
            return json.loads(cached)
        roles = await self._get_user_roles(user_id, user_type)
        perms = await self._get_effective_permissions(roles)
        result = sorted(perms.get("allow", []))
        await self.redis.set(cache_key, json.dumps(result), ex=self.cache_ttl)
        return result

    async def get_role_permissions(self, role_id: UUID) -> list:
        """Get all permissions for a specific role."""
        cache_key = f"ghos:roleperms:{role_id}"
        cached = await self.redis.get(cache_key)
        if cached:
            return json.loads(cached)
        rps = await db.query(
            """SELECT p.code, rp.allowed, rp.conditions
             FROM role_permissions rp
             JOIN permissions p ON p.id = rp.permission_id
             WHERE rp.role_id = $1""", role_id
        ).fetchall()
        result = [{"code": r["code"], "allowed": r["allowed"],
                   "conditions": r["conditions"]} for r in rps]
        await self.redis.set(cache_key, json.dumps(result), ex=self.cache_ttl)
        return result
    async def has_any_permission(
        self, user_id: UUID, permission_codes: list,
        user_type: str = "staff", resource: dict = None
    ) -> bool:
        """Check if user has ANY of the listed permissions."""
        for code in permission_codes:
            if await self.check_permission(user_id, code, user_type, resource):
                return True
        return False

    async def has_all_permissions(
        self, user_id: UUID, permission_codes: list,
        user_type: str = "staff", resource: dict = None
    ) -> bool:
        """Check if user has ALL of the listed permissions."""
        for code in permission_codes:
            if not await self.check_permission(user_id, code, user_type, resource):
                return False
        return True


    async def _get_effective_permissions(self, roles: list) -> dict:
        """Aggregate allows, denies, and conditions across all roles."""
        role_ids = sorted([r['id'] for r in roles])
        sep = chr(45)
        cache_key = 'ghos:rolepermset:' + sep.join(role_ids)
        cached = await self.redis.get(cache_key)
        if cached:
            return json.loads(cached)
        result = {'allow': set(), 'deny': set(), 'conditions': {}}
        for rid in role_ids:
            rp_list = await self.get_role_permissions(UUID(rid))
            for rp in rp_list:
                if rp['allowed']:
                    result['allow'].add(rp['code'])
                    if rp.get('conditions'):
                        result['conditions'][rp['code']] = rp['conditions']
                else:
                    result['deny'].add(rp['code'])
        result['allow'] = list(result['allow'])
        result['deny'] = list(result['deny'])
        await self.redis.set(cache_key, json.dumps(result, default=str), ex=self.cache_ttl)
        return result

    def _evaluate_conditions(self, conditions: list, user_id: UUID, resource: dict) -> bool:
        """Evaluate ABAC conditions against request context."""
        if not conditions:
            return True
        for cond in conditions:
            if cond.get("type") == "owner":
                resource_owner = resource and resource.get('owner_id')
                if not resource_owner or str(resource_owner) != str(user_id):
                    return False
            elif cond.get("type") == "department":
                roles = asyncio.run(self._get_user_roles(user_id, 'staff'))
                user_depts = {r.get('dept') for r in roles if r.get('dept')}
                resource_dept = resource and resource.get('department_id')
                if not resource_dept or str(resource_dept) not in user_depts:
                    return False
            elif cond.get("type") == "branch":
                roles = asyncio.run(self._get_user_roles(user_id, 'staff'))
                user_branches = {r.get('branch') for r in roles if r.get('branch')}
                res_branch = resource and resource.get('branch_id')
                if not res_branch or str(res_branch) not in user_branches:
                    return False
            elif cond.get("type") == "time_window":
                now = datetime.now().strftime('%H:%M')
                if not (cond["start"] <= now <= cond["end"]):
                    return False
            elif cond.get("type") == "rate_limit":
                count = asyncio.run(self._get_action_count(
                    user_id, cond.get('action', ''), cond.get('period', 'daily')
                ))
                if count >= cond.get('max', 100):
                    return False
        return True

    async def _is_super_admin(self, user_id: UUID) -> bool:
        """Fast path: check if user has super_admin role."""
        cache_key = 'ghos:superadmin:' + str(user_id)
        cached = await self.redis.get(cache_key)
        if cached is not None:
            return cached == '1'
        row = await db.query(
            '''SELECT 1 FROM user_roles ur
             JOIN roles r ON r.id = ur.role_id
             WHERE r.slug = 'super_admin' AND ur.user_id = $1''', user_id
        ).fetchone()
        is_sa = row is not None
        await self.redis.set(cache_key, '1' if is_sa else '0', ex=self.cache_ttl)
        return is_sa

    async def invalidate_cache(self, user_id=None, role_id=None):
        """Clear cached permission data for a user or role."""
        if user_id:
            uid = str(user_id)
            keys = ['ghos:userroles:' + uid, 'ghos:userperms:' + uid, 'ghos:superadmin:' + uid]
            for k in keys:
                await self.redis.delete(k)
        if role_id:
            await self.redis.delete('ghos:roleperms:' + str(role_id))

    async def _log_denied(self, user_id, permission_code, reason):
        await db.query(
            '''INSERT INTO permission_audit
             (actor_id, action, permission_code, reason, created_at)
             VALUES ($1, 'denied', $2, $3, NOW())''',
            user_id, permission_code, reason
        )

    async def _get_action_count(self, user_id, action, period):
        """Count how many times an action was performed in a period."""
        if period == 'daily':
            cutoff = datetime.now() - timedelta(hours=24)
        elif period == 'hourly':
            cutoff = datetime.now() - timedelta(hours=1)
        else:
            return 0
        row = await db.query(
            '''SELECT COUNT(*) as cnt FROM permission_audit
             WHERE actor_id = $1 AND permission_code = $2 AND created_at >= $3''',
            user_id, action, cutoff
        ).fetchone()
        return row['cnt'] if row else 0

```

---

## 7. ABAC EXTENSIONS (Attribute-Based Access Control)

ABAC conditions are stored as JSONB in the `role_permissions.conditions` column and evaluated
at runtime by the PermissionEngine. They extend RBAC with fine-grained contextual rules.

### 7.1 Condition Types

| Condition Type | JSON Schema | Example | Effect |
|---------------|-------------|---------|--------|
| owner | {"type": "owner", "field": "doctor_id"} | {"type":"owner","field":"created_by"} | User can only access resources they own |
| department | {"type": "department", "field": "dept_id"} | {"type":"department","field":"department_id"} | User can only access resources in their department |
| branch | {"type": "branch", "field": "branch_id"} | {"type":"branch","field":"branch_id"} | User can only access resources in their branch |
| time_window | {"type": "time_window", "start": "09:00", "end": "20:00"} | {"type":"time_window","start":"09:00","end":"17:00"} | Permission active only during business hours |
| rate_limit | {"type": "rate_limit", "max": 100, "period": "daily", "action": "patient.create"} | {"type":"rate_limit","max":50,"period":"daily","action":"patient.create"} | Limit action count per period |

### 7.2 ABAC Rule Examples

```json
// Doctor can only view their own patients
{"type": "owner", "field": "doctor_id"}

// Nurse accesses only patients in their department
{"type": "department", "field": "department_id"}

// Billing operations only during business hours
{"type": "time_window", "start": "09:00", "end": "20:00"}

// Receptionist limited to 100 registrations per day
{"type": "rate_limit", "max": 100, "period": "daily", "action": "patient.create"}

// Pharmacist dispenses only from assigned inventory
{"type": "attribute_match", "user_field": "assigned_inventory_id", "resource_field": "inventory_id"}
```

### 7.3 Condition Evaluation Priority

Conditions are evaluated in order. If ANY condition in the list fails, the permission is denied.
This is an AND relationship. For OR relationships, create separate role_permissions rows.

Evaluation order: owner -> department -> branch -> time_window -> rate_limit -> attribute_match

---

## 8. PREDEFINED ROLE TEMPLATES

Each system role has a predefined permission set. Hospital admins can override these within limits.
The YAML below defines the complete permission set for each role.

```yaml
roles:
  super_admin:
    description: "GHOS-level super user with unrestricted cross-hospital access"
    permissions: ["*"]  # Wildcard: all permissions
    inherits: null
    is_system: true
    max_users: 3

  hospital_admin:
    description: "Full administrative access for a single hospital"
    permissions: ["admin.*", "patient.*", "queue.*", "billing.*", "appointment.*",
                  "clinical.*", "report.*", "audit.*", "notification.*", "document.*",
                  "consent.*", "analytics.*", "system.*", "inventory.*", "pharmacy.*", "lab.*"]
    inherits: ["doctor", "receptionist", "accountant"]
    is_system: true

  branch_manager:
    description: "Branch-level oversight and reporting"
    permissions:
      allow:
        - "patient.view"
        - "patient.create"
        - "patient.update"
        - "queue.view"
        - "queue.call"
        - "queue.skip"
        - "appointment.*"
        - "billing.view"
        - "inventory.view"
        - "inventory.add"
        - "inventory.adjust"
        - "report.*"
        - "analytics.view"
        - "analytics.create"
        - "admin.staff.view"
        - "admin.branch.view"
        - "notification.view"
        - "notification.send"
        - "audit.view"
      deny:
        - "billing.create"
        - "billing.payment"
        - "patient.delete"
        - "admin.settings.*"
        - "admin.staff.create"
        - "admin.staff.update"
    inherits: null
    is_system: true

  doctor:
    description: "Clinical care: diagnose, prescribe, order tests"
    permissions:
      allow:
        - "patient.view"
        - "patient.update"
        - "queue.view"
        - "queue.call"
        - "queue.complete"
        - "queue.transfer"
        - "appointment.*"
        - "clinical.diagnose"
        - "clinical.prescribe"
        - "clinical.order_test"
        - "clinical.view_report"
        - "clinical.sign_report"
        - "report.view"
        - "report.create"
        - "notification.view"
        - "document.view"
        - "document.sign"
      deny: []
    inherits: null
    is_system: true

  senior_doctor:
    description: "Senior doctor with additional signing authority"
    inherits: ["doctor"]
    permissions:
      allow:
        - "clinical.sign_report"  # Unrestricted signing
        - "report.schedule"
        - "clinical.verify_report"
    is_system: true

  nurse:
    description: "Clinical support: vitals, patient monitoring"
    permissions:
      allow:
        - "patient.view"
        - "patient.update"
        - "queue.view"
        - "appointment.view"
        - "clinical.order_test"
        - "clinical.view_report"
        - "lab.enter_result"
        - "lab.view_result"
        - "nurse.vitals"
    inherits: null
    is_system: true

  receptionist:
    description: "Front desk: registration, appointments, queue"
    permissions:
      allow:
        - "patient.view"
        - "patient.create"
        - "patient.update"
        - "queue.view"
        - "queue.call"
        - "queue.skip"
        - "queue.complete"
        - "appointment.*"
        - "notification.view"
        - "document.view"
        - "document.upload"
        - "consent.view"
        - "consent.collect"
    inherits: null
    is_system: true

  lab_technician:
    description: "Laboratory operations and test processing"
    permissions:
      allow:
        - "patient.view"
        - "queue.view"
        - "queue.call"
        - "lab.view"
        - "lab.perform"
        - "lab.enter_result"
        - "lab.view_result"
        - "lab.verify_result"
        - "inventory.view"
    inherits: null
    is_system: true

  pharmacist:
    description: "Pharmacy: dispensing and inventory"
    permissions:
      allow:
        - "patient.view"
        - "clinical.view_report"
        - "pharmacy.dispense"
        - "pharmacy.verify"
        - "pharmacy.return"
        - "pharmacy.adjust_stock"
        - "pharmacy.view"
        - "inventory.view"
        - "inventory.add"
        - "inventory.adjust"
    inherits: null
    is_system: true

  accountant:
    description: "Billing, payments, and financial operations"
    permissions:
      allow:
        - "patient.view"
        - "billing.view"
        - "billing.create"
        - "billing.payment"
        - "billing.refund"
        - "billing.void"
        - "billing.settle"
        - "billing.adjust"
        - "report.view"
        - "report.create"
        - "report.export"
        - "analytics.view"
        - "analytics.create"
        - "consent.view"
        - "notification.view"
        - "document.view"
    inherits: null
    is_system: true

  patient:
    description: "Self-service access for patients"
    permissions:
      allow:
        - "patient.view"    # Condition: owner=self
        - "billing.view"    # Condition: owner=self
        - "billing.payment" # Condition: owner=self
        - "appointment.view" # Condition: owner=self
        - "appointment.create" # Self
        - "appointment.cancel" # Self
        - "appointment.reschedule" # Self
        - "clinical.view_report" # Condition: owner=self
        - "lab.view_result" # Condition: owner=self
        - "consent.view"    # Condition: owner=self
        - "consent.collect" # Condition: owner=self
        - "consent.revoke"  # Condition: owner=self
        - "document.view"  # Condition: owner=self
    inherits: null
    is_system: true

  ai_agent:
    description: "API-based AI agent with limited scope"
    permissions:
      allow:
        - "patient.view"
        - "queue.view"
        - "notification.view"
        - "notification.send"
      deny:
        - "patient.create"
        - "patient.update"
        - "patient.delete"
        - "billing.*"
        - "clinical.*"
        - "admin.*"
        - "pharmacy.*"
    inherits: null
    is_system: true
    rate_limit: 1000  # API calls per hour

  auditor:
    description: "Read-only access for compliance auditing"
    permissions:
      allow:
        - "patient.view"
        - "queue.view"
        - "appointment.view"
        - "clinical.view_report"
        - "billing.view"
        - "pharmacy.view"
        - "lab.view"
        - "lab.view_result"
        - "inventory.view"
        - "report.view"
        - "report.create"
        - "report.export"
        - "audit.view"
        - "audit.export"
        - "audit.archive"
        - "consent.view"
        - "consent.audit"
        - "admin.staff.view"
        - "admin.settings.view"
        - "admin.branch.view"
        - "system.health"
        - "system.config"
        - "system.logs"
        - "analytics.view"
        - "notification.view"
        - "document.view"
      deny:
        - "*.create"
        - "*.update"
        - "*.delete"
        - "billing.payment"
        - "billing.refund"
        - "admin.staff.create"
        - "admin.settings.update"
    inherits: null
    is_system: true
```

---
## 9. CUSTOM ROLES

Hospitals can create custom roles by selecting a base system role and modifying the permission set.
Custom roles are scoped to the creating hospital and cannot overlap with system role names.

### 9.1 Custom Role Rules
- Custom roles must inherit from exactly one system role (the base)
- Permissions can only be added within the same domain as the base role
- Deny entries can be added to remove permissions from the base role
- Custom roles cannot include admin.*, system.*, or audit.* permissions
- Maximum 10 custom roles per hospital
- Maximum 50 assignees per custom role
- Custom role names must be unique within the hospital

### 9.2 Custom Role Creation Flow

1. Hospital admin selects a base role (e.g., nurse)
2. System displays the base role permission set (read-only)
3. Admin selects additional permissions (restricted to nurse-compatible domains)
4. Admin configures deny-overrides to remove specific permissions
5. Admin names the custom role and sets max assignees
6. System validates: no scope creep, no admin permissions
7. Custom role is created and immediately available for assignment

### 9.3 Validation Rules

```python
def validate_custom_role(base_role_id, permission_ids, hospital_id):
    base = get_role(base_role_id)
    if not base or base.is_system == False:
        raise ValidationError("Base role must be a system role")
    base_perms = get_role_permissions(base_role_id)
    base_domains = {p.split(".")[0] for p in base_perms}
    new_perms = get_permissions_by_ids(permission_ids)
    for p in new_perms:
        domain = p.code.split(".")[0]
        if domain not in base_domains:
            raise ValidationError(f"Permission {p.code} outside base role scope")
        if domain in ("admin", "system", "audit"):
            raise ValidationError(f"Cannot add {domain}.* permissions to custom roles")
    count = count_custom_roles(hospital_id)
    if count >= 10:
        raise ValidationError("Maximum 10 custom roles per hospital")
    return True
```

---
## 10. PERMISSION AUDIT

### 10.1 Audit Events

| Event | Trigger | Logged Data |
|-------|---------|-------------|
| granted | Role assigned to user | actor_id, target_user, role, reason |
| revoked | Role removed from user | actor_id, target_user, role, reason |
| denied | Permission check failed | actor_id, permission_code, resource, reason |
| changed | Permission added/removed from role | actor_id, role, permission, action |
| custom_role_created | New custom role created | actor_id, role_name, permission_ids |
| custom_role_modified | Custom role edited | actor_id, role_name, changes |

### 10.2 Suspicious Activity Detection

The PermissionAuditor runs periodically (every 5 minutes) and flags:

- Brute force attempt: 10+ denials in 5 minutes from one user
- Off-hours changes: Permission modifications outside 6:00-22:00
- Escalation attempt: Low-privilege role requesting admin actions
- Rapid role churn: 5+ role changes for a single user in 1 hour
- Stale super admin: Super admin not logged in for 90+ days

```python
class PermissionAuditor:
    """Detects suspicious permission patterns."""

    async def detect_suspicious(self):
        alerts = []
        now = datetime.now()
        five_min_ago = now - timedelta(minutes=5)

        # Brute force detection
        rows = await db.query('''
            SELECT actor_id, COUNT(*) as cnt FROM permission_audit
            WHERE action = 'denied' AND created_at >= $1
            GROUP BY actor_id HAVING COUNT(*) >= 10
        ''', five_min_ago).fetchall()
        for r in rows:
            alerts.append({'type': 'brute_force',
                          'actor_id': str(r['actor_id']),
                          'count': r['cnt'],
                          'severity': 'high'})

        # Off-hours changes
        rows = await db.query('''
            SELECT actor_id, action, created_at FROM permission_audit
            WHERE action IN ('granted', 'revoked', 'changed')
            AND EXTRACT(HOUR FROM created_at) NOT BETWEEN 6 AND 22
            AND created_at >= NOW() - INTERVAL '24 hours'
        ''').fetchall()
        for r in rows:
            alerts.append({'type': 'off_hours_change',
                          'actor_id': str(r['actor_id']),
                          'action': r['action'],
                          'severity': 'medium'})

        return alerts
```

---
## 11. API GUARD AND MIDDLEWARE

### 11.1 Decorator: @requires_permission

```python
import functools

def requires_permission(permission_code, resource_param=None):
    """Decorator: check permission before allowing API access.

    Args:
        permission_code: The permission required (e.g., "patient.view")
        resource_param: Optional request parameter containing the resource ID
    """
    def decorator(handler):
        @functools.wraps(handler)
        async def wrapper(request, *args, **kwargs):
            user = getattr(request.state, "user", None)
            if not user:
                raise HTTPException(status_code=401)

            resource = None
            if resource_param and resource_param in kwargs:
                resource = {
                    "id": kwargs[resource_param],
                    "owner_id": user.get("sub"),
                    "type": permission_code.split(".")[0]
                }

            engine = PermissionEngine()
            if not await engine.check_permission(
                UUID(user["sub"]),
                permission_code,
                user.get("type", "staff"),
                resource
            ):
                raise HTTPException(
                    status_code=403,
                    detail=f"Permission denied: {permission_code}"
                )
            return await handler(request, *args, **kwargs)
        return wrapper
    return decorator


def requires_role(role_slug):
    """Simpler decorator for coarse role-based checks."""
    def decorator(handler):
        @functools.wraps(handler)
        async def wrapper(request, *args, **kwargs):
            user = getattr(request.state, "user", None)
            if not user:
                raise HTTPException(status_code=401)
            engine = PermissionEngine()
            roles = await engine._get_user_roles(
                UUID(user["sub"]),
                user.get("type", "staff")
            )
            if not any(r["name"] == role_slug for r in roles):
                raise HTTPException(
                    status_code=403,
                    detail=f"Role required: {role_slug}"
                )
            return await handler(request, *args, **kwargs)
        return wrapper
    return decorator
```

### 11.2 Middleware Chain

For REST and gRPC APIs, the permission check flows through this middleware chain:

```
Request --> AuthMiddleware (JWT validation)
              |
              v
         HospitalScopeMiddleware (resolve hospital_id from token)
              |
              v
         PermissionMiddleware (check @requires_permission or route config)
              |
              v
         ResourceMiddleware (load resource, attach ABAC context)
              |
              v
         Handler (business logic, data access)
```

### 11.3 Short-Circuit with Redis

The PermissionMiddleware caches decisions aggressively:
- **Permission check**: 5-min TTL, key = ghos:perm:{user_id}:{permission_code}
- **User roles**: 5-min TTL, key = ghos:userroles:{user_id}
- **Role permissions**: 5-min TTL, key = ghos:rolepermset:{sorted_role_ids}
- **Cache invalidation**: Triggered on role assignment change, permission change, or user deactivation

Short-circuit flow:
1. Middleware receives request
2. Extract permission_code from route metadata or decorator
3. Redis GET ghos:perm:{user_id}:{permission_code}
4. Cache HIT: return ALLOW/DENY immediately (no DB query)
5. Cache MISS: run full PermissionEngine.check_permission()
6. Store result in Redis, return decision

---
## 12. SEEDING SQL (Default Roles and Permissions)

When a new hospital is created, the following SQL seeds the default roles and permissions.

```sql
-- ============================================================
-- SEED: Default permissions
-- ============================================================
INSERT INTO permissions (code, name, domain, action, is_system) VALUES
('patient.view', 'View Patient', 'patient', 'view', TRUE),
('patient.create', 'Create Patient', 'patient', 'create', TRUE),
('patient.update', 'Update Patient', 'patient', 'update', TRUE),
('patient.delete', 'Delete Patient', 'patient', 'delete', TRUE),
('patient.merge', 'Merge Patient Records', 'patient', 'merge', TRUE),
('patient.export', 'Export Patient Data', 'patient', 'export', TRUE),
('queue.view', 'View Queue', 'queue', 'view', TRUE),
('queue.call', 'Call Queue Token', 'queue', 'call', TRUE),
('queue.skip', 'Skip Queue Token', 'queue', 'skip', TRUE),
('queue.complete', 'Complete Queue Token', 'queue', 'complete', TRUE),
('queue.transfer', 'Transfer Queue Token', 'queue', 'transfer', TRUE),
('queue.prioritize', 'Prioritize Queue Token', 'queue', 'prioritize', TRUE),
('appointment.view', 'View Appointment', 'appointment', 'view', TRUE),
('appointment.create', 'Create Appointment', 'appointment', 'create', TRUE),
('appointment.update', 'Update Appointment', 'appointment', 'update', TRUE),
('appointment.cancel', 'Cancel Appointment', 'appointment', 'cancel', TRUE),
('appointment.reschedule', 'Reschedule Appointment', 'appointment', 'reschedule', TRUE),
('clinical.diagnose', 'Add Diagnosis', 'clinical', 'diagnose', TRUE),
('clinical.prescribe', 'Prescribe Medication', 'clinical', 'prescribe', TRUE),
('clinical.order_test', 'Order Lab Test', 'clinical', 'order_test', TRUE),
('clinical.view_report', 'View Clinical Report', 'clinical', 'view_report', TRUE),
('clinical.sign_report', 'Sign Clinical Report', 'clinical', 'sign_report', TRUE),
('billing.view', 'View Billing', 'billing', 'view', TRUE),
('billing.create', 'Create Invoice', 'billing', 'create', TRUE),
('billing.payment', 'Process Payment', 'billing', 'payment', TRUE),
('billing.refund', 'Process Refund', 'billing', 'refund', TRUE),
('billing.void', 'Void Invoice', 'billing', 'void', TRUE),
('billing.settle', 'Settle Account', 'billing', 'settle', TRUE),
('billing.adjust', 'Adjust Billing', 'billing', 'adjust', TRUE),
('pharmacy.dispense', 'Dispense Medication', 'pharmacy', 'dispense', TRUE),
('pharmacy.verify', 'Verify Prescription', 'pharmacy', 'verify', TRUE),
('pharmacy.return', 'Return Medication', 'pharmacy', 'return', TRUE),
('pharmacy.adjust_stock', 'Adjust Pharmacy Stock', 'pharmacy', 'adjust_stock', TRUE),
('pharmacy.view', 'View Pharmacy', 'pharmacy', 'view', TRUE),
('lab.view', 'View Lab', 'lab', 'view', TRUE),
('lab.perform', 'Perform Lab Test', 'lab', 'perform', TRUE),
('lab.enter_result', 'Enter Lab Result', 'lab', 'enter_result', TRUE),
('lab.view_result', 'View Lab Result', 'lab', 'view_result', TRUE),
('lab.verify_result', 'Verify Lab Result', 'lab', 'verify_result', TRUE),
('inventory.view', 'View Inventory', 'inventory', 'view', TRUE),
('inventory.add', 'Add Inventory', 'inventory', 'add', TRUE),
('inventory.adjust', 'Adjust Inventory', 'inventory', 'adjust', TRUE),
('inventory.transfer', 'Transfer Inventory', 'inventory', 'transfer', TRUE),
('inventory.audit', 'Audit Inventory', 'inventory', 'audit', TRUE),
('inventory.order', 'Order Inventory', 'inventory', 'order', TRUE),
('report.view', 'View Report', 'report', 'view', TRUE),
('report.create', 'Create Report', 'report', 'create', TRUE),
('report.export', 'Export Report', 'report', 'export', TRUE),
('report.delete', 'Delete Report', 'report', 'delete', TRUE),
('report.schedule', 'Schedule Report', 'report', 'schedule', TRUE),
('audit.view', 'View Audit Log', 'audit', 'view', TRUE),
('audit.export', 'Export Audit Log', 'audit', 'export', TRUE),
('audit.archive', 'Archive Audit Log', 'audit', 'archive', TRUE),
('admin.staff.view', 'View Staff', 'admin.staff', 'view', TRUE),
('admin.staff.create', 'Create Staff', 'admin.staff', 'create', TRUE),
('admin.staff.update', 'Update Staff', 'admin.staff', 'update', TRUE),
('admin.staff.deactivate', 'Deactivate Staff', 'admin.staff', 'deactivate', TRUE),
('admin.staff.assign_role', 'Assign Staff Role', 'admin.staff', 'assign_role', TRUE),
('admin.settings.view', 'View Settings', 'admin.settings', 'view', TRUE),
('admin.settings.update', 'Update Settings', 'admin.settings', 'update', TRUE),
('admin.settings.toggle', 'Toggle Setting', 'admin.settings', 'toggle', TRUE),
('admin.branch.view', 'View Branch', 'admin.branch', 'view', TRUE),
('admin.branch.create', 'Create Branch', 'admin.branch', 'create', TRUE),
('admin.branch.update', 'Update Branch', 'admin.branch', 'update', TRUE),
('admin.branch.toggle', 'Toggle Branch', 'admin.branch', 'toggle', TRUE),
('admin.subscription.view', 'View Subscription', 'admin.subscription', 'view', TRUE),
('admin.subscription.update', 'Update Subscription', 'admin.subscription', 'update', TRUE),
('admin.subscription.cancel', 'Cancel Subscription', 'admin.subscription', 'cancel', TRUE),
('notification.view', 'View Notification', 'notification', 'view', TRUE),
('notification.send', 'Send Notification', 'notification', 'send', TRUE),
('notification.template', 'Manage Templates', 'notification', 'template', TRUE),
('notification.configure', 'Configure Notifications', 'notification', 'configure', TRUE),
('document.view', 'View Document', 'document', 'view', TRUE),
('document.upload', 'Upload Document', 'document', 'upload', TRUE),
('document.delete', 'Delete Document', 'document', 'delete', TRUE),
('document.sign', 'Sign Document', 'document', 'sign', TRUE),
('consent.view', 'View Consent', 'consent', 'view', TRUE),
('consent.collect', 'Collect Consent', 'consent', 'collect', TRUE),
('consent.revoke', 'Revoke Consent', 'consent', 'revoke', TRUE),
('consent.audit', 'Audit Consent', 'consent', 'audit', TRUE),
('analytics.view', 'View Analytics', 'analytics', 'view', TRUE),
('analytics.create', 'Create Analytics', 'analytics', 'create', TRUE),
('analytics.export', 'Export Analytics', 'analytics', 'export', TRUE),
('analytics.dashboard', 'Manage Dashboards', 'analytics', 'dashboard', TRUE),
('system.health', 'System Health', 'system', 'health', TRUE),
('system.config', 'System Config', 'system', 'config', TRUE),
('system.logs', 'View System Logs', 'system', 'logs', TRUE),
('system.backup', 'System Backup', 'system', 'backup', TRUE),
ON CONFLICT (code) DO NOTHING;

-- ============================================================
-- SEED: System roles (called per hospital creation)
-- ============================================================
CREATE OR REPLACE FUNCTION seed_hospital_roles(h_id UUID) RETURNS void AS $$
DECLARE
    admin_role_id UUID;
    doc_role_id UUID;
    rec_role_id UUID;
    nurse_role_id UUID;
    lab_role_id UUID;
    pharm_role_id UUID;
    acct_role_id UUID;
    patient_role_id UUID;
    branch_role_id UUID;
    agent_role_id UUID;
    auditor_role_id UUID;
BEGIN
    -- Insert roles
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Hospital Admin', 'hospital_admin', 'Hospital administrator', TRUE)
    RETURNING id INTO admin_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Doctor', 'doctor', 'Medical doctor', TRUE)
    RETURNING id INTO doc_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Receptionist', 'receptionist', 'Front desk staff', TRUE)
    RETURNING id INTO rec_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Nurse', 'nurse', 'Clinical nurse', TRUE)
    RETURNING id INTO nurse_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Lab Technician', 'lab_technician', 'Lab staff', TRUE)
    RETURNING id INTO lab_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Pharmacist', 'pharmacist', 'Pharmacy staff', TRUE)
    RETURNING id INTO pharm_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Accountant', 'accountant', 'Billing staff', TRUE)
    RETURNING id INTO acct_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Patient', 'patient', 'Self-service patient', TRUE)
    RETURNING id INTO patient_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Branch Manager', 'branch_manager', 'Branch oversight', TRUE)
    RETURNING id INTO branch_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'AI Agent', 'ai_agent', 'AI API agent', TRUE)
    RETURNING id INTO agent_role_id;
    INSERT INTO roles (hospital_id, name, slug, description, is_system)
    VALUES (h_id, 'Auditor', 'auditor', 'Read-only auditor', TRUE)
    RETURNING id INTO auditor_role_id;

    -- Map permissions to roles (simplified -- use code mappings in practice)
    -- Full mapping logic follows the YAML template in section 8
END;
$$ LANGUAGE plpgsql;
```

---
## 13. KEY DESIGN DECISIONS

1. **Deny by default, allow by exception** — Every permission check starts with denial. Only explicit allow entries grant access. This prevents privilege escalation through role accumulation or misconfiguration.

2. **Explicit deny always wins** — If any role assigned to a user has an explicit deny for a permission, the check fails regardless of allows from other roles. This provides a safety valve for emergency restrictions.

3. **Redis cache with 5-min TTL** — Permission decisions are cached aggressively. Cache invalidation is triggered on role changes. This makes permission checks effectively zero-cost (sub-millisecond) on hot paths.

4. **Super admin bypass** — The fastest code path. Super admin has unrestricted cross-hospital access and bypasses all permission checks. This is a deliberate trade-off: audit logging still captures all actions.

5. **Hierarchical role inheritance** — Roles inherit permissions from parent roles through a recursive CTE. This avoids duplicating permission assignments and makes the hierarchy self-documenting.

6. **ABAC-lite conditions** — Conditions stored as JSONB on role_permissions extend RBAC with contextual checks (owner, department, time, rate limit) without requiring a full ABAC policy engine.

7. **Wildcard support** — The asterisk (*) grants all permissions in a domain (patient.*) or globally (*). Only super_admin and hospital_admin receive global wildcards.

8. **Department and branch scoping** — Same role in different departments provides different data access. A doctor in Cardiology cannot see patients in Orthopedics unless explicitly assigned.

9. **Emergency bypass mechanism** — A hospital_admin can trigger a 15-minute emergency override that temporarily grants full access to designated roles. Every emergency action is logged with mandatory reason.

10. **Audit all denials** — Every denied permission check is logged with actor, permission, resource, and reason. This is critical for intrusion detection, debugging, and compliance audits.

---

## 14. CONFIGURATION

```yaml
permissions:
  cache:
    user_roles_ttl: 300          # 5 minutes
    role_perms_ttl: 300         # 5 minutes
    user_perms_ttl: 300         # 5 minutes
    super_admin_ttl: 300        # 5 minutes
  audit:
    log_denied: true
    log_granted: true
    log_revoked: true
    suspicious_threshold: 10    # Denials in window
    suspicious_window_minutes: 5
    off_hours_start: 22         # 10 PM
    off_hours_end: 6            # 6 AM
  defaults:
    auto_seed_roles: true
    auto_seed_permissions: true
    deny_on_error: true         # If cache/db fail, deny access
  limits:
    max_custom_roles_per_hospital: 10
    max_assignees_per_custom_role: 50
    max_super_admins: 3
    emergency_override_minutes: 15
  ui:
    show_denied_toast: true
    hide_disabled_buttons: true  # Remove UI elements user cant access
    show_permission_test_tool: true
```

---
