---
file_id: "0802"
module_name: "Backup & Disaster Recovery"
version: "1.0"
status: "Draft"
phase: "Phase 8 — Security"
dependencies: ["0800_SECURITY.md", "0801_ENCRYPTION.md"]
related_files: []
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "backup", "disaster-recovery", "data-loss", "pitr", "wal-archiving"]
---

# GHOS - Backup & Disaster Recovery

> "Your backup is only as good as your last restore test. Hospitals cannot afford to learn this the hard way."

---

## 1. BACKUP ARCHITECTURE OVERVIEW

```
  +------------------------------------------------------------------+
  |                    BACKUP INFRASTRUCTURE                          |
  |                                                                   |
  |  +-------------------+  +-------------------+  +----------------+ |
  |  |  PostgreSQL       |  |  File Storage     |  |  Configuration | |
  |  |  (Primary DB)     |  |  (S3/MinIO)       |  |  (Git/Etcd)   | |
  |  +--------+----------+  +--------+----------+  +-------+--------+ |
  |           |                      |                      |         |
  +-----------|----------------------|----------------------|---------+
              |                      |                      |
     +--------v----------+  +--------v----------+  +-------v--------+
     | WAL Streaming     |  | File Sync (Rclone) |  | Config Backup  |
     | (Continuous)      |  | (Daily Incremental)|  | (On Change)    |
     +--------+----------+  +--------+----------+  +-------+--------+
              |                      |                      |
     +--------v----------------------v----------------------v--------+
     |                     BACKUP STAGING LAYER                       |
     |  +----------------------------------------------------------+ |
     |  |  pgBarman / pgBackRest / pg_dump                          | |
     |  |  Compression (zstd:3) + Encryption (AES-256-GCM)         | |
     |  +----------------------------------------------------------+ |
     +----------------------------+----------------------------------+
                                  |
     +----------------------------v----------------------------------+
     |                    STORAGE TIERS                               |
     |  +------------+  +------------+  +------------+  +----------+ |
     |  | Hot (SSD)  |  | Warm (S3)  |  | Cold (Gla) |  | Geo-Red  | |
     |  | Ret: 7d    |  | Ret: 90d   |  | Ret: 7yr   |  | Cross-R  | |
     |  +------------+  +------------+  +------------+  +----------+ |
     +----------------------------------------------------------------+
```

### Backup Tools
| Tool | Use Case | RPO | RTO | Compressor |
|------|----------|-----|-----|------------|
| pgBarman | Production DR | 5 min | 1 hr | zstd:3 |
| pgBackRest | Daily full + diff | 24 hr | 2 hr | zstd:6 |
| pg_dump | Logical/schema only | On-demand | 30 min | gzip |
| WAL Streaming | Continuous archive | 5 min | 5 min (applied) | -- |
| Rclone | File backup | 24 hr | 4 hr | -- |

## 2. BACKUP TYPES

### 2.1 Logical Backup (pg_dump)
```bash
# Schema-only backup (for migration/upgrade)
pg_dump -h localhost -U ghos_admin -d ghos_db   --schema-only --no-owner --no-acl   -f /backup/schema/ghos_schema_$(date +%Y%m%d).sql

# Full database dump with compression
pg_dump -h localhost -U ghos_admin -d ghos_db   --format=custom --compress=9 --no-owner   -f /backup/logical/ghos_full_$(date +%Y%m%d_%H%M%S).dump
```

### 2.2 Physical Backup (pgBackRest)
```ini
# /etc/pgbackrest/pgbackrest.conf
[ghos_db]
pg1-path=/var/lib/postgresql/16/main
pg1-port=5432

[global]
repo1-path=/backup/pgbackrest
repo1-retention-full=4
repo1-retention-diff=14
repo1-cipher-type=aes-256-cbc
repo1-cipher-pass=FROM_ENV
compress-type=zst
compress-level=6
process-max=4
```

### 2.3 WAL Archiving (Continuous)
```bash
# postgresql.conf
wal_level = replica
archive_mode = on
archive_command = 'pgbackrest --stanza=ghos_db archive-push %p'
archive_timeout = 60
max_wal_size = 4GB
min_wal_size = 1GB
```

### 2.4 File Backup (Rclone)
```yaml
# /etc/rclone/ghos-backup.conf
[ghos-files]
type = s3
provider = MinIO
endpoint = https://minio.internal:9000
region = us-east-1
acl = private
```

## 3. STORAGE TIERS AND RETENTION

| Tier | Storage | Retention | Encryption | Cost/GB/Mo |
|------|---------|-----------|------------|------------|
| Hot | Local NVMe RAID10 | 7 days | LUKS + pg_tde | ~$0.15 |
| Warm | S3/MinIO Standard | 90 days | AES-256-S3 | ~$0.023 |
| Cold | Glacier Deep Archive | 7 years | AES-256-GCM | ~$0.001 |
| Geo-Red | Cross-region S3 | 30 days sync | AES-256 | ~$0.03 |

### Retention Schedule
```yaml
retention_policies:
  full_backup:
    daily: 7
    weekly: 4
    monthly: 12
    yearly: 7
  wal_archives:
    keep: 14_days
  audit_logs:
    hot: 90_days
    cold: 7_years
  patient_records:
    hot: 1_year
    cold: 10_years
```

## 4. RECOVERY PROCEDURES

### 4.1 Point-in-Time Recovery (PITR)
```bash
# 1. Identify target time
psql -c "SELECT pg_last_wal_receive_lsn(), pg_last_wal_replay_lsn();"

# 2. Perform PITR
pgbackrest --stanza=ghos_db --type=time \
  --target="2026-07-08 14:30:00+05:30" \
  --target-action=promote restore

# 3. Verify data integrity
psql -d ghos_db -c "
  SELECT count(*) as total_patients,
         max(created_at) as latest_record
  FROM patients;
"
```

### 4.2 Full Database Restore
```bash
# Step 1: Stop application
systemctl stop ghos-api

# Step 2: Restore from latest backup
pgbackrest --stanza=ghos_db --type=latest --delta restore

# Step 3: Start database
systemctl start postgresql

# Step 4: Verify and start application
psql -c "SELECT count(*) FROM patients;"
systemctl start ghos-api
```

## 5. RPO / RTO MATRIX

| Data Category | RPO Target | RTO Target | Method |
|---------------|-----------|-----------|--------|
| Critical (Patient) | 5 min | 1 hr | WAL streaming + pgBarman |
| Important (Clinical) | 15 min | 2 hr | WAL + pgBackRest diff |
| Operational (Billing) | 1 hr | 4 hr | pgBackRest full |
| Analytical | 24 hr | 8 hr | pg_dump logical |
| Archived | 7 days | 24 hr | Cold storage |

## 6. DISASTER RECOVERY ARCHITECTURE

```
                    +-------------------------+
                    |   DNS / Load Balancer   |
                    +-----------+-------------+
                                |
          +---------------------+---------------------+
          |                                           |
+---------v----------+                      +---------v----------+
|  PRIMARY REGION    |                      |  DR REGION         |
|  (ap-south-1)      |                      |  (ap-southeast-1)  |
|                    |                      |                    |
|  +--------------+  |   WAL Replication    |  +--------------+  |
|  | PostgreSQL   +--+--------------------->+  | PostgreSQL   |  |
|  | (Primary)    |  |   (Async Streaming) |  | (Standby)    |  |
|  +--------------+  |                      |  +------+-------+  |
|  +--------------+  |                      |         |          |
|  | App Servers  |  |                      |  +------v-------+  |
|  +--------------+  |                      |  | App Servers  |  |
|  +--------------+  |                      |  | (Cold/Warm)  |  |
|  | File Storage |  |   Rclone Sync       |  +--------------+  |
|  +--------------+  +---------------------->  +--------------+  |
|                    |                      |  | File Storage |  |
+--------------------+                      |  | (Replica)    |  |
                                            |  +--------------+  |
                                            +--------------------+
```

### DR Scenarios and Response

| Scenario | Detection | Response | RTO Target |
|----------|-----------|----------|------------|
| Server Failure | Monitoring alert (30s) | Auto-failover to standby | 5 min |
| Disk Corruption | Checksum failure (1 min) | PITR to last clean point | 30 min |
| Ransomware | Anomaly detection (5 min) | Isolate and restore from immutable backup | 2 hr |
| Data Center Outage | Cloud health API (2 min) | Activate DR region | 30 min |
| Region Failure | Cloud status (1 min) | DNS switch to DR region | 1 hr |
| Human Error | Application alert (immediate) | PITR to before deletion | 15 min |
| Software Bug | QA/reporting alert (1 hr) | PITR to pre-deploy state | 4 hr |

## 7. DISASTER RECOVERY DRILL

### Quarterly DR Drill Procedure
```python
class DRDrill:
    def __init__(self):
        self.checklist = [
            "Notify stakeholders (email + WhatsApp 24hr before)",
            "Create restore point on production",
            "Stop writes on primary",
            "Initiate DR region activation",
            "Restore database from latest WAL",
            "Restore file storage",
            "Start application servers in DR",
            "Run integrity checks",
            "Point test traffic to DR",
            "Run smoke tests",
            "Measure actual RTO vs target",
            "Failback to primary",
            "Document gaps and improvements"
        ]

    def execute(self):
        results = []
        for step in self.checklist:
            success = self._run_step(step)
            results.append({"step": step, "success": success})
        return self._generate_report(results)

    def _generate_report(self, results):
        return {
            "drill_date": "2026-07-09",
            "total_steps": len(results),
            "passed": sum(1 for r in results if r["success"]),
            "failed": [r for r in results if not r["success"]]
        }
```

## 8. MONITORING AND ALERTING

```yaml
backup_alerts:
  backup_failed:
    severity: critical
    channels: [email, whatsapp, push]
    escalation: 15min -> manager -> CTO
  backup_age_exceeded:
    severity: warning
    threshold: "last_full_backup > 27 hours OR last_wal_archive > 10 minutes"
  storage_growth:
    severity: info
    threshold: "storage_used / storage_allocated > 0.85"
  restore_test_failed:
    severity: critical
    escalation: immediate to Lead DBA
```

### Python: BackupManager
```python
class BackupManager:
    def __init__(self, config: dict):
        self.tools = {
            "pgbarman": PgBarmanTool(config["pgbarman"]),
            "pgbackrest": PgBackRestTool(config["pgbackrest"]),
            "pg_dump": PgDumpTool(config["pg_dump"]),
        }
        self.storage = BackupStorage(config["storage"])
        self.monitor = BackupMonitor()

    def perform_full_backup(self, backup_type: str = "physical") -> "BackupJob":
        job = BackupJob(backup_type=backup_type)
        try:
            if backup_type == "physical":
                result = self.tools["pgbackrest"].full_backup()
            else:
                result = self.tools["pg_dump"].full_backup()
            encrypted_path = self.storage.encrypt_and_store(result.path)
            self.storage.replicate_to_dr(encrypted_path)
            job.complete(result)
            self.monitor.record_success(job)
        except Exception as e:
            job.fail(str(e))
            self.monitor.record_failure(job)
        return job

    def verify_backup(self, backup_id: str) -> dict:
        backup = self.storage.get_backup(backup_id)
        actual_checksum = self._compute_checksum(backup.path)
        return {
            "backup_id": backup_id,
            "checksum_match": actual_checksum == backup.checksum,
            "decryptable": self._test_decrypt(backup.path),
            "restorable": self._test_restore(backup.path)
        }
```

## 9. SQL SCHEMA

```sql
-- Backup Jobs Catalog
CREATE TABLE backup_jobs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    backup_type     VARCHAR(20) NOT NULL CHECK (backup_type IN ('full','diff','wal','logical','file')),
    tool            VARCHAR(30) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'running'
                    CHECK (status IN ('running','completed','failed','verified')),
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ,
    size_bytes      BIGINT,
    checksum        VARCHAR(64),
    encryption_algo VARCHAR(20) DEFAULT 'AES-256-GCM',
    storage_tier    VARCHAR(20) DEFAULT 'hot',
    storage_path    TEXT,
    error_message   TEXT,
    verified_at     TIMESTAMPTZ,
    verified_by     UUID REFERENCES staff(id),
    metadata        JSONB DEFAULT '{}'
);
CREATE INDEX idx_backup_jobs_status ON backup_jobs(status);
CREATE INDEX idx_backup_jobs_started ON backup_jobs(started_at);

-- Backup Retention Policies
CREATE TABLE backup_retention_policies (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    backup_type     VARCHAR(20) NOT NULL,
    tier            VARCHAR(20) NOT NULL CHECK (tier IN ('hot','warm','cold','geo')),
    retention_days  INTEGER NOT NULL,
    max_count       INTEGER,
    auto_purge      BOOLEAN DEFAULT true,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- DR Drill Reports
CREATE TABLE dr_drill_reports (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    drill_date      DATE NOT NULL,
    drill_type      VARCHAR(50) NOT NULL,
    total_steps     INTEGER NOT NULL,
    passed_steps    INTEGER NOT NULL,
    failed_steps    JSONB DEFAULT '[]',
    actual_rto_sec  INTEGER,
    actual_rpo_sec  INTEGER,
    target_rto_sec  INTEGER,
    target_rpo_sec  INTEGER,
    executed_by     UUID REFERENCES staff(id),
    notes           TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE(drill_date, drill_type)
);

-- Restore Tests
CREATE TABLE restore_tests (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    backup_id       UUID REFERENCES backup_jobs(id),
    test_type       VARCHAR(20) NOT NULL CHECK (test_type IN ('checksum','decrypt','sample_restore','full_restore')),
    status          VARCHAR(20) NOT NULL DEFAULT 'running',
    started_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    completed_at    TIMESTAMPTZ,
    checksum_match  BOOLEAN,
    decryptable     BOOLEAN,
    restorable      BOOLEAN,
    error_message   TEXT,
    duration_sec    INTEGER
);
CREATE INDEX idx_restore_tests_backup ON restore_tests(backup_id);
```

## 10. INTEGRITY VERIFICATION

```python
class BackupVerifier:
    def verify_backup_integrity(self, backup_path: str, expected_checksum: str) -> dict:
        results = {}
        actual_checksum = self._sha256(backup_path)
        results["checksum_match"] = actual_checksum == expected_checksum
        decrypted = self._test_decrypt(backup_path)
        results["decryptable"] = decrypted is not None
        if decrypted:
            results["header_valid"] = self._validate_backup_header(decrypted)
        return results
```

## 11. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Physical vs Logical | Both | Physical for DR speed, logical for migration flexibility |
| WAL Streaming | Async | Avoids 5-15ms write latency from sync replication |
| Compression | zstd:3 WAL, zstd:6 backups | Balanced ratio vs speed |
| Encryption | Envelope (DEK per backup, KEK in KMS) | Key rotation without re-encrypting |
| Storage | Multi-tier (Hot/Warm/Cold/Geo) | Cost optimization |
| DR Architecture | Active-Passive | Cost-effective for hospital budgets |
| Verification | Weekly automated + quarterly drill | Coverage vs operational cost |
| Retention | 7yr cold + 10yr patient records | Indian Clinical Establishments Act compliance |
