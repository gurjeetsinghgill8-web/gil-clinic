---
file_id: "0703"
module_name: "Push Notification"
version: "2.0"
status: "Draft"
phase: "Phase 7 — Communication"
dependencies: ["0104_COMMUNICATION_ENGINE.md"]
related_files: ["0902_PWA.md", "0600_PATIENT_APP.md", "0702_WHATSAPP.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "push", "notification", "fcm", "web-push", "service-worker"]
---

# GHOS - Push Notification System

## 1. PURPOSE
Cross-platform push notification system delivering real-time alerts to patients via browser (PWA) and mobile app (native). Supports notification categories with different priority levels, permission management, silent notifications, notification grouping, delivery analytics, and fallback to SMS/WhatsApp for critical alerts.

## 2. ARCHITECTURE

```
[Application Services]
    │
[Push Notification Service]
    │
├── Push Provider Abstraction
│   ├── Firebase Cloud Messaging (FCM) - Android + Web
│   ├── Apple Push Notification Service (APNs) - iOS
│   └── Web Push API (VAPID) - PWA browsers
│
├── Device Registry
│   ├── Token Management
│   ├── Token Refresh
│   └── Device Preference Store
│
├── Notification Orchestrator
│   ├── Category Manager
│   ├── Priority Queue
│   ├── Rate Limiter
│   ├── Grouping Engine
│   └── Sound/Vibration Config
│
├── Permission Manager
│   ├── Web Permission API
│   ├── Native Permission Requests
│   └── Re-prompt Logic
│
└── Analytics & Monitoring
    ├── Delivery Tracking
    ├── Click-through Tracking
    ├── Permission Metrics
    └── Channel Comparison
```

## 3. DATA MODEL

```sql
-- Push notification devices
CREATE TABLE push_devices (
    device_id           UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID REFERENCES patients(patient_id),
    
    -- Device Info
    device_token        VARCHAR(500) NOT NULL UNIQUE,
    platform            VARCHAR(20) NOT NULL,       -- web, android, ios
    browser             VARCHAR(50),                 -- chrome, firefox, safari, edge
    browser_version     VARCHAR(20),
    os                  VARCHAR(30),                 -- android, ios, windows, macos
    os_version          VARCHAR(20),
    device_model        VARCHAR(100),
    
    -- App Info
    app_version         VARCHAR(20),
    pwa_installed       BOOLEAN DEFAULT FALSE,
    
    -- Token Info
    token_source        VARCHAR(20),                 -- fcm, apns, web_push
    token_refreshed_at  TIMESTAMPTZ,
    token_expires_at    TIMESTAMPTZ,
    is_active           BOOLEAN DEFAULT TRUE,
    
    -- Permission
    permission_status   VARCHAR(20) DEFAULT 'granted',
    -- granted, denied, blocked, default
    
    permission_changed_at TIMESTAMPTZ,
    permission_prompt_count INTEGER DEFAULT 0,
    
    -- Preferences
    quiet_hours_start   TIME,                        -- Patient-set quiet hours
    quiet_hours_end     TIME,
    categories_enabled  JSONB DEFAULT '{}',           -- Per-category toggle
    -- {"appointment": true, "queue": true, "promotional": false}
    
    -- Analytics
    total_notifications INTEGER DEFAULT 0,
    last_notification_at TIMESTAMPTZ,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    INDEX idx_push_patient (patient_id),
    INDEX idx_push_token (device_token),
    INDEX idx_push_platform (platform)
);

-- Push notifications log
CREATE TABLE push_notifications (
    push_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    communication_id    UUID REFERENCES communication_log(communication_id),
    
    -- Target
    device_id           UUID REFERENCES push_devices(device_id),
    patient_id          UUID REFERENCES patients(patient_id),
    
    -- Notification Content
    title               VARCHAR(200) NOT NULL,
    body                TEXT NOT NULL,
    category            VARCHAR(30) NOT NULL,
    -- queue, appointment, report, medicine, feedback, promotional, system, emergency
    
    priority            VARCHAR(20) DEFAULT 'normal', -- high, normal, low, min
    urgency             VARCHAR(20) DEFAULT 'normal', -- critical, high, normal, low
    
    -- Platform-Specific
    platform            VARCHAR(20) NOT NULL,
    provider            VARCHAR(20),                 -- fcm, apns, web_push
    
    -- Payload
    data_payload        JSONB DEFAULT '{}',
    -- {"route": "/visit/123", "action": "open_tracking", "visit_id": "uuid"}
    
    click_action        VARCHAR(100),               -- URL or deep link
    icon                VARCHAR(200),                -- Notification icon URL
    image               VARCHAR(200),                -- Large image (FCM)
    
    -- Sound & Vibration
    sound               VARCHAR(50),                 -- Sound file name
    vibration_pattern   JSONB,                        -- [200, 100, 200]
    
    -- Grouping
    collapse_key        VARCHAR(50),                 -- Android notification grouping
    thread_id           VARCHAR(50),                 -- iOS notification grouping
    tag                 VARCHAR(50),                 -- Web notification replace
    group_summary       TEXT,                         -- "3 new updates"
    is_silent           BOOLEAN DEFAULT FALSE,        -- No sound/vibration
    
    -- Status
    status              VARCHAR(30) DEFAULT 'queued',
    -- queued, sending, sent, delivered, clicked, dismissed, failed
    
    provider_message_id VARCHAR(200),
    provider_response   JSONB DEFAULT '{}',
    error_code          VARCHAR(20),
    error_description   TEXT,
    
    -- Timing
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    sent_at             TIMESTAMPTZ,
    delivered_at        TIMESTAMPTZ,
    clicked_at          TIMESTAMPTZ,
    dismissed_at        TIMESTAMPTZ,
    failed_at           TIMESTAMPTZ,
    
    -- Retry
    retry_count         INTEGER DEFAULT 0,
    max_retries         INTEGER DEFAULT 3,
    
    INDEX idx_push_status (status),
    INDEX idx_push_patient_cat (patient_id, category),
    INDEX idx_push_created (created_at DESC)
);

-- Notification categories configuration
CREATE TABLE notification_categories (
    category_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    category_name       VARCHAR(30) NOT NULL UNIQUE, -- queue, appointment, report, etc.
    display_name        VARCHAR(100),
    display_name_hi     VARCHAR(100),
    description         TEXT,
    
    -- Default behavior
    default_enabled     BOOLEAN DEFAULT TRUE,
    default_priority    VARCHAR(20) DEFAULT 'normal',
    default_sound       VARCHAR(50),
    default_vibration   JSONB,
    
    -- Permissions
    requires_opt_in     BOOLEAN DEFAULT FALSE,
    opt_in_required_for VARCHAR(20),                -- transactional, promotional
    
    -- Rate Limits
    max_per_day         INTEGER DEFAULT 0,          -- 0 = unlimited
    min_interval_min    INTEGER DEFAULT 0,
    
    -- Channels
    supports_web_push   BOOLEAN DEFAULT TRUE,
    supports_fcm        BOOLEAN DEFAULT TRUE,
    supports_apns       BOOLEAN DEFAULT TRUE,
    
    -- Fallback
    fallback_channel    VARCHAR(20),                -- whatsapp, sms, email
    fallback_on_failure BOOLEAN DEFAULT FALSE,
    
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
```

## 4. NOTIFICATION CATEGORIES

```yaml
notification_categories:
  queue:
    type: "transactional"
    priority: "high"
    sound: "alert_tone"
    vibration: [200, 100, 200, 100, 500]
    collapse_key: "queue_updates"
    ttl: 3600  # 1 hour
    
    templates:
      called: "🔔 You are called to Room {room}. Please proceed."
      near: "⏳ You are next in queue. Please be ready."
      position: "📊 Queue position updated: {position} (Wait: {wait} min)"
      delayed: "⚠️ Doctor is running {delay} min late. Updated wait: {wait} min"
      completed: "✅ Your visit is complete! Thank you."
      routed: "🔄 Moving to {department} - Room {room}"
    
  appointment:
    type: "transactional"
    priority: "high"
    sound: "default"
    vibration: [200, 100, 200]
    collapse_key: "appointment"
    
    templates:
      reminder_24h: "Reminder: Appointment with Dr. {doctor} tomorrow at {time}"
      reminder_2h: "Appointment in 2 hours! Please arrive 10 min early."
      reminder_30m: "Time for your appointment! 🏥"
      confirmed: "Appointment confirmed with Dr. {doctor} on {date} at {time}"
      cancelled: "Appointment cancelled: {reason}"
      checkin_reminder: "You haven't checked in yet. Please proceed to reception."
  
  report:
    type: "transactional"
    priority: "medium"
    sound: "default"
    vibration: [100]
    
    templates:
      ready: "📄 Your lab report is ready. Tap to view."
      abnormal: "⚠️ Your test results require doctor's review. Please schedule follow-up."
      shared: "📄 Dr. {doctor} has shared a report with you."
  
  medicine:
    type: "transactional"
    priority: "medium"
    
    templates:
      ready: "💊 Your medicine is ready for collection at pharmacy counter."
      reminder: "💊 Time to take your {medicine_name}. {dosage}"
      refill_needed: "⚠️ Your prescription for {medicine_name} needs refill in {days} days."
  
  feedback:
    type: "transactional"
    priority: "low"
    
    templates:
      request: "How was your visit? We'd love your feedback! ⭐"
      thank_you: "Thank you for your feedback! ❤️"
      response: "Dr. {doctor} responded to your feedback: {response}"
  
  emergency:
    type: "transactional"
    priority: "critical"  # Bypasses all mute/silent settings
    sound: "emergency_alarm"
    vibration: [1000, 500, 1000, 500, 2000]
    
    templates:
      critical_result: "⚠️ CRITICAL: Your test result requires immediate attention. Please contact clinic."
      safety_alert: "🚨 Safety alert: {message}"
      clinic_closure: "🔴 Clinic closed due to emergency. All appointments rescheduled."
  
  promotional:
    type: "promotional"
    priority: "low"
    sound: "none"
    vibration: "none"
    max_per_day: 1
    
    templates:
      health_tip: "💡 Health Tip: {tip}"
      offer: "🎉 Special offer: {offer_description}"
      newsletter: "📰 GIL Clinic Newsletter - {month}"
      camp: "🏥 Free Health Camp on {date} at {location}"
```

## 5. NOTIFICATION ORCHESTRATOR

```python
class PushNotificationOrchestrator:
    """
    Orchestrates push notification delivery across all platforms.
    Handles prioritization, grouping, rate limiting, and fallback.
    """
    
    def __init__(self):
        self.providers = {
            'fcm': FCMPushProvider(),
            'apns': APNSPushProvider(),
            'web_push': WebPushProvider()
        }
        self.fallback = FallbackManager()
    
    async def send_to_patient(self, patient_id: UUID, notification_data: dict) -> list[dict]:
        """Send notification to all active devices of a patient."""
        
        # Get patient's active devices
        devices = PushDevice.query.filter_by(
            patient_id=patient_id,
            is_active=True,
            permission_status='granted'
        ).all()
        
        if not devices:
            # No push-capable device, use fallback
            return await self.fallback.send(patient_id, notification_data)
        
        # Check quiet hours
        devices = self._filter_quiet_hours(devices, notification_data.get('priority', 'normal'))
        
        # Check rate limits
        category = notification_data.get('category')
        devices = [d for d in devices if await self._check_rate_limit(d, category)]
        
        results = []
        for device in devices:
            provider = self.providers[self._get_provider_for_device(device)]
            
            try:
                result = await provider.send(device, notification_data)
                results.append(result)
                
                if not result.success:
                    # Attempt fallback for individual device
                    fallback_result = await self.fallback.send_to_device(device, notification_data)
                    results.append(fallback_result)
                    
            except Exception as e:
                logger.error(f"Push send failed for device {device.device_id}: {e}")
                # Don't fallback for every failure, but log for monitoring
        
        return results
    
    def _filter_quiet_hours(self, devices, priority):
        """Filter devices where quiet hours are active, unless priority is critical."""
        if priority == 'critical':
            return devices  # Critical bypasses quiet hours
        
        now = utcnow().time()
        return [
            d for d in devices
            if not (d.quiet_hours_start and d.quiet_hours_end 
                    and d.quiet_hours_start <= now <= d.quiet_hours_end)
        ]
    
    async def _check_rate_limit(self, device, category):
        """Check if device has exceeded rate limit for this category."""
        if not device.categories_enabled.get(category, True):
            return False
        
        config = NotificationCategory.query.filter_by(category_name=category).first()
        if not config or config.max_per_day == 0:
            return True
        
        recent_count = PushNotification.query.filter(
            PushNotification.device_id == device.device_id,
            PushNotification.category == category,
            PushNotification.created_at >= utcnow() - timedelta(days=1)
        ).count()
        
        return recent_count < config.max_per_day
    
    def _get_provider_for_device(self, device):
        """Map device platform to push provider."""
        return {
            'android': 'fcm',
            'ios': 'apns',
            'web': 'web_push'
        }.get(device.platform, 'fcm')

class FCMPushProvider:
    """Firebase Cloud Messaging provider."""
    
    def __init__(self):
        cred = credentials.Certificate(os.getenv('FCM_SERVICE_ACCOUNT_PATH'))
        self.fcm = firebase_admin.initialize_app(cred)
    
    async def send(self, device, notification_data):
        """Send push notification via FCM."""
        
        message = messaging.Message(
            token=device.device_token,
            notification=messaging.Notification(
                title=notification_data['title'],
                body=notification_data['body']
            ),
            data=notification_data.get('data_payload', {}),
            android=messaging.AndroidConfig(
                priority=notification_data.get('priority', 'normal'),
                notification=messaging.AndroidNotification(
                    sound=notification_data.get('sound', 'default'),
                    tag=notification_data.get('collapse_key'),
                    click_action=notification_data.get('click_action'),
                    priority=notification_data.get('priority', 'normal'),
                    channel_id=notification_data.get('category', 'general')
                ),
                ttl=timedelta(seconds=notification_data.get('ttl', 86400))
            ),
            apns=messaging.APNSConfig(
                headers={'apns-priority': '10'},
                payload=messaging.APNSPayload(
                    aps=messaging.Aps(
                        alert=messaging.ApsAlert(
                            title=notification_data['title'],
                            body=notification_data['body']
                        ),
                        sound=notification_data.get('sound', 'default'),
                        badge=notification_data.get('badge'),
                        category=notification_data.get('category'),
                        thread_id=notification_data.get('thread_id')
                    )
                )
            ),
            webpush=messaging.WebpushConfig(
                notification=messaging.WebpushNotification(
                    title=notification_data['title'],
                    body=notification_data['body'],
                    icon='/icons/icon-192.png',
                    badge='/icons/badge-72.png',
                    vibrate=notification_data.get('vibration_pattern'),
                    tag=notification_data.get('tag')
                ),
                fcm_options=messaging.WebpushFCMOptions(
                    link=notification_data.get('click_action')
                )
            )
        )
        
        try:
            response = messaging.send(message)
            return PushResult(success=True, provider_message_id=response)
        except messaging.UnregisteredError:
            # Token expired, mark device inactive
            device.is_active = False
            db.session.commit()
            return PushResult(success=False, error='token_expired')
        except Exception as e:
            return PushResult(success=False, error=str(e))
```

## 6. PERMISSION MANAGER

```python
class PushPermissionManager:
    """Manages push notification permissions across platforms."""
    
    async def request_permission(self, patient_id: UUID, platform: str):
        """Generate appropriate permission request for platform."""
        
        device = PushDevice.query.filter_by(
            patient_id=patient_id,
            platform=platform,
            is_active=True
        ).first()
        
        if not device:
            return {'action': 'register_device'}
        
        if device.permission_status == 'blocked':
            return {
                'action': 'redirect_to_settings',
                'message': 'Notifications are blocked. Please enable in browser/app settings.'
            }
        
        if device.permission_status == 'granted':
            return {'action': 'already_granted'}
        
        # For web, trigger permission prompt
        if platform == 'web':
            device.permission_prompt_count += 1
            db.session.commit()
            
            return {
                'action': 'request_permission',
                'prompt_count': device.permission_prompt_count,
                'max_prompts': 3
            }
        
        return {'action': 'request_permission'}
    
    async def handle_permission_change(self, patient_id: UUID, platform: str, new_status: str):
        """Handle permission status change from client."""
        
        device = PushDevice.query.filter_by(
            patient_id=patient_id,
            platform=platform,
            is_active=True
        ).first()
        
        if device:
            device.permission_status = new_status
            device.permission_changed_at = utcnow()
            db.session.commit()
    
    async def re_prompt_strategy(self, patient_id: UUID):
        """Determine if/when to re-prompt for permission."""
        
        devices = PushDevice.query.filter_by(
            patient_id=patient_id,
            is_active=True
        ).all()
        
        for device in devices:
            if device.permission_status == 'denied':
                if device.permission_prompt_count >= 3:
                    continue  # Don't re-prompt after 3 attempts
                
                days_since_last = (utcnow() - device.permission_changed_at).days
                
                checkpoints = {
                    1: 30,   # Re-prompt after 30 days
                    2: 90,   # Re-prompt after 90 days
                }
                
                max_prompts = checkpoints.get(device.permission_prompt_count, float('inf'))
                
                if days_since_last >= max_prompts:
                    return {
                        'action': 're_prompt',
                        'device_id': device.device_id,
                        'platform': device.platform
                    }
        
        return {'action': 'none'}
```

## 7. CONFIGURATION

```yaml
push_config:
  providers:
    fcm:
      service_account_path: "${FCM_SERVICE_ACCOUNT_PATH}"
      project_id: "${FCM_PROJECT_ID}"
      default_priority: "normal"
      default_ttl_seconds: 86400
    
    apns:
      key_id: "${APNS_KEY_ID}"
      team_id: "${APNS_TEAM_ID}"
      key_path: "${APNS_KEY_PATH}"
      topic: "com.gilclinic.app"
      environment: "production"  # production, development
    
    web_push:
      vapid_public_key: "${VAPID_PUBLIC_KEY}"
      vapid_private_key: "${VAPID_PRIVATE_KEY}"
      vapid_subject: "mailto:push@gilclinic.com"
      default_ttl_seconds: 86400
  
  categories:
    queue: {enabled: true, max_per_day: 50, fallback: "whatsapp"}
    appointment: {enabled: true, max_per_day: 10, fallback: "whatsapp"}
    report: {enabled: true, max_per_day: 5, fallback: "whatsapp"}
    medicine: {enabled: true, max_per_day: 5}
    feedback: {enabled: true, max_per_day: 3}
    emergency: {enabled: true, max_per_day: 10, bypass_quiet_hours: true}
    promotional: {enabled: false, max_per_day: 1}
  
  device_management:
    max_devices_per_patient: 5
    token_refresh_interval_hours: 24
    cleanup_stale_devices_days: 90
  
  analytics:
    track_delivery: true
    track_clicks: true
    track_dismissals: true
    generate_reports: true
    report_frequency: "daily"
```

## 8. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| FCM as primary, Web Push for PWA, APNs for iOS | Platform-native push for best delivery rates |
| Notification categories with configurable limits | Prevents notification fatigue, respects user preferences |
| Quiet hours support | Patients can set do-not-disturb periods |
| Critical priority bypasses all settings | Emergency alerts should always get through |
| Collapse key and tagging | Groups multiple notifications into one summary |
| Silent notifications for non-urgent updates | Less intrusive, badge-only updates |
| Token expiry detection and cleanup | Maintains delivery rates, prevents sending to dead tokens |
| Fallback to WhatsApp/SMS | Critical notifications must reach patient regardless of channel |
| Permission re-prompt strategy | Recovers denied permissions without annoying users |
| Per-category opt-in/out | Granular control for users, better engagement |
