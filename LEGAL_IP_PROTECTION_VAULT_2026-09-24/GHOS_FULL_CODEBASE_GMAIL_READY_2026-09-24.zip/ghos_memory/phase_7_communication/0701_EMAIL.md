---
file_id: "0701"
module_name: "Email Module"
version: "2.0"
status: "Draft"
phase: "Phase 7 — Communication"
dependencies: ["0104_COMMUNICATION_ENGINE.md"]
related_files: ["0700_SMS.md", "0702_WHATSAPP.md", "0703_PUSH_NOTIFICATION.md"]
last_updated: "2026-07-09"
priority: "Low"
ai_tags: ["ghos", "email", "documents", "sendgrid", "ses", "smtp"]
---

# GHOS - Email Integration Module

## 1. PURPOSE
Email delivery system for sending reports, invoices, prescriptions, and other documents to patients. Supports HTML templates with clinic branding, PDF attachment handling, delivery tracking with open/click analytics, and integration with multiple email providers.

## 2. ARCHITECTURE

```
[Application Services]
    │
[Email Module]
    │
├── Provider Abstraction Layer
│   ├── SendGrid (Primary)
│   ├── AWS SES (Secondary)
│   └── SMTP (Fallback)
│
├── Template Engine
│   ├── HTML Templates (Handlebars)
│   ├── Inline CSS (Premailer)
│   └── Bilingual Support
│
├── Attachment Handler
│   ├── PDF Generation
│   ├── Inline Images
│   └── Size Management (< 25MB)
│
├── Tracking System
│   ├── Open Tracking
│   ├── Click Tracking
│   ├── Bounce Handling
│   └── Complaint Feedback
│
└── Queue Manager
    ├── Rate Limiting
    ├── Retry Logic
    └── Failure Handling
```

## 3. DATA MODEL

```sql
-- Email messages log
CREATE TABLE email_messages (
    email_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    communication_id    UUID REFERENCES communication_log(communication_id),
    
    -- Recipient
    to_email            VARCHAR(255) NOT NULL,
    to_name             VARCHAR(200),
    cc_emails           JSONB DEFAULT '[]',
    bcc_emails          JSONB DEFAULT '[]',
    
    -- Content
    subject             VARCHAR(998) NOT NULL,
    body_html           TEXT,
    body_text           TEXT,
    template_id         UUID REFERENCES email_templates(template_id),
    template_vars       JSONB DEFAULT '{}',
    
    -- Provider
    provider            VARCHAR(20),            -- sendgrid, ses, smtp
    provider_message_id VARCHAR(200),
    provider_response   JSONB DEFAULT '{}',
    
    -- Attachments
    has_attachments     BOOLEAN DEFAULT FALSE,
    attachment_count    INTEGER DEFAULT 0,
    total_attachment_size INTEGER,               -- Bytes
    
    -- Status
    status              VARCHAR(30) DEFAULT 'queued',
    -- queued, sending, sent, delivered, opened, clicked,
    -- bounced, complained, failed, dropped
    
    -- Tracking
    opens_count         INTEGER DEFAULT 0,
    last_opened_at      TIMESTAMPTZ,
    clicks_count        INTEGER DEFAULT 0,
    last_clicked_at     TIMESTAMPTZ,
    
    -- Delivery
    sent_at             TIMESTAMPTZ,
    delivered_at        TIMESTAMPTZ,
    failed_at           TIMESTAMPTZ,
    failure_reason      TEXT,
    
    -- Engagement (SendGrid categories)
    categories          JSONB DEFAULT '[]',      -- For grouping/analytics
    unique_args         JSONB DEFAULT '{}',      -- Custom tracking data
    
    -- Retry
    retry_count         INTEGER DEFAULT 0,
    max_retries         INTEGER DEFAULT 3,
    
    -- Audit
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    INDEX idx_email_status (status),
    INDEX idx_email_recipient (to_email),
    INDEX idx_email_created (created_at DESC),
    INDEX idx_email_template (template_id)
);

-- Email templates
CREATE TABLE email_templates (
    template_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    template_name       VARCHAR(100) NOT NULL UNIQUE,
    
    -- Content
    subject_template    VARCHAR(998) NOT NULL,     -- Handlebars template
    body_html_template  TEXT NOT NULL,              -- HTML with Handlebars
    body_text_template  TEXT,                        -- Plain text fallback
    
    -- Variables
    variables           JSONB DEFAULT '[]',
    -- [{"name": "patient_name", "type": "string"}, {"name": "report_link", "type": "string"}]
    
    -- Design
    header_image        VARCHAR(500),               -- URL to header image
    footer_text         TEXT,
    brand_color         VARCHAR(7) DEFAULT '#0066CC',
    clinic_logo_url     VARCHAR(500),
    
    -- Provider-specific
    provider_template_id VARCHAR(200),              -- SendGrid template ID
    
    -- Categories
    category            VARCHAR(30),               -- report, invoice, prescription, notification
    is_transactional    BOOLEAN DEFAULT TRUE,       -- Transactional > promotional priority
    is_bilingual        BOOLEAN DEFAULT FALSE,
    
    -- Status
    is_active           BOOLEAN DEFAULT TRUE,
    version             INTEGER DEFAULT 1,
    
    -- Audit
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Email attachments tracking
CREATE TABLE email_attachments (
    attachment_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    email_id            UUID NOT NULL REFERENCES email_messages(email_id),
    
    file_name           VARCHAR(255) NOT NULL,
    file_type           VARCHAR(100),               -- MIME type
    file_size           INTEGER NOT NULL,           -- Bytes
    file_path           VARCHAR(500),               -- Storage path
    storage_provider    VARCHAR(20),                -- s3, minio, local
    storage_key         VARCHAR(500),
    
    is_inline           BOOLEAN DEFAULT FALSE,      -- Inline image vs attachment
    content_id          VARCHAR(100),               -- CID for inline images
    
    checksum            VARCHAR(64),                -- SHA-256 for integrity
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
```

## 4. PROVIDER ABSTRACTION

```python
class EmailProvider(ABC):
    """Abstract base class for email providers."""
    
    @abstractmethod
    async def send(self, email: EmailMessage) -> EmailResult:
        pass
    
    @abstractmethod
    async def get_delivery_status(self, provider_id: str) -> DeliveryStatus:
        pass

class SendGridProvider(EmailProvider):
    """SendGrid email provider (Primary)."""
    
    def __init__(self):
        self.client = SendGridAPIClient(os.getenv('SENDGRID_API_KEY'))
    
    async def send(self, email):
        message = Mail(
            from_email=('noreply@gilclinic.com', 'GIL Clinic'),
            to_emails=email.to_email,
            subject=email.subject,
            html_content=email.body_html
        )
        
        # Add tracking settings
        message.tracking_settings = TrackingSettings(
            click_tracking=ClickTracking(enable=True, enable_text=True),
            open_tracking=OpenTracking(enable=True)
        )
        
        # Add categories for analytics
        message.categories = email.categories or ['general']
        
        # Attachments
        for attachment in email.attachments:
            with open(attachment.file_path, 'rb') as f:
                data = f.read()
            encoded = base64.b64encode(data).decode()
            message.add_attachment(
                Attachment(
                    file_content=encoded,
                    file_name=attachment.file_name,
                    file_type=attachment.file_type,
                    disposition='attachment' if not attachment.is_inline else 'inline',
                    content_id=attachment.content_id
                )
            )
        
        try:
            response = self.client.send(message)
            
            return EmailResult(
                success=response.status_code in [200, 201, 202],
                provider_message_id=response.headers.get('X-Message-Id'),
                status_code=response.status_code
            )
        except Exception as e:
            return EmailResult(success=False, error=str(e))

class SESProvider(EmailProvider):
    """AWS SES email provider (Secondary)."""
    
    def __init__(self):
        self.client = boto3.client('ses', region_name='ap-south-1')
    
    async def send(self, email):
        # Create MIME message
        msg = MIMEMultipart('mixed')
        msg['Subject'] = email.subject
        msg['From'] = 'GIL Clinic <noreply@gilclinic.com>'
        msg['To'] = email.to_email
        
        # HTML body
        msg_body = MIMEMultipart('alternative')
        html_part = MIMEText(email.body_html, 'html', 'utf-8')
        text_part = MIMEText(email.body_text or '', 'plain', 'utf-8')
        msg_body.attach(text_part)
        msg_body.attach(html_part)
        msg.attach(msg_body)
        
        # Attachments
        for attachment in email.attachments:
            with open(attachment.file_path, 'rb') as f:
                att = MIMEApplication(f.read())
                att.add_header('Content-Disposition', 'attachment', filename=attachment.file_name)
                msg.attach(att)
        
        try:
            response = self.client.send_raw_email(
                Source='noreply@gilclinic.com',
                Destinations=[email.to_email],
                RawMessage={'Data': msg.as_string()}
            )
            
            return EmailResult(
                success=True,
                provider_message_id=response['MessageId']
            )
        except Exception as e:
            return EmailResult(success=False, error=str(e))
```

## 5. TEMPLATE ENGINE

```python
class EmailTemplateEngine:
    """
    Renders email templates using Handlebars notation.
    Supports inline CSS conversion, bilingual content, and dynamic sections.
    """
    
    def __init__(self):
        self.env = Environment(
            loader=FileSystemLoader('templates/email'),
            autoescape=True
        )
    
    def render(self, template: EmailTemplate, variables: dict, language: str = 'en') -> RenderedEmail:
        """Render an email template with variables."""
        
        # Select language-appropriate template content
        if language == 'hi' and template.is_bilingual:
            subject = template.subject_hi or template.subject_template
            body_html = template.body_html_hi or template.body_html_template
        else:
            subject = template.subject_template
            body_html = template.body_html_template
        
        # Render Handlebars template
        subject_rendered = self._render_template(subject, variables)
        html_rendered = self._render_template(body_html, variables)
        
        # Inline CSS for email client compatibility
        html_inlined = premailer.transform(html_rendered)
        
        # Generate plain text version
        text_rendered = html_to_text(html_inlined)
        
        return RenderedEmail(
            subject=subject_rendered,
            body_html=html_inlined,
            body_text=text_rendered
        )
    
    def _render_template(self, template_str, variables):
        """Render Handlebars-style template."""
        template = self.env.from_string(template_str)
        return template.render(**variables)
```

### 5.1 Email Template Example
```html
<!-- Appointment Confirmation Template -->
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width">
</head>
<body style="margin:0; padding:0; background-color:#f5f7fa; font-family: 'Inter', 'Noto Sans', sans-serif;">
    <table role="presentation" width="100%" cellpadding="0" cellspacing="0">
        <tr>
            <td align="center" style="padding: 40px 0;">
                <table role="presentation" width="600" cellpadding="0" cellspacing="0" style="background-color:#ffffff; border-radius: 12px; box-shadow: 0 2px 8px rgba(0,0,0,0.08);">
                    <!-- Header -->
                    <tr>
                        <td style="background: linear-gradient(135deg, #0066CC, #004999); padding: 30px; border-radius: 12px 12px 0 0; text-align: center;">
                            <img src="{{clinic_logo_url}}" alt="GIL Clinic" width="120" style="margin-bottom: 10px;">
                            <h1 style="color: #ffffff; margin: 10px 0 0; font-size: 24px;">Appointment Confirmed</h1>
                        </td>
                    </tr>
                    
                    <!-- Body -->
                    <tr>
                        <td style="padding: 30px;">
                            <p style="font-size: 16px; color: #1a1a2e; margin: 0 0 20px;">Dear <strong>{{patient_name}}</strong>,</p>
                            <p style="font-size: 14px; color: #4a4a6a; margin: 0 0 25px;">Your appointment has been confirmed. Here are the details:</p>
                            
                            <!-- Appointment Card -->
                            <table role="presentation" width="100%" cellpadding="12" style="background-color: #f0f7ff; border-radius: 8px; margin-bottom: 25px;">
                                <tr>
                                    <td style="border-bottom: 1px solid #d0e3ff;">
                                        <span style="color: #0066CC; font-size: 12px; font-weight: 600;">DOCTOR</span><br>
                                        <span style="color: #1a1a2e; font-size: 16px;">{{doctor_name}}</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td style="border-bottom: 1px solid #d0e3ff;">
                                        <span style="color: #0066CC; font-size: 12px; font-weight: 600;">DATE & TIME</span><br>
                                        <span style="color: #1a1a2e; font-size: 16px;">{{date}} at {{time}}</span>
                                    </td>
                                </tr>
                                <tr>
                                    <td>
                                        <span style="color: #0066CC; font-size: 12px; font-weight: 600;">LOCATION</span><br>
                                        <span style="color: #1a1a2e; font-size: 16px;">{{branch_name}}</span><br>
                                        <span style="color: #6b7280; font-size: 13px;">{{branch_address}}</span>
                                    </td>
                                </tr>
                            </table>
                            
                            <!-- QR Code -->
                            <div style="text-align: center; margin: 20px 0;">
                                <img src="cid:qr_code" alt="QR Code" width="150" style="border: 2px solid #e5e7eb; border-radius: 8px;">
                                <p style="color: #6b7280; font-size: 12px; margin: 5px 0;">Scan this QR at reception for quick check-in</p>
                            </div>
                            
                            <!-- CTA Button -->
                            <table role="presentation" width="100%" cellpadding="0">
                                <tr>
                                    <td align="center" style="padding: 15px 0;">
                                        <a href="{{tracking_link}}" style="background-color: #0066CC; color: #ffffff; text-decoration: none; padding: 14px 32px; border-radius: 8px; font-size: 16px; font-weight: 600; display: inline-block;">Track My Visit</a>
                                    </td>
                                </tr>
                            </table>
                        </td>
                    </tr>
                    
                    <!-- Footer -->
                    <tr>
                        <td style="background-color: #f9fafb; padding: 20px 30px; border-radius: 0 0 12px 12px; border-top: 1px solid #e5e7eb;">
                            <p style="color: #9ca3af; font-size: 12px; margin: 0; text-align: center;">
                                Need help? Call us at <a href="tel:+919876543210" style="color: #0066CC;">+91 98765 43210</a><br>
                                GIL Clinic | {{branch_address}}
                            </p>
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>
</body>
</html>
```

## 6. EMAIL USE CASES

```python
class EmailUseCases:
    """Predefined email use cases with template and attachment configuration."""
    
    USE_CASES = {
        'report_delivery': {
            'template': 'report_ready',
            'subject': 'Your Lab Report is Ready - GIL Clinic',
            'attachments': ['lab_report_pdf'],
            'priority': 'high',
            'categories': ['report', 'transactional']
        },
        'invoice': {
            'template': 'invoice',
            'subject': 'Invoice from GIL Clinic',
            'attachments': ['invoice_pdf', 'receipt_pdf'],
            'priority': 'normal',
            'categories': ['billing', 'transactional']
        },
        'prescription': {
            'template': 'prescription',
            'subject': 'Your Prescription - GIL Clinic',
            'attachments': ['prescription_pdf'],
            'priority': 'normal',
            'categories': ['clinical', 'transactional']
        },
        'appointment_confirmation': {
            'template': 'appointment_confirmation',
            'subject': 'Appointment Confirmed - GIL Clinic',
            'attachments': ['qr_code_png'],
            'priority': 'high',
            'categories': ['appointment', 'transactional']
        },
        'follow_up_reminder': {
            'template': 'follow_up_reminder',
            'subject': 'Follow-up Reminder - GIL Clinic',
            'attachments': [],
            'priority': 'normal',
            'categories': ['followup', 'transactional']
        },
        'health_tips_newsletter': {
            'template': 'health_tips',
            'subject': 'Health Tips from GIL Clinic',
            'attachments': [],
            'priority': 'low',
            'categories': ['newsletter', 'promotional'],
            'limits': 'max_1_per_week'
        },
        'feedback_request': {
            'template': 'feedback_request',
            'subject': 'How was your visit? - GIL Clinic',
            'attachments': [],
            'priority': 'normal',
            'categories': ['feedback', 'transactional']
        },
        'emergency_alert': {
            'template': 'emergency_alert',
            'subject': 'URGENT: Important Health Alert - GIL Clinic',
            'attachments': [],
            'priority': 'critical',
            'categories': ['alert', 'transactional']
        }
    }
    
    async def send_report(self, patient, visit, report_data):
        """Send lab report via email with PDF attachment."""
        
        # Generate PDF report
        pdf_buffer = await report_generator.generate_pdf(
            report_type='lab_report',
            data=report_data,
            template='patient_report'
        )
        
        attachment = EmailAttachment(
            file_name=f'lab_report_{visit.visit_id}_{date.today()}.pdf',
            file_type='application/pdf',
            file_data=pdf_buffer.getvalue()
        )
        
        # Render email
        email = EmailMessage(
            to_email=patient.email,
            subject='Your Lab Report is Ready - GIL Clinic',
            template='report_ready',
            variables={
                'patient_name': patient.name,
                'visit_date': visit.created_at.strftime('%d-%b-%Y'),
                'report_link': f'https://gil.app/reports/{report_data["report_id"]}',
                'doctor_name': visit.doctor.name
            },
            attachments=[attachment],
            categories=['report', 'transactional']
        )
        
        return await email_service.send(email)
```

## 7. DELIVERY ANALYTICS

```sql
-- Email engagement analytics view
CREATE VIEW email_analytics AS
SELECT 
    DATE_TRUNC('day', sent_at) as send_date,
    template_id,
    COUNT(*) as total_sent,
    SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) as delivered,
    SUM(CASE WHEN status = 'opened' THEN 1 ELSE 0 END) as opened,
    SUM(CASE WHEN status = 'clicked' THEN 1 ELSE 0 END) as clicked,
    SUM(CASE WHEN status = 'bounced' THEN 1 ELSE 0 END) as bounced,
    SUM(CASE WHEN status = 'complained' THEN 1 ELSE 0 END) as complained,
    
    -- Rates
    ROUND(100.0 * SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) as delivery_rate,
    ROUND(100.0 * SUM(CASE WHEN status = 'opened' THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN status = 'delivered' THEN 1 ELSE 0 END), 0), 1) as open_rate,
    ROUND(100.0 * SUM(CASE WHEN status = 'clicked' THEN 1 ELSE 0 END) / NULLIF(SUM(CASE WHEN status = 'opened' THEN 1 ELSE 0 END), 0), 1) as click_rate,
    ROUND(100.0 * SUM(CASE WHEN status = 'bounced' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) as bounce_rate,
    ROUND(100.0 * SUM(CASE WHEN status = 'complained' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) as complaint_rate,
    
    AVG(EXTRACT(EPOCH FROM (delivered_at - sent_at))) as avg_delivery_seconds
    
FROM email_messages
WHERE sent_at >= NOW() - INTERVAL '90 days'
GROUP BY DATE_TRUNC('day', sent_at), template_id;
```

## 8. CONFIGURATION

```yaml
email_config:
  default_provider: "sendgrid"
  fallback_providers: ["ses", "smtp"]
  
  providers:
    sendgrid:
      api_key: "${SENDGRID_API_KEY}"
      from_email: "noreply@gilclinic.com"
      from_name: "GIL Clinic"
      enable_tracking: true
      enable_click_tracking: true
      enable_open_tracking: true
      webhook_url: "https://api.gilclinic.com/webhooks/email/sendgrid"
    
    ses:
      region: "ap-south-1"
      access_key: "${AWS_ACCESS_KEY_ID}"
      secret_key: "${AWS_SECRET_ACCESS_KEY}"
      from_email: "noreply@gilclinic.com"
      configuration_set: "gil-clinic-email"
      webhook_url: "https://api.gilclinic.com/webhooks/email/ses"
    
    smtp:
      host: "${SMTP_HOST}"
      port: 587
      username: "${SMTP_USERNAME}"
      password: "${SMTP_PASSWORD}"
      from_email: "noreply@gilclinic.com"
      from_name: "GIL Clinic"
      use_tls: true
  
  limits:
    max_recipients_per_email: 5
    max_attachment_size_mb: 25
    max_attachments_per_email: 10
    rate_limit_per_second: 10
    rate_limit_per_hour: 1000
    
  retry:
    max_retries: 3
    retry_delays: [60, 300, 900]  # Seconds
    retry_on_bounce: false         # Don't retry bounces
    
  compliance:
    unsubscribe_link: true
    physical_address_in_footer: true
    complaint_handling: "auto_block"  # Auto-block on complaint
    block_list_reason: ["bounce", "complaint", "unsubscribe"]
```

## 9. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| SendGrid primary, SES secondary | SendGrid's better deliverability + templates; SES as cost-effective backup |
| HTML with inline CSS (Premailer) | Email clients strip external CSS; inline required for consistent rendering |
| Handlebars templates over string formatting | Reusable templates, designer-friendly syntax, variable validation |
| Attachment stored separately | Enables reprocessing without regenerating; tracking storage costs |
| Open/click tracking enabled | Measure engagement, determine best sending times |
| Transactional > Promotional classification | Transactional bypass spam filters; promotional needs consent |
| Bounce/complaint auto-blocking | Maintain sender reputation, avoid blacklisting |
| Email + SMS + WhatsApp as complementary channels | Patients have different preferences; redundancy for critical messages |
