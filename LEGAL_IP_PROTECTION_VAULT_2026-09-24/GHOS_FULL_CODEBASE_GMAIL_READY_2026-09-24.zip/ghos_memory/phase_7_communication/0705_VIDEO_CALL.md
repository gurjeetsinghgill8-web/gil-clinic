---
file_id: "0705"
module_name: "Video Call Module"
version: "2.0"
status: "Draft"
phase: "Phase 7 — Communication"
dependencies: ["0104_COMMUNICATION_ENGINE.md"]
related_files: ["0603_APPOINTMENT.md", "0604_FOLLOWUP.md", "0200_PATIENT_MODULE.md"]
last_updated: "2026-07-09"
priority: "Low"
ai_tags: ["ghos", "video", "telemedicine", "consultation", "webrtc", "jitsi"]
---

# GHOS - Video Call / Telemedicine Module

## 1. PURPOSE
Telemedicine and video consultation system enabling remote doctor-patient consultations. Built on WebRTC with configurable backend providers. Features include room management, waiting room, screen sharing for report viewing, call recording with consent, in-call chat, and seamless prescription generation during/after consultation.

## 2. ARCHITECTURE

```
[Client Browser / Mobile App]
    │
    ├── WebRTC (Peer Connection)
    │   ├── Video Stream
    │   ├── Audio Stream
    │   └── Screen Share
    │
    ├── Signaling (WebSocket)
    │
    └── In-call Chat (WebSocket)
           │
    ┌───────┴──────────────────────────────┐
    │      Video Call Service               │
    │                                       │
    ├── Room Manager                         │
    │   ├── Create Room                     │
    │   ├── Join Room                       │
    │   ├── Waiting Room                    │
    │   └── Room Lock/Expire                │
    │                                       │
    ├── Provider Adapter                     │
    │   ├── Daily.co (Primary)              │
    │   ├── Jitsi (Self-hosted)             │
    │   ├── Agora (Enterprise)              │
    │   └── Zoom API (Integration)          │
    │                                       │
    ├── Media Manager                        │
    │   ├── Recording Queue                 │
    │   ├── Screen Share                    │
    │   └── Virtual Background              │
    │                                       │
    ├── Collaboration Features               │
    │   ├── In-call Chat                    │
    │   ├── Report Viewer (Co-browse)       │
    │   ├── Prescription Editor             │
    │   └── Note Taking                     │
    │                                       │
    └── Analytics & Monitoring               │
        ├── Call Quality Metrics            │
        ├── Duration Tracking               │
        └── Recording Storage               │
```

## 3. DATA MODEL

```sql
-- Video call rooms
CREATE TABLE video_rooms (
    room_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Room Identity
    room_name           VARCHAR(100) NOT NULL UNIQUE,  -- Human-readable room ID
    room_url            VARCHAR(500),                   -- Provider-specific room URL
    
    -- Participants
    appointment_id      UUID REFERENCES appointments(appointment_id),
    doctor_id           UUID REFERENCES doctors(doctor_id),
    patient_id          UUID REFERENCES patients(patient_id),
    
    -- Room Type
    room_type           VARCHAR(30) DEFAULT 'consultation',
    -- consultation, follow_up, emergency, group_session, staff_meeting
    
    -- Provider
    provider            VARCHAR(30) NOT NULL,            -- daily, jitsi, agora, zoom
    provider_room_id    VARCHAR(200),                    -- Provider's room identifier
    
    -- Tokens
    doctor_token        VARCHAR(500),                    -- Doctor's access token
    patient_token       VARCHAR(500),                    -- Patient's access token
    host_token          VARCHAR(500),                    -- Host/owner token
    
    -- Status
    status              VARCHAR(30) DEFAULT 'pending',
    -- pending, active, in_progress, completed, cancelled, expired
    is_locked           BOOLEAN DEFAULT FALSE,
    
    -- Schedule
    scheduled_at        TIMESTAMPTZ,                     -- Scheduled start time
    started_at          TIMESTAMPTZ,
    ended_at            TIMESTAMPTZ,
    duration_seconds    INTEGER GENERATED ALWAYS AS (
        CASE WHEN ended_at IS NOT NULL AND started_at IS NOT NULL
             THEN EXTRACT(EPOCH FROM (ended_at - started_at))::INTEGER
             ELSE NULL END
    ) STORED,
    
    -- Settings
    max_participants    INTEGER DEFAULT 2,
    enable_recording    BOOLEAN DEFAULT FALSE,
    enable_chat         BOOLEAN DEFAULT TRUE,
    enable_screen_share BOOLEAN DEFAULT TRUE,
    enable_waiting_room BOOLEAN DEFAULT TRUE,
    auto_record         BOOLEAN DEFAULT FALSE,
    
    -- Configuration
    room_config         JSONB DEFAULT '{}',
    -- {"video_codec": "H264", "audio_codec": "opus", "resolution": "720p", "fps": 30}
    
    -- Audit
    created_by          UUID REFERENCES staff(staff_id),
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    expires_at          TIMESTAMPTZ,                     -- Auto-expiry
    
    INDEX idx_vr_appointment (appointment_id),
    INDEX idx_vr_doctor (doctor_id),
    INDEX idx_vr_status (status)
);

-- Video call sessions (individual participant connections)
CREATE TABLE video_call_sessions (
    session_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id             UUID NOT NULL REFERENCES video_rooms(room_id),
    
    -- Participant
    participant_id      UUID,                            -- doctor_id or patient_id
    participant_type    VARCHAR(20) NOT NULL,             -- doctor, patient, staff_observer
    participant_name    VARCHAR(200),
    
    -- Connection
    provider_session_id VARCHAR(200),                     -- Provider's session identifier
    ip_address          INET,
    user_agent          TEXT,
    device_type         VARCHAR(50),                      -- mobile, desktop, tablet
    browser             VARCHAR(50),
    
    -- Media
    video_enabled       BOOLEAN DEFAULT TRUE,
    audio_enabled       BOOLEAN DEFAULT TRUE,
    screen_sharing      BOOLEAN DEFAULT FALSE,
    
    -- Session
    joined_at           TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    left_at             TIMESTAMPTZ,
    duration_seconds    INTEGER,
    disconnect_reason   VARCHAR(50),                     -- normal, timeout, error, kicked
    
    -- Quality
    connection_quality  INTEGER,                          -- 1-5
    quality_metrics     JSONB DEFAULT '{}',
    -- {"avg_bitrate": 1500000, "packet_loss": 0.5, "jitter": 20, "latency": 50}
    
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- Video call recordings
CREATE TABLE video_recordings (
    recording_id        UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id             UUID NOT NULL REFERENCES video_rooms(room_id),
    
    -- Recording
    provider_recording_id VARCHAR(200),
    recording_type      VARCHAR(20) DEFAULT 'combined',  -- combined, gallery, individual
    storage_url         VARCHAR(500),
    storage_provider    VARCHAR(20),                     -- s3, minio, provider_storage
    
    -- Metadata
    duration_seconds    INTEGER,
    file_size           BIGINT,
    file_format         VARCHAR(10),                     -- mp4, webm
    resolution          VARCHAR(10),                     -- 720p, 1080p
    
    -- Consent
    consent_obtained    BOOLEAN DEFAULT FALSE,
    consent_recorded_at TIMESTAMPTZ,
    consent_method      VARCHAR(30),                     -- verbal, checkbox, signed_form
    
    -- Status
    status              VARCHAR(30) DEFAULT 'processing',
    -- pending, processing, completed, failed, deleted
    
    -- Retention
    retention_days      INTEGER DEFAULT 90,
    auto_delete_at      TIMESTAMPTZ,
    deleted_at          TIMESTAMPTZ,
    
    -- Transcript
    transcription       TEXT,
    transcription_status VARCHAR(20) DEFAULT 'pending',
    
    created_at          TIMESTAMPTZ DEFAULT NOW()
);

-- In-call chat messages
CREATE TABLE video_call_chat (
    chat_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    room_id             UUID NOT NULL REFERENCES video_rooms(room_id),
    session_id          UUID REFERENCES video_call_sessions(session_id),
    
    sender_id           UUID NOT NULL,
    sender_type         VARCHAR(20) NOT NULL,             -- doctor, patient
    sender_name         VARCHAR(200),
    message_type        VARCHAR(20) DEFAULT 'text',       -- text, image, file, system
    
    message_text        TEXT,
    file_url            VARCHAR(500),
    file_name           VARCHAR(200),
    
    sent_at             TIMESTAMPTZ DEFAULT NOW(),
    read_at             TIMESTAMPTZ,
    
    INDEX idx_chat_room (room_id, sent_at)
);
```

## 4. PROVIDER ADAPTER

```python
class VideoProvider(ABC):
    """Abstract base class for video call providers."""
    
    @abstractmethod
    async def create_room(self, config: RoomConfig) -> RoomResult:
        pass
    
    @abstractmethod
    async def get_room(self, room_id: str) -> RoomInfo:
        pass
    
    @abstractmethod
    async def delete_room(self, room_id: str) -> bool:
        pass
    
    @abstractmethod
    async def generate_token(self, room_id: str, participant: ParticipantInfo) -> str:
        pass

class DailyCoProvider(VideoProvider):
    """Daily.co video provider (Primary - free tier available)."""
    
    def __init__(self):
        self.api_key = os.getenv('DAILY_API_KEY')
        self.base_url = 'https://api.daily.co/v1'
    
    async def create_room(self, config):
        """Create a Daily.co room."""
        
        payload = {
            'name': config.room_name,
            'privacy': 'private',
            'properties': {
                'max_participants': config.max_participants or 2,
                'enable_recording': config.recording or 'local',
                'enable_chat': config.enable_chat,
                'enable_screenshare': config.enable_screen_share,
                'start_video_off': False,
                'start_audio_off': False,
                'enable_emoji_reactions': True,
                'enable_hand_raising': True,
                'enable_prejoin_ui': False,       # Skip pre-join screen
                'enable_people_ui': True,
                'enable_pip_ui': True,
                'auto_join': True,                 # Join without host present
                'owner_only_broadcast': False,
                'exp': int(config.expires_at.timestamp()) if config.expires_at else None
            }
        }
        
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f'{self.base_url}/rooms',
                json=payload,
                headers=headers
            )
        
        if response.status_code == 200:
            data = response.json()
            return RoomResult(
                success=True,
                provider_room_id=data['id'],
                room_url=data['url'],
                room_name=data['name']
            )
        else:
            return RoomResult(success=False, error=response.text)
    
    async def generate_token(self, room_id, participant):
        """Generate participant token for the room."""
        
        payload = {
            'properties': {
                'room_name': room_id,
                'user_name': participant.name,
                'user_id': str(participant.id),
                'is_owner': participant.role == 'host',
                'start_video_off': False,
                'start_audio_off': False,
                'enable_recording': participant.permissions.get('recording', False),
                'enable_screenshare': participant.permissions.get('screen_share', True),
                'exp': int((utcnow() + timedelta(hours=2)).timestamp())
            }
        }
        
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f'{self.base_url}/meeting-tokens',
                json=payload,
                headers=headers
            )
        
        if response.status_code == 200:
            data = response.json()
            return data['token']
        else:
            raise VideoProviderException(f"Token generation failed: {response.text}")
    
    async def set_presence(self, room_id, participant_id, present: bool):
        """Mark participant presence in room."""
        # Implement if needed for waiting room management
        pass

class JitsiProvider(VideoProvider):
    """Self-hosted Jitsi Meet provider."""
    
    def __init__(self):
        self.server_url = os.getenv('JITSI_SERVER_URL', 'https://meet.gilclinic.com')
        self.app_id = os.getenv('JITSI_APP_ID')
        self.app_secret = os.getenv('JITSI_APP_SECRET')
    
    async def create_room(self, config):
        """Create a Jitsi room (Jitsi rooms are created on first join)."""
        
        room_name = f"gil-{config.room_name}-{int(utcnow().timestamp())}"
        room_url = f"{self.server_url}/{room_name}"
        
        return RoomResult(
            success=True,
            provider_room_id=room_name,
            room_url=room_url,
            room_name=room_name
        )
    
    async def generate_token(self, room_id, participant):
        """Generate JWT token for Jitsi authentication."""
        
        now = int(utcnow().timestamp())
        payload = {
            'context': {
                'user': {
                    'name': participant.name,
                    'id': str(participant.id),
                    'email': participant.email,
                    'avatar': participant.avatar_url
                }
            },
            'aud': 'jitsi',
            'iss': self.app_id,
            'sub': self.server_url,
            'room': room_id,
            'exp': now + 7200,  # 2 hours
            'iat': now,
            'moderator': participant.role == 'host'
        }
        
        token = jwt.encode(payload, self.app_secret, algorithm='HS256')
        return token
```

## 5. ROOM MANAGEMENT SERVICE

```python
class VideoRoomManager:
    """
    Manages the full lifecycle of video consultation rooms.
    Creates rooms, manages waiting room, handles participants, and cleans up.
    """
    
    def __init__(self):
        self.providers = {
            'daily': DailyCoProvider(),
            'jitsi': JitsiProvider(),
            'agora': AgoraProvider(),
            'zoom': ZoomProvider()
        }
        self.default_provider = 'daily'
    
    async def create_consultation_room(self, appointment: Appointment, doctor: Staff, patient: Patient) -> VideoRoom:
        """Create a room for a scheduled consultation."""
        
        config = RoomConfig(
            room_name=f"consult-{appointment.appointment_id[:8]}",
            max_participants=2,
            enable_chat=True,
            enable_screen_share=True,
            enable_recording=appointment.allow_recording or False,
            expires_at=appointment.end_time + timedelta(hours=1),
            waiting_room=True
        )
        
        provider = self.providers[self.default_provider]
        result = await provider.create_room(config)
        
        if not result.success:
            # Fallback to alternate provider
            for name, alt_provider in self.providers.items():
                if name == self.default_provider:
                    continue
                result = await alt_provider.create_room(config)
                if result.success:
                    provider = alt_provider
                    break
        
        if not result.success:
            raise VideoRoomCreationException("All providers failed to create room")
        
        # Generate tokens
        doctor_token = await provider.generate_token(
            result.provider_room_id, 
            ParticipantInfo(doctor.staff_id, doctor.name, doctor.email, role='host')
        )
        
        patient_token = await provider.generate_token(
            result.provider_room_id,
            ParticipantInfo(patient.patient_id, patient.name, patient.email, role='participant')
        )
        
        # Save room
        room = VideoRoom(
            room_name=result.room_name,
            room_url=result.room_url,
            appointment_id=appointment.appointment_id,
            doctor_id=doctor.staff_id,
            patient_id=patient.patient_id,
            room_type='consultation',
            provider=self.default_provider,
            provider_room_id=result.provider_room_id,
            doctor_token=doctor_token,
            patient_token=patient_token,
            status='pending',
            scheduled_at=appointment.start_time,
            expires_at=appointment.end_time + timedelta(hours=1),
            enable_waiting_room=True
        )
        
        db.session.add(room)
        db.session.commit()
        
        return room
    
    async def join_room(self, room_id: UUID, participant_id: UUID, participant_type: str) -> JoinInfo:
        """Join a video consultation room."""
        
        room = VideoRoom.query.get(room_id)
        
        if not room:
            raise RoomNotFoundError()
        
        if room.expires_at and room.expires_at < utcnow():
            raise RoomExpiredError()
        
        if room.is_locked:
            raise RoomLockedError()
        
        # Determine token
        if participant_type == 'doctor':
            token = room.doctor_token
        elif participant_type == 'patient':
            token = room.patient_token
        else:
            token = room.host_token
        
        # Create session record
        session = VideoCallSession(
            room_id=room_id,
            participant_id=participant_id,
            participant_type=participant_type,
            joined_at=utcnow()
        )
        db.session.add(session)
        
        # Update room status
        if room.status == 'pending':
            room.status = 'active'
            room.started_at = utcnow()
        
        db.session.commit()
        
        return JoinInfo(
            room_url=room.room_url,
            token=token,
            provider=room.provider,
            session_id=session.session_id,
            config=room.room_config
        )
    
    async def end_room(self, room_id: UUID):
        """End a video consultation and clean up."""
        
        room = VideoRoom.query.get(room_id)
        room.status = 'completed'
        room.ended_at = utcnow()
        
        # End all active sessions
        active_sessions = VideoCallSession.query.filter_by(
            room_id=room_id,
            left_at=None
        ).all()
        
        for session in active_sessions:
            session.left_at = utcnow()
            session.duration_seconds = int(
                (session.left_at - session.joined_at).total_seconds()
            )
        
        db.session.commit()
        
        # Delete room from provider if needed
        try:
            provider = self.providers[room.provider]
            await provider.delete_room(room.provider_room_id)
        except Exception as e:
            logger.warning(f"Failed to delete provider room: {e}")
```

## 6. IN-CALL FEATURES

### 6.1 Screen Sharing for Report Review
```python
class ReportSharing:
    """
    Enable doctor to share lab reports during consultation.
    Uses screen sharing + overlay, or direct report viewer.
    """
    
    async def share_report(self, room_id, report_id, sharing_by):
        """Share a report during video call."""
        
        report = await self._get_report(report_id)
        
        # Overlay report on video stream (via provider API)
        if self._supports_overlay(room_id):
            overlay_url = self._generate_report_url(report)
            await self._set_overlay(room_id, overlay_url)
        
        # Or broadcast screen share prompt
        else:
            await self._send_chat_message(
                room_id=room_id,
                sender='system',
                message=f"Doctor is sharing report: {report.report_name}",
                metadata={'action': 'view_report', 'report_url': report.view_url}
            )
    
    async def annotate_report(self, room_id, report_id, annotations):
        """Add annotations to shared report."""
        # Save annotations
        # Update real-time view for both participants
        pass
```

### 6.2 In-Call Prescription
```python
class InCallPrescription:
    """
    Generate prescriptions during or immediately after video consultation.
    Doctor fills digital prescription form within the call UI.
    """
    
    async def open_prescription_form(self, room_id, doctor_id):
        """Open prescription form for doctor during call."""
        
        appointment = await self._get_appointment_from_room(room_id)
        
        form_data = {
            'patient_name': appointment.patient.name,
            'patient_age': appointment.patient.age,
            'patient_gender': appointment.patient.gender,
            'date': utcnow().strftime('%d-%b-%Y'),
            'diagnosis': '',
            'medicines': [],
            'tests': [],
            'advice': '',
            'follow_up': None
        }
        
        # Send form URL via chat
        await self._send_chat_message(
            room_id=room_id,
            sender='system',
            message='doctor_opened_prescription',
            metadata={
                'action': 'open_prescription',
                'form_id': str(uuid4()),
                'data': form_data
            }
        )
        
        return form_data
```

## 7. CONFIGURATION

```yaml
video_call_config:
  default_provider: "daily"
  provider_failover: true
  
  providers:
    daily:
      api_key: "${DAILY_API_KEY}"
      domain: "gilclinic.daily.co"
      webhook_url: "https://api.gilclinic.com/webhooks/video/daily"
    
    jitsi:
      server_url: "https://meet.gilclinic.com"
      app_id: "${JITSI_APP_ID}"
      app_secret: "${JITSI_APP_SECRET}"
      enable_auth: true
    
    agora:
      app_id: "${AGORA_APP_ID}"
      app_certificate: "${AGORA_APP_CERTIFICATE}"
      channel_profile: "communication"
    
    zoom:
      client_id: "${ZOOM_CLIENT_ID}"
      client_secret: "${ZOOM_CLIENT_SECRET}"
      account_id: "${ZOOM_ACCOUNT_ID}"
  
  rooms:
    max_duration_minutes: 60
    auto_extend_on_active: true
    extend_by_minutes: 15
    cleanup_expired_after_hours: 24
    max_participants: 2  # 1 doctor + 1 patient
    waiting_room_enabled: true
    auto_lock_on_patient_join: false
  
  media:
    default_resolution: "720p"
    max_bitrate_kbps: 2000
    adaptive_bitrate: true
    simulcast_enabled: true
    fallback_to_audio: true
    
  recording:
    enabled: true
    consent_required: true
    storage: "s3"
    retention_days: 90
    auto_transcribe: true
    transcription_provider: "aws_transcribe"
    
  quality:
    min_bandwidth_kbps: 300
    mos_threshold: 3.5
    notify_on_poor_quality: true
    auto_downgrade_to_audio: false
```

## 8. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| Daily.co as primary provider | Generous free tier (10k min/month), simple API, no self-hosting |
| Jitsi as self-hosted fallback | Complete control, no per-minute costs at scale |
| Provider abstraction layer | Swap providers without changing application code |
| Waiting room for patient | Doctor joins first, patient admitted when ready |
| Recording with explicit consent | Compliance with telemedicine guidelines (India) |
| In-call chat alongside video | Share links, follow-up instructions without interrupting |
| Screen sharing for reports | Doctor can walk patient through results visually |
| In-call prescription generation | Complete consultation workflow without leaving call |
| Quality monitoring with auto-downgrade | Ensures usable call even on poor connections |
| WebRTC with peer-to-peer when possible | Lower latency, no media server costs for 1:1 calls |
