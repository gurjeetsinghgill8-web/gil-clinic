---
file_id: "0704"
module_name: "Voice Call Module"
version: "2.0"
status: "Draft"
phase: "Phase 7 — Communication"
dependencies: ["0104_COMMUNICATION_ENGINE.md", "0503_AI_VOICE_AGENT.md"]
related_files: ["0500_AI_RECEPTIONIST.md", "0702_WHATSAPP.md", "0700_SMS.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "voice", "call", "telephony", "twilio", "exotel", "tts"]
---

# GHOS - Voice Call Integration Module

## 1. PURPOSE
Voice call integration for AI receptionist, automated follow-up calls, critical alert notifications, and interactive voice response (IVR) menus. Supports Text-to-Speech in English and Hindi, call recording, outbound and inbound call handling, missed call service, and comprehensive call analytics.

## 2. ARCHITECTURE

```
[Telephony Providers]
   ├── Twilio (Primary)
   ├── Exotel (India Primary)
   ├── Knowlarity (India Fallback)
   └── Plivo (Backup)
           │
    [Voice Gateway / SIP Trunk]
           │
    ┌──────┴─────────────────────────────┐
    │     Voice Call Engine               │
    │                                     │
    ├── Call Router                        │
    │   ├── Inbound Call Handler           │
    │   ├── Outbound Call Manager          │
    │   └── Missed Call Service            │
    │                                     │
    ├── IVR System                         │
    │   ├── Menu Builder                   │
    │   ├── DTMF Handler                   │
    │   └── Speech Recognition             │
    │                                     │
    ├── TTS Engine                          │
    │   ├── English (en-IN)                │
    │   ├── Hindi (hi-IN)                  │
    │   └── Hinglish (Hinglish)            │
    │                                     │
    ├── Call Recording Manager             │
    │   ├── Auto-record (consent-based)    │
    │   ├── Storage & Retention            │
    │   └── Transcription                  │
    │                                     │
    └── Analytics & Monitoring             │
        ├── Call Metrics                  │
        ├── Quality Scoring               │
        └── Cost Tracking                 │
```

## 3. DATA MODEL

```sql
-- Voice calls log
CREATE TABLE voice_calls (
    call_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    communication_id    UUID REFERENCES communication_log(communication_id),
    
    -- Call Identity
    provider_call_id    VARCHAR(100),              -- Provider's call SID/ID
    provider            VARCHAR(20) NOT NULL,       -- twilio, exotel, knowlarity, plivo
    
    -- Participants
    from_number         VARCHAR(20) NOT NULL,
    to_number           VARCHAR(20) NOT NULL,
    patient_id          UUID REFERENCES patients(patient_id),
    staff_id            UUID REFERENCES staff(staff_id),
    
    -- Direction
    direction           VARCHAR(10) NOT NULL,       -- inbound, outbound
    
    -- Call Type
    call_type           VARCHAR(30) NOT NULL,
    -- ai_receptionist, follow_up, reminder, emergency, appointment_confirmation,
    -- missed_callback, patient_call, staff_call, ivr_menu
    
    -- Timing
    initiated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    connected_at        TIMESTAMPTZ,               -- When call was answered
    duration_seconds    INTEGER,
    ended_at            TIMESTAMPTZ,
    call_end_reason     VARCHAR(30),               -- completed, missed, cancelled, failed, busy, no_answer
    
    -- Status
    status              VARCHAR(30) DEFAULT 'initiating',
    -- initiating, ringing, in_progress, completed, missed, failed, busy, cancelled, no_answer
    
    -- Recording
    recording_enabled   BOOLEAN DEFAULT FALSE,
    recording_consent   BOOLEAN DEFAULT FALSE,      -- Patient consent for recording
    recording_url       VARCHAR(500),               -- Recording file URL
    recording_duration  INTEGER,
    recording_size      INTEGER,
    transcription       TEXT,
    transcription_status VARCHAR(20),               -- pending, completed, failed
    
    -- IVR
    ivr_menu_path       JSONB DEFAULT '[]',         -- Path through IVR menus
    dtmf_inputs         VARCHAR(50),                 -- DTMF keys pressed
    speech_inputs       JSONB DEFAULT '[]',          -- Speech recognition results
    
    -- AI Agent
    ai_agent_id         UUID,
    ai_conversation_log JSONB DEFAULT '[]',
    ai_confidence_score DECIMAL(5, 2),
    ai_escalated_to_human BOOLEAN DEFAULT FALSE,
    
    -- TTS
    tts_enabled         BOOLEAN DEFAULT TRUE,
    tts_language        VARCHAR(10) DEFAULT 'en-IN', -- en-IN, hi-IN
    tts_voice           VARCHAR(50),                 -- Google Wavenet, Polly Neural
    
    -- Cost
    call_cost           DECIMAL(10, 6),
    cost_currency       VARCHAR(5) DEFAULT 'INR',
    cost_breakdown      JSONB DEFAULT '{}',          -- Per-minute cost, recording cost, etc.
    
    -- Quality
    quality_score       INTEGER,                     -- 1-5 based on MOS
    quality_metrics     JSONB DEFAULT '{}',
    -- {"mos": 4.2, "jitter": 12, "latency_ms": 150, "packet_loss_pct": 0.5}
    
    -- Audit
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    INDEX idx_voice_patient (patient_id),
    INDEX idx_voice_status (status),
    INDEX idx_voice_call_type (call_type),
    INDEX idx_voice_provider (provider_call_id)
);

-- Call queues for outbound
CREATE TABLE outbound_call_queue (
    queue_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    call_id             UUID REFERENCES voice_calls(call_id),
    
    patient_id          UUID NOT NULL REFERENCES patients(patient_id),
    phone_number        VARCHAR(20) NOT NULL,
    
    call_type           VARCHAR(30) NOT NULL,
    priority            INTEGER DEFAULT 5,          -- 1 (critical) to 10 (low)
    
    -- Scheduling
    scheduled_at        TIMESTAMPTZ,                 -- When to call
    attempt_count       INTEGER DEFAULT 0,
    max_attempts        INTEGER DEFAULT 3,
    last_attempt_at     TIMESTAMPTZ,
    next_attempt_at     TIMESTAMPTZ,
    
    -- Callback
    is_missed_callback  BOOLEAN DEFAULT FALSE,
    missed_call_from    VARCHAR(20),
    callback_url        VARCHAR(500),               -- Twilio callback
    
    -- Context
    call_context        JSONB DEFAULT '{}',
    -- {"intent": "appointment_reminder", "appointment_id": "uuid", ...}
    
    status              VARCHAR(20) DEFAULT 'queued',
    -- queued, scheduled, calling, completed, failed, cancelled
    
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    
    INDEX idx_outbound_status (status),
    INDEX idx_outbound_priority (priority, scheduled_at)
);
```

## 4. PROVIDER ABSTRACTION

```python
class VoiceProvider(ABC):
    """Abstract base class for voice call providers."""
    
    @abstractmethod
    async def make_call(self, call_request: CallRequest) -> CallResult:
        pass
    
    @abstractmethod
    async def end_call(self, provider_call_id: str) -> bool:
        pass
    
    @abstractmethod
    async def get_call_status(self, provider_call_id: str) -> CallStatus:
        pass
    
    @abstractmethod
    async def gather_dtmf(self, provider_call_id: str, prompt: str, max_digits: int) -> str:
        pass
    
    @abstractmethod
    async def say_text(self, provider_call_id: str, text: str, language: str, voice: str):
        pass

class TwilioVoiceProvider(VoiceProvider):
    """Twilio Voice provider implementation."""
    
    def __init__(self):
        self.client = Client(
            os.getenv('TWILIO_ACCOUNT_SID'),
            os.getenv('TWILIO_AUTH_TOKEN')
        )
        self.from_number = os.getenv('TWILIO_VOICE_NUMBER')
    
    async def make_call(self, call_request):
        """Initiate an outbound voice call."""
        
        twiml = self._build_twiml(call_request)
        
        try:
            call = self.client.calls.create(
                url=twiml,
                to=call_request.to_number,
                from_=self.from_number,
                record=call_request.recording_enabled,
                status_callback=call_request.status_callback_url,
                status_callback_event=['initiated', 'ringing', 'answered', 'completed'],
                timeout=call_request.timeout_seconds or 30
            )
            
            return CallResult(
                success=True,
                provider_call_id=call.sid,
                status='ringing',
                provider_data={'sid': call.sid, 'status': call.status}
            )
            
        except Exception as e:
            return CallResult(success=False, error=str(e))
    
    def _build_twiml(self, call_request):
        """Build TwiML based on call type."""
        response = VoiceResponse()
        
        # AI Agent call - connect to WebSocket
        if call_request.call_type == 'ai_receptionist':
            connect = Connect()
            connect.stream(url=call_request.ws_url)
            response.append(connect)
        
        # IVR Menu call
        elif call_request.call_type == 'ivr_menu':
            gather = Gather(input='dtmf speech', num_digits=1, action=call_request.ivr_callback)
            gather.say(call_request.ivr_prompt, voice='Polly.Aditi', language='hi-IN')
            response.append(gather)
            response.say("We didn't receive any input. Goodbye.")
        
        # Simple text-to-speech
        elif call_request.call_type in ['follow_up', 'reminder', 'emergency']:
            response.say(call_request.tts_text, voice='Polly.Aditi', language=call_request.tts_language)
            response.hangup()
        
        return str(response)

class ExotelVoiceProvider(VoiceProvider):
    """Exotel provider for India-specific calling."""
    
    def __init__(self):
        self.api_key = os.getenv('EXOTEL_API_KEY')
        self.api_token = os.getenv('EXOTEL_API_TOKEN')
        self.exotel_sid = os.getenv('EXOTEL_SID')
        self.from_number = os.getenv('EXOTEL_NUMBER')
        self.base_url = f"https://{self.api_key}:{self.api_token}@api.exotel.com/v1/Accounts/{self.exotel_sid}"
    
    async def make_call(self, call_request):
        """Initiate call via Exotel API."""
        payload = {
            'From': self.from_number,
            'To': call_request.to_number,
            'CallerId': self.from_number,
            'Url': call_request.twiml_url or 'http://my.exotel.com/ivr/greeting.xml',
            'Record': 'true' if call_request.recording_enabled else 'false',
            'StatusCallback': call_request.status_callback_url
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                f"{self.base_url}/Calls/connect.json",
                data=payload
            )
        
        if response.status_code == 200:
            data = response.json()
            return CallResult(
                success=True,
                provider_call_id=data['Call']['Sid'],
                status='ringing'
            )
        else:
            return CallResult(success=False, error=response.text)
```

## 5. TTS ENGINE

```python
class TTSEngine:
    """
    Text-to-Speech engine supporting multiple languages and voices.
    Converts text to natural-sounding speech for automated calls.
    """
    
    VOICES = {
        'en-IN': {
            'primary': 'Google.en-IN-Wavenet-C',
            'fallback': 'Polly.Joanna',
            'speed': '1.0',
            'pitch': '0'
        },
        'hi-IN': {
            'primary': 'Google.hi-IN-Wavenet-A',
            'fallback': 'Polly.Aditi',
            'speed': '0.9',
            'pitch': '0'
        },
        'Hinglish': {
            'primary': 'Google.hi-IN-Wavenet-A',
            'fallback': 'Polly.Aditi',
            'speed': '1.0',
            'pitch': '0'
        }
    }
    
    def __init__(self):
        self.google_client = texttospeech.TextToSpeechClient()
        self.polly_client = boto3.client('polly', region_name='ap-south-1')
    
    async def synthesize(self, text: str, language: str = 'en-IN', voice_type: str = 'google') -> bytes:
        """
        Convert text to speech audio bytes.
        Falls back to Polly if Google TTS fails.
        """
        
        voice_config = self.VOICES.get(language, self.VOICES['en-IN'])
        
        if voice_type == 'google' or voice_type == 'primary':
            try:
                return await self._google_tts(text, language, voice_config['primary'])
            except Exception:
                pass
        
        # Fallback to Polly
        return await self._polly_tts(text, voice_config['fallback'])
    
    async def _google_tts(self, text, language_code, voice_name):
        """Use Google Cloud Text-to-Speech."""
        synthesis_input = texttospeech.SynthesisInput(text=text)
        
        voice = texttospeech.VoiceSelectionParams(
            language_code=language_code,
            name=voice_name
        )
        
        audio_config = texttospeech.AudioConfig(
            audio_encoding=texttospeech.AudioEncoding.LINEAR16,
            speaking_rate=1.0,
            pitch=0
        )
        
        response = self.google_client.synthesize_speech(
            input=synthesis_input,
            voice=voice,
            audio_config=audio_config
        )
        
        return response.audio_content
    
    async def _polly_tts(self, text, voice_id):
        """Use AWS Polly for TTS fallback."""
        response = self.polly_client.synthesize_speech(
            Engine='neural',
            LanguageCode='hi-IN' if 'hi' in voice_id else 'en-IN',
            OutputFormat='mp3',
            Text=text,
            VoiceId=voice_id.split('.')[-1]
        )
        
        return response['AudioStream'].read()
```

## 6. MISSED CALL SERVICE

```python
class MissedCallService:
    """
    Handles missed calls from patients.
    When patient gives a missed call, system calls back or sends WhatsApp link.
    """
    
    def __init__(self):
        self.auto_callback = True
        self.callback_timeout_seconds = 30
    
    async def handle_missed_call(self, from_number: str, provider: str, provider_call_id: str):
        """Process a missed call from a patient."""
        
        # Find or create patient
        patient = await self._find_patient_by_phone(from_number)
        
        if not patient:
            # Unknown number - send registration link
            await self._send_registration_link(from_number)
            return
        
        # Log the missed call
        call = VoiceCall(
            from_number=from_number,
            to_number=self.config.welcome_number,
            direction='inbound',
            call_type='missed_callback',
            status='missed',
            provider=provider,
            provider_call_id=provider_call_id
        )
        db.session.add(call)
        db.session.commit()
        
        # Determine action based on patient context
        context = await self._get_patient_context(patient.patient_id)
        
        if context.get('active_visit'):
            # Patient has active visit - send tracking link
            await self._send_tracking_link(patient, context['active_visit'])
        
        elif context.get('upcoming_appointment'):
            # Patient has upcoming appointment - send reminder
            await self._send_appointment_reminder(patient, context['upcoming_appointment'])
        
        elif self.auto_callback:
            # Auto call back
            await self._initiate_callback(patient, from_number)
        
        else:
            # Send WhatsApp message
            await self._send_whatsapp_options(patient)
    
    async def _initiate_callback(self, patient, from_number):
        """Call the patient back with AI receptionist."""
        
        call_request = CallRequest(
            to_number=from_number,
            call_type='ai_receptionist',
            patient_id=patient.patient_id,
            context={'source': 'missed_call'}
        )
        
        call_result = await voice_engine.make_call(call_request)
        
        if call_result.success:
            # Connect to AI agent for natural conversation
            await ai_voice_agent.handle_call(call_result.provider_call_id, patient)
    
    async def _send_tracking_link(self, patient, visit):
        """Send WhatsApp message with tracking link."""
        await whatsapp_sender.send_template(
            to=patient.phone,
            template='track_visit',
            variables={
                'patient_name': patient.name,
                'tracking_link': f'https://gil.app/track/{visit.token}',
                'token': visit.token
            }
        )
```

## 7. CALL FLOWS

### 7.1 AI Receptionist Flow
```
Patient calls clinic number
  -> Twilio/Exotel answers
  -> Plays greeting: "Welcome to GIL Clinic"
  -> AI Voice Agent: "How can I help you?"
  -> Patient speaks: "I want to book an appointment"
  -> AI processes intent, checks availability
  -> AI: "Sure, Dr. Patel is available tomorrow at 10 AM or 2 PM. Which works?"
  -> Patient: "10 AM works"
  -> AI: "Your appointment with Dr. Patel is confirmed for tomorrow at 10 AM."
  -> AI: "Shall I send confirmation on WhatsApp?"
  -> Patient: "Yes please"
  -> AI: "Done! Anything else?"
  -> Patient: "No, thanks"
  -> AI: "Thank you for calling GIL Clinic. Have a great day!"
  -> Call ends
  -> Confirmation sent via WhatsApp
```

### 7.2 Outbound Alert Flow
```
System triggers critical alert
  -> Try WhatsApp first
  -> If not read within 5 minutes:
    -> Initiate voice call
    -> TTS: "This is an urgent message from GIL Clinic."
    -> TTS: "Your test results require immediate attention."
    -> TTS: "Please visit the clinic or call back at 9876543210."
    -> TTS: "Press 1 to confirm, 2 to request callback"
    -> If DTMF 1: Mark as acknowledged
    -> If DTMF 2: Schedule callback
    -> If no input: Retry in 15 min (up to 3 times)
    -> If all failed: Alert on-call doctor
```

## 8. CONFIGURATION

```yaml
voice_config:
  default_provider: "twilio"
  india_provider: "exotel"
  
  providers:
    twilio:
      account_sid: "${TWILIO_ACCOUNT_SID}"
      auth_token: "${TWILIO_AUTH_TOKEN}"
      voice_number: "${TWILIO_VOICE_NUMBER}"
      status_callback: "https://api.gilclinic.com/webhooks/voice/twilio"
      recording_callback: "https://api.gilclinic.com/webhooks/voice/twilio/recording"
    
    exotel:
      api_key: "${EXOTEL_API_KEY}"
      api_token: "${EXOTEL_API_TOKEN}"
      sid: "${EXOTEL_SID}"
      welcome_number: "${EXOTEL_WELCOME_NUMBER}"
      status_callback: "https://api.gilclinic.com/webhooks/voice/exotel"
  
  tts:
    primary: "google"
    fallback: "polly"
    default_language: "en-IN"
    default_voice: "Google.en-IN-Wavenet-C"
    languages: ["en-IN", "hi-IN"]
  
  recording:
    enabled: true
    consent_required: true
    storage_provider: "s3"
    retention_days: 90
    transcription_enabled: true
  
  outbound:
    max_attempts: 3
    attempt_delays: [0, 300, 900]  # Immediate, 5 min, 15 min
    call_timeout_seconds: 30
    ring_timeout_seconds: 45
    concurrency_limit: 5
  
  missed_call:
    enabled: true
    auto_callback: true
    callback_after_seconds: 5
  
  analytics:
    collect_quality_metrics: true
    track_mos_score: true
    cost_tracking: true
```

## 9. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| Twilio as global primary, Exotel as India primary | Twilio for global reliability, Exotel for India-specific features |
| WebSocket for AI agent voice streaming | Low latency, real-time bidirectional audio |
| Google TTS primary, Polly fallback | Google Wavenet voices more natural; Polly as cost-effective backup |
| Hinglish support (mix of Hindi + English) | Natural for Indian patients, higher comprehension |
| DTMF + Speech recognition dual input | Caters to all users regardless of comfort with voice |
| Missed call service | Common Indian pattern, low-friction way to reach patients |
| Recording with consent verification | Compliance with Indian data protection laws |
| MOS quality tracking | Proactive detection of call quality issues |
| Outbound queue with priority | Prevents overload, critical calls go first |
| Call transcription | Searchable records, AI training data, compliance audit |
