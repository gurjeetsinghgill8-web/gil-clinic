---
file_id: "0702"
module_name: "WhatsApp Module"
version: "2.0"
status: "Draft"
phase: "Phase 7 — Communication"
dependencies: ["0104_COMMUNICATION_ENGINE.md"]
related_files: ["0700_SMS.md", "0600_PATIENT_APP.md", "0605_FEEDBACK.md", "0500_AI_RECEPTIONIST.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "whatsapp", "chat", "primary-channel", "business-api", "meta"]
---

# GHOS - WhatsApp Business Integration

## 1. PURPOSE
Primary patient communication channel using WhatsApp Business API. Handles template messaging, session messaging, media sharing, interactive buttons, webhook processing, opt-in management, and AI-powered conversational flows. WhatsApp has the highest open rate (98%) in India, making it the preferred channel.

## 2. ARCHITECTURE

```
[WhatsApp Cloud API / On-Prem API]
         │
    [Webhook Receiver]
         │
    ┌────┴─────────────────────────────┐
    │      Message Router              │
    │                                  │
    ├── Template Messages              │
    │   (Pre-approved, outbound)        │
    │                                  │
    ├── Session Messages               │
    │   (Free-form, 24h window)         │
    │                                  │
    ├── Interactive Messages           │
    │   (Buttons, Lists, CTA)          │
    │                                  │
    ├── Media Messages                 │
    │   (Images, PDF, Video, Audio)    │
    │                                  │
    └── AI Agent Integration           │
        (Receptionist, FAQ, Booking)   │
         │
    [Template Manager]
         │
    [Opt-In / Opt-Out Manager]
         │
    [Analytics & Reporting]
```

## 3. DATA MODEL

```sql
-- WhatsApp message log
CREATE TABLE whatsapp_messages (
    message_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    communication_id    UUID REFERENCES communication_log(communication_id),
    
    -- WhatsApp IDs
    wam_id              VARCHAR(100),               -- WhatsApp message ID
    wa_phone_number_id  VARCHAR(50),                -- WhatsApp Phone Number ID
    business_account_id VARCHAR(50),                -- WABA ID
    
    -- Conversation
    conversation_id     UUID REFERENCES whatsapp_conversations(conversation_id),
    direction           VARCHAR(10) NOT NULL,       -- inbound, outbound
    message_type        VARCHAR(30) NOT NULL,       -- text, template, interactive, image, document, audio, video, location, contacts, sticker, reaction
    
    -- Sender/Recipient
    from_number         VARCHAR(20),
    to_number           VARCHAR(20),
    
    -- Content
    body                TEXT,                        -- Message text
    template_id         UUID REFERENCES whatsapp_templates(template_id),
    template_vars       JSONB DEFAULT '{}',
    
    -- Media
    media_id            VARCHAR(200),                -- WhatsApp media ID
    media_url           VARCHAR(500),                -- Resolved media URL (expiring)
    media_type          VARCHAR(30),                 -- image, document, audio, video
    media_size          INTEGER,                     -- File size in bytes
    media_filename      VARCHAR(255),
    media_sha256        VARCHAR(64),
    
    -- Interactive
    interactive_type    VARCHAR(20),                -- button_reply, list_reply, button, list, cta_url, cta_call
    interactive_data    JSONB DEFAULT '{}',          -- Button ID, list selection, etc.
    
    -- Status
    status              VARCHAR(30) DEFAULT 'pending',
    -- pending, sent, delivered, read, failed, deleted, rebounced
    
    status_data         JSONB DEFAULT '{}',          -- Status webhook payload
    error_code          VARCHAR(10),
    error_description   TEXT,
    
    -- Pricing
    pricing_category    VARCHAR(20),                -- marketing, utility, authentication, service, referral
    pricing_model       VARCHAR(20),
    cost                DECIMAL(10, 6),
    currency            VARCHAR(5),
    
    -- Timestamps
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    sent_at             TIMESTAMPTZ,
    delivered_at        TIMESTAMPTZ,
    read_at             TIMESTAMPTZ,
    failed_at           TIMESTAMPTZ,
    
    INDEX idx_wam_phone (from_number, to_number),
    INDEX idx_wam_conv (conversation_id),
    INDEX idx_wam_status (status),
    INDEX idx_wam_created (created_at DESC)
);

-- WhatsApp conversations (24-hour sessions)
CREATE TABLE whatsapp_conversations (
    conversation_id     UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID REFERENCES patients(patient_id),
    phone_number        VARCHAR(20) NOT NULL,
    
    -- Conversation type
    conversation_type   VARCHAR(30) DEFAULT 'service',
    -- service, marketing, authentication, utility, referral
    
    -- Session details
    session_started_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    session_expires_at  TIMESTAMPTZ,                -- 24 hours from last message
    last_message_at     TIMESTAMPTZ,
    message_count       INTEGER DEFAULT 0,
    
    -- Context
    context             JSONB DEFAULT '{}',          -- Conversation context for AI
    current_intent      VARCHAR(50),                 -- Current detected intent
    current_flow        VARCHAR(50),                 -- Current conversation flow
    
    -- Status
    status              VARCHAR(20) DEFAULT 'active', -- active, expired, resolved, escalated
    resolved_at         TIMESTAMPTZ,
    resolved_by         VARCHAR(30),                 -- ai, staff, timeout
    escalated_to_staff  BOOLEAN DEFAULT FALSE,
    staff_assigned      UUID REFERENCES staff(staff_id),
    
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW()
);

-- WhatsApp templates (Meta-approved)
CREATE TABLE whatsapp_templates (
    template_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    
    -- Template Identity
    template_name       VARCHAR(100) NOT NULL,       -- Unique name in WABA
    template_category   VARCHAR(30) NOT NULL,        -- marketing, utility, authentication
    
    -- Content
    language            VARCHAR(10) NOT NULL,        -- en, hi, gu, mr
    header_type         VARCHAR(20) DEFAULT 'none',  -- none, text, image, document, video
    header_text         TEXT,
    header_media_url    VARCHAR(500),                -- Approved media URL
    
    body_text           TEXT NOT NULL,                -- With {{variable}} placeholders
    footer_text         TEXT,
    
    -- Buttons
    buttons             JSONB DEFAULT '[]',
    -- [{"type": "quick_reply", "text": "Yes"}, {"type": "quick_reply", "text": "No"}]
    -- [{"type": "url", "text": "Track Visit", "url": "https://gil.app/track/{{variable}}"}]
    -- [{"type": "phone_number", "text": "Call Us", "phone_number": "+919876543210"}]
    
    -- Variables
    variables           JSONB DEFAULT '[]',
    -- [{"name": "patient_name", "max_length": 30}, {"name": "doctor_name", "max_length": 30}]
    
    -- Meta Status
    meta_template_id    VARCHAR(100),                -- Meta's template ID
    meta_status         VARCHAR(30) DEFAULT 'pending',
    -- pending, approved, rejected, paused, disabled
    meta_rejection_reason TEXT,
    meta_quality_score   VARCHAR(20),                -- GREEN, YELLOW, RED
    meta_approved_at    TIMESTAMPTZ,
    
    -- Usage
    is_active           BOOLEAN DEFAULT TRUE,
    last_used_at        TIMESTAMPTZ,
    usage_count         INTEGER DEFAULT 0,
    
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(template_name, language)
);

-- Opt-in/opt-out tracking
CREATE TABLE whatsapp_opt_management (
    opt_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID REFERENCES patients(patient_id),
    phone_number        VARCHAR(20) NOT NULL,
    
    opt_status          VARCHAR(20) NOT NULL,       -- opted_in, opted_out, pending, expired
    opt_source          VARCHAR(30),                -- web_checkbox, qr_scan, staff_entry, whatsapp_optin, sms, api
    opt_channel         VARCHAR(20),                -- whatsapp, sms, web, app
    opt_timestamp       TIMESTAMPTZ DEFAULT NOW(),
    
    opt_out_reason      VARCHAR(50),                -- too_many_messages, not_interested, privacy, other
    opt_out_timestamp   TIMESTAMPTZ,
    
    consent_version     VARCHAR(20),                -- Version tracking for compliance
    consent_text        TEXT,                        -- What patient agreed to
    
    ip_address          INET,
    user_agent          TEXT,
    
    expiry_date         TIMESTAMPTZ,                -- Consent expiry (DPDP compliance)
    renewed_at          TIMESTAMPTZ,
    
    is_active           BOOLEAN DEFAULT TRUE,
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(phone_number)
);
```

## 4. TEMPLATE MANAGEMENT

### 4.1 Template Categories (Meta WhatsApp)
```yaml
template_categories:
  marketing:
    description: "Promotional content, offers, newsletters"
    approval: "Strict"
    rate_limit: "Varies by quality score"
    example: "health_tips, clinic_updates, seasonal_offers"
    
  utility:
    description: "Post-purchase, account updates, transaction alerts"
    approval: "Moderate"
    rate_limit: "Higher than marketing"
    example: "appointment_reminder, report_ready, bill_receipt"
    
  authentication:
    description: "OTP, login codes, 2FA"
    approval: "Automatic"
    rate_limit: "Highest"
    example: "login_otp, verify_phone"
    
  service:
    description: "Resolution of customer inquiries"
    approval: "Templates not needed (session-based)"
    rate_limit: "Within 24h customer-initiated window"
    example: "Free-form responses in active conversations"
```

### 4.2 Template Lifecycle
```
Draft -> Submitted -> Pending Review -> Approved / Rejected -> Active
                                                                    │
                                                                    ▼
                                                              Quality Check
                                                              (Green/Yellow/Red)
                                                                    │
                                                          Disabled if RED for 7 days
```

### 4.3 Template Examples
```json
{
  "name": "appointment_confirmation_v2",
  "language": "en",
  "category": "utility",
  "components": [
    {
      "type": "HEADER",
      "format": "TEXT",
      "text": "Appointment Confirmed ✓"
    },
    {
      "type": "BODY",
      "text": "Dear {{1}}, your appointment with Dr. {{2}} is confirmed.\n\n📅 Date: {{3}}\n⏰ Time: {{4}}\n📍 Location: {{5}}\n🔢 Token: {{6}}\n\nPlease arrive 10 minutes early. Tap below to track your visit."
    },
    {
      "type": "FOOTER",
      "text": "GIL Clinic - Your Health, Our Priority"
    },
    {
      "type": "BUTTONS",
      "buttons": [
        {
          "type": "URL",
          "text": "📍 Track Visit",
          "url": "https://gil.app/track/{{7}}"
        },
        {
          "type": "QUICK_REPLY",
          "text": "✅ Confirm"
        },
        {
          "type": "QUICK_REPLY",
          "text": "🔄 Reschedule"
        }
      ]
    }
  ]
}
```

## 5. MESSAGE ROUTER & WEBHOOK HANDLER

```python
class WhatsAppWebhookHandler:
    """
    Handles incoming WhatsApp webhooks from Meta.
    Routes messages to appropriate handlers based on type and context.
    """
    
    VERIFY_TOKEN = os.getenv('WHATSAPP_VERIFY_TOKEN')
    
    async def verify_webhook(self, request):
        """Webhook verification challenge from Meta."""
        mode = request.query.get('hub.mode')
        token = request.query.get('hub.verify_token')
        challenge = request.query.get('hub.challenge')
        
        if mode == 'subscribe' and token == self.VERIFY_TOKEN:
            return Response(content=challenge, status_code=200)
        return Response(status_code=403)
    
    async def handle_webhook(self, payload):
        """Process incoming webhook payload."""
        for entry in payload.get('entry', []):
            for change in entry.get('changes', []):
                if change.get('field') == 'messages':
                    await self._process_message_change(change.get('value'))
    
    async def _process_message_change(self, value):
        """Process a message change object."""
        metadata = value.get('metadata', {})
        contacts = value.get('contacts', [])
        messages = value.get('messages', [])
        statuses = value.get('statuses', [])
        
        # Process status updates (delivery receipts)
        for status in statuses:
            await self._handle_status_update(status)
        
        # Process incoming messages
        for message in messages:
            await self._handle_incoming_message(message, metadata, contacts)
    
    async def _handle_incoming_message(self, message, metadata, contacts):
        """Route incoming message to appropriate handler."""
        
        from_number = message.get('from')
        message_type = message.get('type')
        
        # Get or create conversation
        conversation = await self._get_or_create_conversation(from_number)
        
        # Update conversation context
        conversation.last_message_at = utcnow()
        conversation.message_count += 1
        
        # Route based on message type
        if message_type == 'text':
            await self._handle_text_message(conversation, message, from_number)
        elif message_type == 'interactive':
            await self._handle_interactive_message(conversation, message, from_number)
        elif message_type in ['image', 'document', 'audio', 'video']:
            await self._handle_media_message(conversation, message, from_number)
        elif message_type == 'location':
            await self._handle_location_message(conversation, message)
        elif message_type == 'button':
            await self._handle_button_reply(conversation, message)
        else:
            await self._handle_unknown_message(conversation, from_number)
    
    async def _handle_text_message(self, conversation, message, from_number):
        """Route text message to AI or staff based on context."""
        text = message['text']['body']
        
        # Check for opt-out
        if text.upper().strip() in ['STOP', 'UNSUBSCRIBE', 'END', 'QUIT']:
            await self._handle_opt_out(from_number)
            return
        
        # Check conversation context
        if conversation.current_flow:
            # Handle within existing flow
            await flow_engine.handle_response(conversation, text)
        else:
            # Route to AI receptionist
            ai_response = await ai_receptionist.process_message(
                patient_id=conversation.patient_id,
                message=text,
                conversation_id=conversation.conversation_id
            )
            
            if ai_response.get('needs_human'):
                conversation.escalated_to_staff = True
                await self._assign_to_staff(conversation, ai_response)
            else:
                await self.send_message(from_number, ai_response['response'])
    
    async def _handle_interactive_message(self, conversation, message, from_number):
        """Process interactive button/list replies."""
        interactive = message['interactive']
        
        if interactive.get('type') == 'button_reply':
            button_id = interactive['button_reply']['id']
            await flow_engine.handle_button_click(conversation, button_id)
        
        elif interactive.get('type') == 'list_reply':
            list_id = interactive['list_reply']['id']
            await flow_engine.handle_list_selection(conversation, list_id)
```

## 6. SENDER API

```python
class WhatsAppSender:
    """Send messages via WhatsApp Business API."""
    
    API_BASE = "https://graph.facebook.com/v18.0"
    
    def __init__(self):
        self.phone_number_id = os.getenv('WHATSAPP_PHONE_NUMBER_ID')
        self.token = os.getenv('WHATSAPP_ACCESS_TOKEN')
    
    async def send_template(self, to: str, template: WhatsAppTemplate, variables: dict) -> dict:
        """Send a pre-approved template message."""
        
        # Build components with variables
        components = []
        
        if template.header_type != 'none':
            components.append({
                'type': 'header',
                'parameters': [{
                    'type': 'text' if template.header_type == 'text' else template.header_type,
                    template.header_type: variables.get(f'header_{i+1}', '')
                } for i in range(len(template.header_parameters or []))]
            })
        
        body_params = [{'type': 'text', 'text': str(variables.get(f'var_{i+1}', ''))} 
                      for i in range(len(template.variables))]
        
        components.append({
            'type': 'body',
            'parameters': body_params
        })
        
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'template',
            'template': {
                'name': template.template_name,
                'language': {'code': template.language},
                'components': components
            }
        }
        
        return await self._api_post(payload)
    
    async def send_text(self, to: str, text: str, preview_url: bool = True) -> dict:
        """Send a free-form text message (within 24h session)."""
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'text',
            'text': {
                'preview_url': preview_url,
                'body': text
            }
        }
        return await self._api_post(payload)
    
    async def send_interactive_buttons(self, to: str, body: str, buttons: list, header: str = None, footer: str = None) -> dict:
        """Send interactive button message (up to 3 buttons)."""
        interactive = {
            'type': 'button',
            'body': {'text': body},
            'action': {
                'buttons': [{
                    'type': 'reply',
                    'reply': {'id': b['id'], 'title': b['title'][:20]}
                } for b in buttons[:3]]
            }
        }
        
        if header:
            interactive['header'] = {'type': 'text', 'text': header}
        if footer:
            interactive['footer'] = {'text': footer}
        
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'interactive',
            'interactive': interactive
        }
        return await self._api_post(payload)
    
    async def send_interactive_list(self, to: str, body: str, button_text: str, sections: list, header: str = None) -> dict:
        """Send interactive list message for multiple options."""
        interactive = {
            'type': 'list',
            'body': {'text': body},
            'action': {
                'button': button_text[:20],
                'sections': sections
            }
        }
        
        if header:
            interactive['header'] = {'type': 'text', 'text': header}
        
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': 'interactive',
            'interactive': interactive
        }
        return await self._api_post(payload)
    
    async def send_media(self, to: str, media_type: str, media_url: str, caption: str = None, filename: str = None) -> dict:
        """Send media message (image, document, audio, video)."""
        media = {
            'type': media_type,
            media_type: {
                'link': media_url
            }
        }
        
        if caption:
            media[media_type]['caption'] = caption
        if filename and media_type == 'document':
            media[media_type]['filename'] = filename
        
        payload = {
            'messaging_product': 'whatsapp',
            'recipient_type': 'individual',
            'to': to,
            'type': media_type,
            media_type: media[media_type]
        }
        return await self._api_post(payload)
    
    async def mark_as_read(self, message_id: str) -> dict:
        """Mark a message as read."""
        payload = {
            'messaging_product': 'whatsapp',
            'status': 'read',
            'message_id': message_id
        }
        return await self._api_post(payload)
    
    async def _api_post(self, payload):
        url = f"{self.API_BASE}/{self.phone_number_id}/messages"
        headers = {
            'Authorization': f'Bearer {self.token}',
            'Content-Type': 'application/json'
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(url, json=payload, headers=headers)
        
        if response.status_code != 200:
            raise WhatsAppAPIException(f"API error: {response.text}")
        
        return response.json()
```

## 7. OPT-IN / OPT-OUT MANAGEMENT

```python
class WhatsAppOptManager:
    """Manage patient opt-in and opt-out for WhatsApp communication."""
    
    OPT_IN_SOURCES = {
        'web_checkbox': "Website checkbox during appointment booking",
        'qr_scan': "QR code scan at clinic",
        'staff_entry': "Staff entered during registration",
        'whatsapp_optin': "User sent first message to clinic",
        'sms_optin': "User replied YES to SMS opt-in request",
        'api': "API integration from partner"
    }
    
    async def record_opt_in(self, phone_number: str, patient_id: UUID, source: str):
        """Record patient opt-in with consent."""
        opt = WhatsAppOptManagement(
            phone_number=phone_number,
            patient_id=patient_id,
            opt_status='opted_in',
            opt_source=source,
            consent_version='1.0',
            consent_text=self._get_consent_text(),
            expiry_date=utcnow() + timedelta(days=365),  # 1 year consent
            ip_address=self._get_client_ip(),
            user_agent=self._get_user_agent()
        )
        db.session.add(opt)
        db.session.commit()
        
        # Send welcome message
        await self._send_welcome_message(phone_number, patient_id)
    
    async def record_opt_out(self, phone_number: str, reason: str = None):
        """Record patient opt-out."""
        opt = WhatsAppOptManagement.query.filter_by(
            phone_number=phone_number,
            is_active=True
        ).first()
        
        if opt:
            opt.opt_status = 'opted_out'
            opt.opt_out_reason = reason
            opt.opt_out_timestamp = utcnow()
            opt.is_active = False
            db.session.commit()
        
        # Add to suppression list
        await self._add_to_suppression_list(phone_number)
    
    async def can_send(self, phone_number: str, message_category: str) -> bool:
        """Check if we can send a message of this category to this number."""
        opt = WhatsAppOptManagement.query.filter_by(
            phone_number=phone_number,
            is_active=True
        ).first()
        
        if not opt or opt.opt_status != 'opted_in':
            return False
        
        if opt.expiry_date and opt.expiry_date < utcnow():
            return False  # Consent expired
        
        return True
    
    async def _send_welcome_message(self, phone_number, patient_id):
        """Send welcome message after opt-in."""
        template = whatsapp_templates.get(name='welcome_message')
        await whatsapp_sender.send_template(
            to=phone_number,
            template=template,
            variables=['var_1': patient.name]
        )
```

## 8. CONFIGURATION

```yaml
whatsapp_config:
  api:
    version: "v18.0"
    phone_number_id: "${WHATSAPP_PHONE_NUMBER_ID}"
    business_account_id: "${WHATSAPP_BUSINESS_ACCOUNT_ID}"
    access_token: "${WHATSAPP_ACCESS_TOKEN}"
    webhook_verify_token: "${WHATSAPP_VERIFY_TOKEN}"
    webhook_url: "https://api.gilclinic.com/webhooks/whatsapp"
  
  templates:
    auto_submit_for_approval: true
    default_language: "en"
    supported_languages: ["en", "hi", "gu"]
    quality_monitoring: true
    pause_on_low_quality: true
  
  session:
    timeout_hours: 24
    auto_resolve_on_timeout: true
    escalation_on_timeout: false
  
  opt_in:
    require_opt_in: true
    opt_in_channels: ["web", "whatsapp", "sms", "qr", "staff"]
    consent_validity_days: 365
    welcome_message_template: "welcome_optin"
  
  rate_limits:
    messages_per_second: 50
    daily_marketing_limit: 1000
    daily_utility_limit: 10000
  
  ai_integration:
    enabled: true
    auto_reply: true
    escalate_to_human_on: ["complex_medical", "complaint", "emergency"]
    ai_model: "receptionist_v2"
    fallback_to_human: true
```

## 9. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| WhatsApp as primary communication channel | 98% open rate in India, patients prefer it |
| Cloud API over On-Premises | No server maintenance, auto-scaling, latest features |
| Pre-approved templates for outbound | WhatsApp policy: only template messages can initiate |
| Session-based free-form for inbound | 24h window allows natural conversation after patient message |
| Interactive buttons and lists | Higher engagement than text-only, structured responses |
| AI integration for auto-reply | Scales communication, instant responses |
| Opt-in with consent expiry | Compliance with DPDP Act 2023 |
| Quality score monitoring | Maintains sender reputation, avoids template restrictions |
| Multi-language template support | Hindi + English + Gujarati for Indian patients |
| Media sharing for reports | Patients can receive reports directly on WhatsApp |
