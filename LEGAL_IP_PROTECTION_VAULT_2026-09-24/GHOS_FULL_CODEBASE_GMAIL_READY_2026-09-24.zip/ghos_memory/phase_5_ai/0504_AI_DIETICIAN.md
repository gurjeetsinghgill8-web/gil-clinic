---
file_id: "0504"
module_name: "AI Dietician"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0201_DOCTOR_MODULE.md", "0103_LAB_MODULE.md"]
related_files: ["0501_AI_TRIAGE.md", "0302_EMERGENCY.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "ai", "diet", "nutrition", "planner", "pdf", "bilingual"]
---

# GHOS — AI Dietician

## 1. PURPOSE
Personalized AI diet plan generator that creates condition-specific meal plans based on patient health profiles, medical conditions, lab results, and dietary preferences. Supports calorie/nutrient tracking, bilingual Hindi/English output, seasonal food alternatives, and PDF generation for print/digital distribution. All plans require doctor approval before patient delivery.

```
┌─────────────────────────────────────────────────────────────────────┐
│                      DIET PLANNER FLOW DIAGRAM                       │
│                                                                      │
│  Input Collection                                                     │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │ Patient Profile: Age, Gender, Weight, Height, Activity Level │     │
│  │ Medical Conditions: Diabetes, HTN, Heart Disease, CKD, etc.  │     │
│  │ Lab Results: HbA1c, Lipid Profile, Creatinine, etc.          │     │
│  │ Preferences: Veg/Non-Veg, Jain, Vegan, Allergies             │     │
│  │ Doctor Recommendations: Calorie target, restrictions         │     │
│  └─────────────────────────────────────────────────────────────┘     │
│                              │                                        │
│                              ▼                                        │
│  Nutrition Engine                                                     │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │ 1. BMR + TDEE Calculation                                    │     │
│  │ 2. Macro Split (Carbs/Protein/Fat) by Condition              │     │
│  │ 3. Micro-nutrient Targeting (Sodium, Potassium, etc.)        │     │
│  │ 4. Meal Structure: 6 meals (B/L/D + 3 Snacks)               │     │
│  │ 5. Recipe Database Match → Filter by Allergens               │     │
│  │ 6. Seasonal Alternative Selection                            │     │
│  └─────────────────────────────────────────────────────────────┘     │
│                              │                                        │
│                              ▼                                        │
│  Output Generation                                                   │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │ Daily Meal Plan (Bilingual Hi/En)                           │     │
│  │ Calorie & Macronutrient Breakdown per Meal                  │     │
│  │ Foods to Eat / Avoid (Condition-Specific)                   │     │
│  │ Portion Guidance (Grams, Cups, Visual)                      │     │
│  │ Grocery Shopping List                                       │     │
│  │ PDF Report (Print-Ready)                                    │     │
│  └─────────────────────────────────────────────────────────────┘     │
│                              │                                        │
│                              ▼                                        │
│  Approval Workflow                                                   │
│  ┌─────────────────────────────────────────────────────────────┐     │
│  │ Doctor Reviews → Approves/Modifies → Generates Final PDF    │     │
│  │ Delivered to Patient via WhatsApp/Email/Portal              │     │
│  └─────────────────────────────────────────────────────────────┘     │
└─────────────────────────────────────────────────────────────────────┘
```

## 2. PATIENT PROFILE INPUT

```python
# patient_profile.py
from dataclasses import dataclass, field
from enum import Enum
from typing import Optional


class DietType(Enum):
    VEG = "vegetarian"
    NON_VEG = "non_vegetarian"
    VEGAN = "vegan"
    JAIN = "jain"
    EGGITARIAN = "eggetarian"


class ActivityLevel(Enum):
    SEDENTARY = 1.2
    LIGHT = 1.375
    MODERATE = 1.55
    ACTIVE = 1.725
    VERY_ACTIVE = 1.9


class MedicalCondition(Enum):
    DIABETES = "diabetes"
    HYPERTENSION = "hypertension"
    HEART_DISEASE = "heart_disease"
    CKD = "chronic_kidney_disease"
    LIVER_DISEASE = "liver_disease"
    PCOS = "pcos"
    THYROID = "thyroid_disorder"
    GOUT = "gout"
    ANEMIA = "anemia"
    GERD = "gerd"
    OBESITY = "obesity"
    PREGNANCY = "pregnancy"
    LACTATION = "lactation"


@dataclass
class PatientProfile:
    patient_id: int
    age: int
    gender: str
    weight_kg: float
    height_cm: float
    activity_level: ActivityLevel
    diet_type: DietType
    medical_conditions: list[MedicalCondition] = field(default_factory=list)
    allergies: list[str] = field(default_factory=list)
    lab_results: dict = field(default_factory=dict)
    doctor_notes: str = ""
    language_preference: str = "en"
    target_weight_kg: Optional[float] = None

    @property
    def bmi(self) -> float:
        height_m = self.height_cm / 100
        return round(self.weight_kg / (height_m ** 2), 1)

    @property
    def bmi_category(self) -> str:
        bmi = self.bmi
        if bmi < 18.5:
            return "underweight"
        elif bmi < 25:
            return "normal"
        elif bmi < 30:
            return "overweight"
        else:
            return "obese"

    def calculate_bmr(self) -> float:
        """
        Mifflin-St Jeor Equation for BMR calculation.
        """
        if self.gender.lower() == "male":
            bmr = 10 * self.weight_kg + 6.25 * self.height_cm - 5 * self.age + 5
        else:
            bmr = 10 * self.weight_kg + 6.25 * self.height_cm - 5 * self.age - 161
        return round(bmr)

    def calculate_tdee(self) -> float:
        """Total Daily Energy Expenditure = BMR * Activity Factor."""
        return round(self.calculate_bmr() * self.activity_level.value)
```

## 3. NUTRITION ENGINE

```python
# nutrition_engine.py
class NutritionEngine:
    """
    Core nutrition calculation engine.
    Determines calorie targets, macro splits, and micro-nutrient
    requirements based on patient profile and medical conditions.
    """

    CONDITION_MACRO_SPLITS = {
        MedicalCondition.DIABETES: {
            "carbs_pct": 40, "protein_pct": 25, "fat_pct": 35,
            "fiber_grams": 40, "sodium_mg": 2000,
            "notes": ["Low glycemic index foods only",
                      "Complex carbohydrates preferred",
                      "Avoid added sugars"]
        },
        MedicalCondition.HYPERTENSION: {
            "carbs_pct": 50, "protein_pct": 20, "fat_pct": 30,
            "fiber_grams": 30, "sodium_mg": 1500,
            "notes": ["DASH diet principles",
                      "Sodium restricted to 1500mg",
                      "High potassium foods encouraged"]
        },
        MedicalCondition.HEART_DISEASE: {
            "carbs_pct": 50, "protein_pct": 20, "fat_pct": 30,
            "fiber_grams": 35, "sodium_mg": 2000,
            "saturated_fat_pct": 7,
            "notes": ["Mediterranean diet pattern",
                      "Omega-3 fatty acids emphasized",
                      "Saturated fat < 7% of calories"]
        },
        MedicalCondition.CKD: {
            "carbs_pct": 55, "protein_pct": 15, "fat_pct": 30,
            "fiber_grams": 25, "sodium_mg": 2000,
            "protein_grams_per_kg": 0.8,
            "notes": ["Protein restricted to 0.8g/kg",
                      "Potassium monitoring required",
                      "Phosphorus restriction if advanced CKD"]
        },
        MedicalCondition.OBESITY: {
            "carbs_pct": 45, "protein_pct": 30, "fat_pct": 25,
            "fiber_grams": 35, "sodium_mg": 2000,
            "calorie_deficit": 500,
            "notes": ["Calorie deficit of 500 kcal/day",
                      "High protein for satiety",
                      "Frequent small meals"]
        }
    }

    def generate_nutrition_plan(self, profile: PatientProfile) -> dict:
        """Generate complete nutrition plan with macros and targets."""
        tdee = profile.calculate_tdee()
        calorie_target = self._calculate_calorie_target(profile, tdee)
        macros = self._calculate_macronutrients(profile, calorie_target)
        micronutrients = self._calculate_micronutrient_targets(profile)

        return {
            "patient_id": profile.patient_id,
            "bmr": profile.calculate_bmr(),
            "tdee": tdee,
            "calorie_target": calorie_target,
            "macros": macros,
            "micronutrients": micronutrients,
            "conditions_applied": [c.value for c in profile.medical_conditions],
            "notes": self._collate_condition_notes(profile)
        }

    def _calculate_calorie_target(self, profile: PatientProfile,
                                   tdee: float) -> float:
        """Calculate target calories considering conditions and weight goals."""
        target = tdee

        # Adjust for weight goals
        if profile.target_weight_kg:
            if profile.target_weight_kg < profile.weight_kg:
                target -= 500  # Deficit for weight loss
            elif profile.target_weight_kg > profile.weight_kg:
                target += 500  # Surplus for weight gain

        # Adjust for conditions
        if MedicalCondition.OBESITY in profile.medical_conditions:
            target -= 500

        if MedicalCondition.DIABETES in profile.medical_conditions:
            target = min(target, tdee)  # Don't exceed maintenance

        return round(max(target, 1200))  # Floor at 1200 kcal
```

## 4. MEAL PLAN GENERATOR

```python
# meal_planner.py
class MealPlanner:
    """
    Generates daily meal plans matching the nutrition targets.
    Uses a recipe database with condition-tagged meals.
    Supports seasonal food substitution and bilingual output.
    """

    MEAL_STRUCTURE = {
        "breakfast": {"time": "7:00-8:00 AM", "cal_pct": 0.20},
        "mid_morning_snack": {"time": "10:00-11:00 AM", "cal_pct": 0.10},
        "lunch": {"time": "1:00-2:00 PM", "cal_pct": 0.30},
        "evening_snack": {"time": "4:00-5:00 PM", "cal_pct": 0.10},
        "dinner": {"time": "7:00-8:00 PM", "cal_pct": 0.25},
        "bedtime_snack": {"time": "10:00 PM", "cal_pct": 0.05}
    }

    RECIPE_DATABASE = {
        "breakfast": {
            "vegetarian": [
                {"name_en": "Oatmeal with nuts and berries",
                 "name_hi": "नट्स और बेरीज के साथ ओटमील",
                 "calories": 300, "protein_g": 12,
                 "carbs_g": 45, "fat_g": 10,
                 "conditions": ["diabetes", "heart_disease", "obesity"],
                 "season": "all", "prep_time": "10 min"},
                {"name_en": "Moong dal chilla",
                 "name_hi": "मूंग दाल चिल्ला",
                 "calories": 250, "protein_g": 15,
                 "carbs_g": 30, "fat_g": 8,
                 "conditions": ["diabetes", "pcos"],
                 "season": "all", "prep_time": "15 min"},
            ],
            "non_vegetarian": [
                {"name_en": "Egg white omelette with vegetables",
                 "name_hi": "सब्जियों के साथ अंडे का सफेद ऑमलेट",
                 "calories": 280, "protein_g": 22,
                 "carbs_g": 8, "fat_g": 12,
                 "conditions": ["obesity", "diabetes"],
                 "season": "all", "prep_time": "10 min"}
            ],
            "vegan": [
                {"name_en": "Smoothie bowl with plant protein",
                 "name_hi": "प्लांट प्रोटीन के साथ स्मूदी बाउल",
                 "calories": 320, "protein_g": 18,
                 "carbs_g": 50, "fat_g": 8,
                 "conditions": ["diabetes"],
                 "season": "summer", "prep_time": "5 min"}
            ]
        },
        "lunch": {
            "vegetarian": [
                {"name_en": "Brown rice + dal + vegetable curry",
                 "name_hi": "ब्राउन राइस + दाल + सब्जी करी",
                 "calories": 500, "protein_g": 22,
                 "carbs_g": 75, "fat_g": 12,
                 "conditions": ["diabetes", "hypertension"],
                 "season": "all", "prep_time": "30 min"},
                {"name_en": "Quinoa pulao with raita",
                 "name_hi": "क्विनोआ पुलाव दही के साथ",
                 "calories": 450, "protein_g": 18,
                 "carbs_g": 65, "fat_g": 10,
                 "conditions": ["diabetes", "obesity"],
                 "season": "all", "prep_time": "25 min"},
            ]
        }
    }

    def generate_daily_plan(self, patient_id: int,
                            nutrition_plan: dict,
                            profile: PatientProfile,
                            language: str = "en",
                            season: str = "all") -> dict:
        """
        Generate a complete daily meal plan.
        Selects recipes matching the patient's condition, diet type,
        and seasonal availability. Calculates precise meal macros.
        """
        daily_plan = {
            "patient_id": patient_id,
            "date": datetime.now().date().isoformat(),
            "language": language,
            "total_calories": 0,
            "total_protein": 0,
            "total_carbs": 0,
            "total_fat": 0,
            "meals": [],
            "meal_timing_suggestions": {},
            "foods_to_eat": [],
            "foods_to_avoid": [],
            "grocery_list": []
        }

        calorie_target = nutrition_plan["calorie_target"]
        conditions = set(c.value for c in profile.medical_conditions)
        diet_type = profile.diet_type.value

        for meal_name, structure in self.MEAL_STRUCTURE.items():
            meal_calories = round(calorie_target * structure["cal_pct"])
            recipe = self._select_recipe(
                meal_name, diet_type, conditions, season, meal_calories
            )

            if recipe:
                adjustment = self._adjust_portion(recipe, meal_calories)
                daily_plan["meals"].append({
                    "meal": meal_name,
                    "time": structure["time"],
                    "recipe": recipe["name_en"] if language == "en"
                              else recipe["name_hi"],
                    "portion": adjustment["portion"],
                    "calories": adjustment["calories"],
                    "protein_g": adjustment["protein_g"],
                    "carbs_g": adjustment["carbs_g"],
                    "fat_g": adjustment["fat_g"],
                    "prep_time": recipe.get("prep_time", ""),
                    "recipe_instructions": self._get_instructions(
                        recipe, language
                    )
                })
                daily_plan["total_calories"] += adjustment["calories"]
                daily_plan["total_protein"] += adjustment["protein_g"]
                daily_plan["total_carbs"] += adjustment["carbs_g"]
                daily_plan["total_fat"] += adjustment["fat_g"]

        daily_plan["foods_to_eat"] = self._get_foods_to_eat(conditions)
        daily_plan["foods_to_avoid"] = self._get_foods_to_avoid(conditions)
        daily_plan["grocery_list"] = self._generate_grocery_list(
            daily_plan["meals"], language
        )

        return daily_plan
```

## 5. BILINGUAL OUTPUT GENERATION

```python
# bilingual_output.py
class BilingualDietOutput:
    """
    Generates bilingual (Hindi/English) diet plan output.
    Supports full plan in either language or side-by-side format.
    """

    SECTION_HEADERS = {
        "diet_plan": {"en": "Personalized Diet Plan", "hi": "व्यक्तिगत आहार योजना"},
        "patient_info": {"en": "Patient Information", "hi": "रोगी जानकारी"},
        "nutrition_targets": {"en": "Nutrition Targets", "hi": "पोषण लक्ष्य"},
        "daily_meals": {"en": "Daily Meal Plan", "hi": "दैनिक भोजन योजना"},
        "foods_to_eat": {"en": "Foods to Eat", "hi": "खाने योग्य खाद्य पदार्थ"},
        "foods_to_avoid": {"en": "Foods to Avoid", "hi": "न खाने योग्य खाद्य पदार्थ"},
        "grocery_list": {"en": "Grocery List", "hi": "किराने की सूची"},
        "important_notes": {"en": "Important Notes", "hi": "महत्वपूर्ण नोट्स"},
        "disclaimer": {
            "en": "This diet plan is a suggestion and must be approved by your doctor.",
            "hi": "यह आहार योजना एक सुझाव है और इसे आपके डॉक्टर द्वारा अनुमोदित किया जाना चाहिए।"
        }
    }

    def generate_text(self, plan: dict, language: str = "en",
                      side_by_side: bool = False) -> str:
        """Generate human-readable diet plan in specified language."""
        if side_by_side:
            en_text = self.generate_text(plan, "en", False)
            hi_text = self.generate_text(plan, "hi", False)
            return f"--- ENGLISH ---\n{en_text}\n\n--- HINDI ---\n{hi_text}"

        lines = []
        lines.append(f"====== {self._header('diet_plan', language)} ======\n")

        lines.append(f"**{self._header('patient_info', language)}**")
        for key in ["patient_id", "age", "gender", "weight_kg", "height_cm",
                     "bmi", "bmi_category"]:
            if key in plan:
                label_en = key.replace("_", " ").title()
                label_hi = self._patient_field_hi(key)
                label = label_hi if language == "hi" else label_en
                lines.append(f"- {label}: {plan[key]}")

        lines.append(f"\n**{self._header('nutrition_targets', language)}**")
        for key in ["calorie_target", "bmr", "tdee"]:
            if key in plan:
                label = self._translate(key, language)
                lines.append(f"- {label}: {plan[key]}")

        macros = plan.get("macros", {})
        if macros:
            lines.append(f"- {self._translate('protein_g', language)}: {macros.get('protein_g', 'N/A')}g")
            lines.append(f"- {self._translate('carbs_g', language)}: {macros.get('carbs_g', 'N/A')}g")
            lines.append(f"- {self._translate('fat_g', language)}: {macros.get('fat_g', 'N/A')}g")

        lines.append(f"\n**{self._header('daily_meals', language)}**")
        for meal in plan.get("meals", []):
            lines.append(
                f"  **{self._translate(meal['meal'], language)}** "
                f"({meal['time']})"
            )
            lines.append(f"  - {meal['recipe']} ({meal['calories']} kcal)")
            lines.append(f"    P:{meal['protein_g']}g C:{meal['carbs_g']}g F:{meal['fat_g']}g")

        return "\n".join(lines)
```

## 6. PDF GENERATION

```python
# pdf_generator.py
class DietPDFGenerator:
    """
    Generates print-ready PDF diet plans with clinic branding.
    Uses reportlab for PDF generation with Unicode support for Hindi.
    """

    def generate_pdf(self, plan: dict, profile: PatientProfile,
                     language: str = "en",
                     approved_by: str | None = None) -> bytes:
        """
        Generate a formatted PDF diet plan.
        Returns PDF bytes for download/print.
        """
        from reportlab.lib.pagesizes import A4
        from reportlab.pdfgen import canvas
        from reportlab.lib.units import mm, cm

        buffer = BytesIO()
        c = canvas.Canvas(buffer, pagesize=A4)
        width, height = A4

        # Header with clinic logo
        c.setFont("Helvetica-Bold", 18)
        c.drawString(20 * mm, height - 20 * mm, "GIL CLINIC")
        c.setFont("Helvetica", 12)
        c.drawString(20 * mm, height - 30 * mm,
                     self._header("diet_plan", language))

        # Patient info
        y = height - 50 * mm
        c.setFont("Helvetica-Bold", 11)
        c.drawString(20 * mm, y, "Patient Info:")
        c.setFont("Helvetica", 10)
        info_lines = [
            f"Name: {profile.patient_id}",
            f"Age: {profile.age} | Gender: {profile.gender}",
            f"Weight: {profile.weight_kg}kg | Height: {profile.height_cm}cm",
            f"BMI: {profile.bmi} ({profile.bmi_category})"
        ]
        for line in info_lines:
            y -= 6 * mm
            c.drawString(25 * mm, y, line)

        # Daily meals table
        y -= 15 * mm
        c.setFont("Helvetica-Bold", 11)
        c.drawString(20 * mm, y, "Daily Meal Plan:")
        y -= 8 * mm
        for meal in plan.get("meals", []):
            recipe_text = meal.get('recipe', '')
            calories = meal.get('calories', 0)
            protein = meal.get('protein_g', 0)
            carbs = meal.get('carbs_g', 0)
            fat = meal.get('fat_g', 0)
            c.setFont("Helvetica", 9)
            line = f"{meal['meal']}: {recipe_text} - {calories}kcal"
            c.drawString(25 * mm, y, line)
            y -= 5 * mm
            c.drawString(30 * mm, y,
                         f"P:{protein}g C:{carbs}g F:{fat}g")
            y -= 8 * mm

            if y < 30 * mm:
                c.showPage()
                y = height - 20 * mm

        # Footer with disclaimer
        c.setFont("Helvetica-Oblique", 8)
        c.drawString(20 * mm, 15 * mm,
                     "This diet plan is AI-generated. Doctor approval required.")
        if approved_by:
            c.drawString(20 * mm, 10 * mm,
                         f"Approved by: Dr. {approved_by}")

        c.save()
        return buffer.getvalue()
```

## 7. SQL DATA MODEL

```sql
-- diet_planner_schema.sql
CREATE TABLE diet_plans (
    id              BIGSERIAL PRIMARY KEY,
    patient_id      BIGINT NOT NULL REFERENCES patients(id),
    doctor_id       BIGINT REFERENCES doctors(id),
    plan_version    INT DEFAULT 1,
    status          VARCHAR(16) DEFAULT 'draft'
                    CHECK (status IN
                      ('draft', 'pending_approval', 'approved',
                       'delivered', 'archived')),
    nutrition_targets JSONB NOT NULL,
    daily_meals     JSONB NOT NULL,
    foods_to_eat    JSONB,
    foods_to_avoid  JSONB,
    grocery_list    JSONB,
    language        VARCHAR(10) DEFAULT 'en',
    pdf_s3_key      VARCHAR(256),
    approved_at     TIMESTAMP,
    delivered_at    TIMESTAMP,
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(patient_id, status),
    INDEX(doctor_id, created_at)
);

CREATE TABLE diet_feedback (
    id              BIGSERIAL PRIMARY KEY,
    plan_id         BIGINT REFERENCES diet_plans(id),
    patient_id      BIGINT REFERENCES patients(id),
    adherence_pct   DECIMAL(5,2),
    satisfaction    INT CHECK (satisfaction BETWEEN 1 AND 5),
    challenges      TEXT,
    weight_change_kg DECIMAL(5,2),
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(plan_id)
);
```

## 8. KEY DESIGN DECISIONS

1. **Condition-Composite Macro Splits**: When a patient has multiple conditions (e.g., diabetes + hypertension), the engine computes a weighted average of the macro splits rather than using a single condition's profile. The weighting prioritizes the stricter condition's constraints.

2. **Recipe Portion Scaling**: Rather than maintaining hundreds of portion-size variants for each recipe, a base recipe is stored with a per-serving macro profile, and portions are scaled linearly. This keeps the recipe database manageable while allowing precise calorie targeting.

3. **Seasonal Food Database**: Recipes are tagged with season ("summer", "winter", "monsoon", "all"). The planner filters out out-of-season items and suggests affordable, locally available alternatives, making plans practical for the patient.

4. **Doctor Approval Gate**: All AI-generated diet plans are created as "draft" and cannot be delivered to the patient without doctor approval. The doctor receives a notification with a link to review, modify, or approve the plan. Only after approval is the PDF generated and delivered.

5. **Progressive Plan Refinement**: The first plan is generated entirely from profile data. Subsequent versions incorporate patient feedback (adherence, satisfaction) and any changes in lab results, creating a learning loop that improves over time.

6. **Visual Portion Guidance**: In addition to gram-based measurements, the plan includes visual portion cues ("the size of your palm", "a fist-sized serving") that are more practical for daily use, especially in the Indian context where kitchen scales are uncommon.

7. **Grocery List Optimization**: The grocery list is deduplicated across meals (e.g., if oats appear in breakfast and snack, it's listed once) and organized by category (vegetables, grains, dairy, etc.) for easy shopping. Quantities are estimates based on meal frequency.
