---
file_id: "0502"
module_name: "AI Follow-up"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0104_COMMUNICATION_ENGINE.md", "0107_TWILIO_MODULE.md", "0604_FOLLOWUP.md"]
related_files: ["0500_AI_RECEPTIONIST.md", "0503_AI_VOICE_AGENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "ai", "followup", "outbound", "calls", "adherence", "reminder"]
---

# GHOS — AI Follow-up

## 1. PURPOSE
Automated AI-driven follow-up call system that schedules and executes post-visit check-ins, medication adherence monitoring, appointment reminders, symptom check-ins, and patient satisfaction feedback collection. Escalates concerning responses directly to the treating doctor.

```
┌───────────────────────────────────────────────────────────────────┐
│                   FOLLOW-UP CALL FLOW DIAGRAM                      │
│                                                                    │
│  Trigger Event (Time-based / Schedule-based)                       │
│       │                                                             │
│       ▼                                                             │
│  Follow-up Scheduler                                               │
│       │                                                             │
│       ├── Post-Visit 24h → Recovery Check                          │
│       ├── Post-Visit 72h → Medication Adherence                    │
│       ├── Post-Visit 7d  → Detailed Symptom Check                  │
│       ├── Appointment D-7   → Appointment Reminder                  │
│       ├── Appointment D-1   → Day-before Confirmation               │
│       ├── Post-Appointment → Feedback Collection                    │
│       └── No-Show Detection → Reschedule Prompt                     │
│                                                                    │
│       ▼                                                             │
│  Call Initiation (Twilio/Vonage Outbound API)                      │
│       │                                                             │
│       ▼                                                             │
│  Conversation Flow (Based on Template)                              │
│       │                                                             │
│       ├── Introduction + Purpose                                    │
│       ├── Structured Questions (Branching Logic)                    │
│       ├── Response Capture + Sentiment Analysis                     │
│       └── Closing + Confirmation                                    │
│                                                                    │
│       ▼                                                             │
│  Response Processing                                                │
│       │                                                             │
│       ├── Normal → Log + Complete                                   │
│       ├── Concerning → Flag → Notify Doctor                         │
│       ├── Adverse Event → Emergency Escalation                      │
│       └── Feedback → Aggregate → Dashboard                          │
│                                                                    │
│       ▼                                                             │
│  Post-Call Actions                                                  │
│       ├── Update EHR Follow-up Section                              │
│       ├── Schedule Next Follow-up (If Needed)                       │
│       └── Send Summary SMS/WhatsApp to Patient                      │
└───────────────────────────────────────────────────────────────────┘
```

## 2. TRIGGER MATRIX

```yaml
# trigger_matrix.yaml
followup_triggers:
  post_visit_24h:
    name: "Post-Visit Recovery Check"
    delay: "24 hours after visit"
    priority: "normal"
    channel: ["voice", "whatsapp"]
    questions:
      - "How are you feeling today compared to yesterday?"
      - "Have you taken the prescribed medication?"
      - "Do you have any new or worsening symptoms?"
      - "Is your pain/discomfort better, worse, or the same?"
    escalation_condition: "patient reports worsening or new severe symptoms"
    action_on_escalation: "Notify treating doctor within 1 hour"

  post_visit_72h:
    name: "Medication Adherence Check"
    delay: "72 hours after visit"
    priority: "normal"
    channel: ["voice"]
    skip_if: "no medication prescribed"
    questions:
      - "Are you taking your medications regularly?"
      - "Have you missed any doses?"
      - "Do you have any side effects?"
      - "Are you facing any difficulty getting the medicines?"
    escalation_condition: "non-adherence reported or side effects"
    action_on_escalation: "Doctor notification + counseling call"

  post_visit_7d:
    name: "Symptom Monitoring"
    delay: "7 days after visit"
    priority: "normal"
    channel: ["voice", "whatsapp"]
    questions:
      - "On a scale of 1-10, how are your symptoms now?"
      - "Have you completed all prescribed tests?"
      - "Are you due for a follow-up visit?"
    escalation_condition: "symptom score > 5 or tests not done"
    action_on_escalation: "Doctor notification + reschedule follow-up"

  appointment_d7:
    name: "Week-Before Reminder"
    delay: "7 days before appointment"
    priority: "low"
    channel: ["whatsapp", "sms"]
    fetch: "appointment details from bookings table"
    message: "Confirm or reschedule"

  appointment_d1:
    name: "Day-Before Confirmation"
    delay: "1 day before appointment"
    priority: "high"
    channel: ["voice", "whatsapp", "sms"]
    questions:
      - "Can you confirm your appointment tomorrow at {time}?"
      - "Do you need any instructions for preparation?"
      - "Would you like to reschedule?"
    escalation_condition: "patient cancels or doesn't confirm"
    action_on_escalation: "Release slot + notify clinic"

  no_show:
    name: "No-Show Follow-up"
    delay: "1 hour after missed appointment"
    priority: "high"
    channel: ["voice"]
    questions:
      - "You missed your appointment today. Would you like to reschedule?"
      - "Was there an emergency or any issue?"
      - "Can we help you book a new slot?"
    escalation_condition: "patient reports emergency"
    action_on_escalation: "Triage assessment + emergency routing"

  feedback:
    name: "Patient Feedback"
    delay: "24 hours after appointment completion"
    priority: "low"
    channel: ["whatsapp", "voice"]
    questions:
      - "How satisfied were you with your visit? (1-5)"
      - "Did you have enough time with the doctor?"
      - "Was the facility clean and comfortable?"
      - "Any suggestions for improvement?"
    escalation_condition: "satisfaction score < 3"
    action_on_escalation: "Flag to clinic manager"
```

## 3. FOLLOW-UP SCHEDULER ENGINE

```python
# followup_scheduler.py
from enum import Enum
from datetime import datetime, timedelta
from typing import Optional


class FollowupType(Enum):
    POST_VISIT_24H = "post_visit_24h"
    POST_VISIT_72H = "post_visit_72h"
    POST_VISIT_7D = "post_visit_7d"
    APPOINTMENT_D7 = "appointment_d7"
    APPOINTMENT_D1 = "appointment_d1"
    NO_SHOW = "no_show"
    FEEDBACK = "feedback"
    CUSTOM = "custom"


class FollowupScheduler:
    """
    Core scheduler that manages the lifecycle of all automated follow-ups.
    Runs as a cron job every 15 minutes, picks up due follow-ups,
    initiates calls, and handles scheduling/deferring.
    """

    def __init__(self, db_connection, voice_agent, notification_engine):
        self.db = db_connection
        self.voice = voice_agent
        self.notifier = notification_engine

    def check_and_dispatch(self) -> int:
        """
        Main dispatch loop. Queries for all due follow-ups,
        batches them by channel, and initiates execution.
        Returns count of follow-ups dispatched.
        """
        due = self.get_due_followups()
        dispatched = 0

        for followup in due:
            try:
                self.initiate_followup(followup)
                dispatched += 1
            except Exception as e:
                log_error(f"Failed to dispatch follow-up {followup['id']}: {e}")
                self.mark_failed(followup["id"], str(e))

        return dispatched

    def get_due_followups(self) -> list[dict]:
        """
        Query all follow-ups whose scheduled_at <= NOW()
        and status = 'pending'.
        Respects quiet hours (9 PM - 8 AM) for voice calls.
        """
        query = """
            SELECT f.*, p.phone, p.full_name, p.language_preference,
                   p.uhid, d.full_name AS doctor_name,
                   COALESCE(f.override_channel, f.default_channel) AS channel
            FROM followup_schedule f
            JOIN patients p ON p.id = f.patient_id
            LEFT JOIN doctors d ON d.id = f.doctor_id
            WHERE f.status = 'pending'
              AND f.scheduled_at <= NOW()
              AND (
                  f.channel != 'voice'
                  OR EXTRACT(HOUR FROM NOW()) BETWEEN 8 AND 21
              )
            ORDER BY f.priority DESC, f.scheduled_at ASC
            LIMIT 50
            FOR UPDATE SKIP LOCKED;
        """
        return execute_read_query(query)

    def schedule_followup(self, patient_id: int,
                          followup_type: FollowupType,
                          doctor_id: int | None = None,
                          appointment_id: int | None = None,
                          custom_delay_hours: int | None = None,
                          channel: str | None = None,
                          language: str | None = None) -> dict:
        """
        Schedule a new follow-up for a patient.
        Calculates delay based on type (or custom delay).
        Creates entry in followup_schedule table.
        """
        rule = FOLLOWUP_RULES[followup_type.value]
        delay_hours = custom_delay_hours or rule.get("delay_hours", 24)
        default_channel = channel or rule.get("default_channel", "voice")

        if appointment_id:
            appt = self.get_appointment(appointment_id)
            base_time = appt["appointment_date"]
        else:
            patient = self.get_patient_last_visit(patient_id)
            base_time = patient["last_visit_date"]

        scheduled_at = base_time + timedelta(hours=delay_hours)

        insert_query = """
            INSERT INTO followup_schedule
                (patient_id, followup_type, doctor_id, appointment_id,
                 scheduled_at, default_channel, language_preference,
                 status, created_at)
            VALUES (%s, %s, %s, %s, %s, %s, %s, 'pending', NOW())
            RETURNING id;
        """
        result = execute_write_query(
            insert_query,
            (patient_id, followup_type.value, doctor_id,
             appointment_id, scheduled_at, default_channel,
             language or "en")
        )
        return {"followup_id": result[0]["id"], "scheduled_at": scheduled_at}
```

## 4. CONVERSATION FLOW ENGINE

```python
# conversation_flow.py
class ConversationFlowEngine:
    """
    Manages the dynamic conversation flow for each follow-up call.
    Uses branching logic based on patient responses.
    Tracks conversation state for interruption recovery.
    """

    def __init__(self, followup_type: str, patient_context: dict):
        self.type = followup_type
        self.patient = patient_context
        self.state = "introduction"
        self.responses = {}
        self.sentiment_history = []
        self.interruption_count = 0

    def get_next_prompt(self) -> dict:
        """
        Get the next question/prompt based on current state
        and previous responses.
        """
        flow = FOLLOWUP_FLOWS.get(self.type, [])
        current_step = self._find_current_step(flow)

        if current_step >= len(flow):
            return {
                "type": "closing",
                "text": self._closing_message(),
                "language": self.patient.get("language", "en")
            }

        step = flow[current_step]
        return {
            "type": step["type"],
            "text": step["text"],
            "options": step.get("options"),
            "branch": step.get("branch"),
            "language": self.patient.get("language", "en"),
            "expected_response_type": step.get("response_type", "free_text"),
            "timeout_seconds": step.get("timeout", 10)
        }

    def process_response(self, response_text: str,
                         sentiment: str,
                         confidence: float) -> dict:
        """
        Process a patient's response, update state,
        and return the next action (next question / escalate / close).
        """
        self.responses[self.state] = {
            "text": response_text,
            "sentiment": sentiment,
            "confidence": confidence,
            "timestamp": datetime.utcnow().isoformat()
        }
        self.sentiment_history.append(sentiment)

        # Check for escalation triggers
        escalation = self._check_escalation_triggers(response_text)
        if escalation["escalate"]:
            return {
                "action": "escalate",
                "reason": escalation["reason"],
                "severity": escalation["severity"],
                "next_prompt": None
            }

        # Check for early termination (patient wants to end)
        if self._check_termination(response_text):
            return {
                "action": "close",
                "reason": "patient_requested_end",
                "next_prompt": self._closing_message()
            }

        # Advance state and get next question
        self.state = self._next_state(response_text)
        return {
            "action": "continue",
            "reason": None,
            "next_prompt": self.get_next_prompt()
        }

    def _check_escalation_triggers(self, text: str) -> dict:
        """Check for keywords that require doctor escalation."""
        text_lower = text.lower()
        critical_keywords = {
            "severe pain": "high",
            "can't breathe": "critical",
            "bleeding": "high",
            "emergency": "critical",
            "hospital": "medium",
            "admit": "high",
            "admission": "high",
            "not better": "medium",
            "worse": "medium",
            "side effect": "medium",
            "allergic": "high",
            "swelling": "medium",
            "fever high": "high",
            "vomiting": "medium",
            "accident": "critical",
            "suicide": "critical",
            "harm": "critical"
        }

        for keyword, severity in critical_keywords.items():
            if keyword in text_lower:
                return {
                    "escalate": True,
                    "reason": f"Keyword trigger: '{keyword}'",
                    "severity": severity
                }

        # Check sentiment trend
        negative_count = sum(
            1 for s in self.sentiment_history[-3:]
            if s in ["negative", "frustrated", "distressed"]
        )
        if negative_count >= 2:
            return {
                "escalate": True,
                "reason": "Sustained negative sentiment",
                "severity": "medium"
            }

        return {"escalate": False, "reason": None, "severity": None}
```

## 5. MEDICATION ADHERENCE CHECK

```python
# adherence_check.py
class MedicationAdherenceChecker:
    """
    Checks and tracks medication adherence during follow-up calls.
    Compares patient-reported adherence with prescription data.
    Generates adherence reports for doctors.
    """

    def check_adherence(self, patient_id: int,
                        prescription_id: int | None = None) -> dict:
        """
        Check medication adherence for a patient.
        1. Fetch active prescriptions
        2. Compare expected doses taken vs reported
        3. Calculate adherence percentage
        4. Flag non-adherence
        """
        prescriptions = self.get_active_prescriptions(
            patient_id, prescription_id
        )
        adherence_data = []

        for rx in prescriptions:
            expected_doses = self._calculate_expected_doses(rx)
            reported_missed = self._get_reported_missed(patient_id, rx["id"])
            actual_doses = expected_doses - reported_missed

            adherence_pct = (
                (actual_doses / expected_doses * 100)
                if expected_doses > 0 else 100
            )

            adherence_data.append({
                "medicine_id": rx["medicine_id"],
                "medicine_name": rx["medicine_name"],
                "dosage": rx["dosage"],
                "frequency": rx["frequency"],
                "expected_doses": expected_doses,
                "reported_missed": reported_missed,
                "adherence_pct": round(adherence_pct, 1),
                "status": "adherent" if adherence_pct >= 80 else
                          "partial" if adherence_pct >= 50 else
                          "non_adherent"
            })

        overall_pct = (
            sum(a["adherence_pct"] for a in adherence_data) /
            len(adherence_data)
        ) if adherence_data else 100

        return {
            "patient_id": patient_id,
            "overall_adherence": round(overall_pct, 1),
            "medications": adherence_data,
            "non_adherent_count": sum(
                1 for a in adherence_data
                if a["status"] == "non_adherent"
            ),
            "partial_count": sum(
                1 for a in adherence_data
                if a["status"] == "partial"
            ),
            "requires_intervention": overall_pct < 70
        }
```

## 6. FEEDBACK COLLECTION & AGGREGATION

```python
# feedback_collector.py
class FeedbackCollector:
    """
    Collects patient feedback during follow-up calls,
    aggregates into satisfaction metrics, and generates
    clinic-level insights.
    """

    FEEDBACK_SCALE = {
        1: "Very Dissatisfied",
        2: "Dissatisfied",
        3: "Neutral",
        4: "Satisfied",
        5: "Very Satisfied"
    }

    def collect_feedback(self, call_sid: str,
                         responses: dict) -> dict:
        """
        Process feedback responses from a follow-up call.
        Extracts structured ratings and qualitative comments.
        """
        feedback = {
            "call_sid": call_sid,
            "ratings": {},
            "comments": [],
            "sentiment_avg": 0,
            "categories": {}
        }

        for key, value in responses.items():
            if "rating" in key or "satisfaction" in key:
                try:
                    rating = int(value["text"])
                    feedback["ratings"][key] = {
                        "score": min(max(rating, 1), 5),
                        "label": self.FEEDBACK_SCALE.get(rating, "Unknown")
                    }
                except (ValueError, TypeError):
                    pass
            elif "suggestion" in key or "comment" in key:
                feedback["comments"].append(value["text"])

        if feedback["ratings"]:
            scores = [r["score"] for r in feedback["ratings"].values()]
            feedback["sentiment_avg"] = round(
                sum(scores) / len(scores), 2
            )

        # Save to analytics
        self._persist_feedback(feedback)
        return feedback
```

## 7. SQL DATA MODEL

```sql
-- followup_schema.sql
CREATE TABLE followup_schedule (
    id                  BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT NOT NULL REFERENCES patients(id),
    doctor_id           BIGINT REFERENCES doctors(id),
    appointment_id      BIGINT REFERENCES appointments(id),
    followup_type       VARCHAR(32) NOT NULL,
    scheduled_at        TIMESTAMP NOT NULL,
    actual_called_at    TIMESTAMP,
    default_channel     VARCHAR(16) DEFAULT 'voice',
    override_channel    VARCHAR(16),
    language_preference VARCHAR(10) DEFAULT 'en',
    priority            VARCHAR(8) DEFAULT 'normal'
                        CHECK (priority IN ('low', 'normal', 'high', 'critical')),
    status              VARCHAR(16) DEFAULT 'pending'
                        CHECK (status IN
                          ('pending', 'in_progress', 'completed',
                           'failed', 'cancelled', 'deferred')),
    retry_count         INT DEFAULT 0,
    max_retries         INT DEFAULT 3,
    response_data       JSONB,
    call_sid            VARCHAR(64),
    duration_seconds    INT,
    created_at          TIMESTAMP DEFAULT NOW(),
    completed_at        TIMESTAMP,
    INDEX(patient_id),
    INDEX(scheduled_at, status),
    INDEX(followup_type)
);

CREATE TABLE medication_adherence_log (
    id              BIGSERIAL PRIMARY KEY,
    followup_id     BIGINT REFERENCES followup_schedule(id),
    patient_id      BIGINT NOT NULL REFERENCES patients(id),
    prescription_id BIGINT REFERENCES prescriptions(id),
    medicine_name   VARCHAR(128) NOT NULL,
    expected_doses  INT NOT NULL,
    missed_doses    INT DEFAULT 0,
    adherence_pct   DECIMAL(5,2),
    reason_missed   TEXT,
    side_effects    TEXT,
    status          VARCHAR(16) CHECK (status IN
                      ('adherent', 'partial', 'non_adherent')),
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(patient_id, created_at)
);

CREATE TABLE feedback_responses (
    id              BIGSERIAL PRIMARY KEY,
    followup_id     BIGINT REFERENCES followup_schedule(id),
    patient_id      BIGINT NOT NULL REFERENCES patients(id),
    category        VARCHAR(32) NOT NULL,
    rating          INT CHECK (rating BETWEEN 1 AND 5),
    comment         TEXT,
    sentiment       VARCHAR(16),
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(patient_id),
    INDEX(category, rating)
);
```

## 8. YAML CONFIGURATION

```yaml
# ai_followup.yaml
followup:
  enabled: true
  scheduler_interval_minutes: 15
  max_concurrent_calls: 10
  max_retries: 3
  retry_delay_minutes: 30

  quiet_hours:
    voice_calls:
      start: "21:00"
      end: "08:00"
    whatsapp_messages:
      start: "22:00"
      end: "07:00"

  escalation:
    doctor_notification_channels: ["push", "sms", "email"]
    emergency_escalation_immediate: true
    critical_keywords_file: "critical_keywords.txt"
    negative_sentiment_threshold: 0.6  # proportion of negative responses

  conversation:
    max_duration_minutes: 5
    no_input_timeout_seconds: 8
    interruption_handling: true
    early_termination_phrases:
      - "I'm busy"
      - "call later"
      - "not now"
      - "stop"
      - "don't call"
      - "बाद में कॉल करें"
      - "अभी नहीं"

  templates:
    post_visit_24h: "followup_recovery_24h"
    post_visit_72h: "followup_adherence_72h"
    post_visit_7d: "followup_symptom_7d"
    appointment_d7: "reminder_d7"
    appointment_d1: "reminder_d1"
    no_show: "followup_noshow"
    feedback: "feedback_collection"
```

## 9. KEY DESIGN DECISIONS

1. **Time-Based, Not Event-Based Triggers**: All follow-ups are scheduled with exact timestamps rather than triggered by database events. This gives predictable call volumes and allows the scheduler to batch dispatch during non-quiet hours.

2. **Quiet Hour Enforcement**: Voice calls are blocked between 9 PM and 8 AM. SMS/WhatsApp are blocked between 10 PM and 7 AM. Follow-ups due during quiet hours are deferred and dispatched at the next available window.

3. **Progressive Response Handling**: On each follow-up, the system takes note of patient responses and adjusts the next follow-up accordingly. A patient reporting "feeling fine" gets less aggressive follow-ups; one reporting "worsening" gets escalated.

4. **Sentiment Trend Escalation**: Rather than escalating on a single negative response, the system tracks sentiment over the last 3 responses. Two or more negative responses in a row trigger escalation, reducing false positives from a single bad-mood response.

5. **Adherence Calculation with Grace Period**: Adherence is calculated with a 24-hour grace period. A missed dose within the last 24 hours is flagged as "can be taken" rather than "missed," preventing unnecessary alerts for patients who are slightly delayed.

6. **Channel Fallback Chain**: Each follow-up has a channel priority order (e.g., voice > whatsapp > sms). If the primary channel fails (no answer, delivered but no response), the system falls through to the next channel within the same batch window.

7. **Opt-Out Registry**: Patients can opt out of follow-up calls at any time during a call (via keyword or explicit request). The opt-out is honored across all future follow-ups unless explicitly re-enabled by the clinic staff.
