---
file_id: "0500"
module_name: "AI Receptionist"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0104_COMMUNICATION_ENGINE.md", "0107_TWILIO_MODULE.md", "0201_DOCTOR_MODULE.md"]
related_files: ["0503_AI_VOICE_AGENT.md", "0502_AI_FOLLOWUP.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "ai", "receptionist", "voice", "stt", "tts", "twilio", "vonage", "bilingual"]
---

# GHOS — AI Receptionist

## 1. PURPOSE
24/7 AI voice receptionist that handles incoming calls, books/cancels/reschedules appointments, performs patient lookups, answers clinic information queries, and routes calls to appropriate departments. Supports bilingual Hindi/English conversation with context-aware switching.

```
┌─────────────────────────────────────────────────────────────────┐
│                     CALL FLOW DIAGRAM                           │
│                                                                  │
│  Incoming Call (Twilio/Vonage)                                   │
│       │                                                          │
│       ▼                                                          │
│  IVR Menu / Direct Connect                                       │
│       │                                                          │
│       ▼                                                          │
│  STT (Deepgram/Whisper) → Transcription                          │
│       │                                                          │
│       ▼                                                          │
│  Intent Classifier (LLM)                                         │
│       │                                                          │
│       ├──→ Appointment Booking → Slot Search → Confirm → TTS     │
│       ├──→ Query (Timings/Location/Doctor) → DB Lookup → TTS    │
│       ├──→ Cancel/Reschedule → Modify Booking → Confirm → TTS   │
│       ├──→ Department Routing → Transfer Call                    │
│       ├──→ Patient Lookup → EHR Query → Speak Details → TTS     │
│       └──→ Take Message → Record → Notify Staff → Confirm → TTS │
│                                                                  │
│  Call End → Summary → Log → Recording Saved                      │
└─────────────────────────────────────────────────────────────────┘
```

## 2. INTENT CLASSIFICATION

### 2.1 Supported Intents
| Intent ID         | Description                    | Confidence Threshold | Action                      |
|-------------------|--------------------------------|----------------------|-----------------------------|
| `book_appt`       | Book a new appointment         | 0.75                 | Slot search + confirm       |
| `cancel_appt`     | Cancel existing appointment    | 0.80                 | Verify identity + cancel    |
| `reschedule_appt` | Reschedule an appointment      | 0.75                 | Verify + offer new slots    |
| `clinic_info`     | Timings, location, contact     | 0.70                 | DB lookup + respond         |
| `doctor_info`     | Doctor availability/specialty  | 0.75                 | Doctor DB query             |
| `dept_routing`    | Route to department            | 0.80                 | Warm transfer               |
| `patient_lookup`  | Look up patient by name/phone  | 0.85                 | EHR query                   |
| `take_message`    | Leave message for staff        | 0.80                 | Record + notify             |
| `emergency`       | Emergency keywords detected    | 0.90                 | Route to emergency          |
| `language_switch` | Switch language mid-conversation| 0.85                 | Toggle language context      |
| `unknown`         | Unclear intent                 | —                    | Reprompt + escalate          |

### 2.2 Intent Classification Prompt
```python
INTENT_PROMPT = """
You are an intent classifier for a medical clinic receptionist.
Given the transcribed user utterance, classify into exactly one intent.

Available intents:
{intent_list}

Patient context: {patient_history}
Current conversation context: {conversation_state}
Detected language: {language}

Output JSON:
{
    "intent": "str",
    "confidence": 0.0-1.0,
    "entities": {
        "doctor_name": "str or null",
        "department": "str or null",
        "date": "str or null",
        "time": "str or null",
        "patient_name": "str or null",
        "phone": "str or null"
    },
    "language": "hi|en|hinglish",
    "sentiment": "positive|neutral|frustrated|angry",
    "requires_escalation": false
}
"""
```

## 3. APPOINTMENT BOOKING WORKFLOW

### 3.1 Slot Search Algorithm
```python
# slot_search.py
def find_available_slots(
    doctor_id: str,
    date: date,
    duration_minutes: int = 15,
    department: str | None = None
) -> list[dict]:
    """
    Searches for available appointment slots for a given doctor on a given date.
    Returns list of slot dicts with start_time, end_time, is_available.
    """
    query = """
        SELECT
            s.id AS slot_id,
            s.start_time,
            s.end_time
        FROM appointment_slots s
        WHERE s.doctor_id = %s
          AND s.slot_date = %s
          AND s.is_available = TRUE
          AND s.start_time >= NOW()
          AND NOT EXISTS (
              SELECT 1 FROM appointments a
              WHERE a.slot_id = s.id
                AND a.status NOT IN ('cancelled', 'no_show')
          )
        ORDER BY s.start_time
        LIMIT 5;
    """
    return execute_read_query(query, (doctor_id, date))


def suggest_alternatives(
    preferred_slots: list[str],
    date: date,
    department: str
) -> dict:
    """
    If preferred slots unavailable, suggest:
    - Different time same doctor
    - Different doctor same specialty
    - Nearby dates
    - Teleconsultation option
    """
    alternatives = {
        "same_doctor": find_available_slots(doctor_id, date),
        "other_doctors": find_doctor_by_department(department),
        "nearby_dates": find_slots_near_date(date, 3),
        "teleconsult": get_teleconsult_slots(date)
    }
    return alternatives
```

### 3.2 Booking Confirmation
```python
def confirm_booking(
    patient_id: int,
    doctor_id: int,
    slot_id: int,
    booking_type: str = "opd",
    language: str = "en"
) -> dict:
    """
    Atomically reserves and confirms a booking.
    Sends confirmation via SMS + WhatsApp.
    Returns booking summary.
    """
    conn = get_db_connection()
    try:
        conn.begin()
        slot = reserve_slot(conn, slot_id, patient_id)
        booking = create_appointment(
            conn, patient_id, doctor_id, slot_id, booking_type
        )
        notification = queue_notification(
            conn,
            channel="whatsapp",
            template="booking_confirmed",
            data={
                "patient_name": patient_name,
                "doctor_name": doctor_name,
                "date": slot["date"],
                "time": slot["start_time"],
                "location": clinic_address,
                "language": language,
                "calendar_link": generate_calendar_link(booking)
            }
        )
        conn.commit()

        speak_text(tts_feedback_text(booking, language))

        return {
            "booking_id": booking["id"],
            "patient_id": patient_id,
            "doctor": doctor_name,
            "date": str(slot["date"]),
            "time": str(slot["start_time"]),
            "confirmation_sent": True
        }
    except Exception:
        conn.rollback()
        speak_text(apology_text(language, "booking_failed"))
        raise
    finally:
        conn.close()
```

## 4. PATIENT LOOKUP

```python
def lookup_patient(identifier: str, lookup_type: str = "phone") -> dict | None:
    """
    Look up a patient by phone number, name, or UHID.
    Returns patient summary for voice response.
    """
    if lookup_type == "phone":
        query = """
            SELECT p.id, p.full_name, p.uhid, p.phone, p.dob,
                   a.appointment_date, a.status AS last_appt_status,
                   d.full_name AS last_doctor
            FROM patients p
            LEFT JOIN appointments a ON a.patient_id = p.id
            LEFT JOIN doctors d ON d.id = a.doctor_id
            WHERE p.phone LIKE %s
            ORDER BY a.appointment_date DESC
            LIMIT 1;
        """
        result = execute_read_query(query, (f"%{identifier}",))

    if not result:
        return None

    return {
        "patient_id": result[0]["id"],
        "name": result[0]["full_name"],
        "uhid": result[0]["uhid"],
        "phone": result[0]["phone"],
        "last_visit": str(result[0]["appointment_date"]),
        "last_doctor": result[0]["last_doctor"]
    }
```

## 5. CLINIC INFORMATION QUERY

### 5.1 Knowledge Base Structure
```yaml
# clinic_info.yaml
clinic:
  name: "GIL Clinic"
  addresses:
    main:
      line1: "123, MG Road"
      city: "Indore"
      state: "Madhya Pradesh"
      pincode: "452001"
      landmark: "Near Gandhi Hall"
      google_maps_link: "https://maps.google.com/?q=..."
  timings:
    opd:
      weekdays: "09:00 AM - 08:00 PM"
      saturday: "09:00 AM - 04:00 PM"
      sunday: "Closed (Emergency Only)"
    emergency: "24x7 Available"
  contact:
    phone: "+91-98765-43210"
    whatsapp: "+91-98765-43210"
    email: "contact@gilclinic.com"
  departments:
    - name: "General Medicine"
      available: true
      doctors_count: 4
    - name: "Cardiology"
      available: true
      doctors_count: 2
    - name: "Pediatrics"
      available: true
      doctors_count: 3
    - name: "Orthopedics"
      available: true
      doctors_count: 2
  services:
    - "OPD Consultation"
    - "Pharmacy"
    - "Diagnostic Lab"
    - "ECG & Echo"
    - "Physiotherapy"
    - "Teleconsultation"
  language_support:
    - "English"
    - "Hindi"
    - "Hinglish"
```

## 6. CALL RECORDING & TRANSCRIPTION

```python
# call_recording.py
class CallRecordingManager:
    """
    Manages call recording lifecycle:
    - Start recording on call connect
    - Stream transcription in real-time
    - Store recording in S3/compatible storage
    - Transcribe full call for EHR notes
    - Auto-delete after retention period (configurable)
    """

    BUCKET_NAME = "gil-clinic-call-recordings"
    RETENTION_DAYS = 90
    ALLOWED_FORMATS = ["wav", "mp3", "ogg"]

    def __init__(self, twilio_client):
        self.twilio = twilio_client

    def start_recording(self, call_sid: str) -> dict:
        """
        Start call recording via Twilio.
        Returns recording resource SID.
        """
        recording = self.twilio.calls(call_sid).recordings.create(
            recording_status_callback=self.RECORDING_CALLBACK_URL,
            recording_status_callback_event=["completed", "failed"],
            recording_track="both"
        )
        return {"recording_sid": recording.sid, "status": "recording"}

    def save_transcript(self, call_sid: str, transcript: str, language: str):
        """Save transcript to database and object storage."""
        transcript_id = generate_uuid()
        s3_key = f"transcripts/{call_sid}/{transcript_id}.json"
        transcript_data = {
            "call_sid": call_sid,
            "transcript": transcript,
            "language": language,
            "created_at": datetime.utcnow().isoformat(),
            "word_count": len(transcript.split()),
            "detected_sentiment": analyze_sentiment(transcript)
        }
        upload_to_s3(self.BUCKET_NAME, s3_key, transcript_data)
        save_to_db(
            "INSERT INTO call_transcripts (call_sid, transcript_id, s3_key,
             language, word_count, created_at)
             VALUES (%s, %s, %s, %s, %s, %s)",
            (call_sid, transcript_id, s3_key, language,
             transcript_data["word_count"], transcript_data["created_at"])
        )

    def schedule_deletion(self, call_sid: str):
        """Schedule recording for deletion after retention period."""
        delete_at = datetime.utcnow() + timedelta(days=self.RETENTION_DAYS)
        save_to_db(
            "INSERT INTO recording_retention (call_sid, delete_at, status)
             VALUES (%s, %s, 'pending')",
            (call_sid, delete_at)
        )
```

## 7. BILINGUAL SUPPORT (HINDI/ENGLISH)

### 7.1 Language Detection & Switching
```python
class BilingualManager:
    """
    Handles language detection and code-switching during calls.
    Automatically detects language of each utterance.
    Maintains per-call language preference.
    Supports Hinglish (mixed Hindi-English).
    """

    LANGUAGE_SIGNATURES = {
        "hi": {"trigger_words": ["namaste", "ji", "kya", "hai", "mera",
               "aap", "kaise", "suniye", "hindi"]},
        "en": {"trigger_words": ["hello", "hi", "please", "thank", "book",
               "appointment", "doctor", "help", "yes", "no"]},
        "hinglish": {"indicators": ["can I", "kya main", "mere", "please",
                     "aap", "iska", "karwa do", "need hai"]}
    }

    def detect_language(self, text: str) -> str:
        """Detect language of utterance using heuristic + confidence scoring."""
        text_lower = text.lower()
        scores = {"hi": 0, "en": 0, "hinglish": 0}

        for lang, sig in self.LANGUAGE_SIGNATURES.items():
            scores[lang] = sum(
                1 for w in sig["trigger_words"] if w in text_lower
            )

        scores["hinglish"] = scores["hinglish"] * 1.5

        if any(w in text_lower for w in self.HINDI_SCRIPT_INDICATORS):
            return "hi"

        return max(scores, key=scores.get)

    def generate_response(self, user_text: str, detected_lang: str) -> str:
        """
        Generate TTS response in the detected language.
        Maintains language for rest of call unless explicitly switched.
        """
        if detected_lang == "hi":
            return self.hindi_llm_response(user_text)
        elif detected_lang == "hinglish":
            return self.hinglish_llm_response(user_text)
        return self.english_llm_response(user_text)
```

## 8. TELEPHONY INTEGRATION

### 8.1 Twilio Webhook Handler
```python
# twilio_webhook.py
from flask import Blueprint, request
from twilio.twiml.voice_response import VoiceResponse, Gather

twilio_bp = Blueprint("twilio", __name__)

@twilio_bp.route("/voice/incoming", methods=["POST"])
def handle_incoming_call():
    """
    Entry point for incoming calls from Twilio.
    Plays greeting, gathers speech input.
    """
    response = VoiceResponse()
    gather = Gather(
        input="speech",
        timeout=5,
        speech_timeout="auto",
        language="hi-IN,en-IN",
        speech_model="phone_call",
        enhanced=True,
        action="/voice/process_input",
        method="POST"
    )
    gather.say(
        "Welcome to GIL Clinic. How can I help you today?",
        voice="Polly.Aditi",
        language="en-IN"
    )
    gather.say(
        "GIL Clinic mein aapka swagat hai. Main aapki kaise madad kar sakti hoon?",
        voice="Polly.Aditi",
        language="hi-IN"
    )
    response.append(gather)
    return str(response)


@twilio_bp.route("/voice/process_input", methods=["POST"])
def process_speech_input():
    """
    Processes user's speech input:
    1. Transcribe (already done by Twilio)
    2. Classify intent
    3. Execute action
    4. Respond via TTS
    """
    user_speech = request.form.get("SpeechResult", "")
    confidence = float(request.form.get("Confidence", 0))
    call_sid = request.form.get("CallSid")
    from_number = request.form.get("From")

    intent_result = classify_intent(user_speech)
    action_result = execute_intent(intent_result, call_sid, from_number)

    response = VoiceResponse()

    if action_result.get("requires_human_transfer"):
        response.say("Please hold while I connect you to our team.",
                     voice="Polly.Aditi")
        response.dial(action_result["transfer_number"])
    else:
        response.say(action_result["tts_text"],
                     voice="Polly.Aditi", language=action_result["language"])

        gather = Gather(
            input="speech",
            timeout=3,
            speech_timeout="auto",
            action="/voice/process_input",
            method="POST"
        )
        gather.say("Is there anything else I can help you with?",
                   voice="Polly.Aditi")
        response.append(gather)

        response.redirect("/voice/end_call", method="POST")

    return str(response)
```

### 8.2 Vonage (Nexmo) Handler
```python
# vonage_handler.py
from vonage import Voice

class VonageVoiceHandler:
    """Handler for Vonage/Nexmo voice API integration."""

    def __init__(self, api_key: str, api_secret: str):
        self.voice = Voice(key=api_key, secret=api_secret)

    def create_ncco(self, greeting: str, language: str) -> list:
        """Create NCCO (Nexmo Call Control Object) flow."""
        ncco = [
            {
                "action": "talk",
                "text": greeting,
                "voice_name": "Aditi" if language == "hi-IN" else "Joanna",
                "language": language,
                "bargeIn": False
            },
            {
                "action": "input",
                "type": ["speech"],
                "speech": {
                    "uuid": ["async"],
                    "endOnSilence": 1.5,
                    "language": language,
                    "context": [
                        "appointment", "book", "cancel", "timing",
                        "doctor", "emergency", "hello", "help"
                    ]
                },
                "eventUrl": ["https://api.gilclinic.com/voice/process"],
                "timeOut": 5
            }
        ]
        return ncco

    def make_outbound_call(self, to_number: str, ncco: list) -> dict:
        """Initiate outbound call using NCCO flow."""
        response = self.voice.create_call({
            "to": [{"type": "phone", "number": to_number}],
            "from": {"type": "phone", "number": self.CLINIC_NUMBER},
            "ncco": ncco
        })
        return response
```

## 9. CALL LOGGING & ANALYTICS

```sql
-- call_logs.sql
CREATE TABLE incoming_calls (
    id              BIGSERIAL PRIMARY KEY,
    call_sid        VARCHAR(64) UNIQUE NOT NULL,
    provider        VARCHAR(16) NOT NULL CHECK (provider IN ('twilio', 'vonage')),
    from_number     VARCHAR(20) NOT NULL,
    to_number       VARCHAR(20) NOT NULL,
    call_status     VARCHAR(20) NOT NULL DEFAULT 'ringing',
    duration_seconds INT DEFAULT 0,
    patient_id      BIGINT REFERENCES patients(id),
    detected_intent VARCHAR(32),
    detected_language VARCHAR(10),
    sentiment_score DECIMAL(4,3),
    transcript_s3_key VARCHAR(256),
    recording_s3_key VARCHAR(256),
    created_at      TIMESTAMP DEFAULT NOW(),
    completed_at    TIMESTAMP,
    INDEX(from_number),
    INDEX(call_status),
    INDEX(created_at)
);

CREATE TABLE call_events (
    id              BIGSERIAL PRIMARY KEY,
    call_sid        VARCHAR(64) REFERENCES incoming_calls(call_sid),
    event_type      VARCHAR(32) NOT NULL,
    event_data      JSONB,
    confidence      DECIMAL(4,3),
    language        VARCHAR(10),
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(call_sid, created_at)
);

CREATE TABLE appointment_bookings (
    id              BIGSERIAL PRIMARY KEY,
    call_sid        VARCHAR(64) REFERENCES incoming_calls(call_sid),
    patient_id      BIGINT REFERENCES patients(id),
    doctor_id       BIGINT REFERENCES doctors(id),
    slot_start      TIMESTAMP NOT NULL,
    slot_end        TIMESTAMP NOT NULL,
    booking_type    VARCHAR(16) DEFAULT 'opd',
    booking_status  VARCHAR(16) DEFAULT 'confirmed',
    confirmation_sent BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(patient_id),
    INDEX(doctor_id, slot_start)
);
```

## 10. YAML CONFIGURATION

```yaml
# ai_receptionist.yaml
receptionist:
  enabled: true
  telephony_provider: "twilio"  # twilio | vonage
  stt_engine: "deepgram"        # deepgram | whisper | twilio
  tts_engine: "polly"           # polly | elevenlabs | google
  llm_model: "gpt-4o-mini"

  call_handling:
    max_call_duration_minutes: 15
    max_retries_on_fail: 2
    no_input_timeout_seconds: 5
    max_idle_seconds: 30
    emergency_keywords:
      - "emergency"
      - "ambulance"
      - "chest pain"
      - "heart attack"
      - "accident"
      - "bleeding"
      - "unconscious"
      - "सीने में दर्द"
      - "एम्बुलेंस"

  appointment_booking:
    default_duration_minutes: 15
    allow_same_day_booking: true
    advance_booking_days: 30
    enable_teleconsult: true
    confirmation_channels: ["sms", "whatsapp"]

  language:
    default: "hi-IN"
    supported: ["hi-IN", "en-IN", "hinglish"]
    auto_detect: true
    allow_mid_call_switch: true

  recording:
    enabled: true
    retention_days: 90
    storage: "s3"
    bucket: "gil-clinic-call-recordings"
    transcript_enabled: true
    consent_required: true

  escalation:
    human_transfer_threshold: 3  # failed attempts before human transfer
    emergency_hotline: "+919876543210"
    supervisor_number: "+919876543211"
    after_hours_routing: true
```

## 11. KEY DESIGN DECISIONS

1. **Streaming STT over Batch**: Deepgram streaming STT chosen over batch Whisper to enable real-time turn-taking and barge-in handling, reducing perceived latency.

2. **Twilio Primary / Vonage Fallback**: Twilio is the default telephony provider due to superior Indian language STT support. Vonage serves as fallback for cost-sensitive routes and regions with better Vonage interconnect rates.

3. **Language Persistence per Call**: Language is auto-detected on first utterance and locked for the call duration unless the user explicitly switches (e.g., "Hindi mein baat karein"). This prevents mid-sentence language switches.

4. **Callback Webhook Pattern**: All async operations (recording completion, transcription done, booking confirmed) use webhook callbacks rather than polling, keeping the call flow non-blocking.

5. **Slot Reservation with TTL**: Slots are reserved with a 5-minute TTL during booking flow. If the conversation stalls, the slot is released automatically. This prevents phantom bookings from abandoned calls.

6. **Emergency Keyword Override**: Any utterance containing an emergency keyword immediately interrupts the current flow, plays an emergency message, and routes to the emergency hotline. This override cannot be bypassed by the AI.

7. **Consent Recording**: Call recording begins only after an explicit consent prompt ("This call may be recorded for quality and training purposes"). The consent flag is stored with the call log for compliance.
