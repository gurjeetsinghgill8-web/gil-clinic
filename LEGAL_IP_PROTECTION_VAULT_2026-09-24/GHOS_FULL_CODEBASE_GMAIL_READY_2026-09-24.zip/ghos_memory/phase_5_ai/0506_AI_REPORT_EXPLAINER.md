---
file_id: "0506"
module_name: "AI Report Explainer"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0108_REPORT_ENGINE.md", "0103_LAB_MODULE.md"]
related_files: ["0501_AI_TRIAGE.md", "0504_AI_DIETICIAN.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "ai", "report", "explanation", "patient", "bilingual", "whatsapp"]
---

# GHOS — AI Report Explainer

## 1. PURPOSE
Patient-facing medical report explanation system that converts complex lab reports, ECG/Echo reports, and radiology reports into simple, layman-friendly language. Highlights abnormal values, provides context in Hindi/English, generates actionable follow-up recommendations, and supports sharing via WhatsApp. The AI explains -- it does not diagnose.

```
┌─────────────────────────────────────────────────────────────────────┐
│                   REPORT EXPLAINER FLOW DIAGRAM                      │
│                                                                      │
│  Report Upload / EHR Fetch                                           │
│       │                                                               │
│       ▼                                                               │
│  Report Type Detection                                                │
│       │                                                               │
│       ├── Lab Report (Blood, Urine, etc.)                             │
│       ├── ECG Report                                                  │
│       ├── Echo Report                                                 │
│       ├── Radiology (X-Ray, MRI, CT, Ultrasound)                      │
│       └── Custom Upload (PDF/Image)                                   │
│       │                                                               │
│       ▼                                                               │
│  Data Extraction & Normalization                                      │
│       │                                                               │
│       ▼                                                               │
│  Reference Range Comparison                                           │
│       │                                                               │
│       ├── Within Normal → Green (Keep up the good work!)             │
│       ├── Borderline  → Yellow (Needs attention)                     │
│       └── Abnormal    → Red (Consult your doctor)                    │
│       │                                                               │
│       ▼                                                               │
│  LLM Explanation Generation                                           │
│       │                                                               │
│       ├── Simple summary (2-3 lines)                                  │
│       ├── Per-parameter explanation in lay terms                      │
│       ├── Trend analysis (compare with previous reports)              │
│       ├── Possible causes (informative, not diagnostic)               │
│       └── Lifestyle/Follow-up recommendations                         │
│       │                                                               │
│       ▼                                                               │
│  Bilingual Output (Hindi / English)                                   │
│       │                                                               │
│       ▼                                                               │
│  Delivery Channels                                                    │
│       ├── In-App Dashboard                                            │
│       ├── WhatsApp Message (Formatted + PDF)                          │
│       ├── Email                                                       │
│       └── SMS Link                                                    │
│                                                                       │
│  Disclaimers Applied on Every Output                                  │
└─────────────────────────────────────────────────────────────────────┘
```

## 2. REPORT TYPE DETECTION & PARSING

```python
# report_parser.py
from enum import Enum
from typing import Optional
import re


class ReportType(Enum):
    LAB_CBC = "lab_cbc"
    LAB_BIO = "lab_biochemistry"
    LAB_LIPID = "lab_lipid_profile"
    LAB_THYROID = "lab_thyroid"
    LAB_DIABETES = "lab_diabetes"
    LAB_URINE = "lab_urine"
    LAB_LIVER = "lab_liver_function"
    LAB_RENAL = "lab_renal_function"
    ECG = "ecg"
    ECHO = "echocardiography"
    XRAY = "radiology_xray"
    MRI = "radiology_mri"
    CT = "radiology_ct"
    ULTRASOUND = "radiology_ultrasound"
    CUSTOM = "custom_upload"


class ReportParser:
    """
    Detects report type and extracts structured data.
    Supports structured EHR data, PDF parsing, and image-based OCR.
    """

    def detect_type(self, report_data: dict) -> ReportType:
        """Detect report type from metadata or content analysis."""
        if "report_type" in report_data:
            return ReportType(report_data["report_type"])

        title = report_data.get("title", "").lower()
        if any(kw in title for kw in ["cbc", "complete blood", "hemogram"]):
            return ReportType.LAB_CBC
        elif any(kw in title for kw in ["lipid", "cholesterol"]):
            return ReportType.LAB_LIPID
        elif any(kw in title for kw in ["thyroid", "t3", "t4", "tsh"]):
            return ReportType.LAB_THYROID
        elif any(kw in title for kw in ["hba1c", "glucose", "sugar"]):
            return ReportType.LAB_DIABETES
        elif any(kw in title for kw in ["liver", "sgpt", "sgot", "alt", "ast"]):
            return ReportType.LAB_LIVER
        elif any(kw in title for kw in ["kidney", "renal", "creatinine", "bun", "urea"]):
            return ReportType.LAB_RENAL
        elif "ecg" in title or "ekg" in title:
            return ReportType.ECG
        elif "echo" in title or "echocardio" in title:
            return ReportType.ECHO
        elif any(kw in title for kw in ["x-ray", "xray", "radiograph"]):
            return ReportType.XRAY
        elif "mri" in title:
            return ReportType.MRI
        elif "ct" in title or "cat scan" in title:
            return ReportType.CT
        elif "ultrasound" in title or "sonography" in title:
            return ReportType.ULTRASOUND
        return ReportType.CUSTOM

    def extract_parameters(self, report: dict,
                           report_type: ReportType) -> list[dict]:
        """
        Extract individual test parameters with values, units, and ranges.
        Returns structured list for processing.
        """
        if report_type.value.startswith("lab_"):
            return self._parse_lab_report(report)
        elif report_type in [ReportType.ECG, ReportType.ECHO]:
            return self._parse_cardiac_report(report)
        elif report_type.value.startswith("radiology_"):
            return self._parse_radiology_report(report)
        return self._parse_custom_report(report)

    def _parse_lab_report(self, report: dict) -> list[dict]:
        """
        Parse structured lab report data.
        Each parameter: name, value, unit, reference_range, flag.
        """
        parameters = []
        raw_params = report.get("parameters", []) or \
                     report.get("results", []) or \
                     report.get("tests", [])

        for param in raw_params:
            value = param.get("value")
            ref_range = param.get("reference_range", "")
            flag = self._calculate_flag(value, ref_range)

            parameters.append({
                "name": param.get("name", "Unknown"),
                "name_hi": self._get_hindi_name(param.get("name", "")),
                "value": value,
                "unit": param.get("unit", ""),
                "reference_range": ref_range,
                "flag": flag,  # "normal", "high", "low", "borderline"
                "is_critical": flag in ["high", "low"] and
                               self._is_critical(param.get("name", ""), value, ref_range),
                "previous_value": param.get("previous_value"),
                "previous_date": param.get("previous_date")
            })

        return parameters

    def _calculate_flag(self, value, ref_range: str) -> str:
        """Determine if a value is normal, high, low, or borderline."""
        if value is None or not ref_range:
            return "unknown"

        try:
            val = float(value)
        except (ValueError, TypeError):
            return "unknown"

        ranges = re.findall(r'[\d.]+', ref_range)
        if len(ranges) >= 2:
            low, high = float(ranges[0]), float(ranges[1])
            margin = (high - low) * 0.1  # 10% borderline zone
            if low - margin <= val <= high + margin:
                return "normal"
            elif val < low:
                return "low" if val < low - margin else "borderline_low"
            else:
                return "high" if val > high + margin else "borderline_high"
        else:
            # Single threshold (e.g., "< 200")
            threshold = float(ranges[0])
            if "<" in ref_range:
                return "normal" if val < threshold else "high"
            elif ">" in ref_range:
                return "normal" if val > threshold else "low"

        return "unknown"
```

## 3. LLM EXPLANATION GENERATOR

```python
# explanation_generator.py
class ExplanationGenerator:
    """
    Generates patient-friendly explanations for medical reports.
    Uses LLM with structured context and safety guardrails.
    Always outputs disclaimers.
    """

    def __init__(self, llm_model: str = "gpt-4o-mini"):
        self.llm = llm_model

    def generate_summary(self, parameters: list[dict],
                         report_type: ReportType,
                         patient_context: dict,
                         language: str = "en") -> dict:
        """
        Generate complete report explanation with:
        - Overall summary (2-3 simple sentences)
        - Per-parameter plain-language explanation
        - Abnormal value highlighting
        - Trend analysis (if previous data available)
        - Follow-up recommendations
        """
        abnormal = [p for p in parameters if p["flag"] not in
                    ["normal", "unknown"]]
        critical = [p for p in parameters if p.get("is_critical")]
        trends = [p for p in parameters if p.get("previous_value")]

        prompt = f"""
        You are a medical report explanation assistant for patients.
        Explain the following {report_type.value} results in simple,
        patient-friendly language.

        REPORT TYPE: {report_type.value}
        LANGUAGE: {language}
        PATIENT AGE: {patient_context.get('age', 'N/A')}
        PATIENT GENDER: {patient_context.get('gender', 'N/A')}

        PARAMETERS:
        {json.dumps(parameters, indent=2)}

        ABNORMAL PARAMETERS:
        {json.dumps(abnormal, indent=2)}

        CRITICAL VALUES:
        {json.dumps(critical, indent=2)}

        TREND DATA:
        {json.dumps(trends, indent=2)}

        For each parameter:
        1. Tell the patient what it checks
        2. What their value means in simple terms
        3. If abnormal, what it might indicate (informative only, never diagnostic)
        4. Practical recommendation

        CRITICAL RULES:
        - NEVER say "you have [disease]". Say "your [value] is [status]"
        - NEVER prescribe treatment. Say "consult your doctor"
        - ALWAYS include: "This explanation is for understanding only.
          Please discuss with your doctor."
        - If Hindi: use simple Hindi, no medical jargon
        - Highlight abnormal values with "NEEDS ATTENTION" or
          "ध्यान देने योग्य" markers

        Output JSON:
        {{
            "overall_summary": "2-3 sentence summary in patient's language",
            "parameter_explanations": [
                {{
                    "name": "str",
                    "patient_friendly_name": "str",
                    "your_value": "str",
                    "normal_range": "str",
                    "what_it_means": "simple explanation",
                    "flag": "normal|abnormal|critical",
                    "recommendation": "actionable suggestion"
                }}
            ],
            "abnormal_highlights": ["list of abnormal items with markers"],
            "trend_analysis": "trend description if previous data exists, else null",
            "recommendations": ["list of follow-up suggestions"],
            "disclaimer": "standard disclaimer text"
        }}
        """

        result = llm_call(prompt, model=self.llm, max_tokens=2048,
                          temperature=0.3)
        explanation = json.loads(result)

        # Ensure disclaimer is always present
        explanation["disclaimer"] = self._get_disclaimer(language)

        return explanation

    def _get_disclaimer(self, language: str) -> str:
        """Get disclaimer in the appropriate language."""
        disclaimers = {
            "en": "This explanation is AI-generated for patient understanding "
                  "only. It does NOT constitute a medical diagnosis or "
                  "replace professional medical advice. Always consult your "
                  "doctor for interpretation of your reports.",
            "hi": "यह व्याख्या AI द्वारा रोगी की समझ के लिए तैयार की गई है। "
                  "यह किसी भी प्रकार का चिकित्सीय निदान नहीं है और "
                  "पेशेवर चिकित्सा सलाह का विकल्प नहीं है। अपनी रिपोर्ट "
                  "की व्याख्या के लिए हमेशा अपने डॉक्टर से परामर्श करें।"
        }
        return disclaimers.get(language, disclaimers["en"])
```

## 4. ABNORMAL VALUE HIGHLIGHTING

```python
# value_highlighter.py
class ValueHighlighter:
    """
    Highlights and prioritizes abnormal values for patient attention.
    Generates color-coded output and urgency indicators.
    """

    FLAG_MAP = {
        "high": {"color": "red", "icon": "⬆️",
                 "label_en": "HIGH - Needs Attention",
                 "label_hi": "उच्च - ध्यान देने योग्य",
                 "priority": 1},
        "low": {"color": "red", "icon": "⬇️",
                "label_en": "LOW - Needs Attention",
                "label_hi": "निम्न - ध्यान देने योग्य",
                "priority": 1},
        "borderline_high": {"color": "orange", "icon": "↗️",
                           "label_en": "Borderline High",
                           "label_hi": "सीमा रेखा उच्च",
                           "priority": 2},
        "borderline_low": {"color": "orange", "icon": "↘️",
                          "label_en": "Borderline Low",
                          "label_hi": "सीमा रेखा निम्न",
                          "priority": 2},
        "normal": {"color": "green", "icon": "✅",
                   "label_en": "Normal", "label_hi": "सामान्य",
                   "priority": 3},
        "unknown": {"color": "gray", "icon": "❓",
                    "label_en": "Could not determine",
                    "label_hi": "निर्धारित नहीं कर सके",
                    "priority": 4}
    }

    WORKING_RANGES = {
        "hemoglobin": {"low": 13 if "male" else 12,
                       "high": 17 if "male" else 15,
                       "unit": "g/dL"},
        "hba1c": {"low": 0, "high": 5.7, "diabetic": 6.5, "unit": "%"},
        "fasting_glucose": {"low": 70, "high": 100, "diabetic": 126,
                            "unit": "mg/dL"},
        "total_cholesterol": {"low": 0, "high": 200, "unit": "mg/dL"},
        "ldl": {"low": 0, "high": 100, "unit": "mg/dL"},
        "hdl": {"low": 40 if "male" else 50, "high": 999,
                "unit": "mg/dL"},
        "triglycerides": {"low": 0, "high": 150, "unit": "mg/dL"},
        "creatinine": {"low": 0.6, "high": 1.2, "unit": "mg/dL"},
        "tsh": {"low": 0.5, "high": 5.0, "unit": "mIU/L"},
        "vitamin_d": {"low": 30, "high": 100, "unit": "ng/mL"},
        "vitamin_b12": {"low": 200, "high": 900, "unit": "pg/mL"}
    }

    def get_flagged_parameters(self, parameters: list[dict],
                               patient_gender: str = "male",
                               language: str = "en") -> list[dict]:
        """
        Annotate each parameter with display flags and priority.
        Sorts by priority (abnormal first).
        """
        flagged = []
        for param in parameters:
            flag_info = self.FLAG_MAP.get(param["flag"], self.FLAG_MAP["unknown"]).copy()
            param_name = param.get("name", "").lower().replace(" ", "_")
            working_range = self.WORKING_RANGES.get(param_name)

            if working_range and "gender" in working_range:
                threshold_key = "male" if patient_gender == "male" else "female"
                working_range = {**working_range,
                                 "low": working_range.get(f"low_{threshold_key}",
                                                         working_range.get("low")),
                                 "high": working_range.get(f"high_{threshold_key}",
                                                          working_range.get("high"))}

            flagged.append({
                **param,
                "display": {
                    "color": flag_info["color"],
                    "icon": flag_info["icon"],
                    "label": flag_info.get(f"label_{language}",
                                           flag_info.get("label_en")),
                    "priority": flag_info["priority"]
                },
                "working_range": working_range
            })

        flagged.sort(key=lambda x: (x["display"]["priority"],
                                    abs(float(x.get("value", 0) or 0)),
                                    x["name"]))
        return flagged
```

## 5. WHATSAPP SHARING

```python
# whatsapp_sharing.py
class WhatsAppShare:
    """
    Handles sharing of report explanations via WhatsApp.
    Generates formatted message and optional PDF attachment.
    Uses WhatsApp Business API for delivery.
    """

    TEMPLATE_NAME = "report_explanation"

    def __init__(self, whatsapp_api, pdf_generator):
        self.api = whatsapp_api
        self.pdf_gen = pdf_generator

    def share_explanation(self, patient_phone: str,
                          explanation: dict,
                          report_name: str,
                          language: str = "en") -> dict:
        """
        Share formatted report explanation via WhatsApp.
        Sends text summary + optional PDF attachment.
        """
        message = self._format_whatsapp_message(explanation, language)

        # Send text message
        text_response = self.api.send_message(
            to=patient_phone,
            template=self.TEMPLATE_NAME,
            parameters={
                "patient_name": explanation.get("patient_name", ""),
                "report_name": report_name,
                "summary": explanation.get("overall_summary", ""),
                "language": language,
                "disclaimer": explanation.get("disclaimer", "")
            }
        )

        # Generate and send PDF
        pdf_bytes = self.pdf_gen.generate_explanation_pdf(
            explanation, language
        )
        pdf_response = self.api.send_document(
            to=patient_phone,
            document=pdf_bytes,
            filename=f"{report_name}_explanation.pdf",
            caption=f"Your {report_name} explained - GIL Clinic"
        )

        return {
            "message_id": text_response.get("message_id"),
            "pdf_id": pdf_response.get("message_id"),
            "status": "delivered",
            "timestamp": datetime.utcnow().isoformat()
        }

    def _format_whatsapp_message(self, explanation: dict,
                                  language: str) -> str:
        """Format explanation as WhatsApp-friendly text."""
        if language == "hi":
            lines = [
                "नमस्ते! 👋",
                "",
                f"आपकी रिपोर्ट का सरल विवरण:",
                "",
                explanation.get("overall_summary", ""),
                "",
                "**ध्यान देने योग्य परिणाम:**"
            ]
            for item in explanation.get("abnormal_highlights", []):
                lines.append(f"⚠️ {item}")
            lines.extend([
                "",
                "**सुझाव:**",
                *[f"• {r}" for r in explanation.get("recommendations", [])],
                "",
                f"_{explanation.get('disclaimer', '')}_"
            ])
        else:
            lines = [
                "Hello! 👋",
                "",
                "Here's a simple explanation of your report:",
                "",
                explanation.get("overall_summary", ""),
                "",
                "**Results needing attention:**"
            ]
            for item in explanation.get("abnormal_highlights", []):
                lines.append(f"⚠️ {item}")
            lines.extend([
                "",
                "**Suggestions:**",
                *[f"• {r}" for r in explanation.get("recommendations", [])],
                "",
                f"_{explanation.get('disclaimer', '')}_"
            ])

        return "\n".join(lines)
```

## 6. SQL DATA MODEL

```sql
-- report_explainer_schema.sql
CREATE TABLE report_explanations (
    id                  BIGSERIAL PRIMARY KEY,
    report_id           BIGINT REFERENCES reports(id),
    patient_id          BIGINT NOT NULL REFERENCES patients(id),
    report_type         VARCHAR(32) NOT NULL,
    original_report_data JSONB NOT NULL,
    extracted_parameters JSONB,
    flagged_parameters  JSONB,
    explanation_data    JSONB NOT NULL,
    language            VARCHAR(10) DEFAULT 'en',
    generation_model    VARCHAR(64),
    token_count         INT,
    latency_ms          INT,
    status              VARCHAR(16) DEFAULT 'generated'
                        CHECK (status IN
                          ('generated', 'viewed', 'shared', 'archived')),
    shared_via          VARCHAR(32),
    feedback_rating     INT CHECK (feedback_rating BETWEEN 1 AND 5),
    created_at          TIMESTAMP DEFAULT NOW(),
    viewed_at           TIMESTAMP,
    INDEX(patient_id, created_at),
    INDEX(report_id)
);

CREATE TABLE explanation_feedback (
    id              BIGSERIAL PRIMARY KEY,
    explanation_id  BIGINT REFERENCES report_explanations(id),
    patient_id      BIGINT REFERENCES patients(id),
    helpful_rating  INT CHECK (helpful_rating BETWEEN 1 AND 5),
    clarity_rating  INT CHECK (clarity_rating BETWEEN 1 AND 5),
    comments        TEXT,
    shared_report   BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT NOW()
);
```

## 7. YAML CONFIGURATION

```yaml
# ai_report_explainer.yaml
report_explainer:
  enabled: true
  llm_model: "gpt-4o-mini"
  max_report_size_kb: 10240

  supported_reports:
    - lab_cbc
    - lab_biochemistry
    - lab_lipid_profile
    - lab_thyroid
    - lab_diabetes
    - lab_liver_function
    - lab_renal_function
    - ecg
    - echocardiography
    - radiology_xray
    - radiology_mri
    - radiology_ct
    - radiology_ultrasound

  explanation:
    max_summary_length: 500
    include_trend_analysis: true
    highlight_critical_only: false  # if false, all abnormals highlighted
    temperature: 0.3
    max_tokens: 2048

  sharing:
    channels:
      - whatsapp
      - email
      - sms_link
      - in_app
    whatsapp_template_name: "report_explanation"
    pdf_attachment: true
    pdf_branding:
      clinic_name: "GIL Clinic"
      logo_url: "https://gilclinic.com/logo.png"
      colors:
        primary: "#0056A0"
        accent: "#00A86B"
        warning: "#FF6B35"
        error: "#D32F2F"

  disclaimers:
    always_show: true
    languages: ["en", "hi"]

  performance:
    cache_explanations: true
    cache_ttl_hours: 24
    async_generation: false  # true for large reports
```

## 8. KEY DESIGN DECISIONS

1. **Flag Calculation with Borderline Zones**: Rather than binary normal/abnormal classification, the system uses a 10% buffer zone around reference range boundaries. Values within 10% of the boundary are flagged as "borderline" rather than abnormal, reducing patient anxiety over clinically insignificant variations.

2. **Parameter-Specific Working Ranges**: Instead of relying solely on lab-provided reference ranges (which vary across labs), the system maintains a database of standardized clinical working ranges per parameter. This ensures consistent explanations regardless of which lab processed the report.

3. **Gender-Aware Thresholds**: Key parameters (hemoglobin, creatinine, HDL) use gender-specific thresholds. The system reads the patient's gender from their profile, not the report, to avoid mismatches when the lab form doesn't include gender.

4. **LLM with Structured Output, Not Free Text**: The LLM is prompted to output structured JSON with specific fields (overall_summary, parameter_explanations, etc.) rather than free-form text. This allows consistent rendering across channels and enables the highlighting system to color-code specific elements.

5. **Severity-Weighted Parameter Display**: Parameters are displayed sorted by deviation severity, not alphabetically. A hemoglobin of 7.0 g/dL (far from normal) appears before a hemoglobin of 12.5 g/dL (slightly low). This prioritizes clinically significant findings.

6. **Shared Channel with Audit Trail**: When a report is shared via WhatsApp/email, the share event is logged with a timestamp and channel. If the patient later asks about the report via a different channel, the system knows what was already communicated.

7. **Cache with Invalidation on New Reports**: Explanations are cached for 24 hours but invalidated immediately if a new report is uploaded for the same patient. The patient always sees the latest explanation, not a cached version of an outdated report.
