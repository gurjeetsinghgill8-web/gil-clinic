---
file_id: "0501"
module_name: "AI Triage"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0302_EMERGENCY.md", "0201_DOCTOR_MODULE.md", "0106_ICD_MODULE.md"]
related_files: ["0500_AI_RECEPTIONIST.md", "0506_AI_REPORT_EXPLAINER.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "ai", "triage", "symptoms", "severity", "icd10", "escalation"]
---

# GHOS — AI Triage

## 1. PURPOSE
AI-driven symptom assessment and severity classification system that accepts symptom input via text or voice, asks structured follow-up questions, assesses severity (Level 1-5), recommends appropriate department, maps symptoms to ICD-10 codes, and escalates emergencies to human doctors. This is a decision-support tool -- never a diagnostic tool.

```
┌──────────────────────────────────────────────────────────────────────┐
│                      TRIAGE FLOW DIAGRAM                             │
│                                                                       │
│  Patient Input (Text/Voice)                                           │
│       │                                                                │
│       ▼                                                                │
│  Emergency Keyword Check ←── Red Alert → Escalate to Emergency        │
│       │                    (chest pain, breathlessness, etc.)          │
│       ▼                                                                │
│  Symptom Extraction (NLP Entity Recognition)                           │
│       │                                                                │
│       ▼                                                                │
│  Structured Follow-up Questions (Adaptive)                             │
│   ├── Onset: When did it start?                                        │
│   ├── Duration: Continuous/Intermittent?                               │
│   ├── Severity: 1-10 scale?                                            │
│   ├── Location: Where exactly?                                         │
│   ├── Aggravating/Alleviating Factors?                                 │
│   └── Associated Symptoms?                                             │
│       │                                                                │
│       ▼                                                                │
│  Severity Classification (Level 1-5)                                   │
│       │                                                                │
│       ├── Level 1: Emergency (Immediate ER)                            │
│       ├── Level 2: Urgent (See doctor within 4 hours)                  │
│       ├── Level 3: Moderate (OPD within 24 hours)                      │
│       ├── Level 4: Mild (OPD within 72 hours)                          │
│       └── Level 5: Self-care (Monitor at home)                         │
│                                                                        │
│  Department Recommendation                                              │
│       │                                                                │
│       ▼                                                                │
│  ICD-10 Code Mapping                                                   │
│       │                                                                │
│       ▼                                                                │
│  Output Report + Disclaimers                                           │
│       │                                                                │
│       ▼                                                                │
│  Patient → Department Booking / Self-care Advice                       │
└──────────────────────────────────────────────────────────────────────┘
```

## 2. SYMPTOM INPUT & ENTITY EXTRACTION

### 2.1 Input Methods
| Input Method | Technology                  | Latency | Use Case                    |
|-------------|-----------------------------|---------|-----------------------------|
| Voice       | Deepgram/Whisper STT        | <2s     | Phone calls, hands-free     |
| Text        | Direct input                | <300ms  | Web chat, WhatsApp, portal  |
| Structured  | Multi-select UI forms       | Instant | Kiosk, mobile app           |

### 2.2 Entity Extraction Engine
```python
# symptom_extractor.py
from enum import Enum
from typing import Optional

class SymptomCategory(Enum):
    CARDIOVASCULAR = "cardiovascular"
    RESPIRATORY = "respiratory"
    GASTROINTESTINAL = "gastrointestinal"
    NEUROLOGICAL = "neurological"
    MUSCULOSKELETAL = "musculoskeletal"
    DERMATOLOGICAL = "dermatological"
    GENERAL = "general"
    ENT = "ent"
    OPHTHALMOLOGY = "ophthalmology"
    UROLOGICAL = "urological"
    GYNECOLOGICAL = "gynecological"
    PSYCHIATRIC = "psychiatric"
    ENDOCRINE = "endocrine"
    HEMATOLOGY = "hematology"


SYMPTOM_DATABASE = {
    "chest pain": {
        "category": SymptomCategory.CARDIOVASCULAR,
        "emergency_keywords": ["pressure", "tightness", "crushing", "radiating"],
        "icd10_prefix": "R07",
        "red_flags": ["shortness of breath", "sweating", "nausea", "dizziness"],
        "followup_questions": [
            "Is the pain sharp or dull?",
            "Does it radiate to your arm, jaw, or back?",
            "Does it worsen with exertion?",
            "Are you feeling nauseous or sweaty?"
        ],
        "urgency_score_base": 5
    },
    "headache": {
        "category": SymptomCategory.NEUROLOGICAL,
        "emergency_keywords": ["sudden", "worst", "thunderclap", "blurred vision"],
        "icd10_prefix": "R51",
        "red_flags": ["vision change", "neck stiffness", "confusion", "fever"],
        "followup_questions": [
            "When did the headache start?",
            "On a scale of 1-10, how severe is it?",
            "Is it on one side or both sides?",
            "Do you have sensitivity to light or sound?"
        ],
        "urgency_score_base": 2
    },
    "fever": {
        "category": SymptomCategory.GENERAL,
        "emergency_keywords": ["very high", "seizure", "unresponsive"],
        "icd10_prefix": "R50",
        "red_flags": ["confusion", "stiff neck", "rash", "difficulty breathing"],
        "followup_questions": [
            "What is the temperature?",
            "How long have you had the fever?",
            "Does it come and go, or is it continuous?",
            "Do you have any other symptoms like cough or body ache?"
        ],
        "urgency_score_base": 2
    },
    "abdominal pain": {
        "category": SymptomCategory.GASTROINTESTINAL,
        "emergency_keywords": ["severe", "sharp", "vomiting blood", "blood in stool"],
        "icd10_prefix": "R10",
        "red_flags": ["vomiting", "fever", "blood in stool", "distension"],
        "followup_questions": [
            "Where exactly is the pain? Upper or lower abdomen?",
            "Is it sharp, cramping, or dull?",
            "Does eating make it better or worse?",
            "Have you vomited or had diarrhea?"
        ],
        "urgency_score_base": 3
    }
}


def extract_symptoms(user_input: str, language: str = "en") -> list[dict]:
    """
    Extract symptoms from free-text input using NLP.
    Returns list of matched symptoms with confidence scores.
    """
    prompt = f"""
    Extract all medical symptoms mentioned in this text.
    For each symptom, provide:
    - symptom name (normalized to our database)
    - confidence (0-1)
    - duration if mentioned
    - severity if mentioned
    - body location if mentioned

    Text: {user_input}
    Language: {language}

    Output JSON list:
    [{{"symptom": "str", "confidence": 0.0, "duration": "str|null",
       "severity": "str|null", "location": "str|null"}}]
    """
    result = llm_call(prompt)
    return json.loads(result)
```

## 3. ADAPTIVE FOLLOW-UP QUESTION ENGINE

```python
# question_engine.py
class AdaptiveQuestionEngine:
    """
    Dynamically generates follow-up questions based on:
    - Identified symptoms
    - Already collected information
    - Patient demographics (age/gender adjusted)
    - Urgency score progression
    - Information entropy (asks questions that maximize diagnostic info)
    """

    def __init__(self, patient_context: dict | None = None):
        self.patient = patient_context or {}
        self.collected_data = {}
        self.question_history = []

    def next_question(self, symptoms: list[dict]) -> str | None:
        """
        Determine the next best question to ask.
        Returns None if sufficient information collected.
        """
        missing_info = self._identify_gaps(symptoms)
        if not missing_info:
            return None

        # Prioritize high-information-yield questions
        priorities = {
            "onset": 5 if "onset" not in self.collected_data else 0,
            "severity": 10 if "severity" not in self.collected_data else 0,
            "red_flags": 20 if not self._red_flags_checked(symptoms) else 0,
            "duration": 5,
            "location": 8,
            "associated": 6,
            "aggravating": 4,
            "medications": 7 if self.patient.get("age", 0) > 60 else 3,
            "pregnancy": 10 if self.patient.get("gender") == "female"
                            and self.patient.get("age", 0) < 50 else 0
        }

        best_gap = max(missing_info, key=lambda g: priorities.get(g, 1))
        return self._question_template(best_gap, symptoms)

    def _identify_gaps(self, symptoms: list[dict]) -> list[str]:
        """Identify information gaps for each symptom."""
        gaps = []
        for symptom in symptoms:
            sname = symptom["symptom"]
            needed = ["onset", "duration", "severity", "location",
                      "associated", "red_flags"]
            for field in needed:
                key = f"{sname}_{field}"
                if key not in self.collected_data:
                    gaps.append(field)
        return list(set(gaps))

    def _is_emergency(self, symptoms: list[dict]) -> tuple[bool, str]:
        """
        Check if any symptom combination constitutes an emergency.
        Returns (is_emergency, reason).
        """
        for symptom in symptoms:
            sname = symptom["symptom"]
            db_entry = SYMPTOM_DATABASE.get(sname)
            if not db_entry:
                continue

            user_text = " ".join([
                str(v) for v in self.collected_data.values()
            ]).lower()

            for kw in db_entry["emergency_keywords"]:
                if kw in user_text:
                    return True, f"{sname}: emergency keyword '{kw}' detected"

            severity = self.collected_data.get(f"{sname}_severity", 0)
            if isinstance(severity, (int, float)) and severity >= 8:
                return True, f"{sname}: severity level {severity}/10"

            red_flag_count = sum(
                1 for rf in db_entry["red_flags"] if rf in user_text
            )
            if red_flag_count >= 2:
                return True, f"{sname}: {red_flag_count} red flags present"

        return False, ""
```

## 4. SEVERITY CLASSIFICATION ALGORITHM

```python
# severity_classifier.py
class SeverityClassifier:
    """
    Classifies urgency into Levels 1-5 using:
    - Symptom base urgency score
    - Severity rating (1-10)
    - Red flag count
    - Duration (acute vs chronic)
    - Patient age/risk factors
    - Symptom combinations (synergistic severity)
    """

    LEVEL_LABELS = {
        1: {
            "name": "Emergency",
            "action": "Immediate emergency care required. Calling ambulance.",
            "response_time": "NOW",
            "color": "red",
            "routing": "emergency"
        },
        2: {
            "name": "Urgent",
            "action": "Visit clinic within 4 hours. Priority OPD.",
            "response_time": "<4 hours",
            "color": "orange",
            "routing": "urgent_care"
        },
        3: {
            "name": "Moderate",
            "action": "Book OPD appointment. See doctor within 24 hours.",
            "response_time": "<24 hours",
            "color": "yellow",
            "routing": "opd"
        },
        4: {
            "name": "Mild",
            "action": "Book OPD appointment. See doctor within 72 hours.",
            "response_time": "<72 hours",
            "color": "blue",
            "routing": "opd"
        },
        5: {
            "name": "Self-care",
            "action": "Self-care at home. Visit OPD if symptoms worsen.",
            "response_time": "Monitor",
            "color": "green",
            "routing": "self_care"
        }
    }

    def classify(self, symptoms: list[dict],
                 patient: dict | None = None) -> dict:
        """
        Full severity classification pipeline.
        """
        total_score = 0
        symptom_assessments = []

        for symptom in symptoms:
            sname = symptom["symptom"]
            db_entry = SYMPTOM_DATABASE.get(sname, {})
            base = db_entry.get("urgency_score_base", 1)
            severity_rating = symptom.get("severity", 5)

            if isinstance(severity_rating, str):
                severity_rating = self._parse_severity_text(severity_rating)

            score = base + (severity_rating * 0.5)

            red_flags = self._count_red_flags(sname, symptom)
            score += red_flags * 2

            if patient:
                age = patient.get("age", 30)
                if age > 65:
                    score += 2
                elif age < 5:
                    score += 2
                if patient.get("pregnant"):
                    score += 3

            symptom_assessments.append({
                "symptom": sname,
                "base_score": base,
                "severity_rating": severity_rating,
                "red_flags": red_flags,
                "adjusted_score": min(score, 15)
            })
            total_score += score

        avg_score = total_score / len(symptoms) if symptoms else 0

        if avg_score >= 12:
            level = 1
        elif avg_score >= 9:
            level = 2
        elif avg_score >= 6:
            level = 3
        elif avg_score >= 3:
            level = 4
        else:
            level = 5

        return {
            "level": level,
            "label": self.LEVEL_LABELS[level]["name"],
            "action": self.LEVEL_LABELS[level]["action"],
            "routing": self.LEVEL_LABELS[level]["routing"],
            "response_time": self.LEVEL_LABELS[level]["response_time"],
            "color": self.LEVEL_LABELS[level]["color"],
            "avg_score": round(avg_score, 2),
            "symptom_assessments": symptom_assessments,
            "timestamp": datetime.utcnow().isoformat(),
            "disclaimer_applied": True
        }
```

## 5. ICD-10 CODE MAPPING

```python
# icd10_mapper.py
class ICD10Mapper:
    """
    Maps symptoms and triage assessment to ICD-10-CM codes.
    Supports single symptoms, symptom combinations, and context-based coding.
    """

    ICD10_MAPPINGS = {
        "chest pain": {
            "R07.1": "Chest pain on breathing",
            "R07.2": "Precordial pain",
            "R07.3": "Other chest pain",
            "R07.4": "Chest pain, unspecified",
            "I20.0": "Unstable angina (if radiating + exertion)"
        },
        "fever": {
            "R50.9": "Fever, unspecified",
            "R50.81": "Fever presenting with conditions classified elsewhere",
            "A00-B99": "If infectious cause suspected"
        },
        "headache": {
            "R51": "Headache",
            "G43.9": "Migraine, unspecified (if unilateral + nausea + photophobia)",
            "G44.2": "Tension-type headache"
        },
        "abdominal pain": {
            "R10.0": "Acute abdomen",
            "R10.1": "Pain localized to upper abdomen",
            "R10.2": "Pelvic and perineal pain",
            "R10.3": "Pain localized to other parts of lower abdomen",
            "R10.4": "Other and unspecified abdominal pain"
        },
        "shortness of breath": {
            "R06.0": "Dyspnea",
            "R06.2": "Wheezing",
            "J45.9": "Asthma (if + wheezing + triggers)"
        }
    }

    def map_symptoms(self, symptoms: list[dict],
                     context: dict | None = None) -> list[dict]:
        """
        Map symptom list to best ICD-10 codes.
        Returns ranked list with confidence scores.
        """
        prompt = f"""
        Given the following symptoms and patient context,
        suggest the most appropriate ICD-10-CM codes.
        Return up to 3 codes ranked by relevance.

        Symptoms: {json.dumps(symptoms)}
        Context: {json.dumps(context or {})}

        Output JSON:
        [{{"code": "str", "description": "str",
           "confidence": 0.0, "is_suspected": false}}]
        """
        result = llm_call(prompt)
        return json.loads(result)


    def generate_triage_report(self, assessment: dict,
                               icd_codes: list[dict],
                               language: str = "en") -> dict:
        """
        Generate final triage report with disclaimers.
        """
        disclaimer = {
            "en": "This is an AI-generated triage assessment and "
                  "does NOT constitute a medical diagnosis. "
                  "All recommendations must be reviewed by a "
                  "qualified healthcare professional. "
                  "In case of emergency, call 108 (India) or your "
                  "local emergency services immediately.",
            "hi": "यह AI-जनित ट्राइएज आकलन है और यह चिकित्सा निदान नहीं है। "
                  "सभी सिफारिशों की समीक्षा किसी योग्य स्वास्थ्य पेशेवर द्वारा "
                  "की जानी चाहिए। आपात स्थिति में, तुरंत 108 पर कॉल करें।"
        }

        return {
            "assessment_id": generate_uuid(),
            "timestamp": datetime.utcnow().isoformat(),
            "patient_summary": assessment,
            "icd10_codes": icd_codes,
            "department_recommendation": self._recommend_department(
                assessment["level"], assessment["symptom_assessments"]
            ),
            "disclaimer": disclaimer.get(language, disclaimer["en"]),
            "disclaimer_language": language,
            "patient_instructions": self._patient_instructions(
                assessment["level"], language
            ),
            "requires_human_review": assessment["level"] <= 3
        }
```

## 6. DISCLAIMER SYSTEM

```yaml
# disclaimers.yaml
disclaimers:
  general:
    text:
      en: >
        This AI triage assessment is a SUGGESTION only and does not
        replace professional medical judgment. Always consult a
        qualified healthcare provider for diagnosis and treatment.
      hi: >
        यह AI ट्राइएज मूल्यांकन केवल एक सुझाव है और पेशेवर चिकित्सा
        निर्णय को प्रतिस्थापित नहीं करता है। निदान और उपचार के लिए
        हमेशा एक योग्य स्वास्थ्य सेवा प्रदाता से परामर्श लें।
    display_on: ["assessment_view", "sms", "whatsapp", "email"]
    must_acknowledge: true

  emergency:
    text:
      en: >
        IF THIS IS A MEDICAL EMERGENCY, CALL 108 IMMEDIATELY.
        Do not wait for AI assessment. Chest pain, difficulty breathing,
        severe bleeding, or unconsciousness require immediate emergency care.
      hi: >
        यदि यह कोई चिकित्सा आपात स्थिति है, तो तुरंत 108 पर कॉल करें।
        AI मूल्यांकन के लिए प्रतीक्षा न करें। सीने में दर्द, सांस लेने
        में कठिनाई, गंभीर रक्तस्राव या बेहोशी के लिए तत्काल आपातकालीन देखभाल की आवश्यकता है।
    display_on: ["all"]
    must_acknowledge: true

  liability:
    text:
      en: >
        The AI triage system (GHOS v2.0) is a clinical decision support
        tool. The clinic and developers assume no liability for outcomes
        resulting from use of this tool. The treating physician bears
        final responsibility.
      hi: >
        AI ट्राइएज सिस्टम (GHOS v2.0) एक क्लिनिकल निर्णय सहायता उपकरण
        है। इस उपकरण के उपयोग से होने वाले परिणामों के लिए क्लिनिक और
        डेवलपर्स कोई देयता नहीं लेते हैं। उपचार करने वाले चिकित्सक की
        अंतिम जिम्मेदारी है।
    display_on: ["assessment_view"]
    must_acknowledge: false
```

## 7. ESCALATION TO HUMAN

```python
# escalation.py
class EscalationManager:
    """
    Manages escalation of triage assessments to human doctors.
    Triggers:
    - Emergency level (1) auto-escalated
    - Patient requests human
    - AI confidence below threshold
    - Multiple contradictory symptoms
    - Pediatric or geriatric with moderate+ severity
    - Pregnancy with any symptom
    """

    def __init__(self, notification_engine):
        self.notifier = notification_engine

    def escalate(self, assessment: dict,
                 reason: str,
                 patient_id: int) -> dict:
        """
        Escalate assessment to appropriate doctor/department.
        """
        department = assessment.get("department_recommendation", "general")
        doctors = self.find_available_doctors(department)
        if not doctors:
            doctors = self.find_oncall_doctor()

        escalation = {
            "escalation_id": generate_uuid(),
            "assessment_id": assessment["assessment_id"],
            "patient_id": patient_id,
            "reason": reason,
            "target_doctor_id": doctors[0]["id"],
            "target_department": department,
            "priority": "critical" if assessment["level"] == 1 else "high",
            "created_at": datetime.utcnow().isoformat()
        }

        self.notifier.send(
            channel="push",
            recipient=doctors[0]["id"],
            template="triage_escalation",
            data={
                "patient_summary": assessment["patient_summary"],
                "reason": reason,
                "assessment_link": f"/triage/{escalation['escalation_id']}"
            }
        )

        if assessment["level"] == 1:
            self.notifier.send(channel="sms",
                               recipient=doctors[0]["phone"],
                               template="emergency_alert",
                               data={"patient": patient_id})

        save_to_db("INSERT INTO triage_escalations ...")
        return escalation
```

## 8. SQL DATA MODEL

```sql
-- ai_triage_schema.sql
CREATE TABLE triage_assessments (
    id                  BIGSERIAL PRIMARY KEY,
    patient_id          BIGINT REFERENCES patients(id),
    session_id          VARCHAR(64) NOT NULL,
    input_method        VARCHAR(16) CHECK (input_method IN
                           ('voice', 'text', 'structured')),
    raw_input_text      TEXT,
    extracted_symptoms  JSONB,
    severity_level      INT CHECK (severity_level BETWEEN 1 AND 5),
    avg_severity_score  DECIMAL(5,2),
    department_recommendation VARCHAR(32),
    icd10_codes         JSONB,
    escalation_status   VARCHAR(16) DEFAULT 'none'
                        CHECK (escalation_status IN
                          ('none', 'pending', 'accepted', 'rejected')),
    escalated_to_doctor_id BIGINT REFERENCES doctors(id),
    disclaimer_acknowledged BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMP DEFAULT NOW(),
    completed_at        TIMESTAMP,
    INDEX(patient_id),
    INDEX(severity_level),
    INDEX(created_at)
);

CREATE TABLE symptom_questions (
    id              BIGSERIAL PRIMARY KEY,
    assessment_id   BIGINT REFERENCES triage_assessments(id),
    question_text   TEXT NOT NULL,
    patient_answer  TEXT,
    question_type   VARCHAR(32),
    sequence_num    INT NOT NULL,
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(assessment_id)
);

CREATE TABLE triage_escalations (
    id              BIGSERIAL PRIMARY KEY,
    assessment_id   BIGINT REFERENCES triage_assessments(id),
    doctor_id       BIGINT REFERENCES doctors(id),
    reason          TEXT NOT NULL,
    status          VARCHAR(16) DEFAULT 'pending'
                    CHECK (status IN
                      ('pending', 'viewed', 'actioned', 'closed')),
    doctor_notes    TEXT,
    resolution      VARCHAR(64),
    created_at      TIMESTAMP DEFAULT NOW(),
    resolved_at     TIMESTAMP,
    INDEX(doctor_id, status)
);
```

## 9. KEY DESIGN DECISIONS

1. **Adaptive Question Ordering by Information Gain**: Questions are ordered by expected information gain, not hardcoded. Red flag checks are always asked first, then severity, then demographic-adjusted questions (e.g., pregnancy check for women of childbearing age).

2. **Synergistic Severity Scoring**: Symptom combinations score higher than individual symptoms (e.g., chest pain + shortness of breath is weighted higher than either alone). This better captures real clinical urgency.

3. **ICD-10 Mapping via Prompt + Lookup**: A two-stage approach: first a lookup table for common mappings, then LLM-assisted coding for complex combinations. The lookup table provides speed for common cases; the LLM handles edge cases.

4. **Mandatory Disclaimer Acknowledgment**: All triage outputs are watermarked with disclaimers in the patient's language. For Level 1-2 assessments, the patient must explicitly acknowledge the disclaimer before receiving recommendations.

5. **Red Flag Unlock Protocol**: If any red flag keyword is detected, the system auto-escalates to Level 1 regardless of other scoring. This override cannot be bypassed by the scoring algorithm -- designed to prevent AI from under-triaging critical cases.

6. **Time-Boxed Assessment Sessions**: Each triage session is time-boxed to 10 minutes maximum. If the patient doesn't complete within that window, the collected data is saved and a callback is scheduled, preventing incomplete assessments from being lost.

7. **Confidence Floor**: If the AI's confidence in any assessment is below 0.6, the case is automatically routed for human review. This prevents low-confidence assessments from reaching the patient as definitive recommendations.
