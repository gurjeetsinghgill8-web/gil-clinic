---
file_id: "0505"
module_name: "AI Prescription Assistant"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0201_DOCTOR_MODULE.md", "0102_PHARMACY_MODULE.md", "0106_ICD_MODULE.md"]
related_files: ["0501_AI_TRIAGE.md", "0504_AI_DIETICIAN.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "ai", "prescription", "medicine", "drug-interaction", "dosage", "allergy"]
---

# GHOS — AI Prescription Assistant

## 1. PURPOSE
AI-assisted prescription writing tool that provides medicine autocomplete, diagnosis-based dosage suggestions, drug interaction checking, allergy alerting, renal/hepatic dose adjustment recommendations, and generic substitution suggestions. The AI suggests -- the doctor decides. No automatic prescription generation.

```
┌─────────────────────────────────────────────────────────────────────┐
│                  PRESCRIPTION ASSISTANT FLOW                         │
│                                                                      │
│  Doctor Starts Prescription                                          │
│       │                                                               │
│       ▼                                                               │
│  Patient Context Loaded                                               │
│   ├── Patient Demographics (Age, Weight, Gender)                     │
│   ├── Active Allergies                                               │
│   ├── Current Medications + Past Prescriptions                       │
│   ├── Lab Results (Creatinine, ALT/AST, eGFR)                        │
│   ├── Medical History (CKD, Liver Disease, Pregnancy)                │
│   └── Diagnosis / ICD-10 Codes                                       │
│       │                                                               │
│       ▼                                                               │
│  Medicine Search & Select                                             │
│   ├── Autocomplete from Clinic Formulary                             │
│   ├── Brand ↔ Generic Name Mapping                                  │
│   └── Recently Prescribed Quick Pick                                │
│       │                                                               │
│       ▼                                                               │
│  Smart Suggestions                                                    │
│   ├── Dosage by Diagnosis + Weight                                    │
│   ├── Frequency + Duration Suggested                                 │
│   ├── Route of Administration                                        │
│   ├── Strength Options                                                │
│   └── Renal/Hepatic Adjustment                                       │
│       │                                                               │
│       ▼                                                               │
│  Safety Checks                                                        │
│   ├── Drug-Drug Interaction (DDI) Check ──► Stop/Flag                │
│   ├── Drug-Allergy Check        ──► Alert                            │
│   ├── Drug-Condition Check      ──► Caution                           │
│   ├── Dose Range Check          ──► Max dose advisory                 │
│   ├── Duplicate Therapy Check   ──► Warn                             │
│   └── Pregnancy/Lactation Check ──► Category alert                   │
│       │                                                               │
│       ▼                                                               │
│  Generic Substitution Suggestion                                      │
│       │                                                               │
│       ▼                                                               │
│  Doctor Reviews → Adjusts → Finalizes                                 │
│       │                                                               │
│       ▼                                                               │
│  Prescription Digital Signature + Format                              │
│       │                                                               │
│       ▼                                                               │
│  Push to Pharmacy + Patient App                                       │
└─────────────────────────────────────────────────────────────────────┘
```

## 2. MEDICINE DATABASE & AUTOCOMPLETE

```python
# medicine_search.py
class MedicineSearch:
    """
    Medicine search and autocomplete system.
    Uses clinic's formulary as primary data source with
    fallback to national drug database for extended searches.
    Supports brand name, generic name, and therapeutic class search.
    """

    def __init__(self):
        self.formulary = self._load_formulary()
        self.search_index = self._build_search_index()

    def _load_formulary(self) -> dict:
        """Load clinic's approved formulary."""
        return {
            "antihypertensives": [
                {"generic": "amlodipine", "brands": ["Amlodac", "Amlopin",
                  "Amlong"], "strengths": ["2.5mg", "5mg", "10mg"]},
                {"generic": "telmisartan", "brands": ["Telma", "Telmikind",
                  "Telsartan"], "strengths": ["20mg", "40mg", "80mg"]},
                {"generic": "metoprolol", "brands": ["Metolar", "Betaloc",
                  "Metocard"], "strengths": ["25mg", "50mg", "100mg"]},
            ],
            "antidiabetics": [
                {"generic": "metformin", "brands": ["Glyciphage", "Bigomet",
                  "Metlong"], "strengths": ["250mg", "500mg", "850mg", "1000mg"]},
                {"generic": "glimepiride", "brands": ["Amaryl", "Glimestar",
                  "Glimisave"], "strengths": ["1mg", "2mg", "3mg", "4mg"]},
                {"generic": "dapagliflozin", "brands": ["Forxiga",
                  "Dapagliflozin"], "strengths": ["5mg", "10mg"]},
            ],
            "antibiotics": [
                {"generic": "amoxicillin", "brands": ["Amoxil", "Mox",
                  "Novamox"], "strengths": ["125mg", "250mg", "500mg"]},
                {"generic": "azithromycin", "brands": ["Azithral", "Zithrox",
                  "Azee"], "strengths": ["250mg", "500mg"]},
            ],
            "nsaids": [
                {"generic": "ibuprofen", "brands": ["Brufen", "Ibugesic",
                  "Ibucalm"], "strengths": ["200mg", "400mg", "600mg"]},
                {"generic": "aceclofenac", "brands": ["Aceclowin",
                  "Dolokind", "Zerodol"], "strengths": ["100mg"]},
            ]
        }

    def autocomplete(self, query: str, limit: int = 10) -> list[dict]:
        """
        Full-text autocomplete search across generic names, brand names,
        and therapeutic classes. Returns ranked results.
        """
        query = query.lower().strip()
        results = []

        for category, medicines in self.formulary.items():
            for med in medicines:
                score = 0
                if query in med["generic"].lower():
                    score = max(score, len(query) / len(med["generic"]))
                for brand in med["brands"]:
                    if query in brand.lower():
                        score = max(score, len(query) / len(brand))
                if query in category.lower():
                    score = max(score, 0.5)

                if score > 0:
                    results.append({
                        "generic": med["generic"],
                        "brands": med["brands"],
                        "strengths": med["strengths"],
                        "category": category,
                        "score": round(score, 3)
                    })

        results.sort(key=lambda x: x["score"], reverse=True)
        return results[:limit]
```

## 3. DOSAGE SUGGESTION ENGINE

```python
# dosage_suggester.py
class DosageSuggester:
    """
    Suggests appropriate dosage, frequency, and duration based on:
    - Diagnosis (ICD-10 code mapped)
    - Patient weight (for weight-based dosing)
    - Patient age (pediatric/geriatric adjustments)
    - Renal function (eGFR-based adjustment)
    - Hepatic function (Child-Pugh based adjustment)
    - Standard clinical guidelines
    """

    DOSAGE_GUIDELINES = {
        "amlodipine": {
            "indications": {
                "hypertension": {
                    "adult": {"min_mg": 2.5, "max_mg": 10,
                              "frequency": "once_daily",
                              "typical_start": 5,
                              "titration": "increase by 2.5mg every 2 weeks"},
                    "geriatric": {"min_mg": 2.5, "max_mg": 5,
                                  "frequency": "once_daily",
                                  "typical_start": 2.5}
                },
                "angina": {
                    "adult": {"min_mg": 5, "max_mg": 10,
                              "frequency": "once_daily",
                              "typical_start": 5}
                }
            },
            "renal_adjustment": {
                "egfr_30_60": {"max_mg": 5, "caution": true},
                "egfr_lt_30": {"max_mg": 2.5, "caution": true, "avoid": true}
            },
            "max_daily_mg": 10,
            "pregnancy_category": "C",
            "monitoring": ["BP weekly", "edema check"]
        },
        "metformin": {
            "indications": {
                "diabetes_type_2": {
                    "adult": {"min_mg": 500, "max_mg": 2550,
                              "frequency": "twice_daily",
                              "typical_start": 500,
                              "titration": "increase by 500mg every week"},
                    "geriatric": {"min_mg": 500, "max_mg": 2000,
                                  "frequency": "twice_daily",
                                  "typical_start": 500}
                },
                "pcos": {
                    "adult": {"min_mg": 500, "max_mg": 1500,
                              "frequency": "twice_daily",
                              "typical_start": 500}
                }
            },
            "renal_adjustment": {
                "egfr_45_60": {"max_mg": 1500, "caution": true},
                "egfr_30_45": {"max_mg": 1000, "caution": true},
                "egfr_lt_30": {"avoid": true, "reason": "Lactic acidosis risk"}
            },
            "max_daily_mg": 2550,
            "pregnancy_category": "B",
            "monitoring": ["HbA1c q3mo", "eGFR q6mo", "B12 annually"]
        },
        "amoxicillin": {
            "indications": {
                "respiratory_infection": {
                    "adult": {"min_mg": 250, "max_mg": 500,
                              "frequency": "three_times_daily",
                              "duration_days": 7,
                              "typical_start": 500},
                    "pediatric": {"min_mg_per_kg": 20, "max_mg_per_kg": 40,
                                  "frequency": "three_times_daily",
                                  "duration_days": 7,
                                  "max_daily_mg": 2000}
                }
            }
        }
    }

    def suggest_dosage(self, medicine_name: str,
                       diagnosis: str,
                       patient: dict) -> dict:
        """
        Suggest dosage for a medicine based on diagnosis and patient factors.
        Returns structured suggestion with rationale.
        """
        guidelines = self.DOSAGE_GUIDELINES.get(medicine_name)
        if not guidelines:
            return {"suggestion": None,
                    "reason": "No guidelines available"}

        indication = guidelines["indications"].get(diagnosis)
        if not indication:
            return {"suggestion": None,
                    "reason": f"No dosage data for {diagnosis}"}

        age = patient.get("age", 30)
        weight = patient.get("weight_kg", 70)
        egfr = patient.get("egfr", 90)

        # Determine age group
        if age < 18:
            age_group = "pediatric"
        elif age > 65:
            age_group = "geriatric"
        else:
            age_group = "adult"

        # Get base dosage
        if age_group == "pediatric" and "pediatric" in indication:
            base = indication["pediatric"]
            per_kg = base.get("min_mg_per_kg")
            if per_kg:
                dose = round(weight * per_kg)
            else:
                dose = base.get("typical_start", base.get("min_mg"))
        else:
            base = indication.get(age_group, indication["adult"])
            dose = base.get("typical_start", base.get("min_mg"))

        # Apply renal adjustment
        max_dose = base.get("max_mg", guidelines.get("max_daily_mg"))
        renal_adj = guidelines.get("renal_adjustment", {})
        for threshold, adj in sorted(renal_adj.items(), reverse=True):
            _, egfr_val = threshold.split("_")
            lo_val = int(egfr_val.split("_")[0]) if "_" in egfr_val else 0
            hi_val = int(egfr_val.split("_")[-1]) if "_" in egfr_val else int(egfr_val)
            if lo_val <= egfr <= hi_val:
                if adj.get("avoid"):
                    return {"suggestion": None, "reason": adj["reason"],
                            "severity": "contraindication"}
                dose = min(dose, adj.get("max_mg", dose))
                max_dose = adj.get("max_mg", max_dose)
                break

        return {
            "medicine": medicine_name,
            "suggested_dose_mg": dose,
            "max_dose_mg": max_dose,
            "frequency": base.get("frequency"),
            "duration_days": base.get("duration_days"),
            "route": base.get("route", "oral"),
            "pregnancy_category": guidelines.get("pregnancy_category"),
            "monitoring": guidelines.get("monitoring", []),
            "titration": base.get("titration"),
            "rationale": f"Started at {dose}mg based on {age_group} dosing, "
                         f"adjusted for eGFR {egfr}",
            "age_group": age_group
        }
```

## 4. DRUG INTERACTION CHECKER

```python
# interaction_checker.py
class DrugInteractionChecker:
    """
    Checks for drug-drug, drug-allergy, and drug-condition interactions.
    Uses a structured interaction database with severity classification.
    """

    SEVERITY_LEVELS = {
        "contraindicated": {"level": 5, "action": "DO NOT PRESCRIBE",
                            "color": "red"},
        "severe": {"level": 4, "action": "Avoid combination. Monitor closely.",
                   "color": "red"},
        "moderate": {"level": 3, "action": "Use with caution. Monitor.",
                     "color": "orange"},
        "minor": {"level": 2, "action": "Limited clinical significance.",
                  "color": "yellow"},
        "none": {"level": 1, "action": "No interaction expected.",
                 "color": "green"}
    }

    INTERACTION_DB = {
        "amoxicillin_metformin": {
            "severity": "minor",
            "mechanism": "No significant interaction",
            "management": "No action needed"
        },
        "amlodipine_metformin": {
            "severity": "none",
            "mechanism": "No known interaction",
            "management": ""
        },
        "aspirin_metformin": {
            "severity": "moderate",
            "mechanism": "May increase metformin levels",
            "management": "Monitor blood glucose more frequently"
        },
        "furosemide_metformin": {
            "severity": "moderate",
            "mechanism": "Possible interaction",
            "management": "Monitor renal function"
        },
        "warfarin_amoxicillin": {
            "severity": "severe",
            "mechanism": "Can increase INR",
            "management": "Monitor INR more frequently"
        },
        "lisinopril_metformin": {
            "severity": "none",
            "mechanism": "No significant interaction",
            "management": ""
        },
        "clopidogrel_omeprazole": {
            "severity": "moderate",
            "mechanism": "Reduced clopidogrel efficacy",
            "management": "Consider pantoprazole instead"
        }
    }

    def check_drug_drug(self, new_medicine: str,
                        current_medicines: list[str]) -> list[dict]:
        """Check interactions between new medicine and current medications."""
        interactions = []
        for current in current_medicines:
            key = "_".join(sorted([new_medicine, current]))
            result = self.INTERACTION_DB.get(key)
            if result and result["severity"] != "none":
                interactions.append({
                    "drug_a": new_medicine,
                    "drug_b": current,
                    "severity": result["severity"],
                    "level": self.SEVERITY_LEVELS[result["severity"]]["level"],
                    "action": self.SEVERITY_LEVELS[result["severity"]]["action"],
                    "mechanism": result["mechanism"],
                    "management": result["management"]
                })
        return sorted(interactions, key=lambda x: x["level"], reverse=True)

    def check_allergies(self, medicine_name: str,
                        patient_allergies: list[str]) -> list[dict]:
        """Check if medicine is contraindicated due to patient allergies."""
        allergy_warnings = []
        drug_class_allergens = {
            "penicillin": ["amoxicillin", "ampicillin", "piperacillin"],
            "cephalosporin": ["cefuroxime", "ceftriaxone", "cefixime"],
            "sulfa": ["sulfamethoxazole", "furosemide",
                      "glimepiride", "celecoxib"],
            "nsaid": ["ibuprofen", "diclofenac", "naproxen", "aceclofenac"],
            "aspirin": ["aspirin"]
        }

        for allergy in patient_allergies:
            allergy_lower = allergy.lower()
            for drug_class, drugs in drug_class_allergens.items():
                if (allergy_lower == drug_class or
                    allergy_lower in drug_class or
                    allergy_lower in drugs):
                    if medicine_name in drugs:
                        allergy_warnings.append({
                            "allergen": allergy,
                            "medicine": medicine_name,
                            "drug_class": drug_class,
                            "severity": "contraindicated" if drug_class
                                        in ["penicillin", "sulfa"]
                                        else "severe",
                            "action": "Avoid. Cross-reactivity possible."
                        })
        return allergy_warnings
```

## 5. GENERIC SUBSTITUTION SUGGESTOR

```python
# generic_substitution.py
class GenericSubstitutor:
    """
    Suggests generic alternatives for prescribed brand-name drugs.
    Helps reduce patient costs while maintaining therapeutic equivalence.
    """

    def suggest_generic(self, brand_name: str) -> dict | None:
        """Find generic alternative for a brand name medicine."""
        for category, medicines in MEDICINE_DATABASE.items():
            for med in medicines:
                if brand_name.lower() in [b.lower() for b in med["brands"]]:
                    return {
                        "brand": brand_name,
                        "generic": med["generic"],
                        "brands_available": med["brands"],
                        "cost_savings_estimate": "20-50%",
                        "bioequivalent": True,
                        "manufacturers": ["Cipla", "Sun Pharma",
                                          "Dr. Reddy's", "Torrent"]
                    }
        return None
```

## 6. SQL DATA MODEL

```sql
-- prescription_assistant_schema.sql
CREATE TABLE prescription_drafts (
    id              BIGSERIAL PRIMARY KEY,
    doctor_id       BIGINT NOT NULL REFERENCES doctors(id),
    patient_id      BIGINT NOT NULL REFERENCES patients(id),
    visit_id        BIGINT REFERENCES appointments(id),
    status          VARCHAR(16) DEFAULT 'draft'
                    CHECK (status IN
                      ('draft', 'completed', 'cancelled')),
    diagnosis       TEXT,
    icd10_codes     JSONB,
    clinical_notes  TEXT,
    ai_suggestions  JSONB,
    created_at      TIMESTAMP DEFAULT NOW(),
    completed_at    TIMESTAMP,
    INDEX(doctor_id, status),
    INDEX(patient_id)
);

CREATE TABLE prescription_items (
    id                  BIGSERIAL PRIMARY KEY,
    prescription_id     BIGINT REFERENCES prescription_drafts(id),
    medicine_generic    VARCHAR(128) NOT NULL,
    medicine_brand      VARCHAR(128),
    strength_mg         DECIMAL(10,2) NOT NULL,
    dosage_form         VARCHAR(32) DEFAULT 'tablet',
    frequency           VARCHAR(32) NOT NULL,
    duration_days       INT,
    route               VARCHAR(16) DEFAULT 'oral',
    quantity            INT,
    instructions        TEXT,
    ai_suggested_dose   JSONB,
    interaction_flags   JSONB,
    is_generic_substitute BOOLEAN DEFAULT FALSE,
    doctor_override     BOOLEAN DEFAULT FALSE,
    created_at          TIMESTAMP DEFAULT NOW(),
    INDEX(prescription_id)
);

CREATE TABLE drug_interaction_log (
    id              BIGSERIAL PRIMARY KEY,
    prescription_id BIGINT REFERENCES prescription_drafts(id),
    drug_a          VARCHAR(128) NOT NULL,
    drug_b          VARCHAR(128) NOT NULL,
    severity        VARCHAR(32) NOT NULL,
    mechanism       TEXT,
    management      TEXT,
    doctor_action   VARCHAR(64),
    created_at      TIMESTAMP DEFAULT NOW()
);
```

## 7. KEY DESIGN DECISIONS

1. **Local Formulary First, National DB Fallback**: The search index is built from the clinic's own formulary first, ensuring only approved medicines appear. If no match is found, it falls back to India's national drug database. This prevents doctors from prescribing non-formulary drugs.

2. **Weight-Based Pediatric Dosing with Safe Caps**: For pediatric patients, dosage is calculated per-kg but capped at the maximum adult dose. The system warns if the calculated dose exceeds standard limits or if liquid formulation is needed (checked against available stock).

3. **Renal/Hepatic Adjustment via Stage-Based Logic**: Adjustments are applied using discrete stage thresholds (e.g., eGFR 30-60, 15-30, <15) rather than continuous formulas, matching how clinical guidelines present adjustments. The most restrictive applicable stage wins.

4. **Structured Interaction DB over LLM**: Drug interaction checking uses a structured database rather than LLM inference because interactions are well-studied and deterministic. LLM hallucination on drug interactions could be dangerous. The DB is updated quarterly from national formularies.

5. **Doctor Override with Audit Trail**: If a doctor prescribes despite a contraindication alert, the override is logged with a reason. This creates an audit trail for medico-legal purposes and allows the clinic to review override patterns for quality improvement.

6. **Brand-to-Generic Mapping with Cost Awareness**: The substitution engine shows cost savings estimates based on real pharmacy pricing data. This encourages generic prescribing while giving the doctor full control to prescribe brands if clinically indicated.

7. **Async Interaction Checking**: Drug interaction checks run asynchronously in the background as the doctor types the prescription. Results appear inline without blocking the typing flow. Severe/contraindicated interactions trigger an immediate modal alert that must be acknowledged before proceeding.
