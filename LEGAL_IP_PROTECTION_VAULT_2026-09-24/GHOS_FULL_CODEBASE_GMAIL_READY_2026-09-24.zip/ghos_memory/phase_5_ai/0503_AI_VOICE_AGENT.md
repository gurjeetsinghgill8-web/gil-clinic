---
file_id: "0503"
module_name: "AI Voice Agent"
version: "2.0"
status: "Approved"
phase: "Phase 5 — AI"
dependencies: ["0104_COMMUNICATION_ENGINE.md", "0107_TWILIO_MODULE.md"]
related_files: ["0500_AI_RECEPTIONIST.md", "0502_AI_FOLLOWUP.md", "0501_AI_TRIAGE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "ai", "voice", "agent", "stt", "tts", "sentiment", "transcription"]
---

# GHOS — AI Voice Agent

## 1. PURPOSE
Multi-purpose, configurable AI voice agent that serves as the core conversational engine across all voice-enabled GHOS modules (receptionist, follow-up, survey, triage). Provides configurable conversation flows, custom prompts, real-time transcription with speaker diarization, sentiment analysis, interruption handling, and seamless human handoff.

```
┌──────────────────────────────────────────────────────────────────────┐
│                      VOICE AGENT ARCHITECTURE                         │
│                                                                       │
│  ┌─────────────┐    ┌──────────────┐    ┌──────────────────┐         │
│  │  Telephony   │    │  WebSocket   │    │   Mobile SDK     │         │
│  │  (Twilio/    │───▶│  (Browser)   │───▶│   (Android/iOS)  │         │
│  │   Vonage)    │    │              │    │                  │         │
│  └──────┬───────┘    └──────┬───────┘    └────────┬─────────┘         │
│         │                  │                      │                   │
│         └──────────────────┼──────────────────────┘                   │
│                            │                                           │
│                            ▼                                           │
│              ┌─────────────────────────────┐                          │
│              │    Audio Stream Manager      │                          │
│              │  (WebRTC / SIP / PSTN)       │                          │
│              └──────────┬──────────────────┘                          │
│                         │                                              │
│              ┌──────────▼──────────┐                                  │
│              │   STT Engine        │  ┌──────────────┐                │
│              │  (Deepgram/Whisper) │──│  Language     │                │
│              │  + Speaker Diar.    │  │  Detector     │                │
│              └──────────┬──────────┘  └──────┬───────┘                │
│                         │                     │                       │
│                         ▼                     ▼                       │
│              ┌─────────────────────────────────────┐                  │
│              │      Conversation Manager            │                  │
│              │  ┌───────────────────────────────┐  │                  │
│              │  │  Intent Classifier (LLM)      │  │                  │
│              │  │  Context Tracker              │  │                  │
│              │  │  State Machine                │  │                  │
│              │  │  Interruption Handler         │  │                  │
│              │  │  Sentiment Analyzer           │  │                  │
│              │  └───────────────────────────────┘  │                  │
│              └──────────┬──────────────────────────┘                  │
│                         │                                              │
│              ┌──────────▼──────────┐                                  │
│              │   Action Executor    │────▶ Clinic APIs / DB            │
│              └──────────┬──────────┘                                  │
│                         │                                              │
│              ┌──────────▼──────────┐                                  │
│              │   TTS Engine         │                                  │
│              │  (ElevenLabs/Polly)  │──▶ Audio Output                  │
│              └─────────────────────┘                                  │
│                                                                       │
└──────────────────────────────────────────────────────────────────────┘
```

## 2. CORE COMPONENTS

### 2.1 Audio Stream Manager
```python
# audio_stream.py
class AudioStreamManager:
    """
    Manages bidirectional audio streams between telephony/WebSocket clients
    and the ASR/TTS pipeline. Supports:
    - WebRTC for browser clients
    - SIP for VoIP integrations
    - PSTN via Twilio/Vonage media streams
    - Multiplexed audio for conference calls
    """

    CODEC_SUPPORT = ["pcmu", "pcma", "opus", "g722", "linear16"]
    SAMPLE_RATE = 16000  # Hz
    BUFFER_SIZE_MS = 100  # 100ms chunks for streaming

    def __init__(self):
        self.active_streams: dict[str, AudioStream] = {}
        self.stream_buffer: dict[str, deque] = {}

    def create_stream(self, session_id: str,
                      codec: str = "pcmu",
                      direction: str = "duplex") -> AudioStream:
        """
        Create an audio stream for a session.
        Returns a stream object that can push/pull audio chunks.
        """
        stream = AudioStream(
            session_id=session_id,
            codec=codec,
            sample_rate=self.SAMPLE_RATE,
            direction=direction,
            on_audio_received=self._on_audio_chunk,
            on_stream_closed=self._on_stream_closed
        )
        self.active_streams[session_id] = stream
        return stream

    def _on_audio_chunk(self, session_id: str,
                        chunk: bytes,
                        timestamp: int):
        """Callback when audio chunk arrives. Forward to STT engine."""
        stream = self.active_streams.get(session_id)
        if not stream:
            return
        # Push chunk to STT processing pipeline
        stt_engine.process_audio_chunk(session_id, chunk, timestamp)
```

### 2.2 STT Engine with Speaker Diarization
```python
# stt_engine.py
class STTEngine:
    """
    Speech-to-Text engine with:
    - Streaming real-time transcription
    - Speaker diarization (who said what)
    - Language auto-detection (Hindi/English/Hinglish)
    - Confidence scoring per word
    - Custom medical vocabulary boosting
    - VAD (Voice Activity Detection) for silence trimming
    """

    def __init__(self, provider: str = "deepgram",
                 model: str = "nova-2",
                 language: str = "hi"):
        self.provider = provider
        self.model = model
        self.language = language
        self.active_sessions: dict[str, STTSession] = {}
        self.MEDICAL_BOOST_WORDS = [
            "paracetamol", "amoxicillin", "hypertension", "diabetes",
            "cholesterol", "ECG", "MRI", "CT scan", "ultrasound",
            "cardiology", "orthopedic", "pediatrics", "gynecology",
            "नमस्ते", "दवा", "बुखार", "दर्द", "सर्दी", "खांसी"
        ]

    def start_session(self, session_id: str,
                      language: str = "hi",
                      diarize: bool = True) -> STTSession:
        """
        Start a new STT session with streaming transcription.
        """
        config = {
            "model": self.model,
            "language": language,
            "diarize": diarize,
            "smart_format": True,
            "punctuate": True,
            "utterance_end_ms": 1000,
            "keywords": self.MEDICAL_BOOST_WORDS,
            "keyword_boost": 1.5
        }
        session = STTSession(session_id, config,
                             on_transcript=self._on_transcript,
                             on_utterance_end=self._on_utterance_end)
        self.active_sessions[session_id] = session
        return session

    def process_audio_chunk(self, session_id: str,
                            audio_chunk: bytes,
                            timestamp: int):
        """Feed audio chunk to active STT session."""
        session = self.active_sessions.get(session_id)
        if session:
            session.feed_audio(audio_chunk, timestamp)

    def _on_transcript(self, session_id: str,
                       transcript: str,
                       is_final: bool,
                       speaker: int | None,
                       confidence: float):
        """
        Fired when a transcript chunk is ready.
        is_final=True means the utterance is complete.
        """
        event = {
            "type": "transcript" if not is_final else "utterance",
            "session_id": session_id,
            "text": transcript,
            "speaker": speaker,
            "confidence": confidence,
            "is_final": is_final,
            "timestamp": datetime.utcnow().isoformat()
        }
        # Publish to conversation manager
        event_bus.publish("stt_transcript", event)
```

### 2.3 Conversation Manager
```python
# conversation_manager.py
class ConversationManager:
    """
    Core conversation orchestration engine. Manages:
    - State machine for turn-by-turn conversation
    - Context accumulation across turns
    - Intent classification with LLM
    - Interruption detection and handling
    - Response generation
    - Human handoff triggering
    """

    def __init__(self, session_id: str, config: dict):
        self.session_id = session_id
        self.config = config
        self.state = "idle"
        self.context = ConversationContext()
        self.turn_count = 0
        self.interruption_count = 0
        self.current_speaker = None
        self.barge_in_enabled = config.get("barge_in", True)

    def process_utterance(self, utterance: dict) -> dict:
        """
        Process a complete utterance (final transcript).
        Returns the agent's response action.
        """
        self.turn_count += 1
        text = utterance["text"]
        speaker = utterance.get("speaker")
        confidence = utterance.get("confidence", 1.0)

        # Check for barge-in (interruption by speaker while agent is speaking)
        if self.state == "agent_speaking" and self.barge_in_enabled:
            self.interruption_count += 1
            self._handle_interruption()

        # Update context
        self.context.add_turn("user", text, speaker)

        # Classify intent
        intent = self._classify_intent(text, confidence)

        # Check if human handoff needed
        if self._should_handoff(intent, utterance):
            return self._initiate_handoff()

        # Execute intent
        action = self._execute_intent(intent)

        # Generate response
        response_text = self._generate_response(action, intent)
        self.context.add_turn("agent", response_text, "agent")
        self.state = "agent_speaking"

        return {
            "action": "respond",
            "text": response_text,
            "tts_voice": self.config.get("voice", "default"),
            "language": self.context.language,
            "sentiment": self._detect_sentiment(text),
            "intent": intent,
            "metadata": action
        }

    def _classify_intent(self, text: str, confidence: float) -> dict:
        """Classify user intent using LLM with context."""
        prompt = self._build_intent_prompt(text)
        result = llm_call(
            prompt,
            model=self.config.get("llm_model", "gpt-4o-mini"),
            max_tokens=256
        )
        intent = json.loads(result)
        intent["confidence"] = min(intent.get("confidence", 0.5), confidence)
        return intent

    def _handle_interruption(self):
        """Handle speaker interrupting the agent mid-response."""
        # Stop current TTS
        tts_engine.stop(self.session_id)
        # Pause and listen for the interruption
        self.state = "listening"
        # Log interruption
        self.context.log_event("interruption", {
            "turn": self.turn_count,
            "interruption_count": self.interruption_count
        })
```

## 3. SENTIMENT ANALYSIS

```python
# sentiment_analyzer.py
class SentimentAnalyzer:
    """
    Real-time sentiment analysis on user utterances.
    Returns sentiment label and score for each utterance.
    Tracks sentiment trend across the conversation.
    """

    LABELS = ["positive", "negative", "neutral", "frustrated",
              "confused", "satisfied", "angry", "anxious"]

    CONFIDENCE_THRESHOLD = 0.6

    def analyze(self, text: str,
                language: str = "en",
                context: dict | None = None) -> dict:
        """
        Analyze sentiment of a text utterance.
        Returns label and confidence score.
        """
        if language in ["hi", "hinglish"]:
            text = self._transliterate_to_english(text)

        prompt = f"""
        Analyze the sentiment of this text from a medical clinic context.
        Current conversation context: {json.dumps(context or {})}

        Text: "{text}"

        Output JSON with:
        - sentiment: one of {self.LABELS}
        - score: 0.0-1.0
        - key_emotion_words: [list of emotion-bearing words]
        - requires_attention: boolean (if negative/frustrated/angry)
        """
        result = llm_call(prompt, max_tokens=128)
        parsed = json.loads(result)

        if parsed.get("score", 0) < self.CONFIDENCE_THRESHOLD:
            return {
                "sentiment": "neutral",
                "score": 0.5,
                "key_emotion_words": [],
                "requires_attention": False,
                "fallback": True
            }

        parsed["requires_attention"] = parsed.get("sentiment") in [
            "negative", "frustrated", "angry", "anxious"
        ]
        return parsed

    def track_trend(self, session_id: str) -> dict:
        """
        Track sentiment trend across the conversation.
        Useful for detecting escalating frustration.
        """
        history = self.get_session_history(session_id)
        if len(history) < 3:
            return {"trend": "insufficient_data", "needs_intervention": False}

        recent = history[-3:]
        negative_count = sum(
            1 for h in recent
            if h["sentiment"] in ["negative", "frustrated", "angry"]
        )

        return {
            "trend": "declining" if negative_count >= 2 else "stable",
            "needs_intervention": negative_count >= 2,
            "history": recent
        }
```

## 4. CONFIGURABLE FLOW DEFINITIONS

```yaml
# voice_agent_flows.yaml
flows:
  receptionist:
    description: "Incoming call handling and appointment booking"
    system_prompt: >
      You are a friendly receptionist at GIL Clinic. Your job is to
      help patients book appointments, answer queries about clinic
      timings and services, and route calls appropriately. Be polite,
      professional, and efficient. Never provide medical advice.
    max_turns: 20
    timeout_seconds: 30
    fallback_action: "transfer_human"
    supported_intents:
      - book_appointment
      - cancel_appointment
      - reschedule_appointment
      - clinic_info
      - doctor_info
      - route_department
    tts_voice: "Aditi"
    barge_in: true
    language: "hi-IN"

  followup:
    description: "Post-visit follow-up and medication adherence"
    system_prompt: >
      You are a caring follow-up assistant from GIL Clinic. You are
      calling to check on a patient after their visit. Be warm and
      empathetic. Ask about recovery, medication adherence, and any
      concerns. If patient reports worsening symptoms, flag for doctor.
    max_turns: 15
    timeout_seconds: 15
    fallback_action: "schedule_callback"
    supported_intents:
      - report_status
      - medication_check
      - symptom_update
      - feedback
      - reschedule
    tts_voice: "Joanna"
    barge_in: true
    language: "en-IN"

  survey:
    description: "Patient satisfaction survey"
    system_prompt: >
      You are collecting patient feedback for GIL Clinic. Ask questions
      one at a time. Be neutral and non-leading. Record all responses
      accurately. Thank the patient for their time.
    max_turns: 10
    timeout_seconds: 20
    fallback_action: "send_sms_survey"
    supported_intents:
      - rate_experience
      - provide_feedback
      - suggest_improvement
    tts_voice: "Aditi"
    barge_in: false  # surveys should not be interrupted
    language: "hi-IN"

  triage:
    description: "Symptom assessment and severity classification"
    system_prompt: >
      You are a symptom assessment assistant. Ask structured questions
      about symptoms one at a time. Never diagnose. If emergency
      keywords are detected, immediately escalate. Always include
      disclaimer that this is not a medical diagnosis.
    max_turns: 25
    timeout_seconds: 20
    fallback_action: "escalate_human"
    supported_intents:
      - describe_symptom
      - answer_question
      - request_human
      - emergency
    tts_voice: "Amy"
    barge_in: true
    language: "en-IN"
```

## 5. TTS ENGINE

```python
# tts_engine.py
class TTSEngine:
    """
    Text-to-Speech engine with:
    - Multiple voice providers (ElevenLabs, Amazon Polly, Google TTS)
    - SSML support for prosody control
    - Voice cloning for clinic branding
    - Streaming audio playback (chunked)
    - Barge-in interrupt support
    - Language-specific voice selection
    """

    VOICE_MAP = {
        "hi-IN": {
            "polly": "Aditi",
            "elevenlabs": "21m00Tcm4TlvDq8ikWAM",
            "google": "hi-IN-Standard-A"
        },
        "en-IN": {
            "polly": "Raveena",
            "elevenlabs": "EXAVITQu4vrVxn66xG5T",
            "google": "en-IN-Standard-A"
        },
        "en-US": {
            "polly": "Joanna",
            "elevenlabs": "21m00Tcm4TlvDq8ikWAM",
            "google": "en-US-Standard-C"
        }
    }

    def __init__(self, provider: str = "elevenlabs",
                 default_voice: str = "default"):
        self.provider = provider
        self.default_voice = default_voice
        self.active_playbacks: dict[str, PlaybackSession] = {}

    def speak(self, session_id: str,
              text: str,
              language: str = "hi-IN",
              voice: str | None = None,
              speed: float = 1.0,
              ssml: bool = False) -> PlaybackSession:
        """
        Convert text to speech and stream it to the session.
        Returns a PlaybackSession that can be stopped/interrupted.
        """
        selected_voice = voice or self.VOICE_MAP.get(
            language, {}
        ).get(self.provider, self.default_voice)

        if ssml:
            text = self._wrap_ssml(text, language)

        playback = PlaybackSession(
            session_id=session_id,
            provider=self.provider,
            text=text,
            voice=selected_voice,
            speed=speed,
            on_chunk=self._on_audio_chunk,
            on_complete=self._on_playback_complete
        )
        self.active_playbacks[session_id] = playback
        playback.start()
        return playback

    def stop(self, session_id: str):
        """Immediately stop TTS playback (barge-in)."""
        playback = self.active_playbacks.get(session_id)
        if playback:
            playback.stop()
            del self.active_playbacks[session_id]
```

## 6. HUMAN HANDOFF

```python
# handoff.py
class HumanHandoffManager:
    """
    Manages seamless handoff from AI voice agent to human staff.
    Triggers:
    - Patient explicitly requests human
    - Sentiment escalation (frustrated/angry 3+ turns)
    - Emergency keyword detected
    - AI confidence below threshold for 2 consecutive turns
    - Unknown intent after 2 re-prompts
    - Duration limit exceeded (configurable per flow)
    """

    def __init__(self, twilio_client, notification_service):
        self.twilio = twilio_client
        self.notifier = notification_service

    def initiate_handoff(self, session_id: str,
                         reason: str,
                         context: ConversationContext) -> dict:
        """
        Transfer call to a human agent with full context.
        Prioritizes available agents by skill/department match.
        """
        # Find available human agent matching context
        target_agent = self.find_agent({
            "department": context.metadata.get("department"),
            "language": context.language,
            "skills": ["triage", "reception"] if reason == "emergency" else []
        })

        if target_agent:
            # Warm transfer: agent gets full conversation context
            handoff_summary = self._prepare_handoff_summary(context)
            self.notifier.send(
                recipient=target_agent["id"],
                channel="internal",
                template="handoff",
                data={
                    "session_id": session_id,
                    "reason": reason,
                    "summary": handoff_summary,
                    "patient": context.patient_id,
                    "conversation_log": context.get_log()
                }
            )

            return {
                "handoff_type": "warm",
                "agent": target_agent,
                "transfer_number": target_agent["extension"],
                "summary": handoff_summary
            }
        else:
            # No agent available: cold transfer to queue
            return {
                "handoff_type": "cold",
                "queue": reason,
                "estimated_wait_minutes": 5,
                "callback_number": context.get_callback_number()
            }
```

## 7. SQL DATA MODEL

```sql
-- voice_agent_schema.sql
CREATE TABLE voice_sessions (
    id                  VARCHAR(64) PRIMARY KEY,
    flow_type           VARCHAR(32) NOT NULL,
    patient_id          BIGINT REFERENCES patients(id),
    call_sid            VARCHAR(64),
    channel             VARCHAR(16) NOT NULL,
    status              VARCHAR(16) DEFAULT 'active'
                        CHECK (status IN
                          ('active', 'paused', 'completed',
                           'handoff', 'failed')),
    language            VARCHAR(10) DEFAULT 'hi-IN',
    stt_provider        VARCHAR(32),
    tts_provider        VARCHAR(32),
    llm_model           VARCHAR(64),
    turn_count          INT DEFAULT 0,
    interruption_count  INT DEFAULT 0,
    sentiment_trend     JSONB,
    context_data        JSONB,
    handoff_status      VARCHAR(16),
    handoff_agent_id    BIGINT REFERENCES staff(id),
    duration_seconds    INT,
    created_at          TIMESTAMP DEFAULT NOW(),
    completed_at        TIMESTAMP,
    INDEX(patient_id),
    INDEX(status),
    INDEX(created_at)
);

CREATE TABLE conversation_turns (
    id              BIGSERIAL PRIMARY KEY,
    session_id      VARCHAR(64) REFERENCES voice_sessions(id),
    turn_number     INT NOT NULL,
    speaker         VARCHAR(16) NOT NULL
                    CHECK (speaker IN ('user', 'agent', 'system')),
    text            TEXT NOT NULL,
    intent          JSONB,
    sentiment       JSONB,
    confidence      DECIMAL(4,3),
    audio_duration_ms INT,
    latency_ms      INT,
    created_at      TIMESTAMP DEFAULT NOW(),
    INDEX(session_id, turn_number)
);

CREATE TABLE handoff_log (
    id              BIGSERIAL PRIMARY KEY,
    session_id      VARCHAR(64) REFERENCES voice_sessions(id),
    trigger_reason  TEXT NOT NULL,
    handoff_type    VARCHAR(16) CHECK (handoff_type IN ('warm', 'cold')),
    agent_id        BIGINT REFERENCES staff(id),
    summary         JSONB,
    patient_wait_seconds INT,
    outcome         VARCHAR(32),
    created_at      TIMESTAMP DEFAULT NOW()
);
```

## 8. KEY DESIGN DECISIONS

1. **Unified Agent with Pluggable Flows**: Rather than separate voice agents for receptionist, follow-up, and triage, a single voice agent engine loads different flow configurations (YAML-defined). This avoids code duplication and ensures consistent audio quality, VAD behavior, and handoff logic across all use cases.

2. **Streaming STT + TTS with Barge-In**: Audio is processed in 100ms chunks. The STT engine delivers partial transcripts mid-utterance, enabling the LLM to start processing before the user finishes speaking. TTS supports mid-stream interruption, allowing the agent to stop speaking when the user begins talking (barge-in).

3. **Interruption-Aware State Machine**: The conversation manager tracks who is speaking. If the user interrupts while TTS is playing, playback stops, the interruption is logged, and the new utterance is processed. The agent acknowledges the interruption naturally ("Sure, let me check that for you").

4. **Sentiment Trend vs Snapshot**: Sentiment is analyzed per-utterance but decisions (handoff, tone change) use the trend over 3+ turns. A single frustrated response is tolerated; sustained negative sentiment triggers intervention.

5. **Warm Handoff with Full Context**: When transferring to a human, the agent packages the full conversation context (transcript, intent history, sentiment trend, patient data) into a structured handoff summary. The human agent receives this before joining the call, minimizing repetition for the patient.

6. **Voice Cloning for Brand Consistency**: The clinic can upload voice samples to create a custom branded voice (via ElevenLabs). This voice is used across all flows, maintaining consistent auditory branding. Fallback to standard voices if custom voice is unavailable.

7. **Audio Codec Negotiation**: The stream manager negotiates the best codec based on network conditions. Opus for WebRTC, PCMU for PSTN. Audio is transcoded to 16kHz mono before STT processing, regardless of source codec.
