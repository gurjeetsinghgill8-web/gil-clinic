---
file_id: "0208"
module_name: "Accountant Module"
version: "2.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0400_BILLING.md"]
related_files: ["0406_FINANCE.md", "0407_GST.md", "0408_INSURANCE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "accountant", "billing", "payment", "invoice", "gst", "insurance"]
---

# GHOS — Accountant Module

## 1. PURPOSE

The Accountant Module is the financial nucleus of GIL CLINIC. It handles:

- **Billing Queue Management** — triaging patients awaiting bills
- **Consolidated Bill Generation** — merging doctor charges, diagnostic tests, and pharmacy into a single patient bill
- **Payment Collection** — accepting Cash, UPI, Card, Insurance, and Clinic Credit
- **Discount Management** — percentage/flat discounts with configurable approval tiers
- **GST Invoice Generation** — tax-compliant invoices with HSN codes and clinic GSTN
- **Insurance Claims** — preparing, submitting, and tracking claim workflows
- **Bill Splitting & Partial Payments** — accommodating group payments and instalments
- **Pending Payments Tracking** — flagging and following up on outstanding dues
- **Daily Settlement Report** — reconciling cash drawer against system totals
- **Refund Processing** — handling cancellations and overpayments
- **Financial Reporting** — daily/monthly revenue summaries for the Finance module (0406)

## 2. BILLING DASHBOARD

```
+------------------------------------------------------+
|  Billing Desk              Tue, 09 Jul 2026  10:30  |
+------------------------------------------------------+
|  Queue: 8 patients pending                           |
|  +--- NEXT PATIENT --------------------------------+ |
|  |  BIL-20260709-099  |  Rajesh Kumar               | |
|  |  UHID: UH-20260042  |  OPD-20260709-312          | |
|  |  -- Bill Summary --                              | |
|  |  Doctor Consultation (General Med):   500         | |
|  |  ECG (HSN 9018):                      350         | |
|  |  Lab - CBC + Lipid Profile (HSN 3822):800         | |
|  |  Pharmacy - Amlodipine 5mg x 30 (HSN 3003): 450  | |
|  |  -----------------------------------------        | |
|  |  Subtotal:                           2,100        | |
|  |  Discount (10%):                       -210       | |
|  |  SGST (9%):                            170        | |
|  |  CGST (9%):                            170        | |
|  |  Net Payable:                        2,230        | |
|  |                                                  | |
|  |  [Cash] [UPI] [Card] [Insurance] [Credit]         | |
|  |  [Generate Invoice] [Print Receipt] [Hold]        | |
|  +--------------------------------------------------+ |
|                                                      |
|  +--- QUEUE ---------------------------------------+ |
|  |  #  Patient         Amount   Status              | |
|  |  1  Rajesh Kumar     2,230   Ready               | |
|  |  2  Sunita Sharma    1,560   Insurance           | |
|  |  3  Amit Verma        450   Pending Lab          | |
|  |  4  Priya Nair       3,200   Awaiting Dr.        | |
|  |  5  Vikram Singh     2,890   Ready               | |
|  +--------------------------------------------------+ |
+------------------------------------------------------+
```

## 3. CONSOLIDATED BILLING

Every patient visit aggregates charges from three subsystems:

```python
class ConsolidatedBill:
    def __init__(self, visit_id: str):
        self.visit_id = visit_id
        self.charges = []
        self.discounts = []
        self.payments = []

    def add_doctor_charge(self, consultation_fee: float, procedure_charges: list):
        self.charges.append({
            "source": "doctor",
            "items": procedure_charges + [{"name": "Consultation", "amount": consultation_fee}]
        })

    def add_lab_charges(self, tests: list):
        self.charges.append({"source": "lab", "items": tests})

    def add_pharmacy_charges(self, medicines: list):
        self.charges.append({"source": "pharmacy", "items": medicines})

    def compute_subtotal(self) -> float:
        return sum(item["amount"] for dept in self.charges for item in dept["items"])

    def apply_discount(self, discount_percent: float = 0.0, discount_flat: float = 0.0):
        subtotal = self.compute_subtotal()
        amount = subtotal - discount_flat
        self.discounts.append({
            "percent": discount_percent,
            "flat": discount_flat,
            "final_discount": subtotal - amount,
            "discounted_subtotal": amount
        })
        return amount

    def compute_gst(self, taxable_amount: float, sgst_rate=0.09, cgst_rate=0.09):
        sgst = round(taxable_amount * sgst_rate, 2)
        cgst = round(taxable_amount * cgst_rate, 2)
        return {"sgst": sgst, "cgst": cgst, "total_tax": sgst + cgst}
```

### Bill Lifecycle

```
VISIT_START
    |
    v
CHARGES_ACCRUING (doctor/lab/pharmacy push line items)
    |
    v
BILL_GENERATED (consolidated bill created, billing queue enqueued)
    |
    v
DISCOUNT_APPLIED (if applicable, with approval if > threshold)
    |
    v
PAYMENT_IN_PROGRESS (one or more payment transactions)
    |
    v
PAID_IN_FULL / PARTIALLY_PAID / PENDING
    |
    v
INVOICE_GENERATED (GST invoice PDF/print)
    |
    v
SETTLED (visit closed, cash drawer updated)
```

## 4. PAYMENT COLLECTION

Supported payment modes and their handling:

| Mode       | Handler                          | Settlement Time  | Notes                        |
|------------|----------------------------------|------------------|------------------------------|
| Cash       | Immediate drawer update           | Real-time        | Requires change calculation  |
| UPI        | QR code / UPI ID                  | 1-5 min (async)  | UPI transaction ID logged    |
| Card       | POS terminal / manual entry       | Real-time        | Last 4 digits + auth code    |
| Insurance  | Refer to Insurance Claim (Sec 7)  | 7-30 days        | TPA approval required        |
| Credit     | Clinic credit account             | Custom due date  | Requires manager approval    |

```python
def process_payment(bill_id: str, mode: str, amount: float, metadata: dict) -> dict:
    \"\"\"Record a payment against a bill. Supports split tenders.\"\"\"
    payment_record = {
        "bill_id": bill_id,
        "mode": mode,
        "amount": amount,
        "status": "completed" if mode in ("cash", "card") else "pending",
        "transaction_ref": metadata.get("ref"),
        "collected_by": metadata.get("cashier"),
        "timestamp": datetime.utcnow().isoformat(),
    }
    # If mode is UPI, trigger async confirmation webhook
    if mode == "upi":
        payment_record["status"] = "awaiting_confirmation"
        trigger_upi_webhook_listener(bill_id, metadata["qr_code"])
    # If mode is credit, create receivable entry in Finance module
    if mode == "credit":
        payment_record["status"] = "awaiting_clearance"
        notify_finance_module("receivable_created", payment_record)
    return payment_record
```

### Split Tender Example

A patient paying via two modes:

```python
payments = [
    {"mode": "cash", "amount": 1000.00, "ref": None},
    {"mode": "upi", "amount": 1230.00, "ref": "UPI-ABC123XYZ"},
]
```

## 5. DISCOUNT MANAGEMENT

### Discount Types

| Type       | Scope                    | Max Without Approval |
|------------|--------------------------|----------------------|
| Percentage | % off net subtotal       | 10%                  |
| Flat       | Fixed rupee amount       | 500                  |
| Combo      | Bill + package deal      | Configurable         |

### Approval Workflow

- Discount <= 10% or <= 500: Cashier discretion, auto-approved.
- Discount 11-20% or 501-2000: Requires manager PIN override.
- Discount > 20% or > 2000: Requires admin approval; reason code mandatory.

```python
def apply_discount(bill_id: str, discount_type: str, value: float, approved_by: str = None) -> dict:
    bill = get_bill(bill_id)
    subtotal = bill["subtotal"]
    thresholds = get_config("discount_thresholds")

    if discount_type == "percentage":
        discount_amount = subtotal * (value / 100)
        requires_approval = value > thresholds["percent_auto_approve"]
    else:  # flat
        discount_amount = min(value, subtotal)
        requires_approval = discount_amount > thresholds["flat_auto_approve"]

    if requires_approval and not approved_by:
        return {"status": "requires_approval", "message": "Manager or admin approval required"}

    return {
        "status": "approved",
        "discount_type": discount_type,
        "discount_value": value,
        "discount_amount": round(discount_amount, 2),
        "new_net": round(subtotal - discount_amount, 2),
        "approved_by": approved_by or "system_auto",
        "timestamp": datetime.utcnow().isoformat(),
    }
```

## 6. GST INVOICE GENERATION

### Clinic GST Configuration

```python
gst_config = {
    "clinic_gstn": "29AABCU1234D1Z5",
    "clinic_name": "GIL CLINIC",
    "clinic_address": "42, JP Nagar 3rd Phase, Bengaluru, Karnataka 560078",
    "state_code": "29",  # Karnataka
    "sgst_rate": 0.09,   # 9%
    "cgst_rate": 0.09,   # 9%
    "igst_rate": 0.00,   # Only for interstate, computed dynamically
}
```

### HSN Code Mapping

| Service / Product              | HSN Code |
|--------------------------------|----------|
| Medical Consultation Services  | 9993     |
| Diagnostic Lab Services        | 3822     |
| ECG / Cardiac Diagnostics      | 9018     |
| X-Ray / Imaging                | 9022     |
| Pharmacy - Medicines           | 3003     |
| Pharmacy - Surgical Items      | 3006     |
| Hospital Bed Charges           | 9993     |
| Physiotherapy                  | 9993     |

### Invoice Record Schema

```python
invoice_record = {
    "invoice_id": "INV-20260709-042",
    "bill_id": "BIL-20260709-099",
    "gstn": "29AABCU1234D1Z5",
    "place_of_supply": "Karnataka (29)",
    "customer": {
        "name": "Rajesh Kumar",
        "gstn": None,
        "address": "#12, 5th Cross, JP Nagar, Bangalore",
        "state_code": "29",
    },
    "items": [
        {"hsn": "9993", "desc": "General Medicine Consultation", "qty": 1, "rate": 500, "taxable": 500},
        {"hsn": "9018", "desc": "ECG", "qty": 1, "rate": 350, "taxable": 350},
        {"hsn": "3822", "desc": "CBC + Lipid Profile", "qty": 1, "rate": 800, "taxable": 800},
        {"hsn": "3003", "desc": "Amlodipine 5mg x 30", "qty": 1, "rate": 450, "taxable": 450},
    ],
    "subtotal": 2100.00,
    "discount": 210.00,
    "taxable_value": 1890.00,
    "sgst": 170.10,
    "cgst": 170.10,
    "total": 2230.20,
    "in_words": "Two Thousand Two Hundred Thirty Rupees and Twenty Paise Only",
    "qr_code": "upi://pay?pa=gilclinic@upi&pn=GIL%20CLINIC&am=2230.20",
}
```

### Invoice Lifecycle

```
DRAFT -> GENERATED -> PRINTED -> EMAILED -> CANCELLED (if bill voided)
```

## 7. INSURANCE CLAIM WORKFLOW

```
    PATIENT_VERIFIED (insurance details collected at registration)
        |
        v
    PRE_AUTHORIZATION (optional - for high-value packages/procedures)
        |
        v
    BILL_GENERATED -> CLAIM_CREATED
        |
        v
    DOCUMENTS_UPLOADED (invoice, prescriptions, investigation reports)
        |
        v
    CLAIM_SUBMITTED (to TPA / insurance portal)
        |
        v
    CLAIM_APPROVED / CLAIM_DENIED
        |                   |
        v                   v
    PAYMENT_RECEIVED     APPEAL / PATIENT_BILL
    (TPA settles clinic) (balance billed to patient)
```

```sql
CREATE TABLE insurance_claims (
    claim_id        VARCHAR(20) PRIMARY KEY,
    bill_id         VARCHAR(20) NOT NULL REFERENCES bills(bill_id),
    patient_uhid    VARCHAR(20) NOT NULL,
    insurer_name    VARCHAR(100) NOT NULL,
    policy_number   VARCHAR(50) NOT NULL,
    tpa_name        VARCHAR(100),
    pre_auth_ref    VARCHAR(50),
    claim_amount    DECIMAL(10,2) NOT NULL,
    approved_amount DECIMAL(10,2),
    status          ENUM('draft','submitted','approved','denied','paid','appealed') DEFAULT 'draft',
    submitted_at    TIMESTAMP,
    approved_at     TIMESTAMP,
    settled_at      TIMESTAMP,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 8. BILL SPLITTING & PARTIAL PAYMENTS

### Bill Splitting

When a group (e.g., family visit) wants to split a single bill:

```python
def split_bill(bill_id: str, splits: list) -> list:
    \"\"\"
    splits: [{"name": "Rajesh", "amount": 1000.00},
             {"name": "Priya",  "amount": 1230.00}]
    Sum of splits must equal bill net total.
    \"\"\"
    bill = get_bill(bill_id)
    total = bill["net_total"]
    split_sum = sum(s["amount"] for s in splits)
    assert abs(split_sum - total) < 0.01, "Split amounts must equal bill total"

    sub_bills = []
    for i, split in enumerate(splits):
        sub_bill_id = f"{bill_id}-{chr(65 + i)}"
        sub_bill = {**bill, "bill_id": sub_bill_id,
                    "payer_name": split["name"],
                    "amount": split["amount"],
                    "parent_bill": bill_id}
        sub_bills.append(sub_bill)
    return sub_bills
```

### Partial Payments

Track payments that do not fully settle a bill:

```sql
ALTER TABLE bills ADD COLUMN paid_amount DECIMAL(10,2) DEFAULT 0.00;
ALTER TABLE bills ADD COLUMN balance_amount DECIMAL(10,2) GENERATED ALWAYS AS (net_total - paid_amount) STORED;
ALTER TABLE bills ADD COLUMN due_date DATE;
```

- Partial payment recorded -> paid_amount incremented, balance_amount updated.
- If balance_amount > 0 past due_date, flagged as overdue.

## 9. PENDING PAYMENTS TRACKING

### Overdue Dashboard

```
+--- PENDING PAYMENTS -------------------------------------+
|  Total Outstanding:  84,560                              |
|  +--- Overdue -----------------------------------------+ |
|  |  BIL-099   Rajesh Kumar   2,230   10 days overdue    | |
|  |  BIL-082   Meera Iyer     1,200    5 days overdue    | |
|  |  BIL-076   Arun D.        5,000   15 days overdue    | |
|  +------------------------------------------------------+ |
|  +--- Upcoming -----------------------------------------+ |
|  |  BIL-107   Sneha Kapoor   3,500   Due in 3 days      | |
|  |  BIL-110   Imran Khan     1,800   Due in 7 days      | |
|  +------------------------------------------------------+ |
|  [Send Reminder SMS] [Generate Dunning Letter]           |
+----------------------------------------------------------+
```

### Follow-Up Automation

- Auto-trigger SMS reminder when bill due date is 3 days away.
- Escalate to Collections group after 15 days overdue.
- Write off (bad debt) only with admin approval after 90 days.

```
OVERDUE_3DAYS  -> SMS Reminder
OVERDUE_7DAYS  -> SMS + Email Reminder
OVERDUE_15DAYS -> Escalated to Collections
OVERDUE_30DAYS -> Mark as High Risk
OVERDUE_90DAYS -> Bad Debt Write-off (admin only)
```

## 10. DAILY SETTLEMENT REPORT

Generated at EOD by the cashier/accountant. Purpose: reconcile physical cash in drawer with system-recorded cash payments.

```
GHOS DAILY SETTLEMENT - 09 July 2026
----------------------------------------
CASHIER: Priya (Shift: 08:00 - 16:00)

CASH PAYMENTS BREAKDOWN
  Total Cash Bills:                42
  System Cash Total:            52,340.00
  Physical Count:               52,500.00
  Variance:                        160.00

VARIANCES
  1. Overpayment - BIL-091 (50 extra tendered)        50
  2. Change short - BIL-094 (10 less in drawer)      -10
  3. Undeposited - BIL-104 (120 unaccounted)          120
  Net Variance:                                        160

NON-CASH BREAKDOWN
  UPI Payments (18 txns):      28,450.00
  Card Payments (12 txns):     15,200.00
  Insurance Claims (3):         8,700.00
  Clinic Credit (2 txns):       3,000.00

GRAND TOTAL COLLECTIONS:      107,690.00

  [Verify & Lock]  [Print Report]  [Push to Finance]
```

```python
def generate_settlement_report(cashier_id: str, shift_date: str) -> dict:
    cash_total = query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE mode='cash' AND collected_by=%s AND DATE(timestamp)=%s", cashier_id, shift_date)
    upi_total  = query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE mode='upi'  AND collected_by=%s AND DATE(timestamp)=%s", cashier_id, shift_date)
    card_total = query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE mode='card' AND collected_by=%s AND DATE(timestamp)=%s", cashier_id, shift_date)
    insurance  = query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE mode='insurance' AND collected_by=%s AND DATE(timestamp)=%s", cashier_id, shift_date)
    credit     = query("SELECT COALESCE(SUM(amount),0) FROM payments WHERE mode='credit' AND collected_by=%s AND DATE(timestamp)=%s", cashier_id, shift_date)

    return {
        "cashier": cashier_id,
        "date": shift_date,
        "cash_total": cash_total,
        "upi_total": upi_total,
        "card_total": card_total,
        "insurance_total": insurance,
        "credit_total": credit,
        "grand_total": cash_total + upi_total + card_total + insurance + credit,
    }
```

## 11. REFUND PROCESSING

### Scenarios Requiring Refund

- Service cancelled before delivery (full refund).
- Overpayment by patient (difference refunded).
- Wrong charge applied (corrected via reversal).
- Insurance denied claim (refund to patient if already paid).

### Refund Workflow

```python
def process_refund(bill_id: str, reason: str, amount: float, approved_by: str, mode: str) -> dict:
    \"\"\"
    mode: same modes as payment (cash, upi, card)
    A refund is a negative payment entry linked to the original bill.
    \"\"\"
    if amount <= 0:
        return {"status": "error", "message": "Refund amount must be positive"}

    bill = get_bill(bill_id)
    if bill["balance_amount"] < amount and reason != "overpayment":
        return {"status": "error", "message": "Refund exceeds balance"}

    refund_txn = {
        "bill_id": bill_id,
        "type": "refund",
        "mode": mode,
        "amount": -amount,
        "reason": reason,
        "approved_by": approved_by,
        "processed_by": current_user(),
        "timestamp": datetime.utcnow().isoformat(),
    }

    record_payment(refund_txn)
    update_bill_balance(bill_id, -amount)

    return {"status": "completed", "refund_txn": refund_txn}
```

## 12. BILLING QUEUE MANAGEMENT

### Queue States

| State            | Description                                    |
|------------------|------------------------------------------------|
| PENDING          | Visit created, charges accruing                 |
| READY            | All charges posted, awaiting payment            |
| HELD             | Cashier paused - waiting on doctor/lab         |
| INSURANCE_HOLD   | Waiting for TPA pre-auth or claim approval      |
| PAID             | Fully settled                                  |
| PARTIAL          | Partially paid, balance due                     |
| VOID             | Bill cancelled, all amounts reversed            |

### Queue Operations

```python
def enqueue(bill):
    get_queue().append({"bill": bill, "state": "PENDING"})

def dequeue():
    \"\"\"Pull next READY bill from queue in FIFO order.\"\"\"
    for entry in get_queue():
        if entry["state"] == "READY":
            entry["state"] = "PROCESSING"
            return entry["bill"]
    return None

def hold_bill(bill_id: str, reason: str):
    entry = find_in_queue(bill_id)
    entry["state"] = "HELD"
    entry["hold_reason"] = reason

def unhold_bill(bill_id: str):
    entry = find_in_queue(bill_id)
    entry["state"] = "READY"
    entry["hold_reason"] = None
```

## 13. DATABASE SCHEMA

### bills

```sql
CREATE TABLE bills (
    bill_id         VARCHAR(30) PRIMARY KEY,
    visit_id        VARCHAR(30) NOT NULL,
    patient_uhid    VARCHAR(20) NOT NULL,
    patient_name    VARCHAR(100) NOT NULL,
    doctor_id       VARCHAR(20),
    subtotal        DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    discount_amount DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    taxable_value   DECIMAL(10,2) GENERATED ALWAYS AS (subtotal - discount_amount) STORED,
    sgst            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    cgst            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    igst            DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    net_total       DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    paid_amount     DECIMAL(10,2) NOT NULL DEFAULT 0.00,
    balance_amount  DECIMAL(10,2) GENERATED ALWAYS AS (net_total - paid_amount) STORED,
    status          ENUM('draft','pending','ready','partial','paid','void','refunded') DEFAULT 'draft',
    invoice_id      VARCHAR(30),
    due_date        DATE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (visit_id) REFERENCES visits(visit_id),
    FOREIGN KEY (patient_uhid) REFERENCES patients(uhid)
);
```

### bill_items

```sql
CREATE TABLE bill_items (
    item_id         BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_id         VARCHAR(30) NOT NULL,
    source          ENUM('doctor','lab','pharmacy','procedure','misc') NOT NULL,
    hsn_code        VARCHAR(10),
    description     VARCHAR(255) NOT NULL,
    quantity        INT NOT NULL DEFAULT 1,
    rate            DECIMAL(10,2) NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    is_taxable      BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id) ON DELETE CASCADE
);
```

### payments

```sql
CREATE TABLE payments (
    payment_id      BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_id         VARCHAR(30) NOT NULL,
    type            ENUM('payment','refund') DEFAULT 'payment',
    mode            ENUM('cash','upi','card','insurance','credit') NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    transaction_ref VARCHAR(100),
    collected_by    VARCHAR(50) NOT NULL,
    approved_by     VARCHAR(50),
    status          ENUM('pending','completed','failed','reversed') DEFAULT 'pending',
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id)
);
```

### insurance_claims (detailed)

```sql
CREATE TABLE insurance_claims (
    claim_id        VARCHAR(30) PRIMARY KEY,
    bill_id         VARCHAR(30) NOT NULL UNIQUE,
    patient_uhid    VARCHAR(20) NOT NULL,
    insurer_name    VARCHAR(100) NOT NULL,
    policy_number   VARCHAR(50) NOT NULL,
    tpa_name        VARCHAR(100),
    claim_type      ENUM('cashless','reimbursement') NOT NULL,
    pre_auth_ref    VARCHAR(50),
    pre_auth_amount DECIMAL(10,2),
    claim_amount    DECIMAL(10,2) NOT NULL,
    approved_amount DECIMAL(10,2),
    deductible      DECIMAL(10,2) DEFAULT 0.00,
    co_pay_amount   DECIMAL(10,2) DEFAULT 0.00,
    status          ENUM('draft','submitted','approved','denied','paid','appealed','closed') DEFAULT 'draft',
    document_urls   JSON,
    submitted_at    TIMESTAMP,
    approved_at     TIMESTAMP,
    settled_at      TIMESTAMP,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id),
    FOREIGN KEY (patient_uhid) REFERENCES patients(uhid)
);
```

### billing_queue

```sql
CREATE TABLE billing_queue (
    queue_id        BIGINT AUTO_INCREMENT PRIMARY KEY,
    bill_id         VARCHAR(30) NOT NULL UNIQUE,
    state           ENUM('pending','ready','processing','held','insurance_hold','paid','partial','void') DEFAULT 'pending',
    hold_reason     VARCHAR(255),
    position        INT NOT NULL DEFAULT 0,
    entered_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (bill_id) REFERENCES bills(bill_id)
);
```

## 14. API ENDPOINTS

### Billing Endpoints

| Method | Endpoint                          | Description                     |
|--------|-----------------------------------|---------------------------------|
| GET    | /api/billing/queue                | List billing queue              |
| POST   | /api/billing/queue/next           | Dequeue next patient            |
| GET    | /api/billing/bills/{bill_id}      | Get bill details                |
| POST   | /api/billing/bills                | Create consolidated bill        |
| PUT    | /api/billing/bills/{id}/discount  | Apply discount                  |
| POST   | /api/billing/bills/{id}/split     | Split bill                      |
| DELETE | /api/billing/bills/{id}           | Void bill                       |

### Payment Endpoints

| Method | Endpoint                                 | Description                     |
|--------|------------------------------------------|---------------------------------|
| POST   | /api/billing/payments                    | Record a payment                |
| POST   | /api/billing/payments/refund             | Process a refund                |
| GET    | /api/billing/payments/pending            | List pending payments           |
| PUT    | /api/billing/payments/{id}/confirm-upi   | Confirm UPI transaction         |

### Invoice Endpoints

| Method | Endpoint                                   | Description                     |
|--------|--------------------------------------------|---------------------------------|
| POST   | /api/billing/invoices/generate             | Generate GST invoice            |
| GET    | /api/billing/invoices/{invoice_id}         | Get invoice details             |
| GET    | /api/billing/invoices/{id}/pdf             | Download invoice PDF            |
| POST   | /api/billing/invoices/{id}/email           | Email invoice to patient        |
| DELETE | /api/billing/invoices/{id}                 | Cancel invoice                  |

### Reporting Endpoints

| Method | Endpoint                                   | Description                     |
|--------|--------------------------------------------|---------------------------------|
| GET    | /api/billing/reports/daily-settlement      | Get daily settlement report     |
| GET    | /api/billing/reports/daily-revenue         | Daily revenue summary           |
| GET    | /api/billing/reports/monthly-revenue       | Monthly revenue summary         |
| GET    | /api/billing/reports/outstanding           | Outstanding / overdue report    |
| GET    | /api/billing/reports/tax-summary           | GST tax summary by period       |

## 15. CONFIGURATION

```python
ACCOUNTANT_CONFIG = {
    "tax_rates": {
        "sgst": 0.09,
        "cgst": 0.09,
        "igst": 0.18,
    },
    "discount_thresholds": {
        "percent_auto_approve": 10,
        "percent_manager_approve": 20,
        "flat_auto_approve": 500.00,
        "flat_manager_approve": 2000.00,
    },
    "payment_methods": {
        "enabled": ["cash", "upi", "card", "insurance", "credit"],
        "upi_id": "gilclinic@upi",
        "upi_qr_static": "/assets/qr/gilclinic-upi.png",
    },
    "overdue_escalation_days": {
        "sms_reminder": 3,
        "email_reminder": 7,
        "collections": 15,
        "high_risk": 30,
        "write_off": 90,
    },
    "billing": {
        "invoice_prefix": "INV-",
        "bill_prefix": "BIL-",
        "default_due_days": 15,
        "auto_generate_invoice_on_payment": True,
        "print_receipt_on_payment": True,
    },
    "settlement": {
        "auto_lock_at": "23:59",
        "variance_threshold": 100.00,
    },
}
```

## 16. KEY DESIGN DECISIONS

1. **Consolidated Bill Over Modular Bills**: Rather than separate bills per department (doctor/lab/pharmacy), a single visit-level bill aggregates all charges. This gives patients one payable amount, simplifies reconciliation, and enables a single GST invoice per visit.

2. **Negative Payments for Refunds**: Refunds are recorded as negative payment entries in the payments table rather than a separate refunds table. This keeps the accounting ledger simple and allows the balance_amount computed column on bills to automatically reflect refunds.

3. **Queue as First-Class Entity**: The billing_queue table decouples bill state from the visit lifecycle. This allows the cashier to manage flow (hold, skip, prioritize) without mutating visit or bill data.

4. **Async UPI Confirmation**: UPI payments are recorded as awaiting_confirmation with a webhook listener. This handles the real-world delay in UPI settlement while preventing the cashier from releasing the patient before funds clear.

5. **Stored Computed Columns for Tax**: taxable_value and balance_amount are generated columns -- computed by the database, never stale, and queryable directly for reports.

6. **Discount Approval Tiers**: Three-tier approval (cashier/manager/admin) is enforced at the API layer and reflected in the approved_by field on the payment record. No discount can be applied silently.

7. **Insurance Claim Separate from Payment**: Insurance claims are tracked in their own table because the lifecycle (submission -> approval -> settlement) is longer and more complex than a simple payment. The payments table records only the final settled amount from the TPA.

8. **HSN Codes at Line-Item Level**: Every bill item carries an HSN code. This enables granular GST reporting and allows the invoice generator to group items by tax rate dynamically.

9. **Daily Settlement Variance Reporting**: The cashier physically counts the drawer and enters the total; the system compares it against the recorded cash total and flags any variance. This catches errors (overpayment, short-change) at EOD rather than at month-end.

10. **Split Bills Create Sub-Bills**: Rather than dividing a single payment record, splitting creates child bills (BIL-099-A, BIL-099-B) each with their own balance tracking. This preserves audit trail and makes it clear who has or hasn't paid.
