---
file_id: "0200"
module_name: "Patient Module"
version: "1.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0105_AUTH_ENGINE.md", "0103_NOTIFICATION_ENGINE.md"]
related_files: ["0600_PATIENT_APP.md", "0601_PATIENT_TIMELINE.md", "0602_PATIENT_TRACKING.md", "0603_APPOINTMENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "patient", "self-service", "portal", "journey"]
---

# 👤 GHOS — Patient Module

> **The Patient Module is the patient's window into GHOS. No app install, no login, no password — just scan a QR code or click a WhatsApp link and see your entire hospital journey in real time.**

---

## 1. PURPOSE

The Patient Module provides every patient with:
- **Zero-friction access** — No account creation, no password, no OTP required for basic status viewing
- **Real-time visibility** — See queue position, wait time, and journey progress
- **Instant alerts** — Sound + vibration when called, routed, or report ready
- **Complete history** — Past visits, reports, and prescriptions in one place
- **Communication** — One-tap call to reception, WhatsApp chat, feedback submission

---

## 2. ACCESS METHODS

### 2.1 QR Code Scan (Fastest)
```
Patient receives WhatsApp message with QR code at registration
  → Opens clinic's PWA or camera app
  → Scans QR code
  → Auto-loads visit status page
  → No input needed — page is live and auto-refreshing
```

### 2.2 WhatsApp Link
```
Patient clicks "Track Your Visit" link in WhatsApp message
  → Opens in phone browser
  → Signed token verified
  → Visit status page loads
  → Link expires after visit completes
```

### 2.3 Mobile Number Entry
```
Patient visits clinic PWA URL
  → Sees "Enter your mobile number" field
  → Enters number → clicks "View Status"
  → If number matches active visit → loads dashboard
  → If no active visit → shows "No active visit found" with option to call clinic
  → No OTP needed for status-only view (OTP required for sensitive actions)
```

### 2.4 Missed Call Detection
```
Patient misses their turn (called but didn't arrive)
  → Staff marks as "missed"
  → System sends WhatsApp/SMS: "You missed your turn. Click here to re-queue."
  → Patient clicks link → re-enters queue at position after current patient
  → Special "re-queued" status shown on dashboard
```

### 2.5 Direct URL (for follow-ups)
```
Patient receives follow-up reminder
  → URL contains visit reference + signed token
  → Opens full history view instead of current visit
  → Can book follow-up appointment from here
```

---

## 3. PATIENT DASHBOARD (Status Page)

The status page is the core UI — it's what the patient sees when tracking their visit.

```
┌──────────────────────────────────────────────┐
│  🏥 GIL CLINIC                     🔄 Live   │
│  📍 Cardiology — Dr. Sharma                  │
├──────────────────────────────────────────────┤
│                                              │
│  👋 Welcome back, Rajesh Kumar               │
│  📋 Token: CRD-042                    ⭐ ID: │
│                                              │
│  ┌─── YOUR JOURNEY ──────────────────────┐   │
│  │                                        │   │
│  │  ✅ Registration     ── 09:15 AM      │   │
│  │       │                                │   │
│  │  🔵 DOCTOR (You are here) ── Wait ~12 │   │
│  │       │                    min         │   │
│  │  ⏳ ECG                               │   │
│  │       │                                │   │
│  │  ⏳ Pharmacy                           │   │
│  │       │                                │   │
│  │  ⬜ Billing                            │   │
│  └────────────────────────────────────────┘   │
│                                              │
│  ⏱ Estimated wait: 12 minutes                │
│  👥 Ahead of you: 2 patients                 │
│  📍 Current at: Room 3                        │
│                                              │
│  [🔔 I'm Here!]   [📞 Call Reception]        │
│                                              │
│  ── Need Help? ──                            │
│  💬 Chat on WhatsApp  📋 Past Visits         │
│  📄 My Reports       ⭐ Rate Your Visit      │
│                                              │
│  🔄 Auto-refreshes every 5 seconds           │
└──────────────────────────────────────────────┘
```

### Dashboard States

| State | Banner Color | Description |
|-------|-------------|-------------|
| Waiting | 🔵 Blue | In queue, not yet called |
| Called | 🟢 Green | Currently being served |
| Routed | 🟠 Orange | Being sent to next department |
| Completed | ✅ Green | Visit completed |
| Missed | 🔴 Red | Patient didn't respond when called |
| Re-queued | 🟣 Purple | Patient rejoined after missing |

---

## 4. PATIENT JOURNEY TIMELINE

The timeline is the centerpiece of the patient dashboard. It shows every step of the visit with status.

```json
{
  "visit_id": "uuid",
  "patient_name": "Rajesh Kumar",
  "current_step": "doctor",
  "steps": [
    {
      "id": "registration",
      "name": "Registration",
      "status": "completed",
      "timestamp": "2026-07-09T09:15:00",
      "details": "Counter 2, Receptionist: Ananya"
    },
    {
      "id": "doctor",
      "name": "Doctor Consultation",
      "status": "in_progress",
      "wait_time_minutes": 12,
      "patients_ahead": 2,
      "location": "Room 3, Dr. Sharma",
      "estimated_at": "2026-07-09T09:30:00"
    },
    {
      "id": "ecg",
      "name": "ECG Test",
      "status": "pending",
      "wait_time_minutes": null,
      "location": "ECG Room 1"
    },
    {
      "id": "pharmacy",
      "name": "Pharmacy",
      "status": "pending",
      "wait_time_minutes": null,
      "location": "Pharmacy Counter"
    },
    {
      "id": "billing",
      "name": "Billing",
      "status": "pending",
      "location": "Billing Counter"
    }
  ]
}
```

### Timeline UI Behavior

- **Completed steps** — Green checkmark, time displayed, clickable for details
- **Current step** — Blue pulsing dot, shows wait time, location, patients ahead
- **Upcoming steps** — Gray with clock icon, shows department name
- **Skipped steps** — Crossed out, reason shown (e.g., "Not required per doctor")
- **Animated transitions** — When status changes, step animates from pending → active
- **Sound trigger** — When any step becomes active → play notification sound

---

## 5. NOTIFICATIONS & ALERTS

### Alert Types

| Alert | Trigger | Action |
|-------|---------|--------|
| Called | Staff clicks "Call" | Sound + vibration, banner: "Your turn! Room 3" |
| Routed | Visit moves to next dept | Sound, banner: "Please go to ECG Department" |
| Report Ready | Doctor signs report | Push notification: "Your reports are ready" |
| Reminder | Patient hasn't arrived 2min after call | Vibration, banner: "Doctor is waiting!" |
| Missed Call | Patient missed turn | WhatsApp: "You missed your turn. Re-queue?" |
| Status Change | Queue position changed | Silent update on dashboard |
| Appointment Reminder | 24h before appointment | WhatsApp notification |
| Follow-up Due | Based on doctor's recommendation | WhatsApp + notification |

### Sound System

```javascript
// JavaScript-based alert system (PWA)
function playAlert(type) {
  const ctx = new (window.AudioContext || window.webkitAudioContext)();
  const osc = ctx.createOscillator();
  const gain = ctx.createGain();
  osc.connect(gain);
  gain.connect(ctx.destination);

  switch(type) {
    case 'called':
      // Triple ascending beep — 523Hz → 659Hz → 784Hz
      osc.frequency.setValueAtTime(523, ctx.currentTime);
      osc.frequency.setValueAtTime(659, ctx.currentTime + 0.15);
      osc.frequency.setValueAtTime(784, ctx.currentTime + 0.3);
      gain.gain.setValueAtTime(0.5, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.6);
      if (navigator.vibrate) navigator.vibrate([200, 100, 200]);
      break;

    case 'routed':
      // Double beep — 660Hz → 880Hz
      osc.frequency.setValueAtTime(660, ctx.currentTime);
      osc.frequency.setValueAtTime(880, ctx.currentTime + 0.2);
      gain.gain.setValueAtTime(0.4, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.4);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.4);
      if (navigator.vibrate) navigator.vibrate([100, 50, 100]);
      break;

    case 'report_ready':
      // Single long beep
      osc.frequency.setValueAtTime(440, ctx.currentTime);
      gain.gain.setValueAtTime(0.3, ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5);
      osc.start(ctx.currentTime);
      osc.stop(ctx.currentTime + 0.5);
      break;
  }
}
```

---

## 6. PATIENT HISTORY

### Past Visits View
```
┌──────────────────────────────────┐
│  📋 Past Visits (Last 5)         │
├──────────────────────────────────┤
│  ┌────────────────────────────┐  │
│  │ 08-Jul-2026 │ Cardiology   │  │
│  │ Dr. Sharma  │ ✅ Completed │  │
│  │ [View Details] [Reports]   │  │
│  ├────────────────────────────┤  │
│  │ 01-Jul-2026 │ General OPD │  │
│  │ Dr. Singh   │ ✅ Completed │  │
│  │ [View Details] [Reports]   │  │
│  ├────────────────────────────┤  │
│  │ 15-Jun-2026 │ Cardiology   │  │
│  │ Dr. Sharma  │ ❌ Missed    │  │
│  │ [View Details]             │  │
│  └────────────────────────────┘  │
│                                  │
│  [Load More →]                   │
└──────────────────────────────────┘
```

### Visit Detail View
```
┌──────────────────────────────────┐
│  Visit — 08-Jul-2026             │
│  Cardiology — Dr. Sharma         │
├──────────────────────────────────┤
│  Timeline:                       │
│  ✅ 09:15 Registration           │
│  ✅ 09:42 Doctor (Room 3)       │
│  ✅ 10:05 ECG (Room 1)          │
│  ✅ 10:20 Pharmacy               │
│  ✅ 10:25 Billing                │
│                                  │
│  Diagnosis: Hypertension         │
│  Prescription: Amlodipine 5mg    │
│  Reports: ECG Report             │
│           [Download PDF]         │
│                                  │
│  Total Bill: ₹1,250              │
│  Paid: ✅ Yes                    │
└──────────────────────────────────┘
```

---

## 7. CALL RECEPTION FEATURE

The "Call Reception" button on the dashboard allows patients to request a call back from reception without revealing their phone number.

```python
class CallReceptionFeature:
    """
    Patient-side call request system.
    
    Flow:
    1. Patient clicks "Call Reception" on dashboard
    2. System checks if reception is available (staffed)
    3. Creates a call-request entry in DB
    4. Reception gets real-time alert (sound + notification)
    5. Reception clicks "Call Back" → system initiates call to patient
    6. Both parties connected — patient gets incoming call from clinic
    """
    
    async def request_call(self, patient_id: UUID, visit_id: UUID, reason: str = None):
        """Patient requests a callback from reception."""
        # Check if reception is staffed
        reception_staff = await StaffUser.filter(
            role="receptionist",
            is_clocked_in=True,
            active=True
        ).count()
        
        if reception_staff == 0:
            return {"success": False, "message": "Reception is currently closed. Please call during clinic hours."}
        
        # Create request
        request = await CallRequest.create(
            patient_id=patient_id,
            visit_id=visit_id,
            reason=reason or "Patient requested callback",
            status="pending",
            created_at=datetime.now()
        )
        
        # Notify reception staff
        await NotificationOrchestrator().send(
            notification_type="callback_requested",
            data={
                "patient_name": (await Patient.get(patient_id)).name,
                "visit_id": str(visit_id),
                "reason": reason,
                "request_id": str(request.id)
            },
            target_roles=["receptionist"]
        )
        
        return {"success": True, "message": "Reception will call you shortly."}
```

---

## 8. FEEDBACK SYSTEM

After visit completion, prompt patient for feedback:

```json
{
  "prompt": "How was your experience today?",
  "rating": 1-5 (stars),
  "categories": {
    "wait_time": 1-5,
    "doctor_behavior": 1-5,
    "staff_behavior": 1-5,
    "cleanliness": 1-5,
    "overall": 1-5
  },
  "comment": "Optional text feedback"
}
```

Embedded in dashboard after status changes to "completed":
- Shows as a slide-up card at bottom of page
- One tap to rate (5 stars)
- Optional comment field expands if tapped
- Submitted asynchronously (doesn't block anything)

---

## 9. DATA MODEL

```sql
CREATE TABLE patient_visit_status_cache (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID UNIQUE NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    current_department VARCHAR(100),
    current_step VARCHAR(100),
    step_status VARCHAR(20),
    estimated_wait_minutes INTEGER,
    patients_ahead INTEGER,
    location VARCHAR(200),
    timeline JSONB,
    last_updated TIMESTAMP DEFAULT NOW()
);

CREATE TABLE call_requests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    visit_id UUID REFERENCES visits(id),
    reason VARCHAR(500),
    status VARCHAR(20) DEFAULT 'pending',
    handled_by UUID REFERENCES staff_users(id),
    handled_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE patient_sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL,
    session_token VARCHAR(500) NOT NULL,
    device_info VARCHAR(500),
    expires_at TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_visit_status_visit ON patient_visit_status_cache(visit_id);
CREATE INDEX idx_visit_status_patient ON patient_visit_status_cache(patient_id);
CREATE INDEX idx_call_requests_status ON call_requests(status, created_at);
CREATE INDEX idx_patient_sessions_token ON patient_sessions(session_token);
```

---

## 10. API ENDPOINTS

```python
# Patient-facing API

@router.get("/api/v1/patient/status")
async def get_visit_status(
    token: str = Query(None),     # Signed token from QR/link
    mobile: str = Query(None),     # Mobile number lookup
    visit_id: UUID = Query(None)   # Direct visit ID (admin only)
):
    """Get current visit status for patient dashboard."""
    # Resolve visit from token, mobile, or visit_id
    ...


@router.get("/api/v1/patient/history")
async def get_patient_history(
    patient_id: UUID,
    limit: int = 5,
    offset: int = 0
):
    """Get patient visit history."""
    ...


@router.post("/api/v1/patient/call-request")
async def request_callback(
    patient_id: UUID,
    visit_id: UUID,
    reason: str = None
):
    """Request a callback from reception."""
    ...


@router.post("/api/v1/patient/feedback")
async def submit_feedback(
    visit_id: UUID,
    rating: int,
    categories: dict,
    comment: str = None
):
    """Submit visit feedback."""
    ...


@router.get("/api/v1/patient/notifications")
async def get_notifications(
    patient_id: UUID,
    since: datetime = None
):
    """Get pending notifications for patient."""
    ...
```

---

## 11. CONFIGURATION

```yaml
patient_module:
  dashboard:
    auto_refresh_seconds: 5
    show_past_visits: 5
    max_history_load: 50
  
  access:
    qr_expiry_hours: 24
    link_expiry_hours: 24
    mobile_lookup_without_otp: true
    
  notifications:
    sound_enabled: true
    vibration_enabled: true
    misscall_alert_delay_seconds: 120
    reminder_interval_seconds: 60
  
  call_request:
    enabled: true
    max_daily_requests: 5
    cooldown_minutes: 2
  
  feedback:
    prompt_on_completion: true
    prompt_delay_seconds: 30
    allow_anonymous: false
```

---

## 12. KEY DESIGN DECISIONS

1. **Zero-login access** — Patients should never need a password. QR and signed links provide secure, frictionless access.
2. **Single page, all info** — Everything the patient needs is on one auto-refreshing page. No navigation, no menus.
3. **Visual timeline** — Journey visualization reduces anxiety. Patient can see exactly where they are and what's next.
4. **Sound + vibration** — Audio alerts are critical in a busy clinic. Patient doesn't need to watch the screen.
5. **No app required** — PWA works in any browser. Share a link, done. No app store, no updates, no permissions.
6. **Cookie-free sessions** — Signed tokens in URL work across devices. Patient can share link with family member.
7. **Reception callback** — Two-way communication without exposing phone numbers. Privacy + convenience.
