---
file_id: "0202"
module_name: "Reception Module"
version: "1.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0102_TOKEN_ENGINE.md", "0107_SEARCH_ENGINE.md"]
related_files: ["0200_PATIENT_MODULE.md", "0603_APPOINTMENT.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "reception", "registration", "patient-intake", "front-desk"]
---

# 🏢 GHOS — Reception Module

> **The Reception Module is the front door of the hospital. It handles patient intake in under 30 seconds — search existing patient or register new, assign departments, print token, and send them on their way. Speed and accuracy at the front desk determine the entire patient experience.**

---

## 1. PURPOSE

The Reception Module is the fastest, most frequently used interface in GHOS. Every patient visit starts here.

Core functions:
- **Patient search** — Find existing patients in under 1 second
- **Patient registration** — New patient intake (name, mobile, age, gender)
- **Visit creation** — Assign departments, visit type, priority
- **Token printing** — Generate and print token slip
- **Queue overview** — See real-time queue for all departments
- **Walk-in management** — Handle patients without appointments
- **Appointment check-in** — Mark arrived patients for scheduled appointments

---

## 2. RECEPTION DASHBOARD

```
┌──────────────────────────────────────────────────────────────┐
│  🏥 Reception Desk — Anjanya                       09:42 AM  │
│  📊 Today: 78 registered  │  Avg time: 28s/patient          │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─── NEW PATIENT ───────────────────────────────────────┐   │
│  │  🔍 Search: [Raj_________]        📋 Last 5 visits    │   │
│  │                                                       │   │
│  │  ┌──────────────────────────────────────────┐         │   │
│  │  │ Rajesh Kumar  ⭐ 9876543210              │         │   │
│  │  │ Last: 2 days ago │ Visits: 12 │ Age: 45  │         │   │
│  │  │ [New Visit] [History] [Edit Details]     │         │   │
│  │  ├──────────────────────────────────────────┤         │   │
│  │  │ Rajendra Singh  9876543211               │         │   │
│  │  │ Last: 15 days ago │ Visits: 3 │ Age 52  │         │   │
│  │  │ [New Visit] [History] [Edit Details]     │         │   │
│  │  └──────────────────────────────────────────┘         │   │
│  │                                                       │   │
│  │  [➕ Register New Patient]                            │   │
│  └───────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─── TODAY'S QUEUE ─────────────────────────────────────┐   │
│  │  🟢 Doctor: 42 waiting  │  Avg wait: 12 min          │   │
│  │  🔵 ECG: 28 waiting     │  Avg wait: 8 min           │   │
│  │  🟣 Lab: 15 waiting     │  Avg wait: 5 min           │   │
│  │  🟠 Echo: 10 waiting    │  Avg wait: 15 min          │   │
│  │  🟡 Pharmacy: 33 waiting│  Avg wait: 3 min           │   │
│  └───────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─── RECENT REGISTRATIONS ─────────────────────────────┐   │
│  │  ⏱ 09:40 │ DOC-045 │ Priya Singh    → Doctor         │   │
│  │  ⏱ 09:38 │ ECG-018 │ Amit Verma     → ECG            │   │
│  │  ⏱ 09:35 │ LAB-012 │ Sunita Sharma  → Lab            │   │
│  │  ⏱ 09:32 │ DOC-044 │ Vikram Patel   → Doctor         │   │
│  └───────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. REGISTRATION FLOW

### 3.1 Returning Patient (Fast Path) — 15 seconds
```
1. Receptionist starts typing name or mobile in search bar
2. Autocomplete shows matching patients within 300ms
3. Receptionist selects patient → "Welcome back!" banner shown
4. Quick visit form appears (pre-filled with patient data):
   - Visit Type: [New Consultation / Follow-up / Emergency]
   - Department: [Select from mapped departments]
   - Priority: [Normal / Senior / VIP]
   - Referred By: [Optional]
5. Click "Register & Print" → Done
6. System: Creates visit → Assigns token → Adds to queue → Prints token
7. Patient receives WhatsApp notification with token and tracking link
```

### 3.2 New Patient (Full Registration) — 45 seconds
```
1. Receptionist clicks "Register New Patient"
2. Fills required fields:
   - Name (required)
   - Mobile number (required, validated: 10 digits)
   - Age (required, or DOB)
   - Gender (required: M/F/O)
   - Address (optional)
   - Email (optional)
3. Auto-checks: duplicate mobile? → warning shown
4. Visit details:
   - Visit Type: [New / Follow-up / Emergency]
   - Department: [Select, can select multiple]
   - Priority: [Normal / Senior / VIP]
5. Click "Register & Print" → Done
6. System: Creates patient → Creates visit → Assigns token → Adds to queue → Prints token
7. Patient receives WhatsApp welcome message + tracking link
```

### 3.3 Emergency Registration (Fastest Path) — 10 seconds
```
1. Receptionist clicks "⚠️ Emergency" button (always visible)
2. Minimal form: Name + Mobile (or skip name, use "Unknown")
3. Auto-assigns: priority=Emergency, department=Emergency
4. Token generated immediately — patient can be rushed in
5. Full details can be filled later by nurse/doctor
```

---

## 4. PATIENT SEARCH

Search is the most-used function at reception. It must be instant and fuzzy.

```python
class ReceptionSearch:
    """
    Optimized patient search for reception desk.
    
    Performance targets:
    - Autocomplete response: < 300ms
    - Full search response: < 500ms
    - Must handle typos, partial names, transliterations
    """
    
    async def search(self, query: str, hospital_id: UUID) -> List[dict]:
        """Search patients with reception-specific context."""
        engine = PatientSearch()
        patients = await engine.search(query, hospital_id, limit=10)
        
        # Enrich with reception context
        results = []
        for p in patients:
            # Get last visit info
            last_visit = await Visit.filter(
                patient_id=UUID(p.id)
            ).order_by("-created_at").first()
            
            results.append({
                **p.dict(),
                "last_visit_days": (date.today() - last_visit.created_at.date()).days if last_visit else None,
                "last_department": last_visit.department.name if last_visit else None,
                "total_visits": await Visit.filter(patient_id=UUID(p.id)).count(),
                "has_active_visit": p.active_visit_id is not None
            })
        
        return results
    
    async def search_by_mobile_prefix(self, prefix: str, hospital_id: UUID) -> List[dict]:
        """Search by mobile number prefix (for SMS/WhatsApp lookups)."""
        patients = await Patient.filter(
            hospital_id=hospital_id,
            mobile__contains=prefix
        ).limit(10).all()
        
        return [{
            "id": str(p.id),
            "name": p.name,
            "mobile": p.mobile,
            "active_visit": str(p.active_visit_id) if p.active_visit_id else None
        } for p in patients]
```

---

## 5. TOKEN PRINTING

```python
class TokenPrinter:
    """
    Thermal token printer integration.
    
    Supports:
    - USB thermal printers (EPSON, Star Micronics)
    - Network printers (via IP)
    - Bluetooth printers (for mobile reception)
    - Virtual PDF (for testing)
    
    Token slip format:
    ┌─────────────────────┐
    │  GIL CLINIC         │
    │  Token: DOC-042     │
    │  Patient: Rajesh K  │
    │  Dept: Cardiology    │
    │  Dr: Sharma          │
    │  Time: 09:42 AM     │
    │                     │
    │  Wait: ~15 min      │
    │  Track: bit.ly/...  │
    │                     │
    │  📱 Scan to track   │
    │  [    QR CODE     ] │
    └─────────────────────┘
    """
    
    TOKEN_TEMPLATE = """
    ╔═════════════════════════╗
    ║  {hospital_name}        ║
    ║  ─────────────────────  ║
    ║  TOKEN: {token_number}  ║
    ║  {patient_name}         ║
    ║  {department}           ║
    ║  {timestamp}            ║
    ║                         ║
    ║  Wait: ~{wait} min      ║
    ║  Track: {short_url}     ║
    ║  ─────────────────────  ║
    ║  [     QR CODE     ]    ║
    ╚═════════════════════════╝
    """
    
    async def print_token(self, visit: Visit, patient: Patient):
        """Print a token slip for the visit."""
        token = await TokenEngine().generate_token(visit)
        
        slip = self.TOKEN_TEMPLATE.format(
            hospital_name=settings.HOSPITAL_NAME,
            token_number=token.display_number,
            patient_name=patient.name[:20],  # Truncate for thermal
            department=visit.department.name,
            timestamp=datetime.now().strftime("%I:%M %p"),
            wait=visit.estimated_wait_minutes,
            short_url=await self._generate_short_url(visit)
        )
        
        # Send to printer
        await self._send_to_printer(slip)
        
        # Also send QR code to patient's WhatsApp
        await self._send_qr_whatsapp(patient, visit)
    
    async def _send_to_printer(self, slip: str):
        """Send to configured thermal printer."""
        printer_type = settings.RECEPTION_PRINTER_TYPE
        if printer_type == "usb":
            # Direct USB connection
            await self._print_usb(slip)
        elif printer_type == "network":
            # Network printer
            await self._print_network(slip)
        elif printer_type == "bluetooth":
            # Bluetooth
            await self._print_bluetooth(slip)
```

---

## 6. WALK-IN MANAGEMENT

### Queue at a Glance
Reception sees a real-time summary of all department queues:
- Color-coded by wait time (green < 10min, yellow 10-20min, red > 20min)
- Click any department to drill into detailed queue
- Quick action: "Pull next patient to X department"

### Check-in Flow
```
Patient walks in (has appointment)
  → Receptionist searches → finds patient → "Appointment at 10 AM"
  → Clicks "Check In"
  → Visit created, token generated, patient added to queue
  → WhatsApp notification sent

Patient walks in (no appointment)
  → Receptionist registers as walk-in
  → Added to queue at the end
  → Estimated wait displayed
```

---

## 7. REPORTING

```python
class ReceptionReports:
    """Daily/periodic reports for reception desk."""
    
    async def get_daily_summary(self, hospital_id: UUID, date: date = None):
        date = date or date.today()
        
        total = await Visit.filter(
            hospital_id=hospital_id,
            created_at__gte=date,
            created_at__lt=date + timedelta(days=1)
        ).count()
        
        new_patients = await self._count_new_patients(hospital_id, date)
        walkins = await self._count_walkins(hospital_id, date)
        appointments = await self._count_appointments(hospital_id, date)
        
        return {
            "date": date.isoformat(),
            "total_registrations": total,
            "new_patients": new_patients,
            "returning": total - new_patients,
            "walkins": walkins,
            "appointments": appointments,
            "avg_registration_time_seconds": await self._avg_reg_time(hospital_id, date),
            "peak_hour": await self._peak_hour(hospital_id, date),
            "by_department": await self._by_department(hospital_id, date)
        }
```

---

## 8. RECEPTION SETTINGS

```yaml
reception:
  search:
    autocomplete_min_chars: 1
    max_results: 10
    cache_ttl_seconds: 300
  
  registration:
    emergency_flow_enabled: true
    require_mobile: true
    min_age: 0
    max_age: 150
    duplicate_mobile_warning: true
    
  token_printing:
    enabled: true
    printer_type: "network"      # usb, network, bluetooth, virtual
    printer_ip: "192.168.1.100"
    paper_width_mm: 58
    qr_code_on_slip: true
    short_url_enabled: true
    
  quick_actions:
    show_department_queue: true
    show_recent_registrations: true
    recent_count: 10
  
  performance:
    target_registration_seconds: 30
    alert_if_exceeds_seconds: 60
    max_patients_per_hour: 40
```

---

## 9. KEY DESIGN DECISIONS

1. **Search-first interface** — The most common action at reception is finding a patient. Search is the default focus, not a popup.
2. **Autocomplete with context** — Show last visit, total visits, and active status inline so receptionist knows who they're dealing with.
3. **Returning patient fast path** — Pre-filled forms for known patients. 15 seconds instead of 45.
4. **Emergency bypass** — 10-second registration for emergencies. Details can be filled later.
5. **Queue at a glance** — Reception needs to know which departments are busy to direct patients efficiently.
6. **Token + WhatsApp** — Printed token for the patient's pocket, WhatsApp link for digital tracking.
7. **One-click registration** — Minimum clicks to register. Search → Select → Department → Register.
