---
file_id: "0206"
module_name: "Lab Technician Module"
version: "1.0"
status: "Draft"
phase: "Phase 2 - User Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0101_WORKFLOW_ENGINE.md"]
related_files: ["0201_DOCTOR_MODULE.md", "0205_NURSE_MODULE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "lab", "technician", "tests", "lis", "quality-control"]
---

# 🔬 GHOS - Lab Technician Module

> **The Lab Technician Module is the clinical lab's operational hub. It manages the full test lifecycle: sample collection, test execution, result recording, quality control, LIS integration, and result dissemination to doctors. Designed for accuracy, traceability, and speed.**

---

## 1. PURPOSE

The Lab Technician Module handles every aspect of the laboratory workflow:

- **Test queue management** - View and call patients from the lab queue, ordered by priority
- **Sample collection** - Tube selection, labeling, barcode printing, and chain-of-custody tracking
- **Test result entry** - Manual and auto-imported results with reference ranges and flagging
- **Quality control** - Daily QC tracking, control sample validation, and lot tracking
- **LIS integration** - Auto-import results from connected analyzers (hematology, chemistry, immunoassay)
- **Abnormal flagging** - Automatic flagging of high/low/critical values with clinical alerts
- **Result notification** - Real-time WebSocket push to doctor dashboards when results are ready
- **Pending results review** - Doctors review and sign completed lab reports

---


## 2. LAB TECHNICIAN DASHBOARD

```
+----------------------------------------------------------------------+
|  🔬 Lab Station - Station 1                     Dr. Sharma's Clinic  |
|  📊 Today: 47 orders | Completed: 32 | Pending: 12 | QC: ✅ Passed  |
+----------------------------------------------------------------------+
|                                                                      |
|  +--- CURRENT PATIENT ------------------------------------------+   |
|   |   LAB-015 | Rajesh Kumar (45/M) | ⏱ Elapsed: 4:20           |   |
|   |   -- Tests Ordered --                                       |   |
|   |   +--------------------------------------------------+      |   |
|   |   | ✅ CBC        [Enter Results ->]  ⏳ Running      |      |   |
|   |   | ⏳ Lipid Profile              [Enter Results ->]  |      |   |
|   |   | ⏳ TSH                        [Enter Results ->]  |      |   |
|   |   +--------------------------------------------------+      |   |
|   |   Sample ID: S-20260709-015 | Collected: 09:15 AM          |   |
|   |                                                             |   |
|   |   [🔬 Run Selected] [✏️ Enter Results] [✅ Mark Complete]    |   |
|   +-------------------------------------------------------------+   |
|                                                                      |
|  +--- WAITING QUEUE --------------------------------------------+   |
|   |  #  | Token | Patient         | Tests         | Wait  | Stat |   |
|   |  --------------------------------------------------------    |   |
|   |  1  | 016   | Priya Singh     | HbA1c, FBS    | 8:20 |       |   |
|   |  2  | 017   | Mohan Lal (60+) | CBC, LFT, KFT | 6:15 | ⭐    |   |
|   |  3  | 018   | Sunil Verma     | Lipid          | 4:30 | ⚠️    |   |
|   |  4  | 019   | Anita Devi      | TSH, T3, T4   | 2:10 |       |   |
|   |  [📞 Call Next] [🔄 Refresh] [📋 Print List]                  |   |
|   +-------------------------------------------------------------+   |
|                                                                      |
|  +--- PENDING DOCTOR REVIEW -----------------------------------+   |
|   |  🔔 8 results pending doctor sign-off                       |   |
|   |  [View Pending Reports ->]                                   |   |
|   +-------------------------------------------------------------+   |
|                                                                      |
|  +--- QC STATUS -----------------------------------------------+   |
|   |  ✅ Control Level 1: Pass (Lot: QC-LOT-042)                |   |
|   |  ✅ Control Level 2: Pass (Lot: QC-LOT-042)                |   |
|   |  ⏰ Next QC due: 14:00 (2h from now)                       |   |
|   |  [🧪 Run QC]                                                |   |
|   +-------------------------------------------------------------+   |
+----------------------------------------------------------------------+
```

---

## 3. LAB WORKFLOW

```
+-----------+    +--------------+    +---------+    +--------------+
|  CALL     |--->|  COLLECT     |--->|  RUN    |--->|  ENTER       |
|  Patient  |    |  Sample      |    |  Tests  |    |  Results      |
+-----------+    +--------------+    +---------+    +------+-------+
                                                             |
                                                             v
                                                    +--------------+
                                                    |  FLAG        |
                                                    |  Abnormals   |
                                                    +------+-------+
                                                             |
                                                             v
                                                    +--------------+    +---------------+
                                                    |  NOTIFY      |--->|  DOCTOR       |
                                                    |  Results     |    |  Reviews      |
                                                    +--------------+    +-------+-------+
                                                                                |
                                                                                v
                                                                       +--------------+
                                                                       |  SIGN &      |
                                                                       |  Finalize    |
                                                                       +--------------+
```

### Step-by-Step Workflow

| Step | Action | System Effect |
|------|--------|---------------|
| **1. Call Patient** | Tech clicks "Call Next" | Queue engine dequeues patient; token displayed on lab screen; SMS/display notification sent |
| **2. Collect Sample** | Select tube type, print barcode label, verify patient ID | Sample record created; status = "collected"; tube count tracked |
| **3. Run Tests** | Tech loads sample on analyzer (manual) or system routes to LIS | Test status = "running"; timer started; TAT tracking begins |
| **4. Enter Results** | Manual entry or LIS auto-import | Results stored; reference range comparison performed |
| **5. Flag Abnormals** | System auto-flags high/low/critical; tech reviews | Flags (H/L/Critical) set on result; alert generated if critical |
| **6. Notify Doctor** | Results published to doctor's pending review queue | WebSocket push; notification sent to doctor dashboard |
| **7. Doctor Reviews** | Doctor opens report, reviews, adds clinical notes | Report status = "reviewed" |
| **8. Sign & Finalize** | Doctor signs electronically | Report finalized; patient can access via portal |

---


## 4. SAMPLE COLLECTION MANAGEMENT

```python
class SampleCollectionManager:
    """
    Manages sample collection workflow including tube selection,
    label printing, barcode generation, and chain-of-custody.
    """

    TUBE_TYPES = {
        "purple": {"name": "EDTA",       "volume_ml": 3, "tests": ["CBC", "HbA1c"]},
        "red":    {"name": "Plain/Clot",  "volume_ml": 5, "tests": ["LFT", "KFT", "Lipid"]},
        "blue":   {"name": "Citrate",     "volume_ml": 2, "tests": ["PT", "APTT", "INR"]},
        "green":  {"name": "Heparin",     "volume_ml": 4, "tests": ["ABG", "Electrolytes"]},
        "yellow": {"name": "ACD",         "volume_ml": 8, "tests": ["Culture", "HLA"]},
        "gray":   {"name": "Fluoride",    "volume_ml": 2, "tests": ["Glucose", "Lactate"]},
    }

    async def collect_sample(
        self, order_id: UUID, tube_type: str, collected_by: UUID
    ) -> SampleRecord:
        """Record sample collection with barcode generation."""
        tube = self.TUBE_TYPES[tube_type]

        sample = await Sample.create(
            order_id=order_id,
            tube_type=tube_type,
            tube_name=tube["name"],
            volume_ml=tube["volume_ml"],
            collected_by=collected_by,
            collected_at=datetime.now(),
            status="collected",
            barcode=f"S-{datetime.now():%Y%m%d}-{str(order_id)[:8]}"
        )

        # Generate barcode image for label printing
        await self.generate_barcode_label(sample)

        return sample

    async def generate_barcode_label(self, sample: Sample) -> str:
        """Generate a barcode PNG and return path for printing."""
        import barcode
        from barcode.writer import ImageWriter

        code128 = barcode.get("code128", sample.barcode, writer=ImageWriter())
        filepath = f"/tmp/labels/{sample.barcode}.png"
        code128.save(filepath)
        return filepath

    async def verify_sample(self, barcode: str) -> dict:
        """Verify sample barcode matches order. Returns patient info."""
        sample = await Sample.get_by_barcode(barcode)
        if not sample:
            raise ValueError(f"Invalid barcode: {barcode}")
        return {
            "sample_id": str(sample.id),
            "barcode": sample.barcode,
            "patient_name": sample.order.patient.name,
            "tests": [t.name for t in sample.order.tests]
        }
```

### Tube Selection Guide

The technician selects tube type based on ordered tests. The system suggests the correct tube:

```
Ordered Tests: CBC, LFT, Lipid Profile
Suggested Tubes:
  ✅ Purple (EDTA) 3mL - CBC
  ✅ Red (Plain) 5mL - LFT, Lipid Profile
  --------------------------
  Total: 2 tubes, 8mL blood required
```

### Label Format

Sample labels follow a standardized format:

```
+-----------------------------------+
|  Dr. Sharma's Clinic              |
|  S-20260709-015                   |
|  [===== BARCODE =====]            |
|  Rajesh Kumar  |  45/M            |
|  CBC, LFT, Lipid Profile          |
|  Purple EDTA 3mL                  |
|  Collected: 09:15 AM              |
+-----------------------------------+
```

---



## 5. TEST RESULT ENTRY

```python
class TestResultEntry:
    """
    Manual and auto-imported test result entry with reference range
    comparison, flagging, and validation.
    """

    REFERENCE_RANGES = {
        "hemoglobin": {
            "unit": "g/dL",
            "adult_male":   {"low": 13.0, "normal": (13.0, 17.0), "high": 17.0, "critical_high": 20.0},
            "adult_female": {"low": 12.0, "normal": (12.0, 15.5), "high": 15.5, "critical_high": 18.0},
            "child_1_5":    {"low": 10.5, "normal": (10.5, 14.0), "high": 14.0, "critical_high": 17.0},
        },
        "wbc": {
            "unit": "x10\u00b3/\u00b5L",
            "default": {"low": 4.0, "normal": (4.0, 11.0), "high": 11.0, "critical_low": 1.0, "critical_high": 30.0},
        },
        "platelets": {
            "unit": "x10\u00b3/\u00b5L",
            "default": {"low": 150, "normal": (150, 450), "high": 450, "critical_low": 20, "critical_high": 1000},
        },
        "glucose_fasting": {
            "unit": "mg/dL",
            "default": {"low": 70, "normal": (70, 100), "high": 100, "critical_low": 40, "critical_high": 500},
        },
        "tsh": {
            "unit": "\u00b5IU/mL",
            "default": {"low": 0.4, "normal": (0.4, 4.5), "high": 4.5},
        },
        "creatinine": {
            "unit": "mg/dL",
            "adult_male":   {"low": 0.6, "normal": (0.6, 1.2), "high": 1.2, "critical_high": 5.0},
            "adult_female": {"low": 0.5, "normal": (0.5, 1.1), "high": 1.1, "critical_high": 4.0},
        },
    }

    async def enter_result(
        self, test_order_id, result_value, entered_by,
        instrument=None, lis_imported=False
    ):
        """Enter a test result with automatic flagging."""
        test_order = await TestOrder.get(test_order_id).prefetch_related("order__patient")
        patient = test_order.order.patient

        ref = self.get_reference_range(
            test_name=test_order.test_name,
            age=patient.age,
            gender=patient.gender
        )

        flag = self.determine_flag(result_value, ref)

        alert = None
        if flag in ("critical_low", "critical_high"):
            alert = await self.create_critical_alert(test_order, result_value, flag, ref)

        result = await TestResult.create(
            test_order_id=test_order_id,
            result_value=result_value,
            unit=ref["unit"],
            reference_range=f"{ref['normal'][0]}-{ref['normal'][1]}",
            flag=flag,
            instrument=instrument,
            lis_imported=lis_imported,
            entered_by=entered_by,
            entered_at=datetime.now(),
            is_abnormal=(flag != "normal")
        )

        return result

    def get_reference_range(self, test_name, age, gender):
        """Get age- and gender-specific reference range."""
        test_ref = self.REFERENCE_RANGES.get(test_name)
        if not test_ref:
            return {"unit": "", "normal": (0, 999), "low": None, "high": None}

        key = None
        if age >= 18 and gender == "male" and "adult_male" in test_ref:
            key = "adult_male"
        elif age >= 18 and gender == "female" and "adult_female" in test_ref:
            key = "adult_female"
        elif age < 5 and "child_1_5" in test_ref:
            key = "child_1_5"

        if key:
            base = test_ref[key]
        else:
            base = test_ref.get("default", test_ref)

        return base

    def determine_flag(self, value, ref):
        """Determine flag status for a result value."""
        low, high = ref["normal"]

        if "critical_high" in ref and value >= ref["critical_high"]:
            return "critical_high"
        if "critical_low" in ref and value <= ref["critical_low"]:
            return "critical_low"
        if value > high:
            return "high"
        if value < low:
            return "low"
        return "normal"

    async def create_critical_alert(self, test_order, value, flag, ref):
        """Create a critical alert notification for doctors."""
        alert = {
            "patient_name": test_order.order.patient.name,
            "test_name": test_order.test_name,
            "value": value,
            "unit": ref["unit"],
            "flag": flag,
            "reference_range": f"{ref['normal'][0]}-{ref['normal'][1]}",
            "timestamp": datetime.now().isoformat(),
            "severity": "critical"
        }

        await NotificationOrchestrator.send_critical_alert(
            alert,
            channel="whatsapp_sms",
            recipients=test_order.order.assigned_doctors
        )

        return alert
```

### Result Entry UI

When entering results, the technician sees a structured form:

```
+--- CBC -------------------------------------------------+
|  Test           | Result  | Flag  | Ref Range | Unit    |
| ------------------------------------------------------- |
|  Hemoglobin     | [14.2]  | Normal| 13-17     | g/dL    |
|  WBC            | [12.5]  | H     | 4-11      | x10\u00b3 |
|  Platelets      | [450]   | Normal| 150-450   | x10\u00b3 |
|  Neutrophils %  | [68]    | Normal| 40-80     | %       |
|  Lymphocytes %  | [25]    | Normal| 20-40     | %       |
|                                                         |
|  [Save All Results]  [Discard]  [Print Report]          |
+---------------------------------------------------------+
```

---

## 6. RESULT FLAG LEGEND

| Flag | Label | Meaning | Action Required |
|------|-------|---------|-----------------|
| Normal | -- | Within reference range | None |
| H | High | Above normal range | Doctor notified in-panel |
| L | Low | Below normal range | Doctor notified in-panel |
| Critical High | Critical High | Life-threatening high value | Immediate SMS + WhatsApp to doctor |
| Critical Low | Critical Low | Life-threatening low value | Immediate SMS + WhatsApp to doctor |
| Delta | Delta Check | >20% change from previous | Tech to verify sample integrity |

---


## 7. LIS (LAB INFORMATION SYSTEM) INTEGRATION

```python
class LISIntegration:
    """
    Bi-directional interface with laboratory analyzers via HL7 or ASTM protocols.
    Supports auto-import of results from connected instruments.
    """

    SUPPORTED_INSTRUMENTS = {
        "sysmex_xn1000": {"protocol": "hl7", "tests": ["CBC", "DIFF"]},
        "cobas_6000":    {"protocol": "hl7", "tests": ["LFT", "KFT", "Lipid", "TSH"]},
        "cobas_e411":    {"protocol": "hl7", "tests": ["T3", "T4", "TSH", "FERRITIN"]},
        "d10_hba1c":     {"protocol": "astm", "tests": ["HbA1c"]},
        "clot_plus":     {"protocol": "hl7", "tests": ["PT", "APTT", "INR"]},
    }

    async def poll_instrument(self, instrument_id):
        """Poll a connected instrument for new results."""
        instrument = self.SUPPORTED_INSTRUMENTS[instrument_id]
        config = await self.get_instrument_config(instrument_id)

        if instrument["protocol"] == "hl7":
            raw = await self.poll_hl7(config)
            return self.parse_hl7_results(raw)
        elif instrument["protocol"] == "astm":
            raw = await self.poll_astm(config)
            return self.parse_astm_results(raw)

        return []

    async def import_result(self, lis_data):
        """Import a result from LIS. Auto-match to pending order."""
        sample_barcode = lis_data["sample_id"]
        sample = await Sample.get_by_barcode(sample_barcode)

        if not sample:
            return await self.queue_unmatched(lis_data)

        test_order = await TestOrder.get(sample.order_id)
        result = await TestResultEntry().enter_result(
            test_order_id=test_order.id,
            result_value=lis_data["value"],
            entered_by=LIS_SYSTEM_USER_ID,
            instrument=lis_data["instrument"],
            lis_imported=True
        )

        return result

    def parse_hl7_results(self, raw_message):
        """Parse HL7 ORU^R01 message into structured results."""
        results = []
        segments = raw_message.split("")
        for seg in segments:
            if seg.startswith("OBX"):
                fields = seg.split("|")
                results.append({
                    "sample_id": self._extract_sample_id(segments, fields),
                    "test_name": fields[3].split("^")[1],
                    "value": float(fields[5]),
                    "unit": fields[6],
                    "ref_range": fields[7],
                    "flag": fields[8],
                    "instrument": "lis_import"
                })
        return results

    def parse_astm_results(self, raw_message):
        """Parse ASTM E1381-02 message into structured results."""
        results = []
        for line in raw_message.split("
"):
            if line.startswith("R") and line[1] == "|":
                fields = line.split("|")
                results.append({
                    "sample_id": fields[2],
                    "test_name": fields[3],
                    "value": float(fields[4]),
                    "unit": fields[5],
                })
        return results
```

### LIS Connection Dashboard

```
+--------------------------------------------------------+
|  Instrument       | Status  | Results | Last Sync       |
| ------------------------------------------------------- |
|  Sysmex XN-1000  | Online  | 24 pend.| 09:42:01        |
|  Cobas 6000      | Online  | 18 pend.| 09:41:55        |
|  Cobas e411      | Idle    | 0 pend. | 09:30:00        |
|  D10 HbA1c       | Offline | --      | 08:15:00        |
|                                                        |
|  [Connect] [Disconnect] [Force Poll] [Logs]            |
+--------------------------------------------------------+
```

---

## 8. QUALITY CONTROL TRACKING

```python
class QualityControl:
    """
    Daily quality control tracking for lab instruments.
    Ensures all test systems are validated before patient
    samples are processed.
    """

    CONTROL_MATERIALS = {
        "cbc_level1":  {"instrument": "sysmex_xn1000", "level": 1},
        "cbc_level2":  {"instrument": "sysmex_xn1000", "level": 2},
        "chem_level1": {"instrument": "cobas_6000",     "level": 1},
        "chem_level2": {"instrument": "cobas_6000",     "level": 2},
    }

    QC_INTERVAL_HOURS = 8

    async def run_qc(self, control_id, lot_number, results, technician_id):
        """Record QC run results and determine pass/fail."""
        control = self.CONTROL_MATERIALS[control_id]
        passed = self.validate_qc_results(control_id, results)

        qc_record = await QCRecord.create(
            control_id=control_id,
            instrument=control["instrument"],
            level=control["level"],
            lot_number=lot_number,
            results=results,
            passed=passed,
            run_by=technician_id,
            run_at=datetime.now()
        )

        if not passed:
            await self.handle_qc_failure(control_id, qc_record)

        return qc_record

    def validate_qc_results(self, control_id, results):
        """Validate QC results against Westgard rules."""
        for test, value in results.items():
            mean = self.get_control_mean(control_id, test)
            sd = self.get_control_sd(control_id, test)
            z_score = abs(value - mean) / sd if sd > 0 else 999

            if z_score > 3.0:
                return False
            elif z_score > 2.0:
                self.flag_westgard_violation(control_id, test, "2s", z_score)

        return True

    async def handle_qc_failure(self, control_id, record):
        """Handle QC failure - notify supervisor, block testing."""
        await self.lock_instrument(record.instrument)
        await NotificationOrchestrator().send_alert(
            title=f"QC Failure - {record.instrument}",
            message=f"Control {control_id} failed at {record.run_at}.",
            severity="high",
            department="lab_admin"
        )

    async def get_qc_dashboard(self):
        """Get current QC status for all instruments."""
        statuses = {}
        for control_id in self.CONTROL_MATERIALS:
            last = await QCRecord.filter(
                control_id=control_id
            ).order_by("-run_at").first()
            hours_since = (datetime.now() - last.run_at).total_seconds() / 3600 if last else 999
            statuses[control_id] = {
                "last_run": last.run_at if last else None,
                "passed": last.passed if last else None,
                "due": hours_since >= self.QC_INTERVAL_HOURS,
                "hours_since_qc": round(hours_since, 1)
            }
        return statuses
```

---


## 9. ERROR HANDLING

### Sample Rejection Reasons

| Reason | Code | Description | Action |
|--------|------|-------------|--------|
| Hemolyzed | HEM | RBCs ruptured, serum discolored | Redraw with proper venipuncture |
| Insufficient Quantity | INQ | Volume below minimum required | Redraw, use larger tube |
| Clotted | CLT | Anticoagulant mix failed | Redraw, invert tube properly |
| Wrong Tube | WRT | Incorrect tube type for tests | Redraw with correct tube |
| Mislabeled | MSL | Label doesn't match patient ID | Discard, recollect with correct label |

### Result Validation Rules

```python
class ResultValidator:
    \"\"\"Validates result values against instrument ranges and clinical plausibility.\"\"\"

    MEASURABLE_RANGES = {
        \"hemoglobin\":      (0.1, 25.0),
        \"wbc\":             (0.01, 100.0),
        \"platelets\":       (1.0, 2000.0),
        \"glucose\":         (5.0, 1000.0),
        \"creatinine\":      (0.1, 20.0),
        \"tsh\":             (0.001, 100.0),
        \"potassium\":       (1.0, 10.0),
        \"sodium\":          (100.0, 180.0),
        \"total_cholesterol\": (50.0, 500.0),
    }

    async def validate(self, test_name: str, value: float) -> dict:
        lo, hi = self.MEASURABLE_RANGES.get(test_name, (float(\"-inf\"), float(\"inf\")))
        if not (lo <= value <= hi):
            return {\"valid\": False, \"reason\": f\"Value {value} outside range ({lo}-{hi})\", \"severity\": \"error\"}
        return {\"valid\": True, \"reason\": None, \"severity\": None}

    async def delta_check(self, patient_id, test_name, new_value, threshold_pct=20.0):
        previous = await TestResult.filter(
            patient_id=patient_id, test_name=test_name
        ).order_by(\"-entered_at\").first()

        if not previous:
            return {\"delta\": False, \"previous\": None}

        change_pct = abs(new_value - previous.result_value) / previous.result_value * 100
        if change_pct > threshold_pct:
            return {
                \"delta\": True,
                \"previous\": previous.result_value,
                \"change_pct\": round(change_pct, 1),
                \"alert\": f\"Delta check: {change_pct:.1f}% change from previous\"
            }
        return {\"delta\": False, \"previous\": previous.result_value, \"change_pct\": round(change_pct, 1)}
```

---

## 10. DATABASE SCHEMA

```sql
-- Lab Orders
CREATE TABLE lab_orders (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    doctor_id UUID NOT NULL REFERENCES staff_users(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    priority VARCHAR(10) NOT NULL DEFAULT 'normal',
    ordered_at TIMESTAMP DEFAULT NOW(),
    collected_at TIMESTAMP,
    completed_at TIMESTAMP,
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Tests within each order
CREATE TABLE lab_order_tests (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lab_order_id UUID NOT NULL REFERENCES lab_orders(id) ON DELETE CASCADE,
    test_name VARCHAR(100) NOT NULL,
    test_category VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    result_value DECIMAL(15,4),
    unit VARCHAR(20),
    reference_range VARCHAR(50),
    flag VARCHAR(20),
    instrument VARCHAR(100),
    lis_imported BOOLEAN DEFAULT FALSE,
    entered_by UUID REFERENCES staff_users(id),
    entered_at TIMESTAMP,
    verified_by UUID REFERENCES staff_users(id),
    verified_at TIMESTAMP,
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Physical samples
CREATE TABLE samples (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lab_order_id UUID NOT NULL REFERENCES lab_orders(id),
    barcode VARCHAR(50) UNIQUE NOT NULL,
    tube_type VARCHAR(20) NOT NULL,
    tube_name VARCHAR(50),
    volume_ml DECIMAL(5,2),
    collected_by UUID REFERENCES staff_users(id),
    collected_at TIMESTAMP,
    received_at TIMESTAMP DEFAULT NOW(),
    status VARCHAR(20) NOT NULL DEFAULT 'ordered',
    rejection_reason VARCHAR(100),
    storage_location VARCHAR(50),
    disposed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Quality control records
CREATE TABLE quality_control (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    control_id VARCHAR(50) NOT NULL,
    instrument VARCHAR(100) NOT NULL,
    level INTEGER NOT NULL,
    lot_number VARCHAR(50) NOT NULL,
    results JSONB NOT NULL,
    passed BOOLEAN NOT NULL,
    westgard_violations JSONB,
    run_by UUID REFERENCES staff_users(id),
    run_at TIMESTAMP DEFAULT NOW(),
    reviewed_by UUID REFERENCES staff_users(id),
    reviewed_at TIMESTAMP
);

-- Result values
CREATE TABLE lab_results (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    test_order_id UUID NOT NULL REFERENCES lab_order_tests(id) ON DELETE CASCADE,
    lab_order_id UUID NOT NULL REFERENCES lab_orders(id),
    result_value DECIMAL(15,4) NOT NULL,
    unit VARCHAR(20),
    reference_range VARCHAR(50),
    flag VARCHAR(20),
    instrument VARCHAR(100),
    lis_imported BOOLEAN DEFAULT FALSE,
    entered_by UUID REFERENCES staff_users(id),
    entered_at TIMESTAMP DEFAULT NOW(),
    is_abnormal BOOLEAN DEFAULT FALSE,
    delta_check BOOLEAN DEFAULT FALSE,
    previous_value DECIMAL(15,4),
    notes TEXT
);

-- Critical value alerts
CREATE TABLE lab_abnormal_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    lab_result_id UUID NOT NULL REFERENCES lab_results(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    doctor_id UUID NOT NULL REFERENCES staff_users(id),
    test_name VARCHAR(100) NOT NULL,
    result_value DECIMAL(15,4) NOT NULL,
    flag VARCHAR(20) NOT NULL,
    alert_type VARCHAR(20) NOT NULL DEFAULT 'abnormal',
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_at TIMESTAMP,
    notification_sent BOOLEAN DEFAULT FALSE,
    notification_channel VARCHAR(50),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_lab_orders_status ON lab_orders(status);
CREATE INDEX idx_lab_orders_patient ON lab_orders(patient_id);
CREATE INDEX idx_lab_orders_date ON lab_orders(ordered_at DESC);
CREATE INDEX idx_samples_barcode ON samples(barcode);
CREATE INDEX idx_lab_order_tests_status ON lab_order_tests(status, lab_order_id);
CREATE INDEX idx_qc_instrument ON quality_control(instrument, level, run_at DESC);
CREATE INDEX idx_qc_lot ON quality_control(lot_number);
CREATE INDEX idx_lab_results_flag ON lab_results(flag) WHERE is_abnormal = TRUE;
```

---

## 11. API ENDPOINTS

| Method | Endpoint | Purpose |
|--------|----------|---------|
| GET | /api/lab/queue | Get lab queue with wait times |
| GET | /api/lab/queue/next | Dequeue next patient |
| POST | /api/lab/samples | Record sample collection |
| GET | /api/lab/samples/:barcode | Lookup sample by barcode |
| POST | /api/lab/samples/:id/reject | Reject a sample |
| POST | /api/lab/results | Enter test results |
| PUT | /api/lab/results/:id | Update test results |
| GET | /api/lab/results/pending | Get unreviewed results for doctor |
| POST | /api/lab/results/:id/sign | Doctor signs off on result |
| GET | /api/lab/qc/status | Get QC status for all instruments |
| POST | /api/lab/qc/run | Run a quality control check |
| GET | /api/lab/instruments | List all connected LIS instruments |
| POST | /api/lab/instruments/:id/poll | Force-poll an instrument |
| GET | /api/lab/orders | List lab orders with filters |
| GET | /api/lab/orders/:id | Get lab order detail with results |

---

## 12. CONFIGURATION

```yaml
lab_technician_module:
  ui:
    auto_refresh_queue_seconds: 15
    show_flags_inline: true
    require_barcode_scan: true
    default_view: "queue"

  sample_management:
    barcode_format: "code128"
    label_printer: "zebra_gk420t"
    auto_suggest_tubes: true
    require_patient_id_verification: true

  results:
    manual_entry_requires_verification: false
    lis_import_auto_accept: true
    delta_check_threshold_percent: 20
    require_doctor_signoff: true
    critical_alert_channels:
      - "websocket"
      - "whatsapp"
      - "sms"

  quality_control:
    interval_hours: 8
    westgard_rules_enabled: true
    block_patient_testing_on_failure: true
    notify_supervisor_on_failure: true
    qc_due_reminder_minutes: 30

  lis:
    auto_poll_interval_seconds: 30
    hl7_port: 2575
    astm_port: 1525
    connection_timeout_seconds: 10
    retry_on_failure: true
    max_retries: 3
    unmatched_results_queue: true

  tat_monitoring:
    enabled: true
    alert_if_exceeds_minutes: 60
    stat_tat_target_minutes: 30
    normal_tat_target_minutes: 120
```

---

## 13. PENDING RESULTS VIEW (FOR DOCTORS)

Results flow from technician entry to doctor review:

```
+--- PENDING REVIEW - Dr. Sharma -------------------------+
|  Status: 8 results pending                              |
| ------------------------------------------------------- |
|  Patient       | Test     | Value | Flag | Collected    |
|  Rajesh Kumar  | CBC       | 14.2  | --   | 09:15 AM   |
|  Priya Singh   | HbA1c     | 7.2   | H    | 08:30 AM   |
|  Mohan Lal     | TSH       | 0.15  | L    | 08:00 AM   |
|  Sunil Verma   | Lipid     | ---   | ---  | 07:45 AM   |
|                                                        |
|  [View Details] [Sign] [Request Redraw] [Compare Prev] |
+--------------------------------------------------------+
```

When a doctor opens a result for review:

```
+--- CBC Report - Rajesh Kumar (45/M) ------------------+
|                                                        |
|  Ordered by: Dr. Sharma on 2026-07-09 09:00 AM         |
|  Sample: S-20260709-015 | EDTA Purple | Collected: 09:15|
|                                                        |
|  Test              | Result | Flag | Ref Range | Unit  |
| ------------------------------------------------------ |
|  Hemoglobin       | 14.2   | --   | 13-17     | g/dL  |
|  WBC              | 12.5   | H    | 4-11      | x10/B3|
|  Platelets        | 450    | --   | 150-450   | x10/B3|
|  Neutrophils %    | 68     | --   | 40-80     | %     |
|  Lymphocytes %    | 25     | --   | 20-40     | %     |
|                                                        |
|  Clinical Note: Mild leukocytosis - likely infection   |
|                                                        |
|  [Sign Report] [Add Note] [Print]                      |
+--------------------------------------------------------+
```

---

## 14. KEY DESIGN DECISIONS

1. **Barcode-first workflow** -- Every sample gets a unique barcode at collection. All subsequent operations (result entry, LIS matching, verification) use barcode scanning. No manual patient ID entry after collection.

2. **LIS integration as first-class feature** -- GHOS treats connected analyzers as primary data sources. HL7/ASTM parsing is built into the core, not an afterthought. Auto-import with manual matching fallback for unmapped samples.

3. **Reference ranges by demographics** -- Normal ranges vary by age, gender, and population. The system selects the correct range automatically based on patient demographics.

4. **Critical alerts bypass queues** -- Critical results (e.g., critical low platelets, critical high potassium) skip the normal review queue and go directly to the doctor via SMS + WhatsApp.

5. **QC gates patient testing** -- If daily QC has not been passed on an instrument, patient samples cannot be processed on that instrument. Enforces CLIA regulatory compliance.

6. **Westgard rules for QC validation** -- Industry-standard Westgard multi-rules (1s, 2s, R4s, 10x) are applied automatically. QC failures lock the instrument until reviewed by a supervisor.

7. **TAT tracking built-in** -- Every test has a timer from order to result. Alerts fire when thresholds are exceeded. STAT orders have shorter TAT targets.

8. **Delta checks prevent errors** -- If a result differs by >20% from the patient's previous result, a delta flag is raised. The technician must verify sample integrity before releasing.

9. **Doctor sign-off required** -- Results are "draft" until a doctor signs them. Only signed results are visible to the patient and used for clinical decisions.

10. **Audit trail for everything** -- Every sample rejection, result edit, QC run, and sign-off is recorded with timestamp and user ID. Full chain of custody for medico-legal purposes.

---

## 15. INTEGRATION POINTS

| Component | Integration |
|-----------|-------------|
| Queue Engine (0100) | Lab technician calls next patient from lab queue via dequeue() |
| Workflow Engine (0101) | Patients routed to lab from doctor; routed back to doctor for review |
| Doctor Module (0201) | Doctors view pending results and sign reports |
| Nurse Module (0205) | Nurses may collect samples before lab run |
| Notification Engine (0103) | Critical alerts sent via WhatsApp/SMS |
| Report Engine (0108) | Lab reports generated and stored for patient access |
| Patient Module (0200) | Patients view completed lab reports on portal |
