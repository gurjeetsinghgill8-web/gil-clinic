---
file_id: "0204"
module_name: "Owner Module"
version: "2.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0109_ANALYTICS_ENGINE.md"]
related_files: ["1002_SUBSCRIPTION.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "owner", "business", "dashboard", "revenue"]
---

# GHOS — Owner Module

## 1. PURPOSE

The Owner Module is the business owner's command center for GIL CLINIC. It provides a single-pane-of-glass view across all branches, departments, and time periods — answering the question: **"How is my business doing right now?"**

Capabilities include:
- Real-time dashboard with today's headline numbers
- Revenue analytics with trends and target comparisons
- Doctor productivity ranking across all branches
- Department bottleneck detection and resource alerts
- Branch comparison for multi-location operations
- Peak hours identification for staffing optimization
- No-show rate tracking with revenue loss calculations
- Patient acquisition trends (new vs returning over time)
- Subscription and billing management
- Staff overview with attendance tracking
- Export reports in PDF and CSV formats

---

## 2. OWNER DASHBOARD

The dashboard is the first thing the owner sees on login. It aggregates real-time data from all branches into a single view.

```
+------------------------------------------------------------------+
|  GIL CLINIC — Owner Dashboard                                     |
|  [Chart] Jul 9, 2026 | Refresh: Auto (30s)                        |
+------------------------------------------------------------------+
|                                                                   |
|  +-- TODAY'S NUMBERS -----------------------------------------+  |
|  |  Total Patients:  142                                       |  |
|  |  Revenue:         Rs 42,500                                  |  |
|  |  Avg Wait:        12 min                                    |  |
|  |  Satisfaction:    4.3 / 5.0                                 |  |
|  |  New Patients:    38 (27%)                                  |  |
|  |  Returning:       104 (73%)                                 |  |
|  |  No-Shows:        7 (4.9%)                                  |  |
|  |  Rev Loss:        Rs 8,750 (est.)                           |  |
|  +-------------------------------------------------------------+  |
|                                                                   |
|  +-- REVENUE THIS MONTH --------------------------------------+  |
|  |  MTD Revenue: Rs 8,42,000  vs Target: Rs 10,00,000          |  |
|  |  Progress: 84.2%  |  On track: Yes                          |  |
|  |  Last Month: Rs 9,15,000  |  YoY: +12.3%                    |  |
|  +-------------------------------------------------------------+  |
|                                                                   |
|  +-- BOTTLENECKS & ALERTS ------------------------------------+  |
|  |  ECG:       8 min behind schedule                           |  |
|  |  Lab:       On track                                        |  |
|  |  Doctor:    5 min behind (high load)                        |  |
|  |  Peak Hour: 11:00 AM — 1:00 PM (all depts)                  |  |
|  +-------------------------------------------------------------+  |
|                                                                   |
|  +-- BRANCH COMPARISON ---------------------------------------+  |
|  |  Main:      142 pts | Rs 42,500  | 4.3 stars                  |  |
|  |  Branch 2:   89 pts  | Rs 28,000  | 4.1 stars                  |  |
|  |  Branch 3:   67 pts  | Rs 21,000  | 4.5 stars                  |  |
|  +-------------------------------------------------------------+  |
|                                                                   |
|  [View Full Analytics] [Staff Overview] [Export PDF]              |
|  [Subscription: Premium] [Branches: 3] [Last Sync: 12s]           |
+------------------------------------------------------------------+
```

### Dashboard Sections

| Section | Source | Refresh |
|---------|--------|---------|
| Today's Numbers | analytics_kpis (period=today) | Every event |
| Revenue This Month | analytics_kpis (period=this_month) | Daily (1 AM) |
| Bottlenecks & Alerts | analytics_metrics (queue.*) | Real-time (5 min) |
| Branch Comparison | analytics_kpis (dimension=branch_id) | Every event |
| Peak Hour Indicator | analytics_metrics (hourly buckets) | Hourly |

---

## 3. TODAY'S NUMBERS — DETAILED BREAKDOWN

The "Today's Numbers" section gives the owner an at-a-glance pulse of daily operations.

### 3.1 Patient Volume
```python
async def get_todays_patient_volume(hospital_id: UUID, date: date = None) -> dict:
    """Aggregate today's patient counts across all branches."""
    date = date or date.today()
    
    total = await Visit.filter(
        hospital_id=hospital_id,
        created_at__gte=date,
        created_at__lt=date + timedelta(days=1)
    ).count()
    
    new_patients = await Visit.filter(
        hospital_id=hospital_id,
        created_at__gte=date,
        created_at__lt=date + timedelta(days=1),
        is_first_visit=True
    ).count()
    
    returning = total - new_patients
    
    return {
        "total": total,
        "new": new_patients,
        "returning": returning,
        "new_pct": round((new_patients / total) * 100, 1) if total else 0,
        "returning_pct": round((returning / total) * 100, 1) if total else 0
    }
```

### 3.2 Revenue Snapshot
```python
async def get_todays_revenue(hospital_id: UUID, date: date = None) -> dict:
    """Today's revenue from all billing transactions."""
    date = date or date.today()
    
    result = await Billing.filter(
        hospital_id=hospital_id,
        paid_at__gte=date,
        paid_at__lt=date + timedelta(days=1)
    ).annotate(
        total=Sum("amount_paid"),
        count=Count("id"),
        avg=Avg("amount_paid")
    ).values("total", "count", "avg")
    
    return {
        "total_revenue": float(result[0]["total"]) if result else 0.0,
        "total_transactions": result[0]["count"] if result else 0,
        "avg_bill": round(float(result[0]["avg"]), 2) if result else 0.0
    }
```

### 3.3 Wait Time & Satisfaction
```sql
-- Average wait time today (across all departments)
SELECT
    AVG(EXTRACT(EPOCH FROM (called_at - entered_at)) / 60) AS avg_wait_minutes,
    department_id,
    COUNT(*) AS sample_size
FROM queue_entries
WHERE DATE(entered_at) = CURRENT_DATE
  AND called_at IS NOT NULL
  AND hospital_id = :hospital_id
GROUP BY department_id
ORDER BY avg_wait_minutes DESC;

-- Today's satisfaction score
SELECT
    AVG(rating) AS avg_satisfaction,
    COUNT(*) AS total_responses
FROM feedback
WHERE DATE(created_at) = CURRENT_DATE
  AND hospital_id = :hospital_id;
```

---

## 4. REVENUE ANALYTICS

### 4.1 Daily Revenue Trend
```python
async def get_revenue_trend(
    hospital_id: UUID,
    granularity: str = "daily",
    from_date: date = None,
    to_date: date = None
) -> list:
    """Time-series revenue data for chart rendering."""
    from_date = from_date or (date.today() - timedelta(days=30))
    to_date = to_date or date.today()
    
    metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="revenue.daily",
        granularity=granularity,
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).order_by("time_bucket").all()
    
    return [
        {
            "date": m.time_bucket.isoformat(),
            "revenue": float(m.value),
            "day_name": m.time_bucket.strftime("%A")
        }
        for m in metrics
    ]
```

### 4.2 Revenue vs Target
```sql
SELECT
    kpi_name,
    period,
    value AS actual,
    (SELECT value FROM analytics_kpis 
     WHERE kpi_name = 'revenue.target' 
       AND period = 'this_month'
       AND hospital_id = :hospital_id) AS target,
    change_percent,
    trend
FROM analytics_kpis
WHERE kpi_name LIKE 'revenue.%'
  AND period IN ('today', 'this_week', 'this_month', 'this_year')
  AND hospital_id = :hospital_id;
```

### 4.3 Revenue by Department
```python
async def get_revenue_by_department(
    hospital_id: UUID,
    from_date: date,
    to_date: date
) -> list:
    """Revenue contribution by department."""
    metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="revenue.by_department",
        granularity="daily",
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).all()
    
    dept_revenue = {}
    for m in metrics:
        dept = m.dimension.get("department_name", "Unknown")
        dept_revenue[dept] = dept_revenue.get(dept, 0) + float(m.value)
    
    total = sum(dept_revenue.values())
    
    return [
        {
            "department": dept,
            "revenue": amount,
            "percentage": round((amount / total) * 100, 1) if total else 0
        }
        for dept, amount in sorted(dept_revenue.items(), key=lambda x: x[1], reverse=True)
    ]
```

### 4.4 Weekly & Monthly Comparisons
```sql
-- Week-over-week revenue
SELECT
    DATE_TRUNC('week', time_bucket) AS week_start,
    SUM(value) AS weekly_revenue
FROM analytics_metrics
WHERE metric_name = 'revenue.daily'
  AND granularity = 'daily'
  AND hospital_id = :hospital_id
  AND time_bucket >= NOW() - INTERVAL '8 weeks'
GROUP BY week_start
ORDER BY week_start DESC;

-- Month-over-month with change
SELECT
    DATE_TRUNC('month', time_bucket) AS month_start,
    SUM(value) AS monthly_revenue,
    LAG(SUM(value)) OVER (ORDER BY DATE_TRUNC('month', time_bucket)) AS prev_month,
    ROUND(
        ((SUM(value) - LAG(SUM(value)) OVER (ORDER BY DATE_TRUNC('month', time_bucket)))
         / LAG(SUM(value)) OVER (ORDER BY DATE_TRUNC('month', time_bucket))) * 100, 2
    ) AS change_pct
FROM analytics_metrics
WHERE metric_name = 'revenue.daily'
  AND granularity = 'daily'
  AND hospital_id = :hospital_id
  AND time_bucket >= NOW() - INTERVAL '12 months'
GROUP BY month_start
ORDER BY month_start DESC;
```

---

## 5. DOCTOR PRODUCTIVITY RANKING

```python
async def get_doctor_productivity(
    hospital_id: UUID,
    from_date: date = None,
    to_date: date = None,
    branch_id: UUID = None
) -> list:
    """Rank doctors by patients seen and revenue generated."""
    from_date = from_date or date.today()
    to_date = to_date or date.today()
    
    filters = {
        "hospital_id": hospital_id,
        "time_bucket__gte": from_date,
        "time_bucket__lte": to_date
    }
    if branch_id:
        filters["dimension__branch_id"] = str(branch_id)
    
    # Patients seen per doctor
    patient_metrics = await AnalyticsMetric.filter(
        metric_name="doctor.patients_seen",
        granularity="daily",
        **filters
    ).all()
    
    # Revenue per doctor
    revenue_metrics = await AnalyticsMetric.filter(
        metric_name="doctor.revenue",
        granularity="daily",
        **filters
    ).all()
    
    # Aggregate by doctor
    doctors = {}
    for m in patient_metrics:
        doc_id = m.dimension.get("doctor_id")
        doc_name = m.dimension.get("doctor_name", "Unknown")
        dept = m.dimension.get("department_name", "General")
        if doc_id not in doctors:
            doctors[doc_id] = {
                "doctor_name": doc_name,
                "department": dept,
                "patients_seen": 0,
                "revenue": 0.0
            }
        doctors[doc_id]["patients_seen"] += int(m.value)
    
    for m in revenue_metrics:
        doc_id = m.dimension.get("doctor_id")
        if doc_id in doctors:
            doctors[doc_id]["revenue"] += float(m.value)
    
    # Calculate averages and rank
    ranked = sorted(doctors.values(), key=lambda x: x["patients_seen"], reverse=True)
    for i, doc in enumerate(ranked, 1):
        doc["rank"] = i
        doc["avg_per_day"] = round(doc["patients_seen"] / max((to_date - from_date).days, 1), 1)
    
    return ranked
```

### Ranking Display
```
Doctor Productivity Ranking (Jul 1 - Jul 9, 2026)
+------+------------------+------------+---------------+-----------+----------------+
| Rank | Doctor           | Department | Patients Seen | Revenue   | Avg/Day        |
+------+------------------+------------+---------------+-----------+----------------+
| 1    | Dr. Sharma       | Cardiology | 142           | Rs 1,25,000 | 15.8           |
| 2    | Dr. Singh        | General    | 98            | Rs 72,000  | 10.9           |
| 3    | Dr. Patel        | Ortho      | 76            | Rs 89,000  | 8.4            |
| 4    | Dr. Verma        | Pediatrics | 65            | Rs 48,000  | 7.2            |
| 5    | Dr. Kapoor       | ENT        | 52            | Rs 39,000  | 5.8            |
+------+------------------+------------+---------------+-----------+----------------+
```

---

## 6. DEPARTMENT BOTTLENECK DETECTION

```python
async def detect_bottlenecks(hospital_id: UUID) -> list:
    """Identify which departments are falling behind schedule."""
    departments = await Department.filter(hospital_id=hospital_id).all()
    bottlenecks = []
    
    for dept in departments:
        # Get current queue state
        waiting = await QueueEntry.filter(
            department_id=dept.id,
            status="waiting"
        ).count()
        
        # Get average service time (last 20 completed)
        completed = await QueueEntry.filter(
            department_id=dept.id,
            status="completed"
        ).order_by("-completed_at").limit(20).all()
        
        if not completed:
            continue
        
        service_times = [
            (e.called_at - e.entered_at).total_seconds() / 60
            for e in completed if e.called_at
        ]
        avg_service = sum(service_times) / len(service_times) if service_times else 0
        
        # Staff on duty
        staff_count = await StaffUser.filter(
            department_id=dept.id,
            is_clocked_in=True,
            active=True
        ).count()
        
        # Determine status
        wait_per_patient = avg_service / max(staff_count, 1)
        behind_minutes = (waiting * wait_per_patient) - (staff_count * 5)  # 5 min buffer per staff
        
        status = "on_track"
        if behind_minutes > 10:
            status = "critical"
        elif behind_minutes > 5:
            status = "warning"
        
        bottlenecks.append({
            "department": dept.name,
            "patients_waiting": waiting,
            "avg_service_minutes": round(avg_service, 1),
            "staff_on_duty": staff_count,
            "behind_minutes": round(max(behind_minutes, 0), 1),
            "status": status
        })
    
    return sorted(bottlenecks, key=lambda x: x["behind_minutes"], reverse=True)
```

### Bottleneck Alert Levels
```
+------------+------------------+---------------------+
| Level      | Behind Schedule  | Recommended Action  |
+------------+------------------+---------------------+
| Green      | < 5 min          | No action needed    |
| Yellow     | 5-10 min         | Monitor, consider   |
|            |                  | reallocating staff  |
| Red        | > 10 min         | Immediate action:   |
|            |                  | pull staff from     |
|            |                  | low-traffic depts   |
+------------+------------------+---------------------+
```

### Bottleneck Notification
```json
{
  "alert_type": "bottleneck_detected",
  "department": "ECG",
  "severity": "critical",
  "behind_minutes": 8,
  "patients_waiting": 12,
  "staff_on_duty": 1,
  "recommended_action": "Assign additional technician from Radiology (low load)",
  "timestamp": "2026-07-09T11:30:00"
}
```

---

## 7. BRANCH COMPARISON

```python
async def get_branch_comparison(hospital_id: UUID = None, date: date = None) -> list:
    """Compare performance metrics across all branches."""
    date = date or date.today()
    
    # If owner has access to all hospitals (multi-branch), aggregate across them
    if hospital_id:
        hospitals = await Hospital.filter(id=hospital_id).all()
    else:
        hospitals = await Hospital.all()  # Owner sees all branches
    
    results = []
    for hospital in hospitals:
        # Today's metrics
        patients_today = await Visit.filter(
            hospital_id=hospital.id,
            created_at__gte=date,
            created_at__lt=date + timedelta(days=1)
        ).count()
        
        revenue_today = await Billing.filter(
            hospital_id=hospital.id,
            paid_at__gte=date,
            paid_at__lt=date + timedelta(days=1)
        ).annotate(total=Sum("amount_paid")).values("total")
        
        avg_wait = await AnalyticsMetric.filter(
            hospital_id=hospital.id,
            metric_name="queue.avg_wait",
            granularity="daily",
            time_bucket=date
        ).first()
        
        satisfaction = await AnalyticsMetric.filter(
            hospital_id=hospital.id,
            metric_name="patient.satisfaction",
            granularity="daily",
            time_bucket=date
        ).first()
        
        results.append({
            "branch_name": hospital.name,
            "branch_location": hospital.location,
            "patients_today": patients_today,
            "revenue_today": float(revenue_today[0]["total"]) if revenue_today else 0.0,
            "avg_wait_minutes": round(float(avg_wait.value), 1) if avg_wait else 0,
            "satisfaction": round(float(satisfaction.value), 1) if satisfaction else 0.0,
            "active_doctors": await StaffUser.filter(
                hospital_id=hospital.id,
                role="doctor",
                is_clocked_in=True
            ).count(),
            "bed_occupancy_pct": await self._get_bed_occupancy(hospital.id)
        })
    
    return sorted(results, key=lambda x: x["patients_today"], reverse=True)
```

### Comparison View
```
Branch Comparison — Jul 9, 2026
+----------+------------+--------+--------+------+-------+------+--------+
| Branch   | Patients   | Revenue| Avg    | Sat  | Active| Bed  | Trend  |
|          |            |        | Wait   |      | Docs  | Occ% |        |
+----------+------------+--------+--------+------+-------+------+--------+
| Main     | 142        | 42.5K  | 12 min | 4.3  | 8     | 75%  | Up     |
| Branch 2 | 89         | 28.0K  | 8 min  | 4.1  | 5     | 60%  | Stable |
| Branch 3 | 67         | 21.0K  | 15 min | 4.5  | 4     | 45%  | Down   |
+----------+------------+--------+--------+------+-------+------+--------+
```

---

## 8. PEAK HOURS IDENTIFICATION

```python
async def identify_peak_hours(
    hospital_id: UUID,
    date: date = None
) -> dict:
    """Identify busiest time slots across departments."""
    date = date or date.today()
    
    # Get hourly patient volume
    hourly_metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="queue.throughput",
        granularity="hourly",
        time_bucket__gte=date,
        time_bucket__lt=date + timedelta(days=1)
    ).order_by("time_bucket").all()
    
    hourly_data = {}
    for m in hourly_metrics:
        hour = m.time_bucket.hour
        if hour not in hourly_data:
            hourly_data[hour] = {"total": 0, "departments": {}}
        
        dept = m.dimension.get("department_name", "Unknown") if m.dimension else "General"
        hourly_data[hour]["total"] += int(m.value)
        hourly_data[hour]["departments"][dept] =             hourly_data[hour]["departments"].get(dept, 0) + int(m.value)
    
    # Sort hours by volume descending
    sorted_hours = sorted(hourly_data.items(), key=lambda x: x[1]["total"], reverse=True)
    
    return {
        "date": date.isoformat(),
        "peak_hour": sorted_hours[0][0] if sorted_hours else None,
        "peak_volume": sorted_hours[0][1]["total"] if sorted_hours else 0,
        "hourly_breakdown": [
            {
                "hour": f"{h:02d}:00",
                "patients": data["total"],
                "departments": data["departments"],
                "is_peak": i == 0
            }
            for i, (h, data) in enumerate(sorted_hours)
        ],
        "recommendation": self._generate_staffing_recommendation(sorted_hours)
    }
```

### Peak Hour Heatmap Display
```
Hourly Patient Load — Jul 9, 2026
+----------+-------+------+--------+---------+--------+
| Hour     | Total | Card | General| Ortho   | Lab    |
+----------+-------+------+--------+---------+--------+
| 09:00    | 18    | 5    | 7      | 3       | 3      |
| 10:00    | 25    | 8    | 9      | 4       | 4      |
| 11:00    | 32    | 10   | 12     | 5       | 5      |  <-- Peak
| 12:00    | 28    | 9    | 10     | 4       | 5      |
| 13:00    | 15    | 4    | 6      | 2       | 3      |  (Lunch)
| 14:00    | 20    | 6    | 7      | 3       | 4      |
| 15:00    | 22    | 7    | 8      | 3       | 4      |
| 16:00    | 18    | 5    | 7      | 3       | 3      |
| 17:00    | 12    | 3    | 5      | 2       | 2      |
+----------+-------+------+--------+---------+--------+
```

### Staffing Recommendation
```json
{
  "peak_window": "11:00 AM - 1:00 PM",
  "recommended_additional_staff": {
    "reception": 1,
    "nurses": 2,
    "lab_technicians": 1
  },
  "expected_patient_surge": "15% higher than morning average",
  "current_coverage_gap": "2 staff members"
}
```

---

## 9. NO-SHOW RATE & REVENUE LOSS

```python
async def get_no_show_analytics(
    hospital_id: UUID,
    from_date: date = None,
    to_date: date = None
) -> dict:
    """Calculate no-show rate and estimated revenue loss."""
    from_date = from_date or (date.today() - timedelta(days=30))
    to_date = to_date or date.today()
    
    # Total appointments
    total_appointments = await Appointment.filter(
        hospital_id=hospital_id,
        appointment_date__gte=from_date,
        appointment_date__lte=to_date
    ).count()
    
    # No-shows
    no_shows = await Appointment.filter(
        hospital_id=hospital_id,
        appointment_date__gte=from_date,
        appointment_date__lte=to_date,
        status="no_show"
    ).count()
    
    no_show_rate = round((no_shows / total_appointments) * 100, 2) if total_appointments else 0
    
    # Average revenue per completed appointment
    avg_revenue_result = await Billing.filter(
        hospital_id=hospital_id,
        paid_at__gte=from_date,
        paid_at__lte=to_date
    ).annotate(avg=Avg("amount_paid")).values("avg")
    
    avg_revenue = float(avg_revenue_result[0]["avg"]) if avg_revenue_result else 0
    
    # Estimated revenue loss
    estimated_loss = no_shows * avg_revenue
    
    # Department-wise breakdown
    dept_breakdown = await self._get_no_show_by_department(hospital_id, from_date, to_date)
    
    return {
        "period": {"from": from_date.isoformat(), "to": to_date.isoformat()},
        "total_appointments": total_appointments,
        "no_shows": no_shows,
        "no_show_rate_pct": no_show_rate,
        "avg_revenue_per_appointment": round(avg_revenue, 2),
        "estimated_revenue_loss": round(estimated_loss, 2),
        "department_breakdown": dept_breakdown,
        "trend": await self._get_no_show_trend(hospital_id, from_date, to_date)
    }

async def _get_no_show_by_department(self, hospital_id, from_date, to_date):
    """No-show rates by department."""
    return await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="appointment.no_show_rate",
        granularity="daily",
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).all()
```

### No-Show Report Display
```
No-Show Analysis — Last 30 Days
+------------------+--------+---------+----------+--------------+
| Department       | Total  | No-Shows| Rate     | Revenue Loss |
+------------------+--------+---------+----------+--------------+
| Cardiology       | 450    | 28      | 6.2%     | Rs 14,000      |
| General OPD      | 620    | 42      | 6.8%     | Rs 12,600      |
| Orthopedics      | 310    | 15      | 4.8%     | Rs 7,500       |
| Pediatrics       | 280    | 22      | 7.9%     | Rs 6,600       |
| ENT              | 190    | 8       | 4.2%     | Rs 3,200       |
+------------------+--------+---------+----------+--------------+
| TOTAL            | 1,850  | 115     | 6.2%     | Rs 43,900      |
+------------------+--------+---------+----------+--------------+
```

---

## 10. PATIENT ACQUISITION TRENDS

```python
async def get_acquisition_trends(
    hospital_id: UUID,
    granularity: str = "weekly",
    from_date: date = None,
    to_date: date = None
) -> dict:
    """Track new vs returning patient trends over time."""
    from_date = from_date or (date.today() - timedelta(days=90))
    to_date = to_date or date.today()
    
    new_patient_metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="patient.new_count",
        granularity=granularity,
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).order_by("time_bucket").all()
    
    returning_metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name="patient.returning_count",
        granularity=granularity,
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).order_by("time_bucket").all()
    
    # Combine into timeline
    timeline = []
    new_by_period = {m.time_bucket.isoformat(): int(m.value) for m in new_patient_metrics}
    returning_by_period = {m.time_bucket.isoformat(): int(m.value) for m in returning_metrics}
    
    all_periods = set(list(new_by_period.keys()) + list(returning_by_period.keys()))
    for period in sorted(all_periods):
        n = new_by_period.get(period, 0)
        r = returning_by_period.get(period, 0)
        total = n + r
        timeline.append({
            "period": period,
            "new": n,
            "returning": r,
            "total": total,
            "new_pct": round((n / total) * 100, 1) if total else 0,
            "returning_pct": round((r / total) * 100, 1) if total else 0
        })
    
    # Summary stats
    total_new = sum(t["new"] for t in timeline)
    total_returning = sum(t["returning"] for t in timeline)
    total_all = total_new + total_returning
    
    return {
        "granularity": granularity,
        "period": {"from": from_date.isoformat(), "to": to_date.isoformat()},
        "summary": {
            "total_patients": total_all,
            "total_new": total_new,
            "total_returning": total_returning,
            "acquisition_rate_pct": round((total_new / total_all) * 100, 1) if total_all else 0,
            "retention_rate_pct": round((total_returning / total_all) * 100, 1) if total_all else 0
        },
        "timeline": timeline
    }
```

### Acquisition Trend View
```
Patient Acquisition — Last 90 Days (Weekly)
+------------+-------+-----------+-------+-----------+------------+
| Week       | New   | Returning | Total | New %     | Trend      |
+------------+-------+-----------+-------+-----------+------------+
| Apr 14     | 45    | 98        | 143   | 31.5%     | Up         |
| Apr 21     | 52    | 105       | 157   | 33.1%     | Up         |
| Apr 28     | 38    | 112       | 150   | 25.3%     | Down       |
| May 5      | 41    | 108       | 149   | 27.5%     | Stable     |
| May 12     | 55    | 120       | 175   | 31.4%     | Up         |
| May 19     | 48    | 115       | 163   | 29.4%     | Stable     |
| May 26     | 62    | 130       | 192   | 32.3%     | Up         |
| Jun 2      | 58    | 125       | 183   | 31.7%     | Stable     |
| Jun 9      | 50    | 140       | 190   | 26.3%     | Down       |
| Jun 16     | 65    | 135       | 200   | 32.5%     | Up         |
| Jun 23     | 70    | 145       | 215   | 32.6%     | Up         |
| Jun 30     | 55    | 150       | 205   | 26.8%     | Down       |
| Jul 7      | 48    | 142       | 190   | 25.3%     | Down       |
+------------+-------+-----------+-------+-----------+------------+
```

---

## 11. SUBSCRIPTION / BILLING MANAGEMENT

```python
async def get_subscription_info(hospital_id: UUID) -> dict:
    """Get current subscription plan, usage, and billing status."""
    subscription = await Subscription.filter(hospital_id=hospital_id).first()
    if not subscription:
        return {"plan": "free", "status": "no_active_subscription"}
    
    # Calculate usage percentages
    usage = {
        "staff_count": await StaffUser.filter(hospital_id=hospital_id, active=True).count(),
        "patient_count_30d": await Visit.filter(
            hospital_id=hospital_id,
            created_at__gte=date.today() - timedelta(days=30)
        ).count(),
        "storage_used_mb": await self._get_storage_usage(hospital_id)
    }
    
    plan_limits = {
        "free": {"staff": 5, "patients_monthly": 500, "storage_mb": 100},
        "starter": {"staff": 15, "patients_monthly": 2000, "storage_mb": 500},
        "professional": {"staff": 50, "patients_monthly": 10000, "storage_mb": 2000},
        "premium": {"staff": 200, "patients_monthly": 50000, "storage_mb": 10000},
        "enterprise": {"staff": None, "patients_monthly": None, "storage_mb": None}
    }
    
    limits = plan_limits.get(subscription.plan, plan_limits["free"])
    
    return {
        "plan": subscription.plan,
        "status": subscription.status,
        "billing_cycle": subscription.billing_cycle,
        "next_billing_date": subscription.next_billing_date.isoformat() if subscription.next_billing_date else None,
        "amount": float(subscription.amount) if subscription.amount else 0,
        "usage": {
            "staff": {
                "current": usage["staff_count"],
                "limit": limits["staff"],
                "pct": round((usage["staff_count"] / limits["staff"]) * 100, 1) if limits["staff"] else 0
            },
            "patients": {
                "current": usage["patient_count_30d"],
                "limit": limits["patients_monthly"],
                "pct": round((usage["patient_count_30d"] / limits["patients_monthly"]) * 100, 1) if limits["patients_monthly"] else 0
            },
            "storage": {
                "current_mb": usage["storage_used_mb"],
                "limit_mb": limits["storage_mb"],
                "pct": round((usage["storage_used_mb"] / limits["storage_mb"]) * 100, 1) if limits["storage_mb"] else 0
            }
        },
        "features": subscription.features or [],
        "payment_method": subscription.payment_method,
        "invoices": await self._get_recent_invoices(hospital_id)
    }
```

### Plan Comparison Table

| Feature | Free | Starter | Professional | Premium | Enterprise |
|---------|------|---------|-------------|---------|------------|
| Monthly Price | Free | Rs 2,499 | Rs 6,999 | Rs 14,999 | Custom |
| Branches | 1 | 2 | 5 | 10 | Unlimited |
| Staff Users | 5 | 15 | 50 | 200 | Unlimited |
| Patients/Month | 500 | 2,000 | 10,000 | 50,000 | Unlimited |
| Storage | 100 MB | 500 MB | 2 GB | 10 GB | Custom |
| Analytics | Basic | Standard | Advanced | Full Suite | Custom |
| API Access | No | Read-only | Read/Write | Full | Custom |
| Support | Email | Email+Chat | 24/7 Phone | Dedicated | White-Glove |

---

## 12. STAFF OVERVIEW

```python
async def get_staff_overview(hospital_id: UUID) -> dict:
    """Aggregate staff attendance, counts, and utilization."""
    total_staff = await StaffUser.filter(
        hospital_id=hospital_id,
        active=True
    ).count()
    
    clocked_in = await StaffUser.filter(
        hospital_id=hospital_id,
        active=True,
        is_clocked_in=True
    ).count()
    
    doctors = await StaffUser.filter(
        hospital_id=hospital_id,
        active=True,
        role="doctor"
    ).count()
    
    doctors_clocked = await StaffUser.filter(
        hospital_id=hospital_id,
        active=True,
        role="doctor",
        is_clocked_in=True
    ).count()
    
    # Role breakdown
    role_counts = {}
    for role in ["doctor", "nurse", "receptionist", "lab_technician", "pharmacist", "accountant", "admin"]:
        role_counts[role] = await StaffUser.filter(
            hospital_id=hospital_id,
            active=True,
            role=role
        ).count()
    
    # Departments with staffing gaps
    dept_staffing = await self._get_department_staffing(hospital_id)
    
    return {
        "total_staff": total_staff,
        "clocked_in": clocked_in,
        "attendance_rate_pct": round((clocked_in / total_staff) * 100, 1) if total_staff else 0,
        "doctors": {"total": doctors, "clocked_in": doctors_clocked},
        "role_breakdown": role_counts,
        "department_staffing": dept_staffing
    }
```

### Staff Overview Display
```
Staff Overview — Jul 9, 2026
+---------------------------+--------+-----------+--------+
| Role                      | Total  | Present   | Absent |
+---------------------------+--------+-----------+--------+
| Doctors                   | 12     | 10 (83%)  | 2      |
| Nurses                    | 18     | 15 (83%)  | 3      |
| Receptionists             | 6      | 5 (83%)   | 1      |
| Lab Technicians           | 8      | 7 (88%)   | 1      |
| Pharmacists               | 4      | 3 (75%)   | 1      |
| Accountants               | 3      | 3 (100%)  | 0      |
| Admin                     | 4      | 4 (100%)  | 0      |
+---------------------------+--------+-----------+--------+
| TOTAL                     | 55     | 47 (85%)  | 8      |
+---------------------------+--------+-----------+--------+
```

---

## 13. EXPORT REPORTS

```python
class OwnerReportExporter:
    """Generate PDF and CSV reports for any dashboard view."""
    
    async def export_dashboard_pdf(
        self,
        hospital_id: UUID,
        view_name: str,
        date_range: tuple = None,
        branch_ids: list = None
    ) -> bytes:
        """Export any dashboard view as a styled PDF report."""
        date_range = date_range or (date.today() - timedelta(days=30), date.today())
        
        views = {
            "daily_summary": self._render_daily_summary,
            "revenue_analytics": self._render_revenue_analytics,
            "doctor_productivity": self._render_doctor_productivity,
            "branch_comparison": self._render_branch_comparison,
            "acquisition_trends": self._render_acquisition_trends,
            "no_show_analysis": self._render_no_show_analysis,
            "staff_overview": self._render_staff_overview
        }
        
        if view_name not in views:
            raise ValueError(f"Unknown view: {view_name}. Available: {list(views.keys())}")
        
        data = await views[view_name](hospital_id, date_range, branch_ids)
        
        # Render via Jinja2 + WeasyPrint
        env = Environment(loader=FileSystemLoader("templates/reports/"))
        template = env.get_template("owner_report.html")
        html = template.render(
            title=view_name.replace("_", " ").title(),
            hospital_name=(await Hospital.get(hospital_id)).name,
            date_range=date_range,
            data=data,
            generated_at=datetime.now().isoformat()
        )
        
        return HTML(string=html).write_pdf()
    
    async def export_csv(
        self,
        hospital_id: UUID,
        view_name: str,
        date_range: tuple = None
    ) -> str:
        """Export any data view as CSV."""
        from_date, to_date = date_range or (date.today() - timedelta(days=30), date.today())
        import io
        import csv
        
        rows = await self._get_csv_data(hospital_id, view_name, from_date, to_date)
        
        output = io.StringIO()
        if rows:
            writer = csv.DictWriter(output, fieldnames=rows[0].keys())
            writer.writeheader()
            writer.writerows(rows)
        
        return output.getvalue()
```

### Export Options

| View | PDF | CSV | Use Case |
|------|-----|-----|----------|
| Daily Summary | Yes | Yes | End-of-day briefing |
| Revenue Analytics | Yes | Yes | Monthly financial review |
| Doctor Productivity | Yes | Yes | Performance review |
| Branch Comparison | Yes | Yes | Expansion decisions |
| Acquisition Trends | Yes | Yes | Marketing effectiveness |
| No-Show Analysis | Yes | Yes | Operations improvement |
| Staff Overview | Yes | Yes | HR planning |
| Peak Hours Report | Yes | Yes | Scheduling optimization |
| Bottleneck Report | Yes | No | Immediate ops review |

### Export API
```python
@router.get("/api/v1/owner/export/{view_name}")
async def export_report(
    view_name: str,
    format: str = Query("pdf", regex="^(pdf|csv)$"),
    from_date: date = Query(None),
    to_date: date = Query(None),
    branch_id: UUID = Query(None),
    hospital_id: UUID = Header(...)
):
    """Export a dashboard view in PDF or CSV format."""
    exporter = OwnerReportExporter()
    
    if format == "pdf":
        pdf_bytes = await exporter.export_dashboard_pdf(
            hospital_id, view_name, (from_date, to_date), [branch_id] if branch_id else None
        )
        return StreamingResponse(
            io.BytesIO(pdf_bytes),
            media_type="application/pdf",
            headers={"Content-Disposition": f"attachment; filename={view_name}_{date.today()}.pdf"}
        )
    else:
        csv_content = await exporter.export_csv(hospital_id, view_name, (from_date, to_date))
        return StreamingResponse(
            iter([csv_content]),
            media_type="text/csv",
            headers={"Content-Disposition": f"attachment; filename={view_name}_{date.today()}.csv"}
        )
```

---

## 14. DATA MODEL

No new tables are required for the Owner Module. All data is read from the existing
`analytics_metrics` and `analytics_kpis` tables defined in the Analytics Engine (0109).

### Source Tables Used

| Table | Purpose | Query Pattern |
|-------|---------|--------------|
| analytics_metrics | Time-series metric data | Filter by metric_name, granularity, time_bucket, dimension |
| analytics_kpis | Pre-computed KPI snapshots | Filter by kpi_name, period, dimension |
| hospitals (read-only) | Branch metadata | Branch name, location for comparison |
| staff_users (read-only) | Doctor/staff counts | Role and clock-in status filters |

### Dimension Keys (JSONB)

```json
{
  "doctor_id": "uuid",
  "doctor_name": "Dr. Sharma",
  "department_id": "uuid",
  "department_name": "Cardiology",
  "branch_id": "uuid",
  "branch_name": "Main Branch",
  "role": "doctor"
}
```

### Key Metric Names

| Metric Name | Granularity | Description |
|-------------|-------------|-------------|
| queue.avg_wait | daily, hourly | Average wait time per department |
| queue.throughput | daily, hourly | Patients completed per time bucket |
| queue.no_show_rate | daily | Percentage of no-shows |
| revenue.daily | daily | Total revenue per day |
| revenue.by_department | daily | Revenue breakdown by department |
| doctor.patients_seen | daily | Patients per doctor |
| doctor.revenue | daily | Revenue per doctor |
| patient.new_count | daily, weekly | New patient registrations |
| patient.returning_count | daily, weekly | Returning patient visits |
| patient.satisfaction | daily | Average satisfaction score |
| staff.attendance | daily | Staff attendance rate |
| appointment.fill_rate | daily | Appointment slot utilization |

---

## 15. API ENDPOINTS

All Owner Module endpoints are read-only analytics queries.

```python
from fastapi import APIRouter, Header, Query, HTTPException
from typing import Optional
from datetime import date, datetime, timedelta

router = APIRouter(prefix="/api/v1/owner", tags=["owner"])


@router.get("/dashboard")
async def owner_dashboard(
    hospital_id: UUID = Header(...),
    date_param: date = Query(None, alias="date")
):
    """Get the aggregate owner dashboard data."""
    date_param = date_param or date.today()
    engine = MetricsEngine()

    return {
        "date": date_param.isoformat(),
        "today": await engine.get_daily_metrics(hospital_id, date_param),
        "revenue_mtd": await _get_kpi(hospital_id, "revenue.monthly", "this_month"),
        "bottlenecks": await detect_bottlenecks(hospital_id),
        "branches": await get_branch_comparison(hospital_id, date_param),
        "peak_hours": await identify_peak_hours(hospital_id, date_param),
        "staff_overview": await get_staff_overview(hospital_id)
    }


@router.get("/revenue/trend")
async def revenue_trend(
    granularity: str = Query("daily", regex="^(daily|weekly|monthly)$"),
    from_date: date = Query(None),
    to_date: date = Query(None),
    hospital_id: UUID = Header(...)
):
    """Revenue time-series data."""
    return await get_revenue_trend(hospital_id, granularity, from_date, to_date)


@router.get("/revenue/by-department")
async def revenue_by_department(
    from_date: date = Query(None),
    to_date: date = Query(None),
    hospital_id: UUID = Header(...)
):
    """Revenue breakdown by department."""
    return await get_revenue_by_department(
        hospital_id, from_date or date.today(), to_date or date.today()
    )


@router.get("/doctors/productivity")
async def doctor_productivity(
    from_date: date = Query(None),
    to_date: date = Query(None),
    branch_id: UUID = Query(None),
    hospital_id: UUID = Header(...)
):
    """Doctor productivity ranking."""
    return await get_doctor_productivity(hospital_id, from_date, to_date, branch_id)


@router.get("/analytics/no-shows")
async def no_show_analysis(
    from_date: date = Query(None),
    to_date: date = Query(None),
    hospital_id: UUID = Header(...)
):
    """No-show rate and revenue loss analysis."""
    return await get_no_show_analytics(hospital_id, from_date, to_date)


@router.get("/patients/acquisition")
async def acquisition_trends(
    granularity: str = Query("weekly", regex="^(daily|weekly|monthly)$"),
    from_date: date = Query(None),
    to_date: date = Query(None),
    hospital_id: UUID = Header(...)
):
    """New vs returning patient trends."""
    return await get_acquisition_trends(hospital_id, granularity, from_date, to_date)


@router.get("/subscription")
async def subscription_info(
    hospital_id: UUID = Header(...)
):
    """Current subscription plan and usage."""
    return await get_subscription_info(hospital_id)


@router.get("/staff/overview")
async def staff_overview(
    hospital_id: UUID = Header(...)
):
    """Staff attendance and role breakdown."""
    return await get_staff_overview(hospital_id)


@router.get("/export/{view_name}")
async def export_report(
    view_name: str,
    format: str = Query("pdf", regex="^(pdf|csv)$"),
    from_date: date = Query(None),
    to_date: date = Query(None),
    hospital_id: UUID = Header(...)
):
    """Export any dashboard view."""
    exporter = OwnerReportExporter()
    # See Section 13 for full implementation
```

---

## 16. CONFIGURATION

```yaml
owner_module:
  dashboard:
    auto_refresh_seconds: 30
    default_date_range_days: 30
    max_branches_display: 10
    chart_points_max: 365

  analytics:
    revenue_comparison_periods:
      - "previous_month"
      - "same_month_last_year"
      - "monthly_target"
    bottleneck_thresholds:
      warning_minutes: 5
      critical_minutes: 10
    no_show_window_days: 30
    peak_hour_window_days: 7

  export:
    max_date_range_days: 365
    pdf_template: "owner_report.html"
    pdf_page_size: "A4"
    csv_encoding: "utf-8-sig"
    branding:
      logo_path: "/static/logo.png"
      footer_text: "GIL CLINIC - Confidential"

  staff:
    attendance_threshold_pct: 80

  notifications:
    bottleneck_alert: true
    daily_summary_pdf: false
    weekly_report_email: true
    monthly_report_email: true
    alert_recipients: []
```

---

## 17. KEY DESIGN DECISIONS

1. **No new tables** — The Owner Module reads entirely from the existing `analytics_metrics` and `analytics_kpis` tables. Computations happen in the Analytics Engine layer.

2. **Pre-computed KPIs** — All dashboard KPIs are pre-computed by scheduled jobs. The dashboard never runs heavy aggregations on load.

3. **Dimension-based filtering** — Branch, department, and doctor data are stored as JSONB dimensions on metrics. This allows flexible filtering without schema changes.

4. **Read-only endpoints** — Owner API endpoints are strictly read-only. The owner never mutates state through this module.

5. **Multi-branch first** — All queries support filtering by hospital_id (branch). Cross-branch aggregation uses the owner-level hospital context.

6. **Exportable views** — Every dashboard view has a PDF and CSV export. Reports use Jinja2 templates for consistent branding.

7. **Period-over-period comparisons** — Every metric automatically includes the previous period value and percentage change, enabling trend analysis.

8. **Alert-driven bottlenecks** — Bottleneck detection is computed in real-time from queue metrics, but displayed only when thresholds are exceeded to reduce noise.

9. **Subscription-aware** — Certain advanced metrics (e.g., branch comparison, export) are only available based on subscription tier.

10. **Role-based dashboard sections** — Even within the Owner Module, certain views can be restricted based on the owner's subscription level or permissions.
