---
file_id: "0201"
module_name: "Doctor Module"
version: "1.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0101_WORKFLOW_ENGINE.md", "0108_REPORT_ENGINE.md"]
related_files: ["0300_OPD.md", "0505_AI_PRESCRIPTION.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "doctor", "dashboard", "consultation", "prescription", "clinical"]
---

# 🩺 GHOS — Doctor Module

> **The Doctor Module is the most clinically critical interface in GHOS. Designed for speed: every action is one or two clicks. The doctor sees one patient at a time — current patient in focus, next three queued. Everything else is background.**

---

## 1. PURPOSE

The Doctor Module is the primary interface for clinical care. It enables:
- **Patient consultation** — See patient info, vitals, history at a glance
- **Queue management** — Call next, skip, recall, route to departments
- **Prescription** — Quick medicine entry with autocomplete + AI suggestions
- **Diagnosis & notes** — Structured diagnosis entry with ICD-10 coding
- **Report review** — View completed test results inline
- **Patient routing** — Send to lab, ECG, Echo, Pharmacy, or discharge

---

## 2. DOCTOR DASHBOARD

```
┌──────────────────────────────────────────────────────────────┐
│  👨‍⚕️ Dr. Sharma — Cardiology                    09:42 AM      │
│  📊 Today: 42 patients │ Seen: 28 │ Avg: 7.2 min/patient     │
├──────────────────────────────────────────────────────────────┤
│                                                              │
│  ┌─── CURRENT PATIENT ───────────────────────────────────┐   │
│  │                                                        │   │
│  │  📋 DOC-042 │ Rajesh Kumar │ 45/M ⭐ VIP              │   │
│  │  📝 New visit │ Chest pain since 2 days               │   │
│  │  📍 Last visit: 6 months ago (General OPD)            │   │
│  │                                                        │   │
│  │  ┌─── Vitals ───────────────────────────────────┐     │   │
│  │  │  BP: 130/80 ⚠️ | HR: 72 | Temp: 98.6°F     │     │   │
│  │  │  SpO2: 98% | Weight: 72kg | Height: 170cm   │     │   │
│  │  └──────────────────────────────────────────────┘     │   │
│  │                                                        │   │
│  │  ┌─── DIAGNOSIS ─────────────────────────────────┐     │   │
│  │  │  [Unstable Angina (ICD-10: I20.0)________]    │     │   │
│  │  │  [Type 2 Diabetes (ICD-10: E11.9)________]    │     │   │
│  │  │  [➕ Add Diagnosis]                            │     │   │
│  │  └──────────────────────────────────────────────┘     │   │
│  │                                                        │   │
│  │  ┌─── TESTS ORDERED ────────────────────────────┐     │   │
│  │  │  ✅ ECG ⏳ [Pending Result]                   │     │   │
│  │  │  ⏳ Lab: CBC, Lipid Profile                   │     │   │
│  │  │  [➕ Order Test]                              │     │   │
│  │  └──────────────────────────────────────────────┘     │   │
│  │                                                        │   │
│  │  ┌─── PRESCRIPTION ─────────────────────────────┐     │   │
│  │  │  ┌──────────────────────────────┐  ┌──────┐  │     │   │
│  │  │  │ Aspirin 75mg                 │  │1-0-1 │  │     │   │
│  │  │  │ 7 days │ After food          │  └──────┘  │     │   │
│  │  │  ├──────────────────────────────┤            │     │   │
│  │  │  │ Atorvastatin 10mg           │  ┌──────┐  │     │   │
│  │  │  │ 30 days │ At night           │  │0-0-1 │  │     │   │
│  │  │  └──────────────────────────────┘  └──────┘  │     │   │
│  │  │  [➕ Add Medicine] [💡 AI Suggest]            │     │   │
│  │  │  Advice: Low salt diet, walk 30 min daily     │     │   │
│  │  └──────────────────────────────────────────────┘     │   │
│  │                                                        │   │
│  │  ⏱ Session time: 3:28                                 │   │
│  │                                                        │   │
│  │  [✅ Finish & Route] [⏭️ Skip] [🔙 Recall]            │   │
│  │  [🧪 To Lab] [📈 To ECG] [💊 To Pharmacy] [🏠 D/C]    │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─── NEXT PATIENTS ─────────────────────────────────────┐   │
│  │  DOC-043 │ Priya Singh (32/F) │ Follow-up │ 2 min late │   │
│  │  DOC-044 │ Mohan Lal (60/M)   │ New ⭐ Senior          │   │
│  │  DOC-045 │ Sunita (28/F)      │ New | Headache         │   │
│  │  [View Full Queue →]                                  │   │
│  └────────────────────────────────────────────────────────┘   │
│                                                              │
│  ┌─── PENDING REPORTS ──────────────────────────────────┐   │
│  │  🔔 5 reports pending your review                     │   │
│  │  [View Pending Reports →]                             │   │
│  └────────────────────────────────────────────────────────┘   │
└──────────────────────────────────────────────────────────────┘
```

---

## 3. CLINICAL WORKFLOW

```
Patient Called
  → Doctor dashboard shows patient summary within 500ms
  → Doctor reviews history, vitals, reason for visit
  → Examines patient (offline)
  → Enters diagnosis (ICD-10 coded)
  → Orders tests if needed (sends to ECG/Lab/etc.)
  → Writes prescription (with AI suggestions)
  → Adds advice and follow-up instructions
  → Clicks "Finish & Route"
      → If tests ordered: route to lab/ECG
      → If prescription only: route to pharmacy
      → If done: discharge with summary
  → Next patient auto-loaded (500ms transition)
```

### Key Interactions

| Action | Effect |
|--------|--------|
| **Spacebar** | Call next patient from queue |
| **Ctrl+Enter** | Finish current visit (with current route) |
| **Ctrl+Shift+E** | Finish + send to ECG |
| **Ctrl+Shift+L** | Finish + send to Lab |
| **Ctrl+Shift+P** | Finish + send to Pharmacy |
| **Ctrl+D** | Discharge patient (visit complete) |
| **S** | Skip patient (moves to end of queue) |
| **R** | Recall last skipped patient |

---

## 4. PRESCRIPTION SYSTEM

```python
class PrescriptionEngine:
    """
    Doctor prescription system with AI assistance.
    
    Features:
    - Medicine autocomplete (brand + generic names)
    - Dosage suggestions based on diagnosis
    - Drug interaction warnings
    - Bilingual output (English + Hindi)
    - One-tap send to pharmacy
    """
    
    MEDICINE_DB = {
        "aspirin": {"brands": ["Ecosprin", "Aspirin", "Disprin"], "forms": ["75mg", "150mg", "325mg"]},
        "atorvastatin": {"brands": ["Atorva", "Storvas", "Lipitor"], "forms": ["10mg", "20mg", "40mg"]},
        "amlodipine": {"brands": ["Amlopin", "Amlodac", "Norvasc"], "forms": ["2.5mg", "5mg", "10mg"]},
        # ... 1000+ medicines
    }
    
    async def autocomplete(self, query: str) -> List[dict]:
        """Autocomplete medicine names (brand + generic)."""
        results = []
        query = query.lower()
        
        for generic, info in self.MEDICINE_DB.items():
            if query in generic or any(query in b.lower() for b in info["brands"]):
                results.append({
                    "generic": generic,
                    "brands": info["brands"],
                    "forms": info["forms"],
                    "match_type": "generic" if query in generic else "brand"
                })
        
        return sorted(results, key=lambda r: r["match_type"] == "generic", reverse=True)[:10]
    
    async def check_interactions(self, medicines: List[str], patient_id: UUID) -> List[dict]:
        """Check for drug-drug interactions."""
        # Use drug interaction database
        warnings = []
        # Example: Aspirin + Warfarin = bleeding risk
        # Example: ACE inhibitor + K-sparing diuretic = hyperkalemia
        return warnings
    
    async def suggest_dosage(self, diagnosis: str, age: int, weight: float) -> List[dict]:
        """AI-powered dosage suggestions based on diagnosis."""
        # AI model suggests common regimens for the diagnosis
        suggestions = [
            {"medicine": "Aspirin 75mg", "dosage": "1-0-1", "days": 7, "note": "After food"},
            {"medicine": "Atorvastatin 10mg", "dosage": "0-0-1", "days": 30, "note": "At night"}
        ]
        return suggestions
```

---

## 5. DIAGNOSIS SYSTEM (ICD-10)

```python
class DiagnosisSystem:
    """ICD-10 coded diagnosis entry with autocomplete."""
    
    ICD10_DB = {
        "I20.0": "Unstable Angina",
        "I20.1": "Stable Angina",
        "E11.9": "Type 2 Diabetes without complications",
        "E11.8": "Type 2 Diabetes with complications",
        "I10": "Essential Hypertension",
        "J45": "Asthma",
        # ... full ICD-10 catalog
    }
    
    async def search(self, query: str) -> List[dict]:
        """Search ICD-10 codes by name or code."""
        results = []
        query = query.lower()
        for code, name in self.ICD10_DB.items():
            if query in code.lower() or query in name.lower():
                results.append({"code": code, "name": name})
        return results[:10]
```

---

## 6. PATIENT ROUTING

When a doctor completes a consultation, they can route the patient to any department:

```python
class DoctorRouting:
    """Route patients to next department after consultation."""
    
    ROUTE_OPTIONS = {
        "lab": {"department": "Lab", "reason": "Tests ordered", "priority": "normal"},
        "ecg": {"department": "ECG", "reason": "ECG ordered", "priority": "high"},
        "echo": {"department": "Echo", "reason": "Echo ordered", "priority": "high"},
        "tmt": {"department": "TMT", "reason": "TMT ordered", "priority": "normal"},
        "pharmacy": {"department": "Pharmacy", "reason": "Prescription", "priority": "normal"},
        "billing": {"department": "Billing", "reason": "Payment required", "priority": "normal"},
        "discharge": {"department": None, "reason": "Visit complete", "priority": None}
    }
    
    async def route_patient(
        self, visit_id: UUID, route: str, notes: str = None
    ):
        """Route patient to next department or discharge."""
        visit = await Visit.get(visit_id)
        config = self.ROUTE_OPTIONS[route]
        
        if route == "discharge":
            visit.status = "completed"
            visit.completed_at = datetime.now()
            await visit.save()
            
            # Notify patient
            await NotificationOrchestrator().send(
                patient_id=visit.patient_id,
                notification_type="visit_completed",
                data={"summary_url": f"/visits/{visit.id}/summary"}
            )
        else:
            # Route to next department
            visit.status = "routed"
            await visit.save()
            
            await QueueEngine().enqueue(
                patient_id=visit.patient_id,
                department_id=config["department"],
                priority=config["priority"],
                visit_id=visit.id,
                notes=notes
            )
            
            # Notify patient
            await NotificationOrchestrator().send(
                patient_id=visit.patient_id,
                notification_type="patient_routed",
                data={
                    "department": config["department"],
                    "reason": config["reason"],
                    "token": visit.token_number
                }
            )
```

---

## 7. REPORT REVIEW

```python
class DoctorReportReview:
    """Doctors review and sign reports from tests."""
    
    async def get_pending_reports(self, doctor_id: UUID) -> List[dict]:
        """Get reports pending doctor's review."""
        reports = await Report.filter(
            status="draft",
            department__doctor_id=doctor_id
        ).order_by("-created_at").limit(20).all()
        
        return [{
            "id": str(r.id),
            "patient": r.patient.name,
            "type": r.type,
            "created_at": r.created_at,
            "department": r.department.name
        } for r in reports]
    
    async def sign_report(self, report_id: UUID, doctor_id: UUID) -> dict:
        """Sign and finalize a report."""
        report = await Report.get(report_id)
        report.status = "signed"
        report.signed_by = doctor_id
        report.signed_at = datetime.now()
        await report.save()
        
        # Trigger notification
        await ReportEngine().notify_ready(report)
        
        return {"success": True, "report_id": str(report.id)}
```

---

## 8. DOCTOR SETTINGS

```yaml
doctor_module:
  ui:
    auto_call_next: true                    # Auto-load next patient when current finishes
    show_next_patients: 3
    show_pending_reports: true
    keyboard_shortcuts_enabled: true
    
  prescription:
    autocomplete_min_chars: 2
    ai_suggestions_enabled: true
    check_interactions: true
    bilingual_output: true
    
  routing:
    default_route_after_finish: "pharmacy"  # If no tests ordered
    confirm_discharge: true
    
  icd10:
    require_icd10_code: true
    auto_suggest_from_history: true
    
  performance:
    target_consultation_minutes: 8
    alert_if_exceeds_minutes: 15
    max_daily_patients: 80
```

---

## 9. DATA MODEL EXTENSIONS

```sql
-- Doctor-specific session tracking
ALTER TABLE visits ADD COLUMN IF NOT EXISTS consultation_started_at TIMESTAMP;
ALTER TABLE visits ADD COLUMN IF NOT EXISTS consultation_ended_at TIMESTAMP;
ALTER TABLE visits ADD COLUMN IF NOT EXISTS diagnosis JSONB;          -- ICD-10 codes
ALTER TABLE visits ADD COLUMN IF NOT EXISTS doctor_notes TEXT;

-- Prescriptions
CREATE TABLE prescriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    doctor_id UUID NOT NULL REFERENCES staff_users(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    medicines JSONB NOT NULL,
    advice TEXT,
    follow_up_days INTEGER,
    ai_generated BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 10. KEY DESIGN DECISIONS

1. **One patient at a time** — The doctor only sees current patient in detail. Next 3 are visible but not distracting.
2. **Keyboard-first** — Every action has a keyboard shortcut. Spacebar = next patient. Ctrl+Enter = finish.
3. **ICD-10 by default** — Diagnosis is coded from the start. Enables analytics, insurance claims, and research.
4. **Prescription with AI** — Autocomplete on medicine names, dosage suggestions by diagnosis, interaction checks.
5. **One-click routing** — Finish consultation + route to next department in one action. No separate "save" step.
6. **Inline report review** — Doctor can view test results without leaving the consultation screen.
7. **Session timing** — Track consultation duration automatically. Helps with productivity analytics and wait time predictions.
