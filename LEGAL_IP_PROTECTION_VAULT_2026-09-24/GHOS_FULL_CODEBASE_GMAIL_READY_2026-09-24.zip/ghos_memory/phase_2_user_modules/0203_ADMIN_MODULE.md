---
file_id: "0203"
module_name: "Admin Module"
version: "2.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0105_AUTH_ENGINE.md", "0106_PERMISSION_ENGINE.md"]
related_files: []
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "admin", "settings", "configuration"]
---

# GHOS Admin Module

## 1. PURPOSE

The Admin Module is the central configuration hub of the clinic system. It empowers
super-administrators to manage every non-clinical aspect of the system:

- Hospital-wide settings (name, branding, timings, holidays)
- Department structure (CRUD, ordering, service-time configuration)
- Staff accounts (add, edit, deactivate, role assignment)
- User accounts and authentication PIN/OTP management
- Role-based access control (delegates to the Permission Engine)
- Localisation (language, currency, receipt templates)
- QR and branding customisation for patient-facing links
- Backup and export (database snapshots, report exports, audit logs)
- System audit log viewer with rich filtering

## 2. ADMIN PANEL NAVIGATION

The admin panel is the left-hand sidebar presented to users with the `super_admin`
or `admin` role. Each section maps to a separate view within the SPA.

```
+-------------------------------------------+
| ADMIN PANEL                        LOGOUT |
+-------------------------------------------+
|                                              |
|  Hospital Setup       >                      |
|    Name, logo, address, timings              |
|  Department Mgmt     >                      |
|    CRUD, ordering, avg service times         |
|  Staff Management    >                      |
|    Add/edit/deactivate staff                 |
|  User Accounts       >                      |
|    PIN/password, activate/deactivate         |
|  Roles & Permissions >                      |
|    Link to permission engine                 |
|  Clinic Settings     >                      |
|    Language, currency, receipts, notifs      |
|  QR & Branding       >                      |
|    Logo, colors, patient link domain         |
|  Holidays & Schedule >                      |
|    Off days, special timings                 |
|  Backup & Export     >                      |
|    DB backup, report export, audit export    |
|  Audit Log Viewer    >                      |
|    Filter by user/action/date range          |
+-------------------------------------------+
```

## 3. HOSPITAL SETUP

This section captures the institution-level metadata used throughout the system
(receipt headers, SMS sender IDs, display names, etc.).

### 3.1 Form Fields

```
Field             Type        Required    Notes
─────────────────────────────────────────────────
hospital_name     string      Yes         Display name on receipts, SMS
hospital_short    string      No          Abbreviation (max 10 chars)
address_line1     string      Yes
address_line2     string      No
city              string      Yes
state             string      Yes
postal_code       string      Yes
country           string      Yes         Default: India
phone             string      Yes         Primary contact number
email             string      No          Support / info email
website           string      No
logo_url          string      No          Uploaded logo path (see branding)
opening_time      time        Yes         e.g. 09:00
closing_time      time        Yes         e.g. 20:00
timezone          string      Yes         e.g. Asia/Kolkata
week_start_day    enum        No          Monday|Sunday (default Monday)
```

### 3.2 Behaviour

- Only one hospital record exists in the system (singleton pattern).
- Changing `opening_time` / `closing_time` affects the default slot generator
  in the Queue/Optimiser modules; existing schedules are NOT retroactively changed.
- Logo upload produces three sizes: full, thumbnail (64x64), and favicon (32x32).

## 4. DEPARTMENT MANAGEMENT

Every department in the clinic is managed here. CRUD operations are immediate
and reflected in the Queue and Appointment modules without restart.

### 4.1 Department Schema

```python
# ghos/admin/schemas.py

from pydantic import BaseModel
from uuid import UUID, uuid4
from typing import Optional

class DepartmentCreate(BaseModel):
    name: str                     # Display name, e.g. "Electrocardiography"
    short_code: str               # Abbreviation used on tokens/receipts, e.g. "ECG"
    avg_service_time_min: int     # Expected appointment duration in minutes
    room_name: str                # Physical room identifier, e.g. "ECG Room 1"
    requires_doctor_referral: bool = False
    icon: Optional[str] = None    # Material icon name or icon URL
    order: int                    # Display order (lower = first)
    active: bool = True

class DepartmentUpdate(DepartmentCreate):
    id: UUID                      # Target department

class DepartmentResponse(DepartmentCreate):
    id: UUID
    created_at: datetime
    updated_at: datetime
    staff_count: int              # Computed: number of active staff assigned
```

### 4.2 Behaviour

- `order` column controls sidebar and dropdown sort order.
- Deleting a department is a **soft delete** (`active = False`). Historical
  appointments and queue entries preserve the department UUID.
- Changing `avg_service_time_min` does NOT reschedule existing appointments;
  it only affects new slot generation.
- `room_name` is used by the token/queue display system for directing patients.

### 4.3 Department List (Admin View)

```
+----+--------+------+------+-------+------+----------+-------+
| #  | Name   | Code | Time | Room  | Ref? | Active   | Order |
+----+--------+------+------+-------+------+----------+-------+
| 1  | ECG    | ECG  | 10m  | Rm 1  | Yes  | YES      | 3     |
| 2  | X-Ray  | XRAY | 15m  | Rm 2  | No   | YES      | 1     |
+----+--------+------+------+-------+------+----------+-------+
|                        [Add Department]                       |
+--------------------------------------------------------------+
```

Inline editing and drag-to-reorder are supported in the UI.

## 5. STAFF MANAGEMENT

Staff records are separate from user accounts (a staff member may or may not
have a login). This section manages the **staff directory**.

### 5.1 Staff Schema

```python
# ghos/admin/schemas.py

class StaffCreate(BaseModel):
    full_name: str
    mobile: str                   # Unique, used as login identifier
    email: Optional[str] = None
    role: str                     # References a role name from Permission Engine
    department_ids: list[UUID]    # Can belong to 1+ departments
    qualification: Optional[str] = None   # e.g. "MD, DM Cardiology"
    registration_no: Optional[str] = None # Medical council registration
    active: bool = True

class StaffUpdate(BaseModel):
    full_name: Optional[str] = None
    email: Optional[str] = None
    role: Optional[str] = None
    department_ids: Optional[list[UUID]] = None
    qualification: Optional[str] = None
    registration_no: Optional[str] = None
    active: Optional[bool] = None
```

### 5.2 Adding a Staff Member

1. Admin fills the form (name, mobile, role, departments).
2. On save:
   - A `staff` record is created (in the `staff` table).
   - A **user account record** is optionally created if "Create login" is toggled.
   - If login is created, a temporary PIN is generated and shown once to the admin
     (or sent via SMS to the staff mobile).
3. The staff member appears in the staff directory immediately.

### 5.3 Deactivation (Soft Delete)

- Setting `active = False` disables the staff member's login (if any).
- The staff member is excluded from dropdowns and assignment lists.
- Historical data (appointments, queue entries) retains the staff UUID.
- A deactivated staff member can be reactivated without data loss.

### 5.4 Staff Directory View

```
+----+------------+--------+-------------+---------+----------+
| #  | Name       | Mobile | Role        | Dept    | Active   |
+----+------------+--------+-------------+---------+----------+
| 1  | Dr. Sharma | 98xxx  | Doctor      | ECG     | YES      |
| 2  | Nurse Anju | 97xxx  | Nurse       | OPD     | YES      |
| 3  | Raj Kumar  | 91xxx  | Reception   | Front   | NO       |
+----+------------+--------+-------------+---------+----------+
|                    [Add Staff] [Export CSV]                   |
+--------------------------------------------------------------+
```

## 6. USER ACCOUNTS

This section manages the authentication credentials and account status for
staff members who have login access.

### 6.1 Capabilities

| Feature                | Description                                              |
|------------------------|----------------------------------------------------------|
| Set PIN                | Set or change the 4-6 digit numeric PIN for a user       |
| Set Password           | Set or change alphanumeric password                      |
| Activate Account       | Enable a previously disabled account                     |
| Deactivate Account     | Disable account (prevents login, preserves data)         |
| Reset OTP              | Invalidate current OTP and generate a new one            |
| Reset PIN              | Force PIN change on next login                           |
| View Login History     | Last N logins with IP, device, timestamp                 |

### 6.2 Behaviour

- PINs are hashed (bcrypt) before storage; never stored in plain text.
- Resetting OTP generates a new OTP and invalidates the old one immediately.
- Deactivation is immediate; active sessions are terminated on next token
  validation (JWT blacklist check within Auth Engine).
- "Force PIN change" sets a flag so the user is prompted on next login.

## 7. ROLE & PERMISSION MANAGEMENT

This section links to the Permission Engine (spec 0106). It does not re-implement
permission logic but provides a UI for role configuration.

### 7.1 Capabilities

```
+----------------------------------------------------------+
| Roles & Permissions                                       |
+----------------------------------------------------------+
|                                                           |
|  Existing Roles:                                          |
|    admin          [Edit] [Clone] [Delete]                 |
|    doctor         [Edit] [Clone] [Delete]                 |
|    nurse          [Edit] [Clone] [Delete]                 |
|    reception      [Edit] [Clone] [Delete]                 |
|                                                           |
|  [Create New Role]                                        |
|                                                           |
|  --- Editing: doctor ---                                  |
|                                                           |
|    Permission Tree                                         |
|    [x] Patient Management                                 |
|    [ ]   View Patient List                                |
|    [x]   View Patient Details                             |
|    [ ]   Edit Patient Details                             |
|    [x] Appointment Management                             |
|    [x]   View Appointments                                |
|    [ ]   Create Appointments                              |
|    [ ]   Cancel Appointments                              |
|    ...                                                    |
|                                                           |
|  [Save Permissions]                                       |
+----------------------------------------------------------+
```

### 7.2 Behaviour

- Deleting a role is blocked if any active staff member is assigned to it.
- Cloning creates a deep copy of the permission set under a new role name.
- Permission changes take effect immediately (next API request re-evaluates).

## 8. CLINIC SETTINGS

Miscellaneous settings that affect the day-to-day operation of the clinic.

### 8.1 Settings Table

```json
{
  "language": "hi",
  "currency": "INR",
  "currency_symbol": "\u20b9",
  "receipt_format": "standard",
  "receipt_show_doctor": true,
  "receipt_show_department": true,
  "receipt_show_qr": true,
  "receipt_footer_text": "Thank you for visiting!",
  "notification_default_channel": "sms",
  "notification_appointment_reminder_min": 60,
  "notification_followup_reminder_days": 7,
  "max_appointments_per_slot": 1,
  "default_appointment_duration_min": 15,
  "enable_online_booking": true,
  "enable_walkin": true,
  "patient_registration_otp_required": true,
  "staff_login_pin_required": true,
  "staff_login_pin_length": 4
}
```

### 8.2 Supported Languages

| Code | Language    |
|------|-------------|
| en   | English     |
| hi   | Hindi       |

Future: gu (Gujarati), mr (Marathi), bn (Bengali), ta (Tamil).

### 8.3 Supported Currencies

| Code | Symbol | Name      |
|------|--------|-----------|
| INR  | \u20b9 | Indian Rupee |
| USD  | $      | US Dollar |
| GBP  | \u00a3 | Pound Sterling |

## 9. QR & BRANDING CUSTOMISATION

Patient-facing QR codes (e.g., appointment link, feedback link, payment link)
inherit the clinic's branding.

### 9.1 Configuration

```
+----------------------------------------------------------+
| QR & Branding Customisation                                |
+----------------------------------------------------------+
|                                                           |
|  Clinic Logo    [Upload Image]   [Remove]                 |
|  Logo Preview:  (64x64 preview displayed)                 |
|                                                           |
|  Primary Color  [#_____] [Pick]  e.g. #2563EB             |
|  Secondary Color [#_____] [Pick] e.g. #1E40AF             |
|  Accent Color   [#_____] [Pick]  e.g. #F59E0B             |
|                                                           |
|  Patient Portal Domain: [https://clinic.example.com]      |
|                                                           |
|  QR Code Preview:                                         |
|    +---------+                                            |
|    |[QR IMG] |                                            |
|    +---------+                                            |
|    clinic.example.com/appt/ABC123                         |
|                                                           |
|  [Save Branding]  [Reset to Defaults]                     |
+----------------------------------------------------------+
```

### 9.2 Behaviour

- Logo upload stores files under `uploads/branding/{hospital_id}/`.
- QR codes use the configured domain as the base URL.
- Colour changes are reflected in:
  - Patient-facing web pages (appointment portal)
  - Email/SMS templates that embed colours
  - Printed tokens and receipts
- "Reset to Defaults" clears custom values and uses system defaults.

## 10. HOLIDAY & SCHEDULE MANAGEMENT

This section lets admins define non-working days and special (modified) timings.

### 10.1 Holiday Definition

```python
# ghos/admin/schemas.py

from datetime import date, time

class HolidayCreate(BaseModel):
    date: date                   # The specific date
    name: str                    # e.g. "Diwali", "National Holiday"
    type: str                    # "full_day" | "half_day" | "special"
    opening_time: Optional[time] = None   # For half_day / special
    closing_time: Optional[time] = None   # For half_day / special
    repeat_yearly: bool = False          # Auto-apply every year
    active: bool = True

class HolidayResponse(HolidayCreate):
    id: UUID
    created_at: datetime
```

### 10.2 Schedule Calendar View

```
+----------------------------------------------------------+
| Holiday & Schedule Calendar     [Year: 2026]              |
+----------------------------------------------------------+
|  Month: July 2026                                         |
|  Su Mo Tu We Th Fr Sa                                     |
|          1  2  3  4                                       |
|   5  6  7  8  9 10 11                                     |
|  12 13 14 15 16 17 18                                     |
|  19 20 21 22 23 24 25                                     |
|  26 27 28 29 30 31                                       |
|                                                            |
|  Holidays in July:                                        |
|   15 Jul - Eid (Full Day)    [Edit] [Remove]              |
|                                                            |
|  [Add Holiday]  [Import CSV]                               |
+----------------------------------------------------------+
```

### 10.3 Behaviour

- Holiday dates override the default `opening_time` / `closing_time` for that day.
- If `repeat_yearly` is true, the holiday auto-applies on the same date every year
  (except Feb 29 handling: applied on Feb 28 in non-leap years).
- The Queue and Appointment modules check holidays before generating slots.
- Half-day holidays use `opening_time` and `closing_time` to restrict available slots.

## 11. BACKUP & EXPORT

### 11.1 Database Backup

```
+----------------------------------------------------------+
| Backup & Export                                            |
+----------------------------------------------------------+
|                                                           |
|  Database Backup                                          |
|    Last backup: 2026-07-08 03:00 AM                       |
|    Size: 124 MB                                           |
|    [Download Backup]   [Create Backup Now]                |
|    [Schedule Backup]  Daily at 03:00 AM  [Change]         |
|                                                           |
|  Report Export                                            |
|    [x] Patient Reports     Period: [Last 30 Days]         |
|    [x] Financial Summary                                 |
|    [ ] Appointment Log                                    |
|    [x] Department Stats                                   |
|    Format: [CSV v]   [Export]                             |
|                                                           |
|  Audit Log Export                                         |
|    Filter by: User [All v]  Action [All v]                |
|    Date Range: [2026-06-01] to [2026-07-01]              |
|    Format: [CSV v]   [Export]                             |
|                                                           |
+----------------------------------------------------------+
```

### 11.2 Behaviour

- DB backup uses `pg_dump` (or `sqlite3 .backup`) depending on the configured
  database engine.
- Backups are stored in a secure directory (outside web root).
- Report exports stream the generated file; large exports run as background jobs
  with notification on completion.
- Audit log exports respect the same filter parameters as the audit viewer.

## 12. SYSTEM AUDIT LOG VIEWER

Every action performed by a logged-in user is recorded in the audit log. The
admin panel provides a read-only viewer.

### 12.1 Viewer Interface

```
+----------------------------------------------------------+
| System Audit Log                         [Export CSV]     |
+----------------------------------------------------------+
| Filter:                                                   |
|  User: [Select User v]  Action: [Select Action v]        |
|  Date From: [____]  Date To: [____]                      |
|  Department: [All v]  [Apply Filters]  [Clear]           |
|                                                            |
|  Results (showing 1-25 of 1,234)                          |
|                                                            |
|  Time                  | User          | Action             |
| -----------------------+--------------+--------------------|
| 2026-07-09 10:32:15    | admin        | Staff created      |
|                        |              | Details: Dr. Mehta  |
| 2026-07-09 09:15:42    | reception1   | Patient registered |
|                        |              | Details: Ravi K.    |
| 2026-07-09 08:00:01    | system       | Backup completed   |
| 2026-07-08 23:45:00    | admin        | Settings changed   |
|                        |              | Details: lang=en    |
|  ...                                                      |
|                                                            |
|  [< Prev]  Page 1 of 50  [Next >]                         |
+----------------------------------------------------------+
```

### 12.2 Audit Log Schema

```sql
-- ghos/admin/audit.sql

CREATE TABLE audit_log (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    actor_id        UUID NOT NULL REFERENCES users(id),
    actor_name      VARCHAR(100) NOT NULL,           -- Denormalised for fast display
    action          VARCHAR(50) NOT NULL,             -- e.g. 'staff.created', 'settings.updated'
    resource_type   VARCHAR(50),                      -- e.g. 'staff', 'department', 'appointment'
    resource_id     UUID,                             -- The affected record
    details         JSONB,                            -- Arbitrary payload
    ip_address      INET,
    user_agent      TEXT,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_audit_actor ON audit_log(actor_id);
CREATE INDEX idx_audit_action ON audit_log(action);
CREATE INDEX idx_audit_created ON audit_log(created_at DESC);
```

### 12.3 Recorded Actions

| Action                    | Trigger                                      |
|---------------------------|----------------------------------------------|
| staff.created             | New staff member added                       |
| staff.updated             | Staff details edited                         |
| staff.deactivated         | Staff account disabled                       |
| staff.reactivated         | Staff account re-enabled                     |
| department.created        | New department added                         |
| department.updated        | Department details changed                   |
| department.deleted        | Department soft-deleted                      |
| user.pin_changed          | Staff PIN changed by admin                   |
| user.activated            | User account activated                       |
| user.deactivated          | User account deactivated                     |
| user.otp_reset            | OTP reset by admin                           |
| role.created              | New role created                             |
| role.updated              | Role permissions changed                     |
| role.deleted              | Role deleted                                 |
| settings.updated          | Clinic settings changed                      |
| branding.updated          | Logo or colours changed                      |
| holiday.created           | Holiday added                                |
| holiday.updated           | Holiday modified                             |
| holiday.deleted           | Holiday removed                              |
| backup.created            | Database backup triggered                    |
| backup.downloaded         | Backup file downloaded                       |
| export.requested          | Report or audit export requested             |
| login.success             | Successful login (from Auth Engine)          |
| login.failed              | Failed login attempt (from Auth Engine)      |

## 13. DATABASE SCHEMA

### 13.1 hospital_settings

```sql
-- ghos/admin/schema.sql

CREATE TABLE hospital_settings (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_name       VARCHAR(200) NOT NULL,
    hospital_short      VARCHAR(10),
    address_line1       VARCHAR(255) NOT NULL,
    address_line2       VARCHAR(255),
    city                VARCHAR(100) NOT NULL,
    state               VARCHAR(100) NOT NULL,
    postal_code         VARCHAR(20) NOT NULL,
    country             VARCHAR(100) NOT NULL DEFAULT 'India',
    phone               VARCHAR(20) NOT NULL,
    email               VARCHAR(200),
    website             VARCHAR(255),
    logo_url            VARCHAR(500),
    logo_thumbnail_url  VARCHAR(500),
    logo_favicon_url    VARCHAR(500),
    opening_time        TIME NOT NULL,
    closing_time        TIME NOT NULL,
    timezone            VARCHAR(50) NOT NULL DEFAULT 'Asia/Kolkata',
    week_start_day      VARCHAR(10) NOT NULL DEFAULT 'Monday',
    primary_color       VARCHAR(7) DEFAULT '#2563EB',
    secondary_color     VARCHAR(7) DEFAULT '#1E40AF',
    accent_color        VARCHAR(7) DEFAULT '#F59E0B',
    patient_portal_domain VARCHAR(255),
    language            VARCHAR(5) NOT NULL DEFAULT 'en',
    currency            VARCHAR(3) NOT NULL DEFAULT 'INR',
    currency_symbol     VARCHAR(5) NOT NULL DEFAULT '\u20b9',
    receipt_format      VARCHAR(20) DEFAULT 'standard',
    receipt_footer_text TEXT,
    notification_default_channel VARCHAR(10) DEFAULT 'sms',
    notification_appointment_reminder_min INT DEFAULT 60,
    notification_followup_reminder_days INT DEFAULT 7,
    max_appointments_per_slot INT DEFAULT 1,
    default_appointment_duration_min INT DEFAULT 15,
    enable_online_booking BOOLEAN DEFAULT TRUE,
    enable_walkin BOOLEAN DEFAULT TRUE,
    patient_registration_otp_required BOOLEAN DEFAULT TRUE,
    staff_login_pin_required BOOLEAN DEFAULT TRUE,
    staff_login_pin_length INT DEFAULT 4,
    created_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at          TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Singleton constraint: only one row allowed
CREATE UNIQUE INDEX idx_hospital_singleton ON hospital_settings((TRUE));
```

### 13.2 holidays

```sql
CREATE TABLE holidays (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    date            DATE NOT NULL,
    name            VARCHAR(200) NOT NULL,
    type            VARCHAR(20) NOT NULL CHECK (type IN ('full_day', 'half_day', 'special')),
    opening_time    TIME,
    closing_time    TIME,
    repeat_yearly   BOOLEAN DEFAULT FALSE,
    active          BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE UNIQUE INDEX idx_holiday_date ON holidays(date) WHERE active = TRUE;
```

### 13.3 staff

```sql
CREATE TABLE staff (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    full_name         VARCHAR(200) NOT NULL,
    mobile            VARCHAR(15) NOT NULL UNIQUE,
    email             VARCHAR(200),
    role              VARCHAR(50) NOT NULL,
    qualification     VARCHAR(200),
    registration_no   VARCHAR(100),
    active            BOOLEAN DEFAULT TRUE,
    created_at        TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE staff_departments (
    staff_id        UUID NOT NULL REFERENCES staff(id) ON DELETE CASCADE,
    department_id   UUID NOT NULL REFERENCES departments(id) ON DELETE CASCADE,
    PRIMARY KEY (staff_id, department_id)
);
```

## 14. API ENDPOINTS

All endpoints are prefixed with `/api/v1/admin`. Every endpoint requires
authentication and the `admin` or `super_admin` role.

### 14.1 Hospital Settings

| Method | Path                           | Description                    |
|--------|--------------------------------|--------------------------------|
| GET    | /api/v1/admin/hospital         | Get hospital settings          |
| PUT    | /api/v1/admin/hospital         | Update hospital settings       |
| POST   | /api/v1/admin/hospital/logo    | Upload logo image              |
| DELETE | /api/v1/admin/hospital/logo    | Remove logo                    |

### 14.2 Departments

| Method | Path                                    | Description            |
|--------|-----------------------------------------|------------------------|
| GET    | /api/v1/admin/departments               | List all departments   |
| POST   | /api/v1/admin/departments               | Create department      |
| GET    | /api/v1/admin/departments/{id}          | Get department details |
| PUT    | /api/v1/admin/departments/{id}          | Update department      |
| DELETE | /api/v1/admin/departments/{id}          | Soft-delete department |
| PATCH  | /api/v1/admin/departments/reorder       | Bulk update order      |

### 14.3 Staff

| Method | Path                                    | Description                  |
|--------|-----------------------------------------|------------------------------|
| GET    | /api/v1/admin/staff                     | List all staff               |
| POST   | /api/v1/admin/staff                     | Create staff member          |
| GET    | /api/v1/admin/staff/{id}                | Get staff details            |
| PUT    | /api/v1/admin/staff/{id}                | Update staff                 |
| PATCH  | /api/v1/admin/staff/{id}/deactivate     | Soft-deactivate staff        |
| PATCH  | /api/v1/admin/staff/{id}/reactivate     | Reactivate staff             |

### 14.4 User Accounts

| Method | Path                                       | Description              |
|--------|--------------------------------------------|--------------------------|
| GET    | /api/v1/admin/users                        | List user accounts       |
| GET    | /api/v1/admin/users/{id}                   | Get user details         |
| POST   | /api/v1/admin/users/{id}/set-pin           | Set user PIN             |
| POST   | /api/v1/admin/users/{id}/set-password      | Set user password        |
| POST   | /api/v1/admin/users/{id}/activate          | Activate account         |
| POST   | /api/v1/admin/users/{id}/deactivate        | Deactivate account       |
| POST   | /api/v1/admin/users/{id}/reset-otp         | Reset OTP                |
| POST   | /api/v1/admin/users/{id}/force-pin-change  | Force PIN reset on login |

### 14.5 Roles

| Method | Path                                    | Description              |
|--------|-----------------------------------------|--------------------------|
| GET    | /api/v1/admin/roles                     | List all roles           |
| POST   | /api/v1/admin/roles                     | Create role              |
| GET    | /api/v1/admin/roles/{id}                | Get role with permissions|
| PUT    | /api/v1/admin/roles/{id}                | Update role              |
| DELETE | /api/v1/admin/roles/{id}                | Delete role (if no users)|
| POST   | /api/v1/admin/roles/{id}/clone          | Clone role               |

### 14.6 Holidays

| Method | Path                                    | Description              |
|--------|-----------------------------------------|--------------------------|
| GET    | /api/v1/admin/holidays                  | List holidays (filterable)|
| POST   | /api/v1/admin/holidays                  | Create holiday           |
| GET    | /api/v1/admin/holidays/{id}             | Get holiday details      |
| PUT    | /api/v1/admin/holidays/{id}             | Update holiday           |
| DELETE | /api/v1/admin/holidays/{id}             | Delete holiday           |
| POST   | /api/v1/admin/holidays/import           | Bulk import from CSV     |

### 14.7 Backup & Export

| Method | Path                                    | Description                    |
|--------|-----------------------------------------|--------------------------------|
| POST   | /api/v1/admin/backup/create             | Trigger database backup        |
| GET    | /api/v1/admin/backup/latest             | Get latest backup info         |
| GET    | /api/v1/admin/backup/download           | Download latest backup         |
| POST   | /api/v1/admin/export/reports            | Export reports (async)         |
| POST   | /api/v1/admin/export/audit-log          | Export audit log (async)       |

### 14.8 Audit Log

| Method | Path                                    | Description                    |
|--------|-----------------------------------------|--------------------------------|
| GET    | /api/v1/admin/audit-log                 | List audit entries (paginated) |
| GET    | /api/v1/admin/audit-log/actions         | List distinct action types     |

### 14.9 Clinic Settings

| Method | Path                                    | Description                    |
|--------|-----------------------------------------|--------------------------------|
| GET    | /api/v1/admin/settings                  | Get all settings               |
| PUT    | /api/v1/admin/settings                  | Update settings                |
| GET    | /api/v1/admin/settings/{key}            | Get specific setting           |

## 15. CONFIGURATION

```python
# ghos/admin/config.py

ADMIN_CONFIG = {
    # Backup
    "BACKUP_DIR": "/var/ghos/backups",
    "BACKUP_SCHEDULE": "0 3 * * *",          # Daily at 3 AM (cron)
    "BACKUP_RETENTION_DAYS": 30,
    "BACKUP_DB_COMMAND": "pg_dump -U {user} -d {db} -F c -f {path}",

    # Logo / Branding uploads
    "UPLOAD_DIR": "/var/ghos/uploads/branding",
    "LOGO_MAX_SIZE_MB": 5,
    "LOGO_ALLOWED_TYPES": ["image/png", "image/jpeg", "image/webp"],
    "LOGO_THUMBNAIL_SIZE": (64, 64),
    "LOGO_FAVICON_SIZE": (32, 32),

    # Export
    "EXPORT_DIR": "/var/ghos/exports",
    "EXPORT_MAX_ROWS": 100_000,
    "EXPORT_PAGE_SIZE": 1_000,

    # Audit log
    "AUDIT_LOG_PAGE_SIZE": 25,
    "AUDIT_LOG_MAX_EXPORT_ROWS": 50_000,
}
```

## 16. KEY DESIGN DECISIONS

| Decision                            | Rationale                                                    |
|-------------------------------------|--------------------------------------------------------------|
| Singleton hospital record           | A clinic system serves one institution per installation      |
| Soft delete for staff/departments   | Preserves referential integrity for historical data          |
| Denormalised actor_name in audit    | Avoids JOINs on every audit log read; the name rarely changes|
| JSONB payload in audit details      | Flexible schema for arbitrary action-specific metadata       |
| Separate staff vs. user records     | A person can be staff without login access                   |
| Holiday check before slot gen       | Prevents generation of invalid slots early in the pipeline   |
| Yearly-repeat holidays              | Reduces admin overhead for recurring holidays                |
| Async exports for large datasets    | Prevents HTTP timeout for large report extractions           |
| Timezone-aware timestamps everywhere| Ensures correct behaviour across daylight-saving boundaries  |

## 17. DEPENDENCIES

| Module                     | Relationship                                        |
|----------------------------|------------------------------------------------------|
| Auth Engine (0105)         | Provides authentication for admin panel access        |
| Permission Engine (0106)   | Provides role definitions and permission checks       |
| Queue Module               | Reads department/holiday config for slot generation   |
| Appointment Module         | Reads department/holiday config for booking rules     |
| Patient Module             | Reads branding/QR config for patient-facing links     |
