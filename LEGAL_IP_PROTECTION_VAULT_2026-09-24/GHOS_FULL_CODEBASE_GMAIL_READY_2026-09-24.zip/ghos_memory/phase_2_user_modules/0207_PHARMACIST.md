---
file_id: "0207"
module_name: "Pharmacist Module"
version: "2.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0100_QUEUE_ENGINE.md"]
related_files: ["0309_PHARMACY.md", "0401_INVENTORY.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "pharmacist", "pharmacy", "dispensing", "inventory", "narcotics"]
---

# GHOS — Pharmacist Module

## 1. PURPOSE
Pharmacy interface for receiving prescriptions from doctors, dispensing medicines to patients, managing pharmacy inventory, printing medicine labels, and tracking controlled substances. Acts as the final verification gate before medicine leaves the clinic.

## 2. PHARMACY DASHBOARD

```
                 ┌──────────────────────────────────────────────────────────┐
                 │              PHARMACY DASHBOARD — GIL CLINIC              │
                 ├──────────────────────────────────────────────────────────┤
                 │  Queue     Dispensed Today   Stock Alerts   Expiry Warnings│
                 │     7            42               3               2       │
                 └──────────────────────────────────────────────────────────┘

┌─────────────────────────────────────────────────────────────────────────────┐
│  PENDING PRESCRIPTIONS                                    [Refresh] [Filter]│
├─────────────────────────────────────────────────────────────────────────────┤
│  ┌─── #1: PHA-055 ──────────────────────────────────────────────────────┐   │
│  │  Patient: Rajesh Kumar (M/45)   |   Prescribed By: Dr. Sharma       │   │
│  │  ── Medicines ──────────────────────────────────────────────────     │   │
│  │  ✓ Aspirin 75mg        | 1-0-1 | 7 days | Qty: 21   ✅ In Stock     │   │
│  │  ✓ Atorvastatin 10mg   | 0-0-1 | 30 days| Qty: 30  ✅ In Stock     │   │
│  │  ✓ Metformin 500mg     | 1-1-1 | 30 days| Qty: 90  ✅ In Stock     │   │
│  │  ────────────────────────────────────────────────────────────────    │   │
│  │  Status: Awaiting Pickup   Created: 2026-07-09 09:30 AM              │   │
│  │  [Dispense] [Partial] [Out of Stock] [Notify Doctor]                 │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
│                                                                             │
│  ┌─── #2: PHA-056 ──────────────────────────────────────────────────────┐   │
│  │  Patient: Sunita Verma (F/62) | Prescribed By: Dr. Mehta             │   │
│  │  ── Medicines ──────────────────────────────────────────────────     │   │
│  │  ✓ Insulin Glargine 100U/mL | 1-0-0 | 30 days | Qty: 1 vial         │   │
│  │  ❗ Insulin Glargine      ❌ Cold Chain Required — Fridge OK          │   │
│  │  ✓ Glipizide 5mg         | 1-0-1 | 30 days | Qty: 60  ✅ In Stock   │   │
│  │  ────────────────────────────────────────────────────────────────    │   │
│  │  Status: Awaiting Dispensing   Created: 2026-07-09 10:15 AM          │   │
│  │  [Dispense] [Partial] [Out of Stock] [Notify Doctor]                 │   │
│  └──────────────────────────────────────────────────────────────────────┘   │
└─────────────────────────────────────────────────────────────────────────────┘

┌─────────────────────────────┐    ┌─────────────────────────────────────┐
│  STOCK ALERTS              │    │  RECENT DISPENSING ACTIVITY          │
├─────────────────────────────┤    ├─────────────────────────────────────┤
│  ⚠ Amoxicillin 250mg    — 12│    │  09:45  PHA-052  Amit S. Dispensed │
│  ⚠ Paracetamol 500mg   — 8 │    │  09:30  PHA-051  Neha K. Partial(2/3)│
│  ⚠ Metformin ER 500mg — 5  │    │  09:15  PHA-050  Vikram R. Dispensed│
└─────────────────────────────┘    └─────────────────────────────────────┘
```

## 3. PRESCRIPTION QUEUE MANAGEMENT

### 3.1 Queue States
Each prescription moves through these pharmacy states:

```
Order Created (by Doctor) ──> Sent to Pharmacy ──> Pending Verification
                                                         │
                                                         v
                                                  Awaiting Dispensing
                                                         │
                                                 ┌───────┴───────┐
                                                 v               v
                                            Full Dispense    Partial Dispense
                                                 │               │
                                                 v               v
                                            Awaiting Pickup <──┘
                                                 │
                                                 v
                                              Collected
                                                 │
                                                 v
                                              Archived
```

### 3.2 Queue Sorting Rules
- **Priority prescriptions** (marked "STAT" by doctor) appear at top with red border
- **Cold-chain items** (insulin, vaccines) flagged with temperature icon
- **Narcotic prescriptions** flagged with controlled-substance icon and require dual verification
- Older prescriptions bubble up within same priority tier (FIFO)

### 3.3 Queue Display Columns
| Field | Description |
|-------|-------------|
| Queue # | Auto-incrementing position |
| Prescription ID | PHA-XXX format |
| Patient Name + Age/Gender | For quick identification |
| Medicine Count | Total line items |
| Priority Flags | STAT, Cold Chain, Narcotic badges |
| Wait Time | Time since order was created |
| Status | Current queue state |
| Action Buttons | Context-sensitive (Dispense/Partial/View) |

## 4. DISPENSING WORKFLOW

### 4.1 Full Dispensing Process

```
Step 1: VERIFY PRESCRIPTION
  ├── Confirm patient identity (Name + DOB + Token #)
  ├── Verify prescription is signed/authorized
  ├── Check for drug-drug interactions (flag if any)
  └── Confirm no duplicate therapy exists

Step 2: CHECK INVENTORY (Auto)
  ├── For each medicine line:
  │   ├── Is stock >= required quantity?  ->  ✅ Available
  │   ├── Is stock < required but > 0?    ->  ⚠ Partial possible
  │   └── Is stock = 0?                   ->  ❌ Out of Stock
  └── Display availability summary to pharmacist

Step 3: PICK MEDICINES
  ├── System displays shelf/bin location for each item
  ├── Pharmacist picks physical stock and scans barcode
  ├── System verifies scanned medicine matches prescription
  └── If barcode scan fails: manual override with manager PIN

Step 4: LABEL PRINTING
  ├── Auto-generate label for each medicine bottle/packet
  ├── Label contains: Patient Name, Medicine, Dosage, Frequency,
  │                   Duration, Date, Pharmacy ID
  └── Print via thermal label printer (60mm x 40mm labels)

Step 5: HAND OVER
  ├── Mark order as "Awaiting Pickup"
  ├── Notify patient via SMS/in-app notification
  ├── Log dispensing transaction
  └── Update inventory (deduct stock)
```

### 4.2 Dispensing Confirmation Dialog

```
┌─ DISPENSE CONFIRMATION ──────────────────────────────────┐
│  Prescription: PHA-055   |   Patient: Rajesh Kumar       │
├──────────────────────────────────────────────────────────┤
│  Item                Qty   Batch        Expiry    Status │
│  Aspirin 75mg        21   BATCH-012    2027-03   ✅    │
│  Atorvastatin 10mg   30   BATCH-008    2027-06   ✅    │
│  Metformin 500mg     90   BATCH-015    2027-08   ✅    │
├──────────────────────────────────────────────────────────┤
│  Pharmacist ID: ____ (scan badge or enter code)          │
│  [Cancel]                                    [Confirm]  │
└──────────────────────────────────────────────────────────┘
```

## 5. INVENTORY CHECK AT DISPENSING

### 5.1 Auto-Availability Check
When a pharmacist opens a prescription, the system automatically performs an availability check:

```sql
-- Auto-run for each medicine line when prescription is opened
SELECT
    m.medicine_id,
    m.name,
    m.dosage,
    m.form,
    inv.batch_number,
    inv.batch_expiry,
    inv.stock_quantity AS available_qty,
    rx_med.quantity AS required_qty,
    CASE
        WHEN inv.stock_quantity >= rx_med.quantity THEN 'Available'
        WHEN inv.stock_quantity > 0 THEN 'Partial'
        ELSE 'Out of Stock'
    END AS availability_status,
    inv.shelf_location,
    inv.storage_condition
FROM prescription_medicines rx_med
JOIN medicines m ON rx_med.medicine_id = m.medicine_id
LEFT JOIN pharmacy_inventory inv ON m.medicine_id = inv.medicine_id
    AND inv.batch_expiry > CURRENT_DATE
    AND inv.batch_status = 'active'
WHERE rx_med.prescription_id = :prescription_id
ORDER BY rx_med.line_number;
```

### 5.2 Stock Deduction (on Dispense)
```sql
BEGIN TRANSACTION;

-- Deduct stock from inventory batch (FIFO: oldest batch first)
UPDATE pharmacy_inventory
SET stock_quantity = stock_quantity - :dispensed_qty,
    last_updated = CURRENT_TIMESTAMP
WHERE inventory_id = (
    SELECT inv.inventory_id
    FROM pharmacy_inventory inv
    WHERE inv.medicine_id = :medicine_id
      AND inv.batch_expiry > CURRENT_DATE
      AND inv.batch_status = 'active'
      AND inv.stock_quantity >= :dispensed_qty
    ORDER BY inv.batch_expiry ASC
    LIMIT 1
);

-- Insert dispensing log entry
INSERT INTO dispensing_log (
    prescription_id, medicine_id, batch_number, quantity_dispensed,
    pharmacist_id, dispensed_at, dispensing_type
) VALUES (
    :prescription_id, :medicine_id, :batch_number,
    :dispensed_qty, :pharmacist_id, CURRENT_TIMESTAMP, 'full'
);

-- If stock drops to zero, auto-disable that batch
UPDATE pharmacy_inventory
SET batch_status = 'depleted'
WHERE stock_quantity <= 0 AND batch_status = 'active';

COMMIT;
```

## 6. OUT-OF-STOCK HANDLING

### 6.1 Workflow
When a medicine is unavailable:

```
Medicine Out of Stock
        │
        ├──> 1. Auto-Suggest Therapeutically Equivalent Alternatives
        │        (e.g., Atorvastatin 10mg -> Rosuvastatin 5mg)
        │
        ├──> 2. Show alternative stock levels
        │
        ├──> 3. Pharmacist selects alternative OR marks as "Cannot Substitute"
        │
        └──> 4. Notify Prescribing Doctor (via in-app alert)
                 │
                 ├── Doctor Approves Alternative -> Update Prescription
                 │                                   -> Resume Dispensing
                 └── Doctor Rejects / Prescribes New Medicine
                                                     -> New Prescription Created
```

### 6.2 Alternative Suggestion Query
```sql
SELECT
    a.medicine_id,
    m.name,
    m.dosage,
    m.form,
    a.substitution_reason,
    inv.stock_quantity,
    inv.batch_expiry
FROM medicine_alternatives a
JOIN medicines m ON a.alternative_medicine_id = m.medicine_id
LEFT JOIN pharmacy_inventory inv ON m.medicine_id = inv.medicine_id
    AND inv.batch_expiry > CURRENT_DATE
    AND inv.batch_status = 'active'
WHERE a.original_medicine_id = :out_of_stock_medicine_id
  AND a.is_active = 1
ORDER BY a.priority ASC;
```

### 6.3 Notification to Doctor
```python
def notify_doctor_out_of_stock(prescription_id, medicine_id, alternative_list):
    """
    Sends out-of-stock alert with alternatives to the prescribing doctor.
    Returns notification_id for tracking.
    """
    notification = {
        "type": "out_of_stock",
        "priority": "high",
        "prescription_id": prescription_id,
        "medicine_id": medicine_id,
        "alternatives": [
            {
                "medicine_id": alt["medicine_id"],
                "name": alt["name"],
                "dosage": alt["dosage"],
                "stock_available": alt["stock_quantity"]
            }
            for alt in alternative_list
        ],
        "pharmacist_notes": "",
        "status": "pending_doctor_response",
        "created_at": "CURRENT_TIMESTAMP"
    }

    # persist notification
    db.execute("""
        INSERT INTO doctor_notifications
            (prescription_id, notification_type, payload, status, created_at)
        VALUES
            (:pid, 'out_of_stock', :payload, 'pending', CURRENT_TIMESTAMP)
    """, {"pid": prescription_id, "payload": json.dumps(notification)})

    return notification
```

## 7. MEDICINE LABEL PRINTING

### 7.1 Label Template (60mm x 40mm thermal)
```
┌──────────────────────────────────────┐
│  GIL CLINIC PHARMACY                 │
│  Plot No. 123, Sector 15, City     │
│  Tel: +91-XXXX-XXXXXX               │
├──────────────────────────────────────┤
│  Patient: Rajesh Kumar              │
│  Prescription: PHA-055              │
│  Date: 2026-07-09                   │
├──────────────────────────────────────┤
│  Aspirin 75mg Tablet                │
│  Dosage: 1-0-1 (Morning & Night)    │
│  Duration: 7 Days                   │
│  Qty: 21 Tablets                    │
├──────────────────────────────────────┤
│  Batch: BATCH-012                   │
│  Expiry: 2027-03-15                 │
│  Dispensed By: Pharm. Anita K.     │
├──────────────────────────────────────┤
│  [Barcode: PHA055-ASP75-21]        │
│  Store in cool dry place            │
└──────────────────────────────────────┘
```

### 7.2 Label Generation Function
```python
def generate_medicine_label(dispensing_record):
    """
    Generates a ZPL-compatible label for thermal printing.
    Returns raw ZPL string ready to send to printer.
    """
    zpl_template = f"""
^XA
^FO50,20^A0N,30,30^FDGIL CLINIC PHARMACY^FS
^FO50,55^A0N,20,20^FD{dispensing_record['clinic_address']}^FS
^FO50,80^A0N,20,20^FDTel: {dispensing_record['clinic_phone']}^FS
^FO50,110^GB550,2,2^FS
^FO50,120^A0N,22,22^FDPatient: {dispensing_record['patient_name']}^FS
^FO50,145^A0N,20,20^FDRx: {dispensing_record['prescription_id']} | {dispensing_record['date']}^FS
^FO50,170^GB550,2,2^FS
^FO50,180^A0N,25,25^FD{dispensing_record['medicine_name']} {dispensing_record['dosage']}^FS
^FO50,210^A0N,20,20^FDDosage: {dispensing_record['dosage_instructions']}^FS
^FO50,235^A0N,20,20^FDDuration: {dispensing_record['duration']}^FS
^FO50,260^A0N,20,20^FDQty: {dispensing_record['quantity']}^FS
^FO50,285^GB550,2,2^FS
^FO50,295^A0N,18,18^FDBatch: {dispensing_record['batch_number']} | Exp: {dispensing_record['expiry']}^FS
^FO50,320^A0N,18,18^FDDispensed By: {dispensing_record['pharmacist_name']}^FS
^FO50,345^GB550,2,2^FS
^FO50,355^B3N,N,50,Y,N^FD{dispensing_record['barcode_data']}^FS
^FO50,415^A0N,18,18^FDStore in cool dry place^FS
^XZ
"""
    return zpl_template
```

## 8. BARCODE SCANNING FOR MEDICINES

### 8.1 Scanning Process
When scanning a medicine barcode at dispensing:

```python
def process_barcode_scan(scanned_code, prescription_id, medicine_id):
    """
    Validates scanned barcode against expected medicine.
    Returns (match_status, medicine_details) tuple.
    """
    # Expected barcode format: MED-{medicine_id}-BATCH-{batch_number}
    expected_format = f"MED-{medicine_id}"

    if expected_format not in scanned_code:
        return {
            "match": False,
            "error": "Barcode does not match prescribed medicine",
            "action": "retry_or_override"
        }

    # Extract batch from barcode
    batch_number = scanned_code.split("-BATCH-")[-1] if "-BATCH-" in scanned_code else None

    # Verify batch exists and is valid
    if batch_number:
        batch_valid = db.execute("""
            SELECT 1 FROM pharmacy_inventory
            WHERE batch_number = :batch
              AND medicine_id = :med_id
              AND batch_expiry > CURRENT_DATE
              AND batch_status = 'active'
        """, {"batch": batch_number, "med_id": medicine_id})

        if not batch_valid:
            return {
                "match": False,
                "error": "Batch expired or inactive",
                "action": "reject"
            }

    return {
        "match": True,
        "batch_number": batch_number,
        "action": "proceed"
    }
```

### 8.2 Supported Barcode Formats
| Format | Standard | Usage |
|--------|----------|-------|
| Code 128 | GS1-128 | Medicine identification |
| EAN-13 | GS1 | Commercial medicine packages |
| QR Code | ISO/IEC 18004 | Shelf/bin location labels |
| DataMatrix | GS1 DataMatrix | Small vials/ampoules |

## 9. NARCOTIC / CONTROLLED SUBSTANCE TRACKING

### 9.1 Dual-Verification Requirement
Controlled substances (Schedule H, X) require two pharmacists to verify:

```python
def dispense_narcotic(prescription_id, pharmacist_1_id, pharmacist_2_id):
    """
    Narcotic dispensing requires two-pharmacist verification.
    """
    # Pharmacist 1 scans badge and selects batch
    p1_verified = verify_pharmacist_credentials(pharmacist_1_id)
    if not p1_verified:
        return {"status": "failed", "reason": "Pharmacist 1 not authorized"}

    # Pharmacist 2 scans badge to co-sign
    p2_verified = verify_pharmacist_credentials(pharmacist_2_id)
    if not p2_verified:
        return {"status": "failed", "reason": "Pharmacist 2 not authorized"}

    # Both must be different pharmacists
    if pharmacist_1_id == pharmacist_2_id:
        return {"status": "failed", "reason": "Dual verification requires two different pharmacists"}

    # Log narcotic dispensing with both IDs
    db.execute("""
        INSERT INTO narcotic_dispensing_log (
            prescription_id, medicine_id, batch_number,
            quantity_dispensed, pharmacist_1_id, pharmacist_2_id,
            dispensed_at, patient_id
        ) VALUES (
            :rx, :med, :batch, :qty, :p1, :p2, CURRENT_TIMESTAMP, :patient
        )
    """, {
        "rx": prescription_id, "med": medicine_id, "batch": batch_number,
        "qty": quantity, "p1": pharmacist_1_id, "p2": pharmacist_2_id,
        "patient": patient_id
    })

    return {"status": "dispensed", "log_id": new_log_id}
```

### 9.2 Narcotic Log Fields
| Field | Type | Description |
|-------|------|-------------|
| narcotic_log_id | UUID | Primary key |
| prescription_id | VARCHAR | FK to prescriptions |
| medicine_id | INT | FK to medicines |
| batch_number | VARCHAR | Dispensed batch |
| quantity_dispensed | DECIMAL | Amount dispensed |
| pharmacist_1_id | INT | Primary dispenser |
| pharmacist_2_id | INT | Co-signer |
| patient_id | INT | FK to patients |
| dispensed_at | TIMESTAMP | When dispensed |
| stock_balance_after | DECIMAL | Running balance of this batch |

## 10. COLD CHAIN TRACKING

### 10.1 Temperature-Sensitive Medicines
Medicines requiring refrigeration (2-8 deg C) are flagged:

```sql
-- Flag cold-chain items in the queue
SELECT
    rx.prescription_id,
    m.name AS medicine_name,
    inv.batch_number,
    inv.storage_condition,
    CASE
        WHEN temp.last_temp_check IS NULL THEN 'No Recent Check'
        WHEN temp.temperature_c BETWEEN 2 AND 8 THEN 'Within Range'
        ELSE 'Temperature Breach'
    END AS cold_chain_status
FROM prescriptions rx
JOIN prescription_medicines rx_med ON rx.prescription_id = rx_med.prescription_id
JOIN medicines m ON rx_med.medicine_id = m.medicine_id
JOIN pharmacy_inventory inv ON m.medicine_id = inv.medicine_id
LEFT JOIN (
    SELECT batch_number, temperature_c, last_temp_check
    FROM cold_chain_log
    WHERE last_temp_check > CURRENT_TIMESTAMP - INTERVAL '1 HOUR'
) temp ON inv.batch_number = temp.batch_number
WHERE m.requires_cold_chain = 1
  AND rx.pharmacy_status = 'pending_dispensing';
```

### 10.2 Temperature Log Table
```sql
CREATE TABLE cold_chain_log (
    log_id         INTEGER PRIMARY KEY AUTOINCREMENT,
    batch_number   VARCHAR(50) NOT NULL,
    refrigerator_id VARCHAR(20) NOT NULL,
    temperature_c  DECIMAL(4,1) NOT NULL,
    recorded_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    recorded_by    INTEGER REFERENCES pharmacists(pharmacist_id),
    alert_triggered BOOLEAN DEFAULT 0,
    alert_acknowledged_by INTEGER REFERENCES pharmacists(pharmacist_id),
    FOREIGN KEY (batch_number) REFERENCES pharmacy_inventory(batch_number)
);
```

## 11. PARTIAL DISPENSING WORKFLOW

### 11.1 Use Cases
- Insufficient stock for full quantity but partial available
- Patient requests partial pickup (financial reasons)
- Doctor's order for gradual dispensing (e.g., narcotics)

### 11.2 Partial Dispense Flow

```python
def process_partial_dispense(prescription_id, line_items, pharmacist_id):
    """
    Processes a partial dispensing request.
    line_items: list of {medicine_id, quantity_to_dispense, reason}
    """
    for item in line_items:
        # Validate that requested qty <= remaining undispensed qty
        remaining = get_remaining_quantity(prescription_id, item["medicine_id"])

        if item["quantity_to_dispense"] > remaining:
            return {
                "status": "error",
                "message": f"Cannot dispense more than remaining quantity ({remaining})"
            }

        # Deduct stock
        deduct_inventory(item["medicine_id"], item["quantity_to_dispense"])

        # Log partial dispensing
        db.execute("""
            INSERT INTO dispensing_log (
                prescription_id, medicine_id, batch_number,
                quantity_dispensed, pharmacist_id, dispensed_at,
                dispensing_type, partial_reason, remaining_qty
            ) VALUES (
                :rx, :med, :batch, :qty, :ph, CURRENT_TIMESTAMP,
                'partial', :reason, :remaining
            )
        """, {
            "rx": prescription_id, "med": item["medicine_id"],
            "batch": get_available_batch(item["medicine_id"]),
            "qty": item["quantity_to_dispense"], "ph": pharmacist_id,
            "reason": item.get("reason", ""),
            "remaining": remaining - item["quantity_to_dispense"]
        })

        # If all items are fully dispensed after this partial, mark order complete
        update_prescription_status(prescription_id)

    return {"status": "partial_dispense_complete"}
```

### 11.3 Partial Dispense Tracking
The prescription header tracks aggregate quantities:

```sql
ALTER TABLE prescriptions
ADD COLUMN is_partial_dispense BOOLEAN DEFAULT 0;

ALTER TABLE prescription_medicines
ADD COLUMN quantity_dispensed INTEGER DEFAULT 0,
ADD COLUMN quantity_remaining INTEGER GENERATED ALWAYS AS (quantity - quantity_dispensed);
```

## 12. DATA MODEL

### 12.1 dispensing_log Table
```sql
CREATE TABLE dispensing_log (
    log_id           INTEGER PRIMARY KEY AUTOINCREMENT,
    prescription_id  VARCHAR(20) NOT NULL REFERENCES prescriptions(prescription_id),
    medicine_id      INTEGER NOT NULL REFERENCES medicines(medicine_id),
    batch_number     VARCHAR(50) NOT NULL,
    quantity_dispensed DECIMAL(10,2) NOT NULL,
    unit             VARCHAR(20) DEFAULT 'tablet',
    pharmacist_id    INTEGER NOT NULL REFERENCES pharmacists(pharmacist_id),
    dispensed_at     TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    dispensing_type  VARCHAR(20) CHECK(dispensing_type IN ('full', 'partial', 'replacement')),
    partial_reason   TEXT,
    remaining_qty    DECIMAL(10,2),
    label_printed    BOOLEAN DEFAULT 0,
    is_narcotic      BOOLEAN DEFAULT 0,
    narcotic_cosigner_id INTEGER REFERENCES pharmacists(pharmacist_id),
    notes            TEXT
);

CREATE INDEX idx_dispensing_log_prescription ON dispensing_log(prescription_id);
CREATE INDEX idx_dispensing_log_pharmacist ON dispensing_log(pharmacist_id);
CREATE INDEX idx_dispensing_log_date ON dispensing_log(dispensed_at);
```

### 12.2 pharmacy_inventory Table
```sql
CREATE TABLE pharmacy_inventory (
    inventory_id      INTEGER PRIMARY KEY AUTOINCREMENT,
    medicine_id       INTEGER NOT NULL REFERENCES medicines(medicine_id),
    batch_number      VARCHAR(50) NOT NULL,
    batch_expiry      DATE NOT NULL,
    stock_quantity    DECIMAL(10,2) NOT NULL DEFAULT 0,
    unit              VARCHAR(20) DEFAULT 'tablet',
    reorder_level     DECIMAL(10,2) NOT NULL DEFAULT 10,
    reorder_quantity  DECIMAL(10,2) NOT NULL DEFAULT 100,
    shelf_location    VARCHAR(30),
    storage_condition VARCHAR(50) DEFAULT 'room_temperature',
    requires_cold_chain BOOLEAN DEFAULT 0,
    is_narcotic       BOOLEAN DEFAULT 0,
    batch_status      VARCHAR(20) CHECK(batch_status IN ('active', 'depleted', 'expired', 'quarantined')),
    supplier_id       INTEGER REFERENCES suppliers(supplier_id),
    purchase_price    DECIMAL(10,2),
    selling_price     DECIMAL(10,2),
    last_updated      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(batch_number, medicine_id)
);

CREATE INDEX idx_inventory_medicine ON pharmacy_inventory(medicine_id);
CREATE INDEX idx_inventory_expiry ON pharmacy_inventory(batch_expiry);
CREATE INDEX idx_inventory_status ON pharmacy_inventory(batch_status);
```

### 12.3 pharmacists Table
```sql
CREATE TABLE pharmacists (
    pharmacist_id    INTEGER PRIMARY KEY AUTOINCREMENT,
    employee_code    VARCHAR(20) UNIQUE NOT NULL,
    full_name        VARCHAR(100) NOT NULL,
    license_number   VARCHAR(50) UNIQUE NOT NULL,
    qualification    VARCHAR(100),
    is_narcotic_authorized BOOLEAN DEFAULT 0,
    is_active        BOOLEAN DEFAULT 1,
    created_at       TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

## 13. API ENDPOINTS

### 13.1 Pharmacy Queue
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/pharmacy/queue` | List pending prescriptions |
| GET | `/api/pharmacy/queue/{id}` | Get prescription details |
| PATCH | `/api/pharmacy/queue/{id}/status` | Update queue status |
| GET | `/api/pharmacy/queue/filter?status=` | Filter by status |

### 13.2 Dispensing
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pharmacy/dispense/full` | Full dispense prescription |
| POST | `/api/pharmacy/dispense/partial` | Partial dispense |
| POST | `/api/pharmacy/dispense/narcotic` | Narcotic dispense (dual verify) |
| GET | `/api/pharmacy/dispense/log/{prescription_id}` | Get dispensing history |

### 13.3 Inventory
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/pharmacy/inventory` | List inventory (paginated) |
| GET | `/api/pharmacy/inventory/{medicine_id}` | Stock by medicine |
| POST | `/api/pharmacy/inventory/receive` | Receive new stock batch |
| PATCH | `/api/pharmacy/inventory/{id}` | Update stock (adjustments) |
| GET | `/api/pharmacy/inventory/alerts` | Stock and expiry alerts |
| GET | `/api/pharmacy/inventory/cold-chain` | Cold chain items |

### 13.4 Labels & Scanning
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pharmacy/label/generate` | Generate label for dispensed item |
| POST | `/api/pharmacy/scan/verify` | Verify barcode scan |
| GET | `/api/pharmacy/scan/history` | Scan history for audit |

### 13.5 Notifications
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/pharmacy/notify/doctor` | Notify doctor out of stock |
| POST | `/api/pharmacy/notify/patient` | Notify patient ready for pickup |
| GET | `/api/pharmacy/notifications/pending` | Pending alert responses |

## 14. CONFIGURATION

### 14.1 Stock Alerts
```python
PHARMACY_CONFIG = {
    "stock_alerts": {
        "low_stock_threshold": 10,        # Alert when stock drops below this
        "critical_stock_threshold": 3,     # Critical alert level
        "expiry_warning_days": 90,         # Warn when batch expires within N days
        "expiry_critical_days": 30,        # Critical expiry warning
        "auto_disable_expired_batches": True,  # Auto-set batch_status='expired'
    },
    "label_printing": {
        "printer_type": "thermal_zpl",
        "label_width_mm": 60,
        "label_height_mm": 40,
        "print_batch": True,              # Print batch number on label
        "print_barcode": True,            # Print barcode on label
        "default_language": "en",
    },
    "narcotic_control": {
        "require_dual_verification": True,
        "max_days_supply_narcotic": 7,    # Max days for controlled substances
        "narcotic_log_retention_days": 3650,  # 10 years as per regulations
    },
    "cold_chain": {
        "min_temp_c": 2.0,
        "max_temp_c": 8.0,
        "temp_check_interval_minutes": 60,
        "auto_alert_on_breach": True,
        "breach_notify_roles": ["pharmacy_manager", "admin"],
    },
    "general": {
        "default_pharmacy_id": "PHARM-001",
        "max_queue_items_per_page": 20,
        "auto_refresh_interval_seconds": 30,
        "require_patient_confirmation": True,  # Patient signs on pickup
        "enable_partial_dispensing": True,
    }
}
```

### 14.2 Expiry Warning Query
```sql
-- Daily cron job: check for expiring batches
SELECT
    inv.inventory_id,
    m.name AS medicine_name,
    inv.batch_number,
    inv.batch_expiry,
    inv.stock_quantity,
    DATEDIFF(DAY, CURRENT_DATE, inv.batch_expiry) AS days_until_expiry,
    CASE
        WHEN DATEDIFF(DAY, CURRENT_DATE, inv.batch_expiry) <= 30 THEN 'CRITICAL'
        WHEN DATEDIFF(DAY, CURRENT_DATE, inv.batch_expiry) <= 90 THEN 'WARNING'
        ELSE 'OK'
    END AS alert_level
FROM pharmacy_inventory inv
JOIN medicines m ON inv.medicine_id = m.medicine_id
WHERE inv.batch_expiry <= DATE_ADD(CURRENT_DATE, INTERVAL 90 DAY)
  AND inv.batch_status = 'active'
ORDER BY inv.batch_expiry ASC;
```

## 15. KEY DESIGN DECISIONS

1. **FIFO Stock Deduction**: When dispensing, the system always picks the oldest expiring batch first. This minimizes expiry waste and is enforced at the database level.

2. **Two-Phase Dispensing**: Verification and dispensing are separate steps. The pharmacist reviews the entire prescription first, then commits the dispense. This prevents partial committal on error.

3. **Barcode as Validation Gate**: Scanning the medicine barcode is mandatory before dispensing is allowed. Manual override exists but requires a manager PIN, creating an audit trail.

4. **Narcotic Dual Verification**: Controlled substances require two pharmacist badge scans. The system enforces that the two IDs are different and that both pharmacists are authorized for narcotic dispensing.

5. **Partial Dispensing as First-Class Feature**: Rather than treating partial dispensing as an edge case, the schema tracks `quantity_dispensed` and `quantity_remaining` per line item, and the prescription status transitions normally once all items reach zero remaining.

6. **Cold Chain Separate Tracking**: Temperature monitoring is independent of inventory — a separate `cold_chain_log` table records temperature readings by batch and refrigerator. Inventory checks cross-reference this table to flag breaches before dispensing.

7. **Label Generation at Dispense Time**: Labels are generated from the dispensing log record (not the prescription), ensuring the batch number, expiry, and pharmacist name are accurate at the moment of dispense.

8. **Queue Status is Authoritative**: All pharmacy operations transition the prescription through a state machine (`prescription.pharmacy_status`). No operation is valid unless the current status permits it. This prevents double dispensing.

9. **Doctor Notification Loop**: Out-of-stock does not block the prescription permanently. The pharmacist can suggest alternatives, the doctor responds, and the queue item updates without recreating the entire prescription flow.

10. **Audit Trail**: Every dispensing action, inventory adjustment, barcode scan override, and narcotic co-sign is logged with timestamps and user IDs. The `dispensing_log` and `narcotic_dispensing_log` tables serve as the legal record for regulatory compliance.
