---
file_id: "0205"
module_name: "Nurse Module"
version: "1.0"
status: "Draft"
phase: "Phase 2 — User Modules"
dependencies: ["0100_QUEUE_ENGINE.md"]
related_files: ["0201_DOCTOR_MODULE.md", "0106_VITALS_ENGINE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "nurse", "vitals", "assist", "preparation"]
---

# 👩‍⚕️ GHOS — Nurse Module

> **The Nurse Module is the vitals gateway and preparation hub of GHOS. Every patient entering the clinical workflow passes through the nursing station first. Designed for speed and accuracy: record vitals in under 60 seconds, flag abnormalities immediately, and prepare patients for procedures with a single click.**

---

## 1. PURPOSE

The Nurse Module is the clinical front door of the hospital. It enables:

- **Vitals recording** — Blood pressure, heart rate, temperature, SpO2, weight, height, BMI
- **Vitals validation** — Auto-flag abnormal readings with color-coded alerts based on age-stratified normal ranges
- **Patient preparation** — Prepare patients for ECG, Echo, TMT, and other procedures
- **Queue management** — See which patients need vitals before seeing the doctor
- **Doctor assistance** — Prepare patient summaries, update symptoms, apply dressings
- **Medication administration** — Record administered doses (inpatient / observation)
- **Wound care & procedure notes** — Document wound state, dressing changes, catheter care
- **Emergency escalation** — One-click alert to all doctors on duty with patient context
- **Vitals history** — View trend graphs for returning patients

---

## 2. NURSE DASHBOARD

```
┌────────────────────────────────────────────────────────────────┐
│  👩‍⚕️ Nurse Station — Ward A             📅 09-Jul-2026 10:42     │
│  📊 Today's vitals: 38 done │ 12 pending │ Avg: 52s each        │
├────────────────────────────────────────────────────────────────┤
│                                                                │
│  ┌─── WAITING FOR VITALS (12) ──────────────────────────┐     │
│  │  ⏳ DOC-042 │ Rajesh Kumar │ 45/M │ New │ ⏱ 4 min   │     │
│  │  ⏳ DOC-043 │ Priya Singh  │ 32/F │ Follow-up        │     │
│  │  ⏳ DOC-045 │ Mohan Lal    │ 60/M │ Senior Citizen   │     │
│  │  ⏳ LAB-003 │ Sunita Devi  │ 28/F │ Pre-lab vitals   │     │
│  │  ... (tap to expand)                                  │     │
│  └────────────────────────────────────────────────────────┘     │
│                                                                │
│  ┌─── CURRENT PATIENT ────────────────────────────────────┐    │
│  │                                                        │    │
│  │  📋 DOC-042 │ Rajesh Kumar │ 45/M │ New Visit         │    │
│  │  🏥 Dr. Sharma (Cardiology)                            │    │
│  │  📝 Complaint: Chest pain since 2 days                 │    │
│  │  🔄 Last vitals: 6 months ago                           │    │
│  │                                                        │    │
│  │  ┌─── VITALS FORM ───────────────────────────────┐     │    │
│  │  │  BP         [ 120 ] / [  80 ] mmHg   🔵 Normal │     │    │
│  │  │  Heart Rate [   72 ] bpm          🔵 Normal    │     │    │
│  │  │  Temp       [ 36.8 ] °C           🔵 Normal    │     │    │
│  │  │  SpO2      [   98 ] %            🔵 Normal    │     │    │
│  │  │  Weight     [   72 ] kg           🔵 Normal    │     │    │
│  │  │  Height     [  170 ] cm           🔵 Normal    │     │    │
│  │  │  ────────────────────────────────────────       │     │    │
│  │  │  BMI: 24.9 (Normal)     📐 Auto-calculated      │     │    │
│  │  │  ────────────────────────────────────────       │     │    │
│  │  │  Symptoms: [Chest pain radiating to left arm__] │     │    │
│  │  │  Notes:    [Patient is anxious_______________]  │     │    │
│  │  └────────────────────────────────────────────────┘     │    │
│  │                                                        │    │
│  │  [✅ Save Vitals & Send to Doctor]                      │    │
│  │  [🔴 Emergency]  [📋 Prep for Procedure]               │    │
│  │  [📈 View Vitals History]                              │    │
│  └────────────────────────────────────────────────────────┘    │
│                                                                │
│  ┌─── CURRENT PREPARATIONS ──────────────────────────────┐    │
│  │  ⚡ ECG Setup — Priya Singh (DOC-043) ⏳ In progress   │    │
│  │  ⚡ TMT Prep — Mohan Lal (DOC-045)  ⏳ Waiting        │    │
│  │  [Manage Preparations →]                              │    │
│  └────────────────────────────────────────────────────────┘    │
└────────────────────────────────────────────────────────────────┘
```

---

## 3. VITALS RECORDING WORKFLOW

```
Patient arrives at nursing station
  → Nurse selects patient from waiting queue
  → Vitals form auto-populated with last recorded values (if returning)
  → Nurse records each vital (BP, HR, Temp, SpO2, Weight, Height)
  → BMI calculated automatically from weight and height
  → Each field validated in real time against age-based normal ranges
      → 🔵 Blue border — normal
      → 🟡 Yellow border — borderline / mildly abnormal
      → 🔴 Red border — critical / requires immediate attention
  → Nurse adds symptoms and optional notes
  → Clicks "Save Vitals & Send to Doctor"
      → Vitals stored in vitals table
      → Patient moved from "Waiting for Vitals" to "Ready for Doctor"
      → Doctor's queue updated in real time
      → Average time: 45-60 seconds per patient
```

### Vitals Input Specifications

| Field | Input Type | Range | Precision | Unit |
|-------|-----------|-------|-----------|------|
| Systolic BP | Number input | 60-260 | Integer | mmHg |
| Diastolic BP | Number input | 30-160 | Integer | mmHg |
| Heart Rate | Number input | 20-250 | Integer | bpm |
| Temperature | Decimal input | 34.0-42.0 | 1 decimal | °C |
| SpO2 | Number input | 50-100 | Integer | % |
| Weight | Decimal input | 1.0-300.0 | 1 decimal | kg |
| Height | Number input | 30-250 | Integer | cm |
| BMI | Auto-calculated (display only) | — | 1 decimal | kg/m² |

### BMI Calculation

```python
def calculate_bmi(weight_kg: float, height_cm: int) -> dict:
    """Calculate BMI and return value with classification."""
    height_m = height_cm / 100
    bmi = round(weight_kg / (height_m ** 2), 1)
    
    if bmi < 18.5:
        classification = "Underweight"
        flag = "yellow"
    elif 18.5 <= bmi < 25.0:
        classification = "Normal"
        flag = "blue"
    elif 25.0 <= bmi < 30.0:
        classification = "Overweight"
        flag = "yellow"
    elif 30.0 <= bmi < 35.0:
        classification = "Obese Class I"
        flag = "red"
    elif 35.0 <= bmi < 40.0:
        classification = "Obese Class II"
        flag = "red"
    else:
        classification = "Obese Class III"
        flag = "red"
    
    return {"value": bmi, "classification": classification, "flag": flag}
```

---

## 4. VITALS NORMAL RANGE VALIDATION

Each vital sign is validated against age-stratified normal ranges on entry. The validation runs client-side (instant feedback) and server-side (data integrity).

```python
class VitalsValidator:
    """
    Real-time vitals validation with color-coded flags.
    
    🔵 Normal   — Value within normal range
    🟡 Borderline — Value outside normal range but not critical
    🔴 Critical — Value requires immediate clinical attention
    """
    
    # Normal ranges stratified by age group
    NORMAL_RANGES = {
        "adult": {  # 18-59 years
            "systolic_bp":   {"normal": (90, 130), "borderline": (130, 140), "critical_high": 180, "critical_low": 80},
            "diastolic_bp":  {"normal": (60, 85),  "borderline": (85, 90),  "critical_high": 120, "critical_low": 50},
            "heart_rate":    {"normal": (60, 100), "borderline": (100, 120), "critical_high": 140, "critical_low": 40},
            "temperature":   {"normal": (36.1, 37.5), "borderline": (37.6, 38.5), "critical_high": 40.0, "critical_low": 35.0},
            "spo2":          {"normal": (95, 100), "borderline": (90, 94), "critical_low": 85},
            "weight_bmi":    {"bmi_normal": (18.5, 25.0)}
        },
        "child": {  # 2-17 years
            "systolic_bp":   {"normal": (80, 120),  "borderline": (120, 130), "critical_high": 160, "critical_low": 70},
            "diastolic_bp":  {"normal": (50, 80),   "borderline": (80, 85),   "critical_high": 100, "critical_low": 40},
            "heart_rate":    {"normal": (70, 130),  "borderline": (130, 150), "critical_high": 170, "critical_low": 50},
            "temperature":   {"normal": (36.1, 37.8), "borderline": (37.9, 39.0), "critical_high": 40.5, "critical_low": 35.0},
            "spo2":          {"normal": (95, 100), "borderline": (90, 94), "critical_low": 85},
        },
        "infant": {  # 0-23 months
            "heart_rate":    {"normal": (100, 160), "borderline": (160, 180), "critical_high": 200, "critical_low": 80},
            "temperature":   {"normal": (36.5, 37.5), "borderline": (37.6, 38.5), "critical_high": 39.5, "critical_low": 35.5},
            "spo2":          {"normal": (95, 100), "borderline": (90, 94), "critical_low": 85},
        },
        "senior": {  # 60+ years
            "systolic_bp":   {"normal": (90, 140),  "borderline": (140, 160), "critical_high": 190, "critical_low": 80},
            "diastolic_bp":  {"normal": (60, 90),   "borderline": (90, 95),   "critical_high": 110, "critical_low": 50},
            "heart_rate":    {"normal": (60, 100), "borderline": (100, 110), "critical_high": 130, "critical_low": 40},
            "temperature":   {"normal": (36.0, 37.3), "borderline": (37.4, 38.2), "critical_high": 39.5, "critical_low": 35.0},
            "spo2":          {"normal": (94, 100), "borderline": (88, 93), "critical_low": 85},
        }
    }
    
    async def validate_vital(
        self, vital_type: str, value: float, patient_age: int
    ) -> dict:
        """Validate a single vital sign and return flag + message."""
        age_group = self._get_age_group(patient_age)
        ranges = self.NORMAL_RANGES.get(age_group, self.NORMAL_RANGES["adult"])
        vital_rules = ranges.get(vital_type)
        
        if not vital_rules:
            return {"status": "unknown", "flag": "blue", "message": None}
        
        normal_range = vital_rules.get("normal")
        borderline_range = vital_rules.get("borderline")
        critical_high = vital_rules.get("critical_high")
        critical_low = vital_rules.get("critical_low")
        
        # Check critical ranges first
        if critical_high and value >= critical_high:
            return {"status": "critical_high", "flag": "red",
                    "message": "Critically high — immediate attention required"}
        if critical_low and value <= critical_low:
            return {"status": "critical_low", "flag": "red",
                    "message": "Critically low — immediate attention required"}
        
        # Check borderline ranges
        if borderline_range:
            if borderline_range[0] <= value <= borderline_range[1]:
                direction = "elevated" if value > normal_range[1] else "low"
                return {"status": f"borderline_{direction}", "flag": "yellow",
                        "message": f"Borderline {direction} — monitor"}
        
        # Check normal range
        if normal_range and normal_range[0] <= value <= normal_range[1]:
            return {"status": "normal", "flag": "blue", "message": None}
        
        # Fallback
        return {"status": "abnormal", "flag": "yellow",
                "message": "Outside normal range — review"}
    
    def _get_age_group(self, age: int) -> str:
        if age < 2:
            return "infant"
        elif age < 18:
            return "child"
        elif age < 60:
            return "adult"
        else:
            return "senior"
```

---

## 5. PATIENT PREPARATION WORKFLOW

Nurses prepare patients for diagnostic procedures ordered by the doctor. The preparation panel opens after vitals are recorded or when a procedure order exists.

```
Doctor orders ECG/Echo/TMT/Procedure
  → Order appears in Nurse Module "Preparations" panel
  → Nurse marks preparation as "In Progress"
  → Nurse follows procedure-specific checklist
  → Nurse marks "Ready" when preparation complete
  → Patient moved to the procedure queue
  → Technician/doctor notified patient is ready
```

### Procedure Preparation Checklists

#### ECG Preparation
```
□ Patient gowned and privacy curtain drawn
□ Chest hair removed (electrode patches) if needed
□ Skin cleaned with alcohol wipes
□ Electrodes placed (standard 12-lead positions)
□ Patient lying supine, arms relaxed
□ Patient instructed to breathe normally and not speak
□ Machine checked — paper, leads, calibration
□ [Mark Ready for ECG]
```

#### Echo (Echocardiogram) Preparation
```
□ Patient positioned in left lateral decubitus
□ ECG leads attached for cardiac gating
□ Left arm raised above head
□ Gel applied to transducer area
□ Room lights dimmed for screen visibility
□ Patient instructed about holding breath on command
□ [Mark Ready for Echo]
```

#### TMT (Treadmill Test) Preparation
```
□ Patient changed into comfortable clothes + walking shoes
□ Light snack only (no heavy meal in last 2 hours)
□ No caffeine or smoking in last 3 hours confirmed
□ ECG electrodes placed (Mason-Likar modification)
□ BP cuff attached (will auto-inflate every 3 min)
□ Emergency crash cart confirmed available nearby
□ Patient explained Bruce protocol stages
□ Consent form signed
□ [Mark Ready for TMT]
```

#### General Procedure Preparation
```
□ Procedure consent verified (signed by doctor + patient)
□ Required equipment confirmed on tray
□ Area prepared (cleaned, draped)
□ Vital signs re-checked (pre-procedure baseline)
□ Allergy status confirmed (betadine, latex, etc.)
□ NBM status confirmed if applicable
□ [Mark Ready for Procedure]
```

```python
class PatientPreparation:
    """Manage patient preparation for procedures."""
    
    PROCEDURE_TYPES = {
        "ecg": {
            "name": "ECG",
            "department": "ECG Room",
            "checklist": [
                "Patient gowned",
                "Chest hair removed if needed",
                "Skin cleaned",
                "Electrodes placed (12-lead)",
                "Patient supine, arms relaxed",
                "Machine checked"
            ],
            "prep_time_estimate_min": 3,
        },
        "echo": {
            "name": "Echocardiogram",
            "department": "Echo Room",
            "checklist": [
                "Left lateral decubitus position",
                "ECG leads attached",
                "Left arm raised",
                "Gel applied",
                "Room dimmed"
            ],
            "prep_time_estimate_min": 5,
        },
        "tmt": {
            "name": "TMT",
            "department": "TMT Room",
            "checklist": [
                "Comfortable clothes + walking shoes",
                "Light snack confirmed",
                "No caffeine/smoking confirmed",
                "ECG electrodes placed (Mason-Likar)",
                "BP cuff attached",
                "Crash cart available",
                "Patient explained Bruce protocol",
                "Consent signed"
            ],
            "prep_time_estimate_min": 8,
        },
        "procedure": {
            "name": "General Procedure",
            "department": "Procedure Room",
            "checklist": [
                "Consent verified",
                "Equipment tray confirmed",
                "Area cleaned and draped",
                "Vitals re-checked",
                "Allergy confirmed",
                "NBM status confirmed"
            ],
            "prep_time_estimate_min": 5,
        }
    }
    
    async def start_preparation(
        self, visit_id: UUID, procedure_type: str
    ) -> dict:
        """Start preparation workflow for a patient."""
        procedure = self.PROCEDURE_TYPES.get(procedure_type)
        if not procedure:
            raise ValueError(f"Unknown procedure type: {procedure_type}")
        
        prep_record = await NursePreparation.create(
            visit_id=visit_id,
            procedure_type=procedure_type,
            status="in_progress",
            checklist={item: False for item in procedure["checklist"]},
            started_at=datetime.now()
        )
        
        return {
            "prep_id": str(prep_record.id),
            "checklist": procedure["checklist"],
            "estimated_minutes": procedure["prep_time_estimate_min"]
        }
    
    async def complete_preparation(self, prep_id: UUID) -> dict:
        """Mark preparation as complete and route patient."""
        prep = await NursePreparation.get(prep_id)
        
        # Verify all checklist items are checked
        unchecked = [item for item, done in prep.checklist.items() if not done]
        if unchecked:
            return {
                "success": False,
                "message": f"Incomplete checklist: {', '.join(unchecked)}"
            }
        
        prep.status = "ready"
        prep.completed_at = datetime.now()
        await prep.save()
        
        # Route patient to procedure queue
        procedure = self.PROCEDURE_TYPES[prep.procedure_type]
        await QueueEngine().enqueue(
            patient_id=prep.visit.patient_id,
            department_id=procedure["department"],
            priority="high",
            visit_id=prep.visit_id,
            notes="Patient prepared and ready"
        )
        
        return {"success": True, "routed_to": procedure["department"]}
```

---

## 6. NURSE QUEUE MANAGEMENT

The nurse queue displays all patients currently waiting for vitals before they reach the doctor. It also shows patients waiting for procedure preparation.

```
┌─── NURSE QUEUE ────────────────────────────────────────────┐
│  Filter: [All ▼]  Sort: [Arrival Time ▼]                   │
│                                                             │
│  ┌─── VITALS PENDING (8) ──────────────────────────────┐   │
│  │  ⏱ DOC-042 │ Rajesh │ 45/M │ Arrived 09:38 │ ⨯ 4m  │   │
│  │  ⏱ DOC-043 │ Priya  │ 32/F │ Arrived 09:41 │ ⨯ 1m  │   │
│  │  ⏱ DOC-045 │ Mohan  │ 60/M │ Arrived 09:42 │ ⨯ 0m  │   │
│  │  ⏱ LAB-003 │ Sunita │ 28/F │ Pre-lab        │       │   │
│  └────────────────────────────────────────────────────┘   │
│  ┌─── PROCEDURE PREP PENDING (3) ─────────────────────┐   │
│  │  ⚡ ECG │ Priya (DOC-043) │ Ordered 09:35         │   │
│  │  ⚡ TMT │ Mohan (DOC-045) │ Ordered 09:30         │   │
│  │  ⚡ Echo│ Ravi (DOC-046)  │ Ordered 09:28         │   │
│  └────────────────────────────────────────────────────┘   │
│  ┌─── READY FOR DOCTOR (4) ───────────────────────────┐   │
│  │  ✅ DOC-040 │ Anil  │ Vitals done │ Sent 09:30     │   │
│  │  ✅ DOC-041 │ Suman │ Vitals done │ Sent 09:33     │   │
│  └────────────────────────────────────────────────────┘   │
└───────────────────────────────────────────────────────────┘
```

### Queue Behaviors

| Queue Action | Effect |
|-------------|--------|
| **Tap patient row** | Load vitals form for that patient |
| **Long-press patient** | Show patient summary card (history, allergies, last visit) |
| **Swipe left** | Skip patient (move to end of vitals queue) |
| **Swipe right** | Mark as urgent (bring to top of queue) |
| **"Save & Send"** | Save vitals, move patient to "Ready for Doctor" |
| **"Prep for Procedure"** | Open preparation checklist panel |
| **Filter by type** | Show only "New", "Follow-up", "Pre-lab", "Procedure" |
| **Sort** | By arrival time, priority, age (senior first), name |

```python
class NurseQueueManager:
    """Manage the nursing station queue — who needs vitals, who is ready."""
    
    async def get_vitals_queue(self, ward_id: UUID) -> List[dict]:
        """Get patients waiting for vitals, ordered by priority + arrival."""
        # Priority ordering: critical > senior > new > follow-up
        pending = await Visit.filter(
            status="checked_in",
            vitals_status="pending",
            ward_id=ward_id
        ).order_by(
            "-is_urgent",
            "priority_score",
            "checked_in_at"
        ).all()
        
        return [{
            "visit_id": str(v.id),
            "token": v.token_number,
            "patient_name": v.patient.name,
            "age": v.patient.age,
            "gender": v.patient.gender,
            "visit_type": v.visit_type,
            "doctor_name": v.doctor.name if v.doctor else None,
            "arrived_at": v.checked_in_at.isoformat(),
            "waiting_minutes": (datetime.now() - v.checked_in_at).seconds // 60,
            "is_urgent": v.is_urgent,
            "priority_score": v.priority_score
        } for v in pending]
    
    async def mark_vitals_complete(
        self, visit_id: UUID, vitals_data: dict
    ) -> dict:
        """Save vitals and move patient to doctor's queue."""
        # Save vitals
        vitals = await Vitals.create(
            visit_id=visit_id,
            **vitals_data,
            recorded_by=nurse_id,
            recorded_at=datetime.now()
        )
        
        # Update visit status
        visit = await Visit.get(visit_id)
        visit.vitals_status = "completed"
        visit.vitals_recorded_at = datetime.now()
        await visit.save()
        
        # Enqueue to doctor
        await QueueEngine().enqueue(
            patient_id=visit.patient_id,
            department_id=visit.doctor.department_id,
            priority=visit.priority_score,
            visit_id=visit.id,
            vitals_id=vitals.id
        )
        
        return {
            "success": True,
            "vitals_id": str(vitals.id),
            "routed_to_doctor": str(visit.doctor_id)
        }
```

---

## 7. EMERGENCY ESCALATION

The emergency escalation button is a prominent red button visible at all times on the nurse dashboard. One click alerts all duty doctors immediately.

```python
class EmergencyEscalation:
    """One-click emergency alert to all duty doctors with patient context."""
    
    async def escalate(
        self, visit_id: UUID, nurse_id: UUID, reason: str = None
    ) -> dict:
        """
        Trigger emergency escalation.
        
        1. Flash emergency alert on all doctor dashboards
        2. Play audible alert (nurse station + doctor rooms)
        3. Send push notification to all duty doctors
        4. Log escalation with timestamp for audit
        5. Send SMS to on-call senior doctor
        6. Optionally call ambulance / code blue
        """
        visit = await Visit.get(visit_id).prefetch_related("patient")
        
        alert = {
            "type": "emergency",
            "severity": "critical",
            "patient": visit.patient.name,
            "token": visit.token_number,
            "location": "Nursing Station",
            "reported_by": nurse_id,
            "reason": reason or "Emergency escalation triggered",
            "timestamp": datetime.now().isoformat(),
            "vitals_context": await self._get_latest_vitals(visit_id)
        }
        
        # Dispatch to all duty doctors
        await self._flash_dashboard_alert(alert)
        await self._play_audible_alert(visit.ward_id)
        await NotificationOrchestrator().broadcast_to_role(
            role="doctor",
            notification_type="emergency",
            data=alert
        )
        
        # Log escalation
        await EmergencyLog.create(
            visit_id=visit_id,
            triggered_by=nurse_id,
            alert_data=alert,
            status="dispatched"
        )
        
        return {"success": True, "alert_id": str(alert_id)}
    
    async def _get_latest_vitals(self, visit_id: UUID) -> dict:
        """Fetch most recent vitals for context."""
        latest = await Vitals.filter(visit_id=visit_id)\
            .order_by("-recorded_at").first()
        if latest:
            return {
                "bp": f"{latest.systolic_bp}/{latest.diastolic_bp}",
                "hr": latest.heart_rate,
                "spo2": latest.spo2,
                "temp": latest.temperature
            }
        return None
```

---

## 8. MEDICATION ADMINISTRATION RECORDING

For inpatient and observation patients, nurses record medication doses administered at the bedside. This creates a permanent record in the MAR (Medication Administration Record).

```python
class MedicationAdministration:
    """
    Record administered medications.
    
    Integration points:
    - Inpatient prescriptions from doctor module flow here
    - Nurse scans patient wristband + medication barcode (future)
    - Each dose recorded with time, route, and witness if controlled drug
    """
    
    async def get_pending_administrations(
        self, ward_id: UUID, shift: str = "morning"
    ) -> List[dict]:
        """Get medications due for administration in current shift."""
        now = datetime.now()
        shift_map = {"morning": (6, 14), "afternoon": (14, 22), "night": (22, 6)}
        start_hour, end_hour = shift_map.get(shift, (0, 23))
        
        pending = await InpatientMedication.filter(
            ward_id=ward_id,
            status="active",
            scheduled_time__gte=now.replace(hour=start_hour, minute=0),
            scheduled_time__lte=now.replace(hour=end_hour, minute=0),
            administered_at__isnull=True
        ).order_by("scheduled_time", "patient__name").all()
        
        return [{
            "med_id": str(m.id),
            "patient_name": m.patient.name,
            "bed": m.bed_number,
            "medicine": m.medicine_name,
            "dosage": m.dosage,
            "route": m.route,
            "scheduled_time": m.scheduled_time.strftime("%H:%M"),
            "is_stat": m.is_stat,
            "requires_witness": m.is_controlled_drug
        } for m in pending]
    
    async def record_administration(
        self,
        medication_id: UUID,
        nurse_id: UUID,
        administered_at: datetime = None,
        route: str = None,
        site: str = None,
        lot_number: str = None,
        expiry_date: str = None,
        witness_id: UUID = None,
        notes: str = None,
        missed_reason: str = None
    ) -> dict:
        """Record that a medication dose was administered (or missed)."""
        med = await InpatientMedication.get(medication_id)
        
        if missed_reason:
            # Log as missed with reason
            med.status = "missed"
            med.missed_reason = missed_reason
            med.notes = notes
            await med.save()
            
            await MedicationLog.create(
                medication_id=medication_id,
                action="missed",
                nurse_id=nurse_id,
                reason=missed_reason,
                timestamp=datetime.now()
            )
            
            return {"success": True, "status": "missed"}
        
        # Record administration
        med.administered_at = administered_at or datetime.now()
        med.administered_by = nurse_id
        med.route = route or med.route
        med.site = site
        med.lot_number = lot_number
        med.expiry_date = expiry_date
        med.witnessed_by = witness_id
        med.notes = notes
        med.status = "administered"
        await med.save()
        
        await MedicationLog.create(
            medication_id=medication_id,
            action="administered",
            nurse_id=nurse_id,
            timestamp=administered_at or datetime.now(),
            notes=notes
        )
        
        return {"success": True, "status": "administered"}
```

### MAR Display

```
┌─── MEDICATION ADMINISTRATION RECORD ───────────────────────┐
│  Ward: A │ Shift: Morning (06:00-14:00) │ Date: 09-Jul     │
├────────────────────────────────────────────────────────────┤
│  Patient   │ Bed │ Medicine        │ Dose    │ Route │ 08 │ 12 │
│───────────│─────│─────────────────│─────────│───────│────│────│
│  Rajesh K │ 201 │ Aspirin 75mg    │ 1-0-0   │ Oral  │ ✅ │    │
│  Rajesh K │ 201 │ Atorvastatin 10 │ 0-0-1   │ Oral  │    │    │
│  Priya S   │ 202 │ Ceftriaxone 1g │ IV BD   │ IV    │ ✅ │    │
│  Mohan L   │ 203 │ Insulin        │ 10U     │ SC    │ ⛔ │    │
│            │     │ (missed — pt refused)     │       │    │    │
└────────────────────────────────────────────────────────────┘
```

---

## 9. WOUND CARE & PROCEDURE NOTES

Nurses document wound assessments, dressing changes, catheter care, and other nursing procedures. These notes become part of the patient's clinical record visible to doctors.

```python
class NurseProceduralNotes:
    """Document wound care, dressing changes, catheter care, etc."""
    
    WOUND_TYPES = {
        "surgical": {"name": "Surgical Wound", "risk": "high"},
        "pressure_ulcer": {"name": "Pressure Ulcer", "risk": "medium"},
        "diabetic_ulcer": {"name": "Diabetic Ulcer", "risk": "high"},
        "traumatic": {"name": "Traumatic Wound", "risk": "medium"},
        "burn": {"name": "Burn", "risk": "high"},
        "catheter_site": {"name": "Catheter Site", "risk": "medium"},
        "drain_site": {"name": "Drain Site", "risk": "low"},
        "iv_site": {"name": "IV Site", "risk": "low"},
    }
    
    WOUND_ASSESSMENT_FIELDS = {
        "wound_type": "select",         # From WOUND_TYPES
        "location": "text",             # e.g., "Left lower abdomen"
        "size_cm": "text",              # e.g., "3.5 x 2.0"
        "depth_cm": "decimal",
        "color": "select",              # "pink", "red", "yellow", "black", "mixed"
        "exudate": "select",            # "none", "serous", "purulent", "sanguineous"
        "exudate_amount": "select",     # "none", "minimal", "moderate", "heavy"
        "odor": "boolean",
        "edges": "select",              # "intact", "maccerated", "rolled", "undermined"
        "surrounding_skin": "select",   # "intact", "erythema", "induration", "rash"
        "pain_level": "number",         # 0-10 scale
        "signs_of_infection": "boolean",
    }
    
    async def record_wound_assessment(
        self,
        visit_id: UUID,
        nurse_id: UUID,
        assessment: dict,
        photos: List[str] = None,
        next_due_hours: int = 24
    ) -> dict:
        """Record a wound assessment / dressing change."""
        note = await NurseNote.create(
            visit_id=visit_id,
            note_type="wound_care",
            nurse_id=nurse_id,
            content=json.dumps(assessment),
            photo_urls=photos or [],
            created_at=datetime.now()
        )
        
        # Schedule next assessment reminder
        if next_due_hours:
            await TaskEngine().schedule_nurse_task(
                visit_id=visit_id,
                task_type="wound_check",
                due_at=datetime.now() + timedelta(hours=next_due_hours),
                assigned_to=nurse_id
            )
        
        return {"success": True, "note_id": str(note.id)}
```

### Documentation Examples

| Note Type | Example Content |
|-----------|----------------|
| **Dressing Change** | "Wound clean, edges pink, no exudate. Dressing changed with betadine. Next change due 24h." |
| **Catheter Care** | "Urine output 300ml clear. Meatal area clean, no erythema. Catheter patent." |
| **IV Site Check** | "IV site (left forearm) intact, no redness or swelling. Dressing changed. Next check 8h." |
| **Pressure Ulcer** | "Stage 2 pressure ulcer right heel. Dimensions 2.5x1.5cm. Dressing applied. Repositioned Q2H." |
| **General Observation** | "Patient alert and oriented. BP stable. Reporting less pain today." |

---

## 10. DATA MODEL

### vitals Table

```sql
CREATE TABLE vitals (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    
    -- Vital signs
    systolic_bp INTEGER CHECK (systolic_bp BETWEEN 60 AND 260),
    diastolic_bp INTEGER CHECK (diastolic_bp BETWEEN 30 AND 160),
    heart_rate INTEGER CHECK (heart_rate BETWEEN 20 AND 250),
    temperature DECIMAL(4,1) CHECK (temperature BETWEEN 34.0 AND 42.0),
    spo2 INTEGER CHECK (spo2 BETWEEN 50 AND 100),
    weight_kg DECIMAL(5,1) CHECK (weight_kg BETWEEN 1.0 AND 300.0),
    height_cm INTEGER CHECK (height_cm BETWEEN 30 AND 250),
    bmi DECIMAL(4,1) GENERATED ALWAYS AS (weight_kg / ((height_cm/100.0)^2)) STORED,
    
    -- Validation results (stored as JSON for audit)
    flags JSONB,  -- e.g., {"systolic_bp": "normal", "heart_rate": "borderline_high", ...}
    abnormal_count INTEGER DEFAULT 0,
    critical_count INTEGER DEFAULT 0,
    
    -- Metadata
    symptoms TEXT,
    notes TEXT,
    recorded_by UUID NOT NULL REFERENCES staff_users(id),
    recorded_at TIMESTAMP DEFAULT NOW(),
    is_verified BOOLEAN DEFAULT FALSE,  -- Senior nurse verification for critical values
    
    -- Soft delete
    deleted_at TIMESTAMP DEFAULT NULL
);

-- Indexes
CREATE INDEX idx_vitals_visit_id ON vitals(visit_id);
CREATE INDEX idx_vitals_patient_id ON vitals(patient_id);
CREATE INDEX idx_vitals_recorded_at ON vitals(recorded_at DESC);
CREATE INDEX idx_vitals_abnormal ON vitals(abnormal_count) WHERE abnormal_count > 0;
```

### nurse_notes Table

```sql
CREATE TABLE nurse_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    nurse_id UUID NOT NULL REFERENCES staff_users(id),
    
    note_type VARCHAR(50) NOT NULL CHECK (note_type IN (
        'wound_care', 'dressing_change', 'catheter_care',
        'iv_site', 'pressure_ulcer', 'general_observation',
        'handover', 'shift_report', 'patient_education',
        'procedure_note', 'other'
    )),
    content TEXT NOT NULL,
    
    -- Structured data for wound assessments
    wound_assessment JSONB,  -- Stores wound_type, location, size, color, exudate, etc.
    photo_urls TEXT[],        -- Array of S3/cloud URLs
    
    is_handover_note BOOLEAN DEFAULT FALSE,
    handover_to UUID REFERENCES staff_users(id),
    is_acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_at TIMESTAMP,
    
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW(),
    deleted_at TIMESTAMP DEFAULT NULL
);

CREATE INDEX idx_nurse_notes_visit ON nurse_notes(visit_id);
CREATE INDEX idx_nurse_notes_type ON nurse_notes(note_type);
CREATE INDEX idx_nurse_notes_created ON nurse_notes(created_at DESC);
```

### nurse_preparations Table

```sql
CREATE TABLE nurse_preparations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    procedure_type VARCHAR(20) NOT NULL CHECK (procedure_type IN ('ecg', 'echo', 'tmt', 'procedure')),
    
    status VARCHAR(20) NOT NULL DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'ready', 'cancelled')),
    checklist JSONB NOT NULL,  -- {"item": true/false, ...}
    
    started_by UUID REFERENCES staff_users(id),
    started_at TIMESTAMP,
    completed_by UUID REFERENCES staff_users(id),
    completed_at TIMESTAMP,
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);
```

### nurse_medication_administration Table

```sql
CREATE TABLE nurse_medication_administration (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    medication_id UUID NOT NULL REFERENCES inpatient_medications(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    
    administered BOOLEAN NOT NULL DEFAULT TRUE,
    administered_at TIMESTAMP NOT NULL DEFAULT NOW(),
    administered_by UUID NOT NULL REFERENCES staff_users(id),
    
    route VARCHAR(20),  -- "oral", "IV", "IM", "SC", "topical", etc.
    site VARCHAR(50),   -- "left arm", "right gluteal", etc.
    lot_number VARCHAR(50),
    expiry_date DATE,
    
    witnessed_by UUID REFERENCES staff_users(id),
    
    missed_reason TEXT,  -- "patient_refused", "vomited", "contraindicated", "not_available"
    
    notes TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE INDEX idx_med_admin_patient ON nurse_medication_administration(patient_id);
CREATE INDEX idx_med_admin_scheduled ON nurse_medication_administration(administered_at);
```

### emergencies_log Table

```sql
CREATE TABLE emergencies_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID NOT NULL REFERENCES visits(id),
    patient_id UUID NOT NULL REFERENCES patients(id),
    
    triggered_by UUID NOT NULL REFERENCES staff_users(id),
    alert_data JSONB NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'dispatched' CHECK (status IN ('dispatched', 'acknowledged', 'resolved', 'false_alarm')),
    resolved_by UUID REFERENCES staff_users(id),
    resolved_at TIMESTAMP,
    resolution_notes TEXT,
    
    created_at TIMESTAMP DEFAULT NOW()
);
```

---

## 11. API ENDPOINTS

All endpoints are prefixed with `/api/v1/nurse/`. Authentication required for all endpoints.

### Vitals Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/vitals/queue` | Get patients waiting for vitals |
| `GET` | `/vitals/{visit_id}` | Get latest vitals for a visit |
| `POST` | `/vitals/{visit_id}` | Record vitals for a patient |
| `PUT` | `/vitals/{vital_id}` | Update a vitals record (correction) |
| `GET` | `/vitals/{patient_id}/history` | Get vitals history for trend view |
| `GET` | `/vitals/ranges?age={age}` | Get normal ranges for a given age |

### Preparation Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/preparations` | Get pending preparations for the nurse's ward |
| `POST` | `/preparations/{visit_id}/start` | Start preparation for a procedure |
| `PUT` | `/preparations/{prep_id}/checklist` | Update checklist item status |
| `POST` | `/preparations/{prep_id}/complete` | Mark preparation as complete |
| `GET` | `/preparations/templates/{type}` | Get checklist template for procedure type |

### Queue Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/queue` | Full nurse queue (vitals pending + procedure prep) |
| `PUT` | `/queue/{visit_id}/prioritize` | Mark patient as urgent |
| `PUT` | `/queue/{visit_id}/skip` | Move patient to end of queue |

### Medication Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/medications/pending` | Get medications due for administration |
| `POST` | `/medications/{med_id}/administer` | Record medication administration |
| `POST` | `/medications/{med_id}/miss` | Record missed dose with reason |

### Notes Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `GET` | `/notes/{visit_id}` | Get all nurse notes for a visit |
| `POST` | `/notes/{visit_id}` | Create a new nurse note |
| `PUT` | `/notes/{note_id}` | Update a nurse note |
| `DELETE` | `/notes/{note_id}` | Soft-delete a nurse note |
| `GET` | `/notes/{visit_id}/handover` | Get handover notes |
| `POST` | `/notes/{note_id}/acknowledge` | Acknowledge a handover note |

### Emergency Endpoints

| Method | Path | Description |
|--------|------|-------------|
| `POST` | `/emergency/escalate` | Trigger emergency escalation |
| `GET` | `/emergency/log` | Get emergency escalation history |
| `PUT` | `/emergency/{emergency_id}/resolve` | Resolve an emergency alert |

---

## 12. CONFIGURATION

```yaml
nurse_module:
  ui:
    auto_refresh_queue_seconds: 10       # Re-fetch queue every 10s
    show_vitals_history: true
    default_vitals_view: "form"          # "form" or "table"
    keyboard_shortcuts:
      save_and_send: "Ctrl+Enter"
      emergency: "Escape"               # Prevent accidental trigger — double-tap
    
  vitals:
    require_bmi_calculation: true
    auto_save_on_field_exit: false       # true = save as nurse types
    require_confirmation_for_critical: true
    enable_voice_input: false            # Future: voice-to-text for vitals
    max_retake_attempts: 3               # How many times a vital can be re-taken
    
    # Normal ranges (overridable per hospital)
    normal_ranges:
      adult:
        systolic_bp: [90, 129]
        diastolic_bp: [60, 84]
        heart_rate: [60, 100]
        temperature: [36.1, 37.5]
        spo2: [95, 100]
      senior:
        systolic_bp: [90, 139]
        diastolic_bp: [60, 89]
        heart_rate: [60, 100]
        temperature: [36.0, 37.3]
        spo2: [94, 100]
      child:
        systolic_bp: [80, 119]
        heart_rate: [70, 130]
        temperature: [36.1, 37.8]
        spo2: [95, 100]
      infant:
        heart_rate: [100, 160]
        temperature: [36.5, 37.5]
        spo2: [95, 100]
    
  preparation:
    auto_route_on_complete: true         # Route to procedure dept when prep done
    require_full_checklist: true
    allow_partial_preparation: false     # false = all checklist items required
    
  medication:
    require_witness_for_controlled: true
    require_lot_number: false
    require_site_for_injections: true
    allow_missed_dose_with_reason: true
    
  emergency:
    alert_all_doctors: true
    play_audible_alert: true
    send_sms_to_oncall: true
    required_reason: false               # true = nurse must enter a reason
    auto_notify_critical_vitals: false   # true = auto-escalate if critical vital detected
    
  notes:
    require_wound_photos: false
    max_photo_size_mb: 10
    allowed_photo_formats: ["jpg", "png", "webp"]
    auto_schedule_next_wound_check: true
    default_next_check_hours: 24
```

---

## 13. KEY DESIGN DECISIONS

1. **Vitals are recorded before the doctor sees the patient.** This is the default GHOS workflow. The doctor dashboard always shows the latest vitals. No patient should reach the doctor without vitals being recorded first.

2. **Age-stratified normal ranges.** Adults, seniors, children, and infants have different normal ranges for vitals. Validation is always done against the patient's age group, not a one-size-fits-all threshold.

3. **Color-coded real-time validation.** Each vital sign field shows a colored border (blue = normal, yellow = borderline, red = critical) as the nurse types. This provides instant feedback without requiring the nurse to memorize ranges.

4. **BMI is auto-calculated, never entered.** Weight and height are entered; BMI is computed as a generated column in the database. This eliminates calculation errors.

5. **Queue-driven workflow.** The nurse does not search for patients. The queue surface shows who needs vitals, who needs preparation, and who is ready. Nurses work from the top of the list.

6. **Emergency button is always visible.** The red emergency button stays in a fixed position on the nurse dashboard. It dispatches to all doctors on duty and plays an audible alert. A confirmation dialog prevents accidental triggers.

7. **Procedure preparation uses structured checklists.** Each procedure type has a defined checklist. The patient cannot be marked "ready" until all checklist items are complete. This reduces preparation errors (e.g., forgetting consent).

8. **Medication administration is tracked per dose.** Every administered dose is recorded with time, route, site, and witness (for controlled drugs). Missed doses are logged with a reason. This creates a complete MAR for audit.

9. **Wound care documentation is structured.** Rather than free-text only, wound assessments use structured fields (size, color, exudate, etc.) that enable analytics and trend tracking. Photo attachments are supported.

10. **Nurse notes are type-categorized.** Notes are tagged by type (wound care, catheter care, handover, etc.) so they can be filtered and reported separately. Handover notes have an acknowledgment workflow to confirm the next shift has read them.
