---
file_id: "0605"
module_name: "Feedback Module"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0109_ANALYTICS_ENGINE.md", "0104_COMMUNICATION_ENGINE.md"]
related_files: ["0702_WHATSAPP.md", "0200_PATIENT_MODULE.md", "0604_FOLLOWUP.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "feedback", "satisfaction", "nps", "rating", "sentiment"]
---

# GHOS - Patient Feedback System

## 1. PURPOSE
Comprehensive patient feedback collection and analysis system that captures satisfaction data across multiple dimensions, computes NPS scores, tracks trends over time, and enables clinic management to respond to feedback and improve service quality.

## 2. DATA MODEL

```sql
-- Core feedback table
CREATE TABLE patient_feedback (
    feedback_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id              UUID NOT NULL REFERENCES patients(patient_id),
    visit_id                UUID REFERENCES visits(visit_id),
    appointment_id          UUID REFERENCES appointments(appointment_id),
    
    -- Feedback Details
    feedback_type           VARCHAR(30) NOT NULL,   -- visit, appointment, general, complaint, compliment
    source                  VARCHAR(30) NOT NULL,   -- whatsapp, sms, pwa, web, kiosk, email, qr
    is_anonymous            BOOLEAN DEFAULT FALSE,
    
    -- Overall Rating (1-5)
    overall_rating          INTEGER CHECK (overall_rating BETWEEN 1 AND 5),
    
    -- Category-specific Ratings (1-5)
    ratings                 JSONB DEFAULT '{}',
    -- {
    --   "wait_time": 4,
    --   "doctor_interaction": 5,
    --   "staff_behavior": 4,
    --   "facility_cleanliness": 5,
    --   "billing_experience": 3,
    --   "communication": 4,
    --   "overall_satisfaction": 4
    -- }
    
    -- NPS Question: How likely to recommend? (0-10)
    nps_score               INTEGER CHECK (nps_score BETWEEN 0 AND 10),
    nps_category            VARCHAR(20) GENERATED ALWAYS AS (
        CASE 
            WHEN nps_score >= 9 THEN 'promoter'
            WHEN nps_score >= 7 THEN 'passive'
            ELSE 'detractor'
        END
    ) STORED,
    
    -- Comments
    comments                TEXT,
    comment_sentiment       VARCHAR(20),            -- positive, negative, neutral, mixed
    comment_language        VARCHAR(10),            -- en, hi, gu (detected)
    
    -- Category-specific Feedback
    category_feedback       JSONB DEFAULT '{}',
    -- {
    --   "doctor_punctuality": "Doctor was on time",
    --   "staff_helpfulness": "Staff guided me well",
    --   "facility_issues": "Parking was difficult"
    -- }
    
    -- Response
    response_text           TEXT,
    responded_by            UUID REFERENCES staff(staff_id),
    responded_at            TIMESTAMPTZ,
    response_sent           BOOLEAN DEFAULT FALSE,
    response_channel        VARCHAR(20),
    
    -- Status
    status                  VARCHAR(30) DEFAULT 'pending',
    -- pending, acknowledged, responded, resolved, escalated, archived
    
    -- Metadata
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    visit_completed_at      TIMESTAMPTZ,            -- When visit finished (for timing analysis)
    feedback_submitted_at   TIMESTAMPTZ DEFAULT NOW(),
    ip_address              INET,
    user_agent              TEXT,
    
    CONSTRAINT valid_overall CHECK (overall_rating BETWEEN 1 AND 5)
);

-- Feedback templates (per department/service type)
CREATE TABLE feedback_templates (
    template_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name                    VARCHAR(100),
    department_id           UUID REFERENCES departments(department_id),
    service_type            VARCHAR(30),            -- opd, ipd, lab, pharmacy, billing, telemedicine
    is_active               BOOLEAN DEFAULT TRUE,
    
    -- Questions (ordered)
    questions               JSONB NOT NULL,
    -- [
    --   {"id": "overall", "type": "rating", "label": "Overall Experience", "required": true},
    --   {"id": "wait_time", "type": "rating", "label": "Wait Time", "required": true},
    --   {"id": "doctor", "type": "rating", "label": "Doctor Interaction", "required": true},
    --   {"id": "staff", "type": "rating", "label": "Staff Behavior", "required": true},
    --   {"id": "recommend", "type": "nps", "label": "Would you recommend us?", "required": true},
    --   {"id": "suggestions", "type": "text", "label": "Any suggestions?", "required": false}
    -- ]
    
    -- Channel-specific templates (different text for different channels)
    channel_templates       JSONB DEFAULT '{}',
    -- {
    --   "whatsapp": {"header": "How was your visit?", "footer": "Reply with rating 1-5"},
    --   "pwa": {"title": "Rate Your Visit", "subtitle": "Help us improve"}
    -- }
    
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- Feedback analytics materialized view (refreshed daily)
CREATE MATERIALIZED VIEW feedback_analytics AS
SELECT 
    DATE_TRUNC('day', feedback_submitted_at) as feedback_date,
    department_id,
    COUNT(*) as total_responses,
    ROUND(AVG(overall_rating), 2) as avg_rating,
    ROUND(AVG(nps_score), 2) as avg_nps,
    ROUND(100.0 * SUM(CASE WHEN nps_category = 'promoter' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) as promoter_pct,
    ROUND(100.0 * SUM(CASE WHEN nps_category = 'detractor' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0), 1) as detractor_pct,
    ROUND(
        (100.0 * SUM(CASE WHEN nps_category = 'promoter' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0)) -
        (100.0 * SUM(CASE WHEN nps_category = 'detractor' THEN 1 ELSE 0 END) / NULLIF(COUNT(*), 0))
    , 1) as nps_score,
    ROUND(AVG((ratings->>'wait_time')::int), 2) as avg_wait_time_rating,
    ROUND(AVG((ratings->>'doctor_interaction')::int), 2) as avg_doctor_rating,
    ROUND(AVG((ratings->>'staff_behavior')::int), 2) as avg_staff_rating,
    ROUND(AVG((ratings->>'facility_cleanliness')::int), 2) as avg_facility_rating
FROM patient_feedback
WHERE status != 'archived'
GROUP BY DATE_TRUNC('day', feedback_submitted_at), department_id
ORDER BY feedback_date DESC;

CREATE INDEX idx_feedback_patient ON patient_feedback(patient_id);
CREATE INDEX idx_feedback_status ON patient_feedback(status);
CREATE INDEX idx_feedback_dept ON patient_feedback(visit_id);
CREATE INDEX idx_feedback_nps ON patient_feedback(nps_category);
CREATE INDEX idx_feedback_created ON patient_feedback(created_at DESC);
```

## 3. FEEDBACK COLLECTION FLOW

```
┌──────────────────────────────────────────────────────────────────┐
│                     TRIGGER                                      │
│  Visit completed (all departments done)                         │
│  OR                                                             │
│  Appointment completed                                          │
│  OR                                                             │
│  Prescription issued                                            │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│              FEEDBACK REQUEST (30 min after visit)               │
│  Channel Priority:                                              │
│    1. WhatsApp (preferred) - Rich interactive feedback           │
│    2. PWA Push Notification - Opens feedback form in app         │
│    3. SMS - Fallback (limited to simple rating)                  │
│    4. Email - Detailed feedback (for registered users)           │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│              FEEDBACK COLLECTION                                 │
│                                                                  │
│  ┌─ WhatsApp Flow ──────────────────────────────────────────┐   │
│  │  Bot: "How was your visit? (1-5)"                       │   │
│  │  User: "4"                                              │   │
│  │  Bot: "Great! How was the doctor? (1-5)"                │   │
│  │  User: "5"                                              │   │
│  │  Bot: "Would you recommend us? (0-10)"                  │   │
│  │  User: "9" - Promoter!                                  │   │
│  │  Bot: "Any suggestions? (optional)"                     │   │
│  │  User: "Doctor was excellent"                           │   │
│  └─────────────────────────────────────────────────────────┘   │
│                                                                  │
│  ┌─ PWA Flow ──────────────────────────────────────────────┐   │
│  │  [Star Rating 1-5] ★★★★☆                               │   │
│  │  Category Ratings (optional slide-out)                   │   │
│  │  [NPS Slider 0-10]                                       │   │
│  │  [Comment Box]                                           │   │
│  │  [Submit]                                                │   │
│  └─────────────────────────────────────────────────────────┘   │
└────────────────────────────┬─────────────────────────────────────┘
                             │
                             ▼
┌──────────────────────────────────────────────────────────────────┐
│                  POST-SUBMISSION                                 │
│  - Thank you message (personalized)                              │
│  - If low rating (< 3):                                          │
│      - Apologize, ask for details                                │
│      - Flag for manager review                                   │
│      - Offer callback if needed                                  │
│  - If high rating (4-5 + Promoter):                              │
│      - Thank you, ask for Google review                          │
│      - Offer referral code                                       │
│  - Store and analyze                                             │
└──────────────────────────────────────────────────────────────────┘
```

## 4. WHATSAPP INTERACTIVE FEEDBACK

```python
# WhatsApp interactive feedback flow
class WhatsAppFeedbackCollector:
    """
    Collects feedback via WhatsApp interactive messages.
    Uses button lists and quick replies for ratings.
    """
    
    async def send_feedback_request(self, patient, visit):
        """Send initial feedback request via WhatsApp."""
        
        # Check if WhatsApp supports interactive messages
        if await self.supports_interactive(patient.phone):
            await self.send_interactive(patient, visit)
        else:
            await self.send_text_based(patient, visit)
    
    async def send_interactive(self, patient, visit):
        """Send WhatsApp interactive list message."""
        
        # Template with interactive buttons
        template_data = {
            'recipient': patient.phone,
            'template': 'feedback_request',
            'language': patient.language,
            'components': [
                {
                    'type': 'header',
                    'parameters': [{'type': 'text', 'text': f'Hi {patient.name}!'}]
                },
                {
                    'type': 'body',
                    'parameters': [{'type': 'text', 'text': 'How was your overall experience?'}]
                },
                {
                    'type': 'button',
                    'sub_type': 'quick_reply',
                    'index': 0,
                    'parameters': [
                        {'type': 'payload', 'payload': 'rating_5'},
                        {'type': 'payload', 'payload': 'rating_4'},
                        {'type': 'payload', 'payload': 'rating_3'},
                        {'type': 'payload', 'payload': 'rating_2'},
                        {'type': 'payload', 'payload': 'rating_1'}
                    ]
                }
            ]
        }
        
        return await communication_engine.send_whatsapp_template(template_data)
    
    async def handle_response(self, patient_id, response_data):
        """Process user response from interactive message."""
        
        feedback = await self.get_or_create_feedback(patient_id)
        
        if 'rating' in response_data:
            rating = int(response_data['rating'])
            feedback.overall_rating = rating
            
            # If low rating, ask for category details
            if rating <= 2:
                await self.ask_category_feedback(patient_id)
            # If high rating, ask for NPS
            elif rating >= 4:
                await self.ask_nps(patient_id)
            else:
                await self.ask_nps(patient_id)
        
        elif 'nps' in response_data:
            feedback.nps_score = int(response_data['nps'])
            await self.ask_comment(patient_id, optional=True)
        
        elif 'category_rating' in response_data:
            category = response_data['category']
            rating = int(response_data['category_rating'])
            feedback.ratings[category] = rating
            await self.next_category_or_done(patient_id, feedback)
        
        elif 'comment' in response_data:
            feedback.comments = response_data['comment']
            await self.complete_feedback(feedback)
    
    async def complete_feedback(self, feedback):
        """Finalize feedback and send thank you."""
        feedback.status = 'completed'
        feedback.feedback_submitted_at = utcnow()
        await feedback.save()
        
        # Personalized thank you
        if feedback.nps_category == 'promoter' and feedback.overall_rating >= 4:
            template = 'feedback_thanks_promoter'
            # Include Google review link
            await self.send_google_review_request(feedback.patient)
        elif feedback.overall_rating <= 2:
            template = 'feedback_thanks_low_rating'
            # Include manager contact
            await self.flag_for_manager_review(feedback)
        else:
            template = 'feedback_thanks'
        
        await communication_engine.send_whatsapp_template({
            'recipient': feedback.patient.phone,
            'template': template,
            'language': feedback.patient.language
        })
```

## 5. NPS SYSTEM

### 5.1 NPS Calculation
```python
class NPSManager:
    """
    Net Promoter Score calculation and management.
    NPS = %Promoters - %Detractors
    """
    
    def calculate_nps(self, department_id=None, date_range=None):
        """Calculate NPS for given scope."""
        
        query = FeedbackAnalytics.query
        
        if department_id:
            query = query.filter_by(department_id=department_id)
        if date_range:
            query = query.filter(
                feedback_submitted_at.between(date_range[0], date_range[1])
            )
        
        results = query.all()
        
        total = len(results)
        if total == 0:
            return {'nps': 0, 'promoters': 0, 'passives': 0, 'detractors': 0, 'total': 0}
        
        promoters = sum(1 for r in results if r.nps_category == 'promoter')
        passives = sum(1 for r in results if r.nps_category == 'passive')
        detractors = sum(1 for r in results if r.nps_category == 'detractor')
        
        nps = round(((promoters / total) - (detractors / total)) * 100, 1)
        
        return {
            'nps': nps,
            'promoters': promoters,
            'promoter_pct': round(promoters / total * 100, 1),
            'passives': passives,
            'passive_pct': round(passives / total * 100, 1),
            'detractors': detractors,
            'detractor_pct': round(detractors / total * 100, 1),
            'total': total
        }
    
    def get_trend(self, department_id=None, granularity='month'):
        """Get NPS trend over time."""
        if granularity == 'week':
            group_by = "DATE_TRUNC('week', feedback_submitted_at)"
        elif granularity == 'month':
            group_by = "DATE_TRUNC('month', feedback_submitted_at)"
        else:
            group_by = "DATE_TRUNC('quarter', feedback_submitted_at)"
        
        query = f"""
            SELECT 
                {group_by} as period,
                COUNT(*) as responses,
                ROUND(100.0 * SUM(CASE WHEN nps_category = 'promoter' THEN 1 ELSE 0 END) / COUNT(*), 1) as promoters,
                ROUND(100.0 * SUM(CASE WHEN nps_category = 'detractor' THEN 1 ELSE 0 END) / COUNT(*), 1) as detractors,
                ROUND(
                    (100.0 * SUM(CASE WHEN nps_category = 'promoter' THEN 1 ELSE 0 END) / COUNT(*)) -
                    (100.0 * SUM(CASE WHEN nps_category = 'detractor' THEN 1 ELSE 0 END) / COUNT(*))
                , 1) as nps
            FROM patient_feedback
            WHERE {department_id if department_id else 'TRUE'}
            GROUP BY period
            ORDER BY period DESC
            LIMIT 12
        """
        return db.session.execute(query).fetchall()
```

### 5.2 NPS Benchmarks
```yaml
nps_benchmarks:
  healthcare_industry_avg: 38
  clinic_average: 45
  hospital_average: 35
  
  gil_targets:
    excellent: "> 70"
    good: "50-70"
    average: "30-50"
    needs_improvement: "10-30"
    critical: "< 10"
  
  department_targets:
    opd: 60
    ipd: 65
    lab: 55
    pharmacy: 50
    billing: 45
    telemedicine: 55
```

## 6. CATEGORY-SPECIFIC FEEDBACK

### 6.1 Rating Categories
```yaml
feedback_categories:
  wait_time:
    label: "Wait Time"
    questions:
      - "How long did you wait for registration?"
      - "How long did you wait for the doctor?"
      - "How long did you wait at pharmacy?"
      - "How long did you wait at billing?"
  
  doctor_interaction:
    label: "Doctor Interaction"
    questions:
      - "Did the doctor listen to your concerns?"
      - "Did the doctor explain clearly?"
      - "Was the doctor respectful?"
      - "Did you feel rushed?"
  
  staff_behavior:
    label: "Staff Behavior"
    questions:
      - "Were staff members helpful?"
      - "Were staff members courteous?"
      - "Did staff communicate clearly?"
      - "Rate reception experience"
  
  facility_cleanliness:
    label: "Facility & Cleanliness"
    questions:
      - "Was the facility clean?"
      - "Were washrooms clean?"
      - "Was the waiting area comfortable?"
      - "Rate overall ambiance"
  
  billing_experience:
    label: "Billing Experience"
    questions:
      - "Was the billing process smooth?"
      - "Were charges explained clearly?"
      - "Was digital payment available?"
      - "Rate billing staff behavior"
  
  communication:
    label: "Communication"
    questions:
      - "Were appointment reminders helpful?"
      - "Was tracking page useful?"
      - "Were updates timely?"
      - "Rate overall communication"
```

## 7. RESPONSE MANAGEMENT

```python
class FeedbackResponseManager:
    """
    Manages clinic responses to patient feedback.
    Ensures timely responses and tracks resolution.
    """
    
    RESPONSE_PRIORITIES = {
        1: {'max_response_time': 60, 'escalate': True},      # Critical: 1 hour
        2: {'max_response_time': 240, 'escalate': True},      # Urgent: 4 hours
        3: {'max_response_time': 720, 'escalate': False},     # Normal: 12 hours
        4: {'max_response_time': 1440, 'escalate': False},    # Low: 24 hours
        5: {'max_response_time': 2880, 'escalate': False}     # Minimal: 48 hours
    }
    
    def determine_priority(self, feedback):
        """Determine response priority based on rating and content."""
        if feedback.overall_rating <= 2:
            # Check for critical keywords
            critical_keywords = ['pain', 'emergency', 'error', 'wrong', 'harm', 'complaint']
            if any(kw in feedback.comments.lower() for kw in critical_keywords):
                return 1
            return 2
        elif feedback.overall_rating == 3:
            return 3
        else:
            return 4
    
    def auto_respond(self, feedback):
        """Generate automated response based on feedback type."""
        if feedback.overall_rating >= 4:
            return {
                'template': 'feedback_thanks_positive',
                'include_review_request': True
            }
        elif feedback.overall_rating == 3:
            return {
                'template': 'feedback_neutral',
                'include_improvement_promise': True
            }
        else:
            return {
                'template': 'feedback_apology',
                'include_callback_offer': True,
                'escalate_to': self._find_appropriate_manager(feedback)
            }
    
    def assign_to_staff(self, feedback):
        """Assign feedback response to appropriate staff member."""
        priority = self.determine_priority(feedback)
        
        if priority <= 2:
            # Assign to department head directly
            assignee = DepartmentHead.query.filter_by(
                department_id=feedback.department_id
            ).first()
        else:
            # Assign to duty manager or pool
            assignee = self._get_next_available_staff(feedback.department_id)
        
        return assignee
```

## 8. TREND ANALYSIS

```python
class FeedbackTrendAnalyzer:
    """
    Analyzes feedback trends over time to identify patterns.
    Generates insights and alerts for management.
    """
    
    def analyze_trends(self, department_id=None, days=90):
        """Generate trend analysis report."""
        
        period_start = utcnow() - timedelta(days=days)
        
        feedbacks = PatientFeedback.query.filter(
            PatientFeedback.created_at >= period_start,
            PatientFeedback.department_id == department_id if department_id else True
        ).all()
        
        analysis = {
            'summary': self._generate_summary(feedbacks),
            'ratings_trend': self._rating_trend(feedbacks),
            'nps_trend': self._nps_trend(feedbacks),
            'category_breakdown': self._category_breakdown(feedbacks),
            'sentiment_analysis': self._sentiment_analysis(feedbacks),
            'top_issues': self._identify_top_issues(feedbacks),
            'improvements': self._track_improvements(feedbacks),
            'comparison': self._compare_previous_period(feedbacks, days)
        }
        
        # Auto-generate alerts
        alerts = self._generate_alerts(analysis)
        
        return {'analysis': analysis, 'alerts': alerts}
    
    def _sentiment_analysis(self, feedbacks):
        """Analyze sentiment of text comments."""
        comments = [f.comments for f in feedbacks if f.comments]
        
        if not comments:
            return {'total': 0}
        
        # Use NLP model for sentiment analysis
        sentiments = self.nlp_service.analyze_batch(comments)
        
        return {
            'total': len(comments),
            'positive': sentiments.count('positive'),
            'negative': sentiments.count('negative'),
            'neutral': sentiments.count('neutral'),
            'positive_pct': round(sentiments.count('positive') / len(comments) * 100, 1),
            'negative_pct': round(sentiments.count('negative') / len(comments) * 100, 1),
            'common_positive_words': self._extract_common_words(comments, 'positive'),
            'common_negative_words': self._extract_common_words(comments, 'negative')
        }
    
    def _identify_top_issues(self, feedbacks):
        """Identify most common issues from low ratings and negative comments."""
        low_ratings = [f for f in feedbacks if f.overall_rating <= 2]
        
        if not low_ratings:
            return []
        
        issue_counts = defaultdict(int)
        
        for f in low_ratings:
            # Check category ratings
            for category, rating in f.ratings.items():
                if isinstance(rating, int) and rating <= 2:
                    issue_counts[category] += 1
            
            # Check comments for keywords
            if f.comments:
                for issue, keywords in ISSUE_KEYWORDS.items():
                    if any(kw in f.comments.lower() for kw in keywords):
                        issue_counts[issue] += 1
        
        # Sort by frequency
        sorted_issues = sorted(issue_counts.items(), key=lambda x: x[1], reverse=True)
        
        return [
            {'issue': issue, 'count': count, 'percentage': round(count/len(low_ratings)*100, 1)}
            for issue, count in sorted_issues[:10]
        ]
```

## 9. CONFIGURATION

```yaml
feedback_config:
  collection:
    request_delay_minutes: 30      # Send feedback request 30 min after visit
    max_requests_per_visit: 2      # Maximum number of reminder requests
    request_cooldown_hours: 24     # Don't send another if already sent within 24h
    expiry_days: 7                 # Feedback request expires after 7 days
    
  channels:
    whatsapp:
      enabled: true
      priority: 1
      interactive: true            # Use WhatsApp interactive buttons
    pwa_push:
      enabled: true
      priority: 2
    sms:
      enabled: true
      priority: 3
      max_length: 160
    email:
      enabled: true
      priority: 4
      include_report_link: true
    
  nps:
    enabled: true
    ask_after_rating: true         # Ask NPS after overall rating
    frequency: "per_visit"         # per_visit, per_month, per_quarter
    
  response:
    auto_response: true
    max_response_time_hours: 24
    escalate_low_rating: true      # Auto-escalate ratings <= 2
    escalation_threshold: 2
    notify_admin_on: ["abuse_report", "critical_feedback", "legal_complaint"]
    response_templates:
      positive: "feedback_response_positive"
      neutral: "feedback_response_neutral"
      negative: "feedback_response_negative"
      
  analytics:
    auto_reporting: true
    report_frequency: "weekly"
    report_recipients: ["admin", "department_heads"]
    trend_period_days: 90
    alert_on_decline: true
    decline_threshold_pct: 10     # Alert if NPS drops by 10% or more
```

## 10. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| NPS + category ratings combined | Provides both benchmarkable metric and actionable granular data |
| WhatsApp interactive as primary channel | Highest response rates in Indian market |
| Sentiment analysis on comments | Quantifies qualitative feedback at scale |
| Category-specific questions per department | Relevant questions increase completion rate |
| Auto-response with escalation | Timely responses improve patient retention |
| Anonymous option | Encourages honest feedback without fear |
| Materialized view for analytics | Pre-computed for dashboard performance |
| Trend analysis with alerts | Proactive issue detection before it becomes systemic |
| Visit-linked feedback | Contextual feedback tied to specific experience |
| Multi-language comment support | Critical for Indian linguistic diversity |
