---
file_id: "0603"
module_name: "Appointment Module"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0100_QUEUE_ENGINE.md", "0105_AUTH_ENGINE.md", "0101_WORKFLOW_ENGINE.md"]
related_files: ["0200_PATIENT_MODULE.md", "0600_PATIENT_APP.md", "0604_FOLLOWUP.md", "0702_WHATSAPP.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "appointment", "booking", "schedule", "slot", "waitlist"]
---

# GHOS - Appointment Module

## 1. PURPOSE
Comprehensive appointment booking and management system that handles the full lifecycle: booking, cancellation, rescheduling, slot management, doctor availability, reminders, waitlist management, and recurring appointments. Integrates with the queue engine for seamless walk-in-to-appointment transition.

## 2. DATA MODEL

```sql
-- Core appointment table
CREATE TABLE appointments (
    appointment_id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id              UUID NOT NULL REFERENCES patients(patient_id),
    doctor_id               UUID NOT NULL REFERENCES doctors(doctor_id),
    department_id           UUID NOT NULL REFERENCES departments(department_id),
    branch_id               UUID NOT NULL REFERENCES branches(branch_id),
    
    -- Schedule
    appointment_date        DATE NOT NULL,
    start_time              TIME NOT NULL,        -- Slot start
    end_time                TIME NOT NULL,        -- Slot end (start + duration)
    slot_id                 UUID REFERENCES time_slots(slot_id),
    
    -- Status
    status                  VARCHAR(30) NOT NULL DEFAULT 'pending',
    -- pending, confirmed, checked_in, in_progress, completed, 
    -- cancelled, rescheduled, no_show, missed
    
    -- Patient Info
    patient_type            VARCHAR(20) DEFAULT 'self',  -- self, family_member, dependent
    linked_patient_id       UUID REFERENCES patients(patient_id),  -- For family bookings
    visit_reason            TEXT,
    is_first_visit          BOOLEAN DEFAULT FALSE,
    is_emergency            BOOLEAN DEFAULT FALSE,
    is_followup             BOOLEAN DEFAULT FALSE,
    followup_from_appt_id   UUID REFERENCES appointments(appointment_id),
    
    -- Booking Source
    source                  VARCHAR(30) NOT NULL,  -- pwa, whatsapp, website, staff, call, api
    booking_channel         VARCHAR(20),            -- online, offline, phone, walk_in
    booked_by               UUID,                   -- staff_id if booked by staff
    booked_at               TIMESTAMPTZ DEFAULT NOW(),
    
    -- Confirmation
    confirmed_at            TIMESTAMPTZ,
    confirmed_by            VARCHAR(30),            -- patient, staff, auto
    confirmation_channel    VARCHAR(20),            -- whatsapp, sms, email, phone
    
    -- Check-in
    checked_in_at           TIMESTAMPTZ,
    checked_in_method       VARCHAR(20),            -- qr, counter, self_service
    queue_entry_id          UUID REFERENCES queue_entries(queue_entry_id),
    
    -- Audit
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    cancelled_at            TIMESTAMPTZ,
    cancellation_reason     TEXT,
    rescheduled_from        UUID REFERENCES appointments(appointment_id),
    rescheduled_to          UUID REFERENCES appointments(appointment_id),
    
    CONSTRAINT valid_time_range CHECK (end_time > start_time),
    CONSTRAINT valid_status CHECK (status IN (
        'pending', 'confirmed', 'checked_in', 'in_progress', 
        'completed', 'cancelled', 'rescheduled', 'no_show', 'missed'
    ))
);

-- Time slots (pre-generated)
CREATE TABLE time_slots (
    slot_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doctor_id           UUID NOT NULL REFERENCES doctors(doctor_id),
    branch_id           UUID NOT NULL REFERENCES branches(branch_id),
    slot_date           DATE NOT NULL,
    start_time          TIME NOT NULL,
    end_time            TIME NOT NULL,
    slot_type           VARCHAR(20) DEFAULT 'regular',  -- regular, express, emergency, telemedicine
    max_bookings        INTEGER DEFAULT 1,
    current_bookings    INTEGER DEFAULT 0,
    is_available        BOOLEAN GENERATED ALWAYS AS (current_bookings < max_bookings) STORED,
    is_blocked          BOOLEAN DEFAULT FALSE,
    block_reason        TEXT,
    is_recurring        BOOLEAN DEFAULT FALSE,
    recurring_pattern   JSONB,                           -- For recurring appointments
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    updated_at          TIMESTAMPTZ DEFAULT NOW(),
    
    UNIQUE(doctor_id, branch_id, slot_date, start_time),
    CONSTRAINT valid_slot CHECK (end_time > start_time)
);

-- Slot generation schedule (configure per doctor)
CREATE TABLE doctor_schedules (
    schedule_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    doctor_id           UUID NOT NULL REFERENCES doctors(doctor_id),
    branch_id           UUID NOT NULL REFERENCES branches(branch_id),
    day_of_week         INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
    is_available        BOOLEAN DEFAULT TRUE,
    start_time          TIME NOT NULL,
    end_time            TIME NOT NULL,
    slot_duration_min   INTEGER DEFAULT 15,
    break_start         TIME,                              -- Lunch break start
    break_end           TIME,                              -- Lunch break end
    max_patients        INTEGER,                           -- Per day limit
    telemedicine_only   BOOLEAN DEFAULT FALSE,
    effective_from      DATE NOT NULL,
    effective_to        DATE,                              -- NULL = ongoing
    created_at          TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(doctor_id, branch_id, day_of_week, effective_from)
);

-- Waitlist
CREATE TABLE appointment_waitlist (
    waitlist_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID NOT NULL REFERENCES patients(patient_id),
    doctor_id           UUID NOT NULL REFERENCES doctors(doctor_id),
    branch_id           UUID NOT NULL REFERENCES branches(branch_id),
    preferred_date      DATE,
    preferred_time_start TIME,
    preferred_time_end  TIME,
    status              VARCHAR(20) DEFAULT 'active',   -- active, notified, booked, expired, cancelled
    position            INTEGER,                          -- Computed position in waitlist
    notified_at         TIMESTAMPTZ,                       -- When patient was notified of slot
    notification_channel VARCHAR(20),
    response_at         TIMESTAMPTZ,                       -- Patient response time
    response            VARCHAR(20),                       -- accepted, declined, no_response
    expires_at          TIMESTAMPTZ,                       -- Offer expiry time
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
```

## 3. APPOINTMENT LIFECYCLE

```
                    ┌──────────────────────┐
                    │   Patient Books      │
                    │   Appointment        │
                    └──────────┬───────────┘
                               │
                    ┌──────────▼───────────┐
            ┌───────┤    PENDING           ├───────┐
            │       │ (Awaiting Confirm)    │       │
            │       └──────────┬───────────┘       │
            │                  │                    │
            │       ┌──────────▼───────────┐       │
            │       │   CONFIRMED          │       │
            │       │ (Slot locked)        │       │
            │       └──────────┬───────────┘       │
            │                  │                    │
            │       ┌──────────▼───────────┐       │
            │       │   CHECKED IN         │       │
            │       │ (Arrived, in queue)  │       │
            │       └──────────┬───────────┘       │
            │                  │                    │
            │       ┌──────────▼───────────┐       │
            │       │   IN PROGRESS        │       │
            │       │ (With doctor)        │       │
            │       └──────────┬───────────┘       │
            │                  │                    │
            │       ┌──────────▼───────────┐       │
            │       │   COMPLETED          │       │
            │       │ (Visit done)         │       │
            │       └──────────────────────┘       │
            │                                      │
            └── CANCELLED ── RESCHEDULED ── NO_SHOW ── MISSED
```

## 4. BOOKING FLOW (DETAILED)

### 4.1 Online Booking Flow
```
Step 1: Patient Authentication
  -> OTP-based login (if not already authenticated)
  -> Fetch patient profile + family members

Step 2: Select Branch
  -> Show nearby branches (based on geolocation)
  -> Or manual selection from list

Step 3: Select Department
  -> Categorized by specialty
  -> Show department info, typical wait times

Step 4: Select Doctor
  -> Doctor cards with:
     - Name, specialization, experience
     - Rating (from feedback)
     - Next available slot
     - Languages spoken
     - Telemedicine availability flag

Step 5: Select Date & Time Slot
  -> Calendar view (30-day lookahead)
  -> Available slots in 15-min intervals
  -> Color coding: green (available), yellow (limited), red (full)
  -> Real-time availability (WebSocket for popular doctors)
  -> Show slot duration and fee

Step 6: Select Patient
  -> Self or family member
  -> Add new family member (name, phone, relationship, age)

Step 7: Add Details
  -> Reason for visit (free text)
  -> Is this a follow-up? (link to previous appointment)
  -> Upload relevant reports (optional)
  -> Any specific requests

Step 8: Review & Confirm
  -> Appointment summary card
  -> Doctor, date, time, branch, fee
  -> Patient details
  -> Confirm button

Step 9: Post-Booking
  -> Appointment confirmed (slot locked)
  -> Confirmation via WhatsApp + calendar invite (.ics)
  -> Add to Google Calendar / Apple Calendar option
  -> Show appointment QR code for check-in
  -> Offer to add reminder
```

### 4.2 Staff-Assisted Booking Flow
```
Staff Login -> Patient Search -> Select patient (or create)
-> Select Doctor -> Select Slot -> Add Notes
-> Confirm -> Print appointment slip
-> WhatsApp confirmation sent to patient
```

### 4.3 WhatsApp Booking Flow
```
Patient sends "Book appointment" to clinic WhatsApp
-> AI Receptionist responds:
   "Please share your name and preferred date/time"
-> NLP parses intent
-> Shows available slots
-> Patient selects
-> Confirmation sent
```

## 5. SLOT MANAGEMENT

### 5.1 Slot Generation
```python
def generate_slots(doctor_id, branch_id, from_date, to_date):
    """Generate 15-min slots for a date range based on doctor schedule."""
    
    schedules = DoctorSchedule.query.filter(
        doctor_id=doctor_id,
        branch_id=branch_id,
        effective_from <= to_date,
        (effective_to.is_(None) | (effective_to >= from_date))
    ).all()
    
    slots = []
    current_date = from_date
    
    while current_date <= to_date:
        day_schedule = next(
            (s for s in schedules if s.day_of_week == current_date.weekday()),
            None
        )
        
        if day_schedule and day_schedule.is_available:
            time = day_schedule.start_time
            while time < day_schedule.end_time:
                # Skip break period
                if day_schedule.break_start and day_schedule.break_end:
                    if day_schedule.break_start <= time < day_schedule.break_end:
                        time = day_schedule.break_end
                        continue
                
                slot_end = time + timedelta(minutes=day_schedule.slot_duration_min)
                
                slots.append({
                    'doctor_id': doctor_id,
                    'branch_id': branch_id,
                    'slot_date': current_date,
                    'start_time': time,
                    'end_time': slot_end,
                    'slot_type': 'regular'
                })
                
                time = slot_end
        
        current_date += timedelta(days=1)
    
    # Bulk insert
    db.session.bulk_insert_mappings(TimeSlot, slots)
    db.session.commit()
```

### 5.2 Slot Locking & Release
```python
class SlotManager:
    """Manages slot locking with timeout to prevent abandoned holds."""
    
    HOLD_DURATION_MINUTES = 10
    
    def hold_slot(self, slot_id, patient_id):
        """Lock slot temporarily during booking process."""
        slot = TimeSlot.query.with_for_update().get(slot_id)
        
        if not slot.is_available:
            raise SlotNotAvailableError()
        
        # Use Redis for temporary hold
        redis_client.setex(
            f"slot_hold:{slot_id}",
            self.HOLD_DURATION_MINUTES * 60,
            patient_id
        )
        
        return True
    
    def release_slot(self, slot_id):
        """Release hold when booking fails or times out."""
        redis_client.delete(f"slot_hold:{slot_id}")
    
    def confirm_booking(self, slot_id):
        """Permanently book the slot."""
        slot = TimeSlot.query.get(slot_id)
        slot.current_bookings += 1
        db.session.commit()
        redis_client.delete(f"slot_hold:{slot_id}")
    
    def cancel_booking(self, slot_id):
        """Release slot on cancellation."""
        slot = TimeSlot.query.get(slot_id)
        slot.current_bookings -= 1
        db.session.commit()
```

## 6. REMINDER SYSTEM

### 6.1 Reminder Schedule
```yaml
reminder_schedule:
  - timing: "-24h"        # 24 hours before
    channel: "whatsapp"
    template: "appointment_reminder_24h"
    content: "Reminder: Your appointment with Dr. {doctor} tomorrow at {time}"
    
  - timing: "-2h"         # 2 hours before
    channel: "whatsapp"
    template: "appointment_reminder_2h"
    content: "Your appointment is in 2 hours. Please arrive 10 min early."
    
  - timing: "-30min"      # 30 minutes before
    channel: "push"
    content: "Time for your appointment! Don't forget to bring previous reports."
    
  - timing: "+15min"      # 15 minutes after (if no check-in)
    channel: "whatsapp"
    content: "We're waiting for you! Please check in at reception."
    action: trigger_no_show_process
```

### 6.2 Reminder Delivery Tracking
```sql
CREATE TABLE reminder_logs (
    reminder_id         UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    appointment_id      UUID NOT NULL REFERENCES appointments(appointment_id),
    reminder_timing     VARCHAR(10),          -- -24h, -2h, -30min, +15min
    channel             VARCHAR(20),           -- whatsapp, sms, email, push, voice
    status              VARCHAR(20),           -- sent, delivered, failed, read
    sent_at             TIMESTAMPTZ,
    delivered_at        TIMESTAMPTZ,
    failed_at           TIMESTAMPTZ,
    failure_reason      TEXT,
    read_at             TIMESTAMPTZ,
    channel_message_id  VARCHAR(100),          -- Provider's message ID
    created_at          TIMESTAMPTZ DEFAULT NOW()
);
```

## 7. WAITLIST SYSTEM

### 7.1 Waitlist Logic
```python
class WaitlistManager:
    """
    Manages waitlist for fully booked slots.
    Automatically notifies patients when slots open up.
    """
    
    def join_waitlist(self, patient_id, doctor_id, preferred_date, time_range):
        entry = AppointmentWaitlist(
            patient_id=patient_id,
            doctor_id=doctor_id,
            preferred_date=preferred_date,
            preferred_time_start=time_range[0],
            preferred_time_end=time_range[1]
        )
        db.session.add(entry)
        db.session.commit()
        self._recalculate_positions(doctor_id, preferred_date)
        return entry
    
    def _recalculate_positions(self, doctor_id, date):
        """Recalculate waitlist positions when someone joins or leaves."""
        entries = AppointmentWaitlist.query.filter_by(
            doctor_id=doctor_id,
            preferred_date=date,
            status='active'
        ).order_by(AppointmentWaitlist.created_at).all()
        
        for i, entry in enumerate(entries, 1):
            entry.position = i
        db.session.commit()
    
    def on_slot_open(self, slot_id):
        """When a slot opens up (cancellation), notify waitlisted patients."""
        slot = TimeSlot.query.get(slot_id)
        waitlisted = self._get_eligible_waitlist(slot)
        
        for entry in waitlisted[:3]:  # Notify top 3
            self._notify_patient(entry, slot)
            entry.status = 'notified'
            entry.notified_at = utcnow()
            entry.notification_channel = 'whatsapp'
            entry.expires_at = utcnow() + timedelta(minutes=15)
        
        db.session.commit()
    
    def _get_eligible_waitlist(self, slot):
        """Get waitlist entries eligible for this slot."""
        return AppointmentWaitlist.query.filter(
            AppointmentWaitlist.doctor_id == slot.doctor_id,
            AppointmentWaitlist.preferred_date == slot.slot_date,
            AppointmentWaitlist.status == 'active',
            AppointmentWaitlist.preferred_time_start <= slot.start_time,
            AppointmentWaitlist.preferred_time_end >= slot.end_time
        ).order_by(AppointmentWaitlist.position).limit(3).all()
```

## 8. RECURRING APPOINTMENTS

### 8.1 Recurring Patterns
```yaml
recurring_patterns:
  weekly:
    - "Every Monday at 10:00"
    - "Every weekday at 09:00"
  
  biweekly:
    - "Every other Friday at 14:00"
  
  monthly:
    - "First Monday of every month at 11:00"
    - "15th of every month at 10:00"
  
  custom:
    - "Every 3 days for 2 weeks"
    - "Every 2 weeks for 3 months"

recurring_limits:
  max_occurrences: 52       # Max one year of weekly
  max_months_forward: 6     # Generate 6 months at a time
  auto_stop_on_missed: 3    # Stop recurring if 3 missed
  cancellation_policy: "Future instances only (no past modification)"
```

## 9. CANCELLATION / RESCHEDULE POLICIES

```yaml
cancellation_policy:
  windows:
    free_cancellation: "> 24 hours before"     # No charge
    late_cancellation: "2-24 hours before"     # 50% fee
    no_show: "< 2 hours or no show"            # Full charge
  
  reschedule:
    free_reschedule: "> 12 hours before"
    fee_reschedule: "< 12 hours before"        # Minor fee
  
  no_show_tracking:
    max_no_shows: 3                             # Before restrictions
    restriction_after: "Require prepayment for future bookings"
    reset_period: "6 months"
    
  cancellation_reasons:
    - "Patient health issue"
    - "Emergency"
    - "Schedule conflict"
    - "Doctor unavailable"
    - "Other (specify)"
```

## 10. API ENDPOINTS

```python
@router.get("/api/v1/appointments/slots/{doctor_id}")
async def get_available_slots(
    doctor_id: UUID,
    date: date,
    branch_id: UUID = None,
    slot_type: str = 'regular'
):
    """Get available slots for a doctor on a given date."""

@router.post("/api/v1/appointments/book")
async def book_appointment(
    booking: AppointmentBookingRequest,
    current_user = Depends(get_current_user)
):
    """Book a new appointment. Holds slot for 10 minutes."""

@router.put("/api/v1/appointments/{appointment_id}/reschedule")
async def reschedule_appointment(
    appointment_id: UUID,
    new_slot_id: UUID,
    reason: str = None
):
    """Reschedule to a different slot."""

@router.put("/api/v1/appointments/{appointment_id}/cancel")
async def cancel_appointment(
    appointment_id: UUID,
    reason: str,
    notify_patient: bool = True
):
    """Cancel appointment and release slot."""

@router.post("/api/v1/appointments/check-in/{appointment_id}")
async def check_in_appointment(
    appointment_id: UUID,
    method: str = 'qr',
    qr_data: str = None
):
    """Check in patient upon arrival. Adds to queue."""

@router.get("/api/v1/appointments/waitlist/{doctor_id}")
async def get_waitlist_position(
    doctor_id: UUID,
    patient_id: UUID
):
    """Get patient's position in waitlist."""

@router.get("/api/v1/appointments/upcoming/{patient_id}")
async def get_upcoming_appointments(patient_id: UUID):
    """Get all upcoming appointments for patient."""
```

## 11. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| TimeSlot as separate table over computed slots | Pre-generation allows blocking, overrides, and query performance |
| Slot holds via Redis | Prevents double-booking without long DB locks |
| Waitlist with expiry offers | Prevents indefinite holds on waitlist notifications |
| Recurring appointments generated in batches | Practical limit, avoids infinite future generation |
| Multiple booking channels unified | Consistent experience across PWA, WhatsApp, phone, walk-in |
| Family member support | Common Indian requirement (booking for parents/children) |
| No-show tracking with escalation | Deters abuse while being fair to genuine cases |
| Slot types (regular, express, emergency) | Flexibility for different patient needs |
