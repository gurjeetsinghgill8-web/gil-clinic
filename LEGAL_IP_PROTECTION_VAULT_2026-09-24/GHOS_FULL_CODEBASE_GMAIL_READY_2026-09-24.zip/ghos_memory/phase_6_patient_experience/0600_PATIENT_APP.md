---
file_id: "0600"
module_name: "Patient App"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0100_QUEUE_ENGINE.md", "0105_AUTH_ENGINE.md", "0104_COMMUNICATION_ENGINE.md"]
related_files: ["0902_PWA.md", "0903_OFFLINE_MODE.md", "0601_PATIENT_TIMELINE.md", "0602_PATIENT_TRACKING.md", "0603_APPOINTMENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "patient", "app", "mobile", "pwa", "flutter", "react-native"]
---

# GHOS - Patient App

## 1. PURPOSE
Patient-facing mobile application delivered as a Progressive Web App (PWA) with native wrappers for Android (Kotlin) and iOS (Swift). The app provides zero-login tracking, OTP-authenticated history/appointments, and full-featured account access. It serves as the primary digital touchpoint for patients interacting with GIL CLINIC.

## 2. ARCHITECTURE OVERVIEW

```
[PWA Shell] <--> [Service Worker] <--> [IndexedDB Cache]
     |
[API Gateway] <--> [Auth Engine] <--> [Queue Engine] <--> [Backend Services]
     |
[FCM / Web Push] <--> [Notification Service]
```

### 2.1 Technology Stack
| Layer | Technology | Rationale |
|-------|-----------|-----------|
| UI Framework | Flutter (primary), React Native (iOS fallback) | Single codebase for web + mobile |
| PWA Shell | Vanilla JS + Workbox | Lightweight, no framework lock-in |
| State Management | Riverpod (Flutter), Redux Toolkit (RN) | Predictable state |
| Offline Storage | IndexedDB via Dexie.js | Structured query offline |
| Push | Firebase Cloud Messaging + Web Push API | Cross-platform |
| Maps | MapBox / Google Maps SDK | Location-aware features |
| Biometrics | WebAuthn + Platform-specific APIs | Fingerprint / Face ID |

## 3. SCREEN HIERARCHY

### 3.1 Zero-Auth Screens (No Login Required)
| Screen | Route | Description |
|--------|-------|-------------|
| Home | `/` | Clinic branding, quick actions, announcements |
| Track Visit | `/track` | Enter mobile or scan QR to track current visit |
| Visit Status | `/visit/:id` | Real-time queue position, department timeline, ETA |
| Clinic Info | `/clinic` | Address, contact, hours, doctor list |
| Emergency | `/emergency` | Quick emergency contact, SOS |

### 3.2 OTP-Auth Screens (Phone + OTP)
| Screen | Route | Description |
|--------|-------|-------------|
| History | `/history` | Past visits summary, reports, invoices |
| Appointments | `/appointments` | Book, view, cancel, reschedule |
| Profile | `/profile` | Manage personal info, family members, preferences |
| Notifications | `/notifications` | All notification history, preferences |
| Feedback | `/feedback/:visit_id` | Post-visit satisfaction survey |

### 3.3 Full-Auth Screens (Email + Password + 2FA)
| Screen | Route | Description |
|--------|-------|-------------|
| Dashboard | `/dashboard` | Complete health summary, timeline, reports |
| Family Management | `/family` | Add/manage family members, linked records |
| Document Vault | `/documents` | All reports, prescriptions, invoices (download/print) |
| Settings | `/settings` | Language, notifications, privacy, account |
| Support | `/support` | Chat, ticket, FAQ |

## 4. CORE FEATURES

### 4.1 Zero-Login Tracking Flow
```
Patient registers at reception
  -> QR code printed on slip
  -> Patient scans QR or receives WhatsApp link
  -> Tracking page opens (no auth)
  -> Real-time updates via WebSocket
  -> Sound + vibration when called
  -> Page auto-closes when visit completes
```

### 4.2 Offline Mode Architecture
```javascript
// Service Worker Strategy
const CACHE_STRATEGIES = {
  'GET /api/queue/status/*': 'NetworkFirst',      // Fresh data preferred
  'GET /api/clinic/info':     'CacheFirst',        // Static info
  'GET /api/patient/*':       'NetworkOnly',       // Never cache PII
  'GET /images/*':            'CacheFirst',        // Assets
  'GET /api/templates/*':     'StaleWhileRevalidate' // Templates
};

// Offline Queue for mutations
const OFFLINE_QUEUE = {
  maxRetries: 5,
  retryInterval: 30000, // 30 seconds
  syncOnReconnect: true,
  supportedActions: ['feedback.submit', 'appointment.request', 'profile.update']
};
```

### 4.3 Push Notification Categories
| Category | Priority | Sound | Vibration | Display |
|----------|----------|-------|-----------|---------|
| queue.called | High | Yes | Long | Banner + Alert |
| queue.nearby | Medium | Yes | Short | Banner |
| report.ready | Medium | No | Short | Silent |
| appointment.reminder | Low | Yes | Short | Banner |
| medicine.ready | Medium | Yes | Short | Banner |
| emergency | Critical | Yes | Continuous | Alert + Override silent |
| promotional | Low | No | None | Digest |

### 4.4 Appointment Booking (Detailed Flow)
```
Step 1: Select Department
  -> Show departments with availability
Step 2: Select Doctor
  -> Doctor cards with ratings, available slots
Step 3: Select Date & Time
  -> Calendar view with slot grid (15-min intervals)
  -> Real-time slot availability via WebSocket
Step 4: Select Patient
  -> Self or family member from saved list
Step 5: Confirm
  -> Summary screen with clinic details
  -> Confirm button
  -> Post-booking: confirmation WhatsApp + calendar invite
  -> Added to slot (blocked from other bookings)
```

### 4.5 Report Viewing
- Reports displayed inline (PDF viewer with text selection)
- Download for offline access
- Share via WhatsApp/Email directly from app
- Report comparison (previous vs current side-by-side)
- AI-generated summary for lab reports
- Report sharing with family members (with patient consent)

### 4.6 Family Management
- Add family members via mobile number or patient ID
- Each member has independent auth (OTP for each)
- Linked accounts for shared access
- Appointments can be booked for any linked member
- Reports viewable for dependents (children, elderly parents)
- Proxy access management (who can see what)

## 5. PWA FEATURES (DETAILED)

### 5.1 Installation
- Manifest.json with full icon set (48px to 512px)
- Install prompt capture (beforeinstallprompt event)
- Desktop PWA support (Chrome, Edge, Safari)
- Custom install button in-app
- Installation analytics tracking

### 5.2 Service Worker Capabilities
- Background sync for offline actions
- Push event handling (notificationclick, notificationclose)
- Cache management (versioned, LRU eviction)
- Periodic background sync (daily health tips)
- Update flow (skipWaiting, clientsClaim)

### 5.3 Hardware Access
| API | Use Case | Fallback |
|-----|----------|----------|
| Camera (QR) | Scan queue QR, prescription QR | Manual entry |
| Geolocation | Find nearest branch | Zip code search |
| Vibration | Call alert in silent mode | Sound only |
| Notifications | All push categories | SMS fallback |
| Battery | Low battery warnings | None |
| Bluetooth | Future device integration (BP monitor) | Manual entry |

## 6. UI/UX DESIGN SYSTEM

### 6.1 Theme
- Primary color: #0066CC (Medical Blue)
- Secondary: #00C853 (Success Green for status updates)
- Accent: #FF6D00 (Warning Orange for alerts)
- Background: #F5F7FA (Light gray)
- Text: #1A1A2E (Dark navy)
- Accessibility: WCAG 2.1 AA minimum, AAA preferred

### 6.2 Typography
- Headings: Inter (Sans-serif)
- Body: Noto Sans (CJK support for Hindi)
- Monospace: JetBrains Mono (for codes/tokens)
- Minimum touch target: 44x44px
- Dynamic type support (iOS) / font scaling (Android)

### 6.3 Responsive Breakpoints
| Breakpoint | Width | Layout |
|------------|-------|--------|
| Mobile | < 480px | Single column, bottom nav |
| Tablet | 480-768px | Two column, side drawer |
| Desktop | > 768px | Full layout, sidebar |

## 7. PERFORMANCE BUDGETS
| Metric | Target | Threshold |
|--------|--------|-----------|
| First Contentful Paint | < 1.5s | < 3s |
| Time to Interactive | < 3s | < 5s |
| First Input Delay | < 50ms | < 100ms |
| Lighthouse Score | > 90 | > 80 |
| Offline Functionality | 100% | Visit tracking |
| App Shell Size | < 100KB | Gzipped |

## 8. LOCALE & L10N
- i18next for internationalization
- Supported languages: English (en), Hindi (hi), Gujarati (gu)
- RTL support for potential future Arabic
- Date/time localized (IST, DD/MM/YYYY)
- Number formatting (Indian numbering system: lakhs, crores)
- Translation management via Lokalise / Crowdin
- Medical terminology translated with expert review

## 9. ANALYTICS & MONITORING
- Screen tracking (which screens, how long, drop-offs)
- Feature usage heatmaps
- Crash reporting (Sentry / Firebase Crashlytics)
- Performance monitoring (Web Vitals)
- A/B testing framework (for UI experiments)
- Session replay (with consent, anonymized)
- Funnel analysis (booking completion rate)

## 10. SECURITY MEASURES
- OTP-based auth with rate limiting (max 5 attempts/hour)
- JWT tokens with 15-minute expiry, refresh token rotation
- Biometric auth for app unlock (fingerprint, Face ID)
- No PII stored in IndexedDB (only non-sensitive cache)
- Certificate pinning for API calls
- Screenshot blocking for sensitive screens (iOS/Android)
- Clipboard clearing on app background
- Remote wipe capability for lost devices

## 11. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| PWA-first, native wrappers later | Zero install friction, wider reach |
| Flutter over React Native | Better performance, single codebase for web+mobile |
| Zero-login tracking | Removes biggest barrier to adoption |
| IndexedDB over localStorage | Structured queries, larger storage, async |
| Workbox for service worker | Battle-tested, declarative caching |
| Riverpod over Provider | Better testability, compile-time safety |
| OTP as primary auth | Familiar to Indian users, low friction |
