---
file_id: "0601"
module_name: "Patient Timeline"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0101_WORKFLOW_ENGINE.md", "0100_QUEUE_ENGINE.md"]
related_files: ["0600_PATIENT_APP.md", "0602_PATIENT_TRACKING.md", "0604_FOLLOWUP.md", "0200_PATIENT_MODULE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "timeline", "journey", "universal", "chronological", "filter"]
---

# GHOS - Patient Timeline

## 1. PURPOSE
A universal, chronological, filterable timeline that captures the patient's complete journey across all departments, visits, tests, reports, prescriptions, and communications. It is the single source of truth for the patient's healthcare journey and is accessible to patients, doctors, reception staff, and administrators through role-scoped views.

## 2. DATA MODEL

```sql
-- Core timeline event table
CREATE TABLE patient_timeline_events (
    event_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID NOT NULL REFERENCES patients(patient_id),
    visit_id            UUID REFERENCES visits(visit_id),
    event_type          VARCHAR(50) NOT NULL,        -- See enum below
    event_category      VARCHAR(30) NOT NULL,        -- visit, clinical, billing, communication, system
    event_timestamp     TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    department_id       UUID REFERENCES departments(department_id),
    actor_id            UUID REFERENCES staff(staff_id),
    actor_role          VARCHAR(50),
    location_id         UUID REFERENCES locations(location_id),
    previous_status     VARCHAR(50),
    new_status          VARCHAR(50),
    metadata            JSONB DEFAULT '{}',           -- Event-specific payload
    source              VARCHAR(30) DEFAULT 'system', -- system, staff_action, patient_action, api
    severity            VARCHAR(20) DEFAULT 'info',   -- info, warning, error, critical
    is_visible_to_patient BOOLEAN DEFAULT TRUE,
    deleted_at          TIMESTAMPTZ                   -- Soft delete for compliance
);

-- Indexes for fast timeline queries
CREATE INDEX idx_timeline_patient_time 
    ON patient_timeline_events(patient_id, event_timestamp DESC);
CREATE INDEX idx_timeline_event_type 
    ON patient_timeline_events(event_type);
CREATE INDEX idx_timeline_visit 
    ON patient_timeline_events(visit_id);
CREATE INDEX idx_timeline_category 
    ON patient_timeline_events(patient_id, event_category);
CREATE INDEX idx_timeline_department 
    ON patient_timeline_events(patient_id, department_id);
```

### 2.1 Event Type Enumeration
```sql
CREATE TYPE timeline_event_type AS ENUM (
    -- Registration & Arrival
    'patient.registered',
    'patient.arrived',
    'patient.checked_in',
    'patient.qr_scanned',
    
    -- Queue Events
    'queue.enqueued',
    'queue.called',
    'queue.routed',
    'queue.skipped',
    'queue.completed',
    'queue.delayed',
    
    -- Department Events
    'dept.entered',
    'dept.exited',
    'dept.wait_started',
    'dept.wait_updated',
    
    -- Clinical Events
    'consultation.started',
    'consultation.completed',
    'diagnosis.recorded',
    'prescription.issued',
    'test.ordered',
    'test.sample_collected',
    'test.result_ready',
    'test.result_viewed',
    
    -- Billing Events
    'bill.generated',
    'bill.payment_initiated',
    'bill.payment_completed',
    'bill.refund_issued',
    'insurance.claim_submitted',
    
    -- Report Events
    'report.generated',
    'report.viewed',
    'report.downloaded',
    'report.shared',
    
    -- Communication Events
    'whatsapp.sent',
    'whatsapp.delivered',
    'whatsapp.read',
    'sms.sent',
    'sms.delivered',
    'email.sent',
    'email.opened',
    'call.initiated',
    'call.completed',
    
    -- Appointment Events
    'appointment.booked',
    'appointment.confirmed',
    'appointment.rescheduled',
    'appointment.cancelled',
    'appointment.no_show',
    
    -- Follow-up Events
    'followup.scheduled',
    'followup.reminder_sent',
    'followup.completed',
    'followup.missed',
    
    -- Feedback Events
    'feedback.requested',
    'feedback.submitted',
    'feedback.responded',
    
    -- System Events
    'record.merged',
    'record.corrected',
    'consent.updated',
    'data.exported'
);
```

## 3. VISUAL TIMELINE COMPONENT

### 3.1 Desktop View
```
┌──────────────────────────────────────────────────────────────┐
│  🔍 Search / Filter      📅 Jul 9, 2026    👤 Patient Name  │
├──────────────────────────────────────────────────────────────┤
│  ┌─ Filters ──────────────────────────────────────────────┐  │
│  │ [All] [Visits] [Clinical] [Billing] [Reports] [Comm]  │  │
│  │ 📅 From: ___  To: ___  Dept: [All ▼]                  │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌─ Visit #1 - Jul 9, 2026 ───────────────────────────────┐  │
│  │  09:15 ✅ Registered         ┃ Reception               │  │
│  │  09:18 ✅ Checked In         ┃ Waiting Area            │  │
│  │  09:22 ✅ QR Scanned         ┃ Self-Service Kiosk      │  │
│  │  09:30 🔵 Doctor (Current)   ┃ Consultation Room 3     │  │
│  │  09:45 ⏳ ECG Pending        ┃ Lab - 2nd Floor         │  │
│  │  10:00 ⬜ Pharmacy            ┃ Ground Floor            │  │
│  │  10:15 ⬜ Billing             ┃ Cash Counter 2          │  │
│  └────────────────────────────────────────────────────────┘  │
│                                                              │
│  ┌─ Visit #2 - Jun 15, 2026 ──────────────────────────────┐  │
│  │  All items completed (View Details ▸)                  │  │
│  └────────────────────────────────────────────────────────┘  │
└──────────────────────────────────────────────────────────────┘
```

### 3.2 Mobile View
```
┌──────────────┐
│ 🔙 Timeline  │
├──────────────┤
│ 📅 Jul 9     │
│              │
│ ✅ 09:15     │
│   Registered │
│    Reception │
│              │
│ ✅ 09:18     │
│   Checked In │
│    Waiting   │
│              │
│ 🔵 09:30     │
│   Doctor     │
│   Room 3     │
│   ◄ You are  │
│     here     │
│              │
│ ⏳ 09:45     │
│   ECG        │
│   Lab(2F)    │
│              │
│ ⬜ Pharmacy  │
└──────────────┘
```

### 3.3 Timeline States and Icons
| Icon | State | CSS Class | Description |
|------|-------|-----------|-------------|
| ✅ | Completed | `.tl-completed` | Done, no issues |
| 🔵 | Active | `.tl-active` | Currently in progress |
| ⏳ | Pending | `.tl-pending` | In queue, waiting |
| ⬜ | Upcoming | `.tl-upcoming` | Scheduled but not yet |
| ❌ | Skipped | `.tl-skipped` | Not needed/waived |
| ⚠️ | Warning | `.tl-warning` | Delay or issue |
| 🔴 | Error | `.tl-error` | Failed/cancelled/error |
| ℹ️ | Info | `.tl-info` | Informational only |

## 4. TIMELINE LIFECYCLE

```
Patient Registration
    │
    ▼
┌─────────────────────────────────────────────────────────────┐
│                     ACTIVE VISIT                            │
│  Events are streamed in real-time via WebSocket             │
│  Each department transition creates a new timeline entry    │
│  Queue position updates are reflected live                  │
│  Estimated wait times calculated from historical averages   │
└─────────────────────────────────────────────────────────────┘
    │
    ▼ (Visit Completes)
┌─────────────────────────────────────────────────────────────┐
│                     VISIT HISTORY                           │
│  Events are persisted and viewable                          │
│  Summary statistics computed (total time, per-dept time)    │
│  Reports and prescriptions linked to timeline points        │
│  Follow-up events appended future-dated                     │
└─────────────────────────────────────────────────────────────┘
```

## 5. API ENDPOINTS

```python
# FastAPI Routes
from fastapi import APIRouter, Query, Depends
from datetime import datetime

router = APIRouter(prefix="/api/v1/timeline", tags=["timeline"])

@router.get("/{patient_id}")
async def get_patient_timeline(
    patient_id: UUID,
    visit_id: UUID = None,
    event_category: str = None,
    event_types: list[str] = Query(None),
    department_id: UUID = None,
    from_date: datetime = None,
    to_date: datetime = None,
    limit: int = 50,
    offset: int = 0,
    include_hidden: bool = False,  # Staff can see hidden events
    current_user = Depends(get_current_user)
):
    """
    Returns paginated timeline events for a patient.
    Respects role-based visibility (patient sees only is_visible_to_patient).
    Orders by event_timestamp DESC (most recent first).
    """

@router.get("/{patient_id}/summary")
async def get_timeline_summary(patient_id: UUID):
    """
    Returns aggregated summary:
    - Total visits
    - Total time spent in clinic
    - Average visit duration
    - Department breakdown (time per dept)
    - Last visit date
    - Upcoming appointments
    - Pending follow-ups
    """

@router.get("/{patient_id}/live/{visit_id}")
async def get_live_timeline(patient_id: UUID, visit_id: UUID):
    """
    WebSocket endpoint for real-time timeline updates.
    Streams events as they happen during active visit.
    Used by tracking page and doctor dashboard.
    """
```

## 6. FILTERING AND SEARCH

### 6.1 Filter Dimensions
| Filter | Type | Values |
|--------|------|--------|
| Event Category | Multi-select | visit, clinical, billing, reports, communication, system |
| Date Range | Date picker | From / To |
| Department | Dropdown | All departments (dynamic from DB) |
| Event Type | Multi-select | From event type enum |
| Visit | Dropdown | Select specific visit |
| Severity | Multi-select | info, warning, error, critical |
| Actor | Search | By staff name or role |

### 6.2 Search Capabilities
- Full-text search across event metadata (JSONB)
- Search by doctor name, medication, test name, amount
- Search by date range (natural language: "last week", "this month")
- Regex support for advanced users (admin)
- Search results highlighted in timeline

## 7. ROLE-BASED VISIBILITY

| Role | Can See | Cannot See |
|------|---------|------------|
| Patient | All marked is_visible_to_patient | Internal notes, audit metadata, financial breakdown |
| Doctor | Full clinical timeline | Billing details, other doctors' private notes |
| Reception | Visit flow, queue events | Clinical details, diagnosis |
| Nurse | Clinical events, queue status | Billing, admin |
| Lab Tech | Test events only | Other departments, billing |
| Pharmacist | Prescription events only | Diagnosis, test results |
| Accountant | Billing events only | Clinical details |
| Admin | Everything | N/A |
| Super Admin | Everything including audit | N/A |

## 8. CACHING AND PERFORMANCE

```yaml
# Timeline caching strategy
timeline_cache:
  ttl:
    active_visit: 0              # No cache for live data
    recent_history_30d: 60       # 60 seconds cache
    old_history: 300             # 5 minutes cache
    summary_stats: 600           # 10 minutes cache
  
  redis:
    key_pattern: "timeline:{patient_id}:{params_hash}"
    invalidation:
      - on new event insertion
      - on visit completion
      - on manual refresh

  pagination:
    default_page_size: 50
    max_page_size: 200
    cursor_based: true           # Keyset pagination for performance
```

## 9. EVENT INGESTION PIPELINE

```python
# Publish-Subscribe pattern for event ingestion
class TimelineEventBus:
    """
    Central event bus that all modules publish to.
    Timeline service subscribes and persists events.
    """
    
    def __init__(self):
        self.subscribers = {
            "queue.*": [self._handle_queue_event],
            "clinical.*": [self._handle_clinical_event],
            "billing.*": [self._handle_billing_event],
            "communication.*": [self._handle_communication_event],
            "appointment.*": [self._handle_appointment_event],
            "followup.*": [self._handle_followup_event],
            "feedback.*": [self._handle_feedback_event],
            "*": [self._handle_generic_event]  # Catch-all
        }
    
    async def publish(self, event: TimelineEvent):
        """Publish event to all matching subscribers."""
        for pattern, handlers in self.subscribers.items():
            if fnmatch(event.event_type, pattern):
                for handler in handlers:
                    await handler(event)
    
    async def _handle_queue_event(self, event):
        """Queue events -> update timeline, notify WebSocket clients."""
        await self.persist_event(event)
        await self.notify_watchers(event.patient_id, event)
        await self.update_live_tracker(event)
```

## 10. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| Single timeline table over separate per-category tables | Unified querying, cross-category filtering, simpler schema |
| JSONB metadata column | Flexible per-event payload without schema explosion |
| Soft delete with deleted_at | Compliance with DPDP Act (right to forget) |
| WebSocket for live updates | Real-time tracking without polling |
| Cursor-based pagination | Stable pagination despite new events being inserted |
| Event sourcing pattern | Full audit trail, replay capability, debugging |
| Separate visibility flag per event | Granular patient-facing control without role-based view duplication |
| Asynchronous event bus | Decoupled modules, no single point of failure |
