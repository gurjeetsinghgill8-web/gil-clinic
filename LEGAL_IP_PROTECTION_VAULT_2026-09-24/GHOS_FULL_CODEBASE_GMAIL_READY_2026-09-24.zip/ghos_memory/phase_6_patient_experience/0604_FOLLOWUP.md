---
file_id: "0604"
module_name: "Follow-up Module"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0104_COMMUNICATION_ENGINE.md", "0603_APPOINTMENT.md"]
related_files: ["0502_AI_FOLLOWUP.md", "0702_WHATSAPP.md", "0704_VOICE_CALL.md", "0200_PATIENT_MODULE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "followup", "reminder", "recall", "adherence", "outcome"]
---

# GHOS - Follow-up Module

## 1. PURPOSE
Automated follow-up management system that schedules, tracks, and manages patient follow-ups based on doctor recommendations. Handles reminders, outcome tracking, no-show handling, and integrates with all communication channels for multi-touch follow-up sequences.

## 2. DATA MODEL

```sql
-- Core follow-up table
CREATE TABLE follow_ups (
    follow_up_id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id              UUID NOT NULL REFERENCES patients(patient_id),
    visit_id                UUID REFERENCES visits(visit_id),
    appointment_id          UUID REFERENCES appointments(appointment_id),
    
    -- Follow-up Details
    follow_up_type          VARCHAR(30) NOT NULL,
    -- post_visit_checkup, scheduled_followup, test_result_review,
    -- medication_adherence, recovery_check, chronic_management,
    -- vaccination_reminder, health_screening, custom
    
    recommendation_source   VARCHAR(30),            -- doctor, ai, system, manual
    recommended_by          UUID REFERENCES staff(staff_id),  -- Doctor ID
    recommendation_notes    TEXT,
    
    -- Timing
    scheduled_date          DATE,
    scheduled_time          TIME,
    recommended_delay       VARCHAR(50),            -- "7 days", "1 month", "3 months"
    delay_unit              VARCHAR(10),            -- days, weeks, months
    delay_value             INTEGER,
    follow_up_window_start  TIMESTAMPTZ,            -- Earliest acceptable time
    follow_up_window_end    TIMESTAMPTZ,            -- Latest acceptable time
    is_recurring            BOOLEAN DEFAULT FALSE,
    recurring_pattern       JSONB,                  -- Same format as appointments
    
    -- Status
    status                  VARCHAR(30) DEFAULT 'scheduled',
    -- scheduled, reminder_sent, reminder_delivered, reminder_read,
    -- in_progress, completed, missed, no_show, cancelled, rescheduled
    
    -- Outcome
    outcome                 VARCHAR(30),            -- successful, needs_revisit, resolved, escalated
    outcome_notes           TEXT,
    outcome_recorded_by     UUID REFERENCES staff(staff_id),
    outcome_recorded_at     TIMESTAMPTZ,
    
    -- Communication
    last_reminder_sent_at   TIMESTAMPTZ,
    reminder_count          INTEGER DEFAULT 0,
    preferred_channel       VARCHAR(20) DEFAULT 'whatsapp',
    communication_log       JSONB DEFAULT '[]',     -- Array of communication attempts
    
    -- Audit
    created_at              TIMESTAMPTZ DEFAULT NOW(),
    updated_at              TIMESTAMPTZ DEFAULT NOW(),
    completed_at            TIMESTAMPTZ,
    cancelled_at            TIMESTAMPTZ,
    cancellation_reason     TEXT,
    cancelled_by            UUID,
    
    CONSTRAINT valid_status CHECK (status IN (
        'scheduled', 'reminder_sent', 'reminder_delivered', 'reminder_read',
        'in_progress', 'completed', 'missed', 'no_show', 'cancelled', 'rescheduled'
    )),
    CONSTRAINT valid_outcome CHECK (outcome IN (
        'successful', 'needs_revisit', 'resolved', 'escalated'
    ))
);

-- Follow-up templates (doctor-defined)
CREATE TABLE follow_up_templates (
    template_id             UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    department_id           UUID REFERENCES departments(department_id),
    speciality              VARCHAR(100),
    name                    VARCHAR(200),
    description             TEXT,
    
    -- Trigger conditions
    trigger_type            VARCHAR(30),            -- diagnosis_code, procedure, medication, visit_type
    trigger_value           VARCHAR(100),           -- ICD code, procedure name, etc.
    
    -- Follow-up schedule
    delay_unit              VARCHAR(10),
    delay_value             INTEGER,
    total_occurrences       INTEGER,                -- How many follow-ups (1 = single)
    interval_between        INTEGER,                -- Days between recurring follow-ups
    
    -- Actions
    requires_appointment    BOOLEAN DEFAULT TRUE,
    requires_test           BOOLEAN DEFAULT FALSE,
    test_type               VARCHAR(100),
    
    -- Messaging
    patient_message_template TEXT,
    staff_notes             TEXT,
    is_active               BOOLEAN DEFAULT TRUE,
    created_at              TIMESTAMPTZ DEFAULT NOW()
);

-- Follow-up outcomes log
CREATE TABLE follow_up_outcomes (
    outcome_id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    follow_up_id            UUID NOT NULL REFERENCES follow_ups(follow_up_id),
    outcome_type            VARCHAR(30) NOT NULL,
    -- patient_attended, patient_missed, rescheduled, cancelled,
    -- condition_improved, condition_stable, condition_worsened,
    -- medication_adherent, medication_non_adherent,
    -- test_result_normal, test_result_abnormal, test_result_pending
    
    recorded_by             UUID,                    -- staff_id or null (patient self-report)
    recorded_by_role        VARCHAR(30),
    recorded_at             TIMESTAMPTZ DEFAULT NOW(),
    details                 JSONB DEFAULT '{}',      -- Flexible outcome data
    
    -- For escalated cases
    escalation_level        INTEGER DEFAULT 0,       -- 0=none, 1=mild, 2=moderate, 3=critical
    escalated_to            UUID REFERENCES staff(staff_id),
    escalation_notes        TEXT
);
```

## 3. FOLLOW-UP WORKFLOW

### 3.1 Automatic Scheduling Flow
```
┌────────────────────────────────────────────────────────────────┐
│                    TRIGGER EVENT                               │
│  Doctor prescribes follow-up during consultation              │
│  OR                                                           │
│  System detects condition requiring follow-up (AI/rule)       │
└───────────────────────────┬────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│                  SCHEDULE FOLLOW-UP                            │
│  - Calculate optimal date based on recommendation             │
│  - Check doctor availability                                  │
│  - Create follow_up record with status='scheduled'            │
│  - Send initial notification to patient                       │
└───────────────────────────┬────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│              REMINDER CHAIN (Multi-Touch)                      │
│  T-7 days:  WhatsApp "You have a follow-up scheduled"         │
│  T-3 days:  WhatsApp "Your follow-up is coming up"            │
│  T-1 day:   WhatsApp + SMS "Tomorrow is your follow-up"       │
│  T-2 hours: WhatsApp "Your follow-up is in 2 hours"           │
│  T-15 min:  WhatsApp "Time for your follow-up"                │
└───────────────────────────┬────────────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────────────┐
│                    PATIENT ACTION                              │
│                            │                                   │
│              ┌─────────────┼─────────────┐                     │
│              ▼             ▼             ▼                     │
│         Attends        Reschedules    No Response              │
│              │             │             │                     │
│              ▼             ▼             ▼                     │
│      Record Outcome  Update Schedule  Escalate                │
│      Schedule Next   Send Conf.      - 1h: WhatsApp           │
│      (if recurring)                   - 2h: SMS               │
│                                        - 4h: Voice Call       │
│                                        - 24h: Mark "Missed"   │
└────────────────────────────────────────────────────────────────┘
```

### 3.2 Follow-up Types and Their Flows
```python
FOLLOW_UP_TYPES = {
    "post_visit_checkup": {
        "description": "General post-visit well-being check",
        "delay": "24-48 hours",
        "channels": ["whatsapp"],
        "questions": [
            "How are you feeling after the visit?",
            "Any new symptoms?",
            "Are you taking prescribed medication?"
        ],
        "escalation": "If patient reports issues -> Schedule revisit"
    },
    
    "scheduled_followup": {
        "description": "Doctor-recommended follow-up appointment",
        "delay": "Per doctor recommendation",
        "channels": ["whatsapp", "sms", "voice"],
        "requires_appointment": True,
        "reminder_chain": [-7, -3, -1, -2/24, -15/60],  # In days
        "escalation": "No-show -> Reschedule offer -> Voice call"
    },
    
    "test_result_review": {
        "description": "Follow-up after test results are ready",
        "delay": "48-72 hours after test",
        "channels": ["whatsapp"],
        "actions": [
            "Notify patient results are ready",
            "Offer tele-consultation for result review",
            "Schedule in-person if needed"
        ],
        "escalation": "Abnormal results -> Priority appointment"
    },
    
    "medication_adherence": {
        "description": "Check medication compliance",
        "delay": "Daily or weekly",
        "channels": ["whatsapp"],
        "frequency": "Daily (first 7 days), weekly (next 3 weeks)",
        "questions": [
            "Did you take your medicine today?",
            "Any side effects?",
            "Need prescription refill?"
        ],
        "escalation": "Non-adherence 3x -> Voice call -> Doctor alert"
    },
    
    "recovery_check": {
        "description": "Post-procedure/surgery recovery monitoring",
        "delay": "Custom per procedure",
        "channels": ["whatsapp", "voice"],
        "duration": "Varies (typically 2-4 weeks)",
        "questions": [
            "Rate your pain level (1-10)",
            "Any fever?",
            "Wound condition (photo upload)"
        ],
        "escalation": "Pain > 7 or fever -> Immediate doctor notification"
    },
    
    "chronic_management": {
        "description": "Ongoing management of chronic conditions",
        "delay": "Monthly/quarterly",
        "channels": ["whatsapp", "voice"],
        "duration": "Ongoing (indefinite)",
        "questions": [
            "Blood sugar reading today?",
            "Blood pressure reading?",
            "Any symptoms this week?"
        ],
        "escalation": "Out-of-range readings -> Doctor scheduled review"
    }
}
```

## 4. REMINDER ENGINE

```python
class FollowUpReminderEngine:
    """
    Manages the multi-touch reminder chain for each follow-up.
    Uses the Communication Engine to send messages across channels.
    """
    
    def __init__(self):
        self.reminder_configs = {
            'default': {
                'chain': [
                    {'timing': -7, 'unit': 'days', 'channel': 'whatsapp', 'template': 'followup_7d'},
                    {'timing': -3, 'unit': 'days', 'channel': 'whatsapp', 'template': 'followup_3d'},
                    {'timing': -1, 'unit': 'days', 'channel': 'whatsapp+sms', 'template': 'followup_1d'},
                    {'timing': -2, 'unit': 'hours', 'channel': 'whatsapp', 'template': 'followup_2h'},
                    {'timing': 15, 'unit': 'minutes', 'channel': 'push', 'template': 'followup_15m'}
                ],
                'no_response': [
                    {'delay': 1, 'unit': 'hours', 'channel': 'whatsapp', 'template': 'missed_1h'},
                    {'delay': 3, 'unit': 'hours', 'channel': 'sms', 'template': 'missed_3h'},
                    {'delay': 6, 'unit': 'hours', 'channel': 'voice', 'template': 'missed_6h'},
                    {'delay': 24, 'unit': 'hours', 'action': 'mark_missed'}
                ]
            },
            'critical': {
                'chain': [
                    {'timing': -3, 'unit': 'days', 'channel': 'whatsapp+sms', 'template': 'critical_3d'},
                    {'timing': -1, 'unit': 'days', 'channel': 'whatsapp+sms+voice', 'template': 'critical_1d'},
                    {'timing': -4, 'unit': 'hours', 'channel': 'whatsapp', 'template': 'critical_4h'},
                    {'timing': -1, 'unit': 'hours', 'channel': 'push+whatsapp', 'template': 'critical_1h'}
                ],
                'no_response': [
                    {'delay': 30, 'unit': 'minutes', 'channel': 'whatsapp', 'template': 'crit_missed_30m'},
                    {'delay': 1, 'unit': 'hours', 'channel': 'voice', 'template': 'crit_missed_1h'},
                    {'delay': 2, 'unit': 'hours', 'action': 'escalate_to_doctor'}
                ]
            }
        }
    
    async def process_follow_up(self, follow_up_id):
        """Main processing loop for a single follow-up."""
        follow_up = await FollowUp.get(follow_up_id)
        
        if follow_up.status in ['completed', 'cancelled', 'missed']:
            return
        
        config = self.reminder_configs.get(
            'critical' if follow_up.is_critical else 'default'
        )
        
        now = utcnow()
        scheduled = follow_up.scheduled_datetime
        
        for reminder in config['chain']:
            reminder_time = scheduled + timedelta(**{reminder['unit']: reminder['timing']})
            
            if now >= reminder_time and not self._already_sent(follow_up, reminder):
                await self._send_reminder(follow_up, reminder)
        
        # Handle no-response
        if follow_up.status == 'reminder_sent' and not follow_up.patient_responded:
            last_reminder = follow_up.last_reminder_at
            if last_reminder:
                for action in config['no_response']:
                    action_time = last_reminder + timedelta(**{action['unit']: action['delay']})
                    if now >= action_time and not self._already_taken(follow_up, action):
                        await self._take_no_response_action(follow_up, action)
    
    async def _send_reminder(self, follow_up, reminder_config):
        """Send reminder via specified channel."""
        template = await self._get_template(reminder_config['template'], follow_up)
        channels = reminder_config['channel'].split('+')
        
        for channel in channels:
            await communication_engine.send(
                channel=channel,
                recipient=follow_up.patient.phone,
                template=template,
                data=self._get_template_data(follow_up)
            )
        
        await follow_up.update(
            last_reminder_sent_at=utcnow(),
            reminder_count=follow_up.reminder_count + 1,
            communication_log=follow_up.communication_log + [{
                'type': 'reminder',
                'config': reminder_config,
                'sent_at': utcnow().isoformat()
            }]
        )
```

## 5. NO-SHOW HANDLING

```python
class NoShowHandler:
    """
    Handles patients who miss their follow-up appointments.
    Implements graduated response based on severity and history.
    """
    
    def handle_no_show(self, follow_up):
        """Process a no-show event."""
        no_show_count = self._get_no_show_history(follow_up.patient_id)
        
        if no_show_count == 0:
            self._first_no_show(follow_up)
        elif no_show_count <= 2:
            self._repeat_no_show(follow_up, no_show_count)
        else:
            self._chronic_no_show(follow_up)
    
    def _first_no_show(self, follow_up):
        """Lenient: offer reschedule."""
        communication_engine.send_whatsapp(
            follow_up.patient.phone,
            template='no_show_first',
            data={
                'patient_name': follow_up.patient.name,
                'doctor_name': follow_up.recommended_by.name,
                'reschedule_link': f'https://gil.app/reschedule/{follow_up.id}'
            }
        )
        follow_up.status = 'missed'
    
    def _repeat_no_show(self, follow_up, count):
        """Moderate: require active confirmation."""
        communication_engine.send_whatsapp(follow_up.patient.phone,
            template='no_show_repeat',
            data={'count': count})
        communication_engine.send_sms(follow_up.patient.phone,
            template='no_show_repeat_sms')
        
        # Flag for staff review
        add_staff_task(
            type='review_no_show',
            patient_id=follow_up.patient_id,
            follow_up_id=follow_up.id,
            priority='medium'
        )
    
    def _chronic_no_show(self, follow_up):
        """Strict: require prepayment, alert doctor."""
        communication_engine.send_whatsapp(follow_up.patient.phone,
            template='no_show_chronic',
            data={'deposit_required': True})
        
        follow_up.requires_prepayment = True
        
        notify_doctor(
            doctor_id=follow_up.recommended_by,
            message=f"Patient {follow_up.patient.name} has {self._get_no_show_history(follow_up.patient_id)} no-shows"
        )
```

## 6. OUTCOME TRACKING

### 6.1 Structured Outcome Collection
```python
# Outcome collection based on follow-up type
OUTCOME_QUESTIONS = {
    "post_visit_checkup": [
        {"question": "How are you feeling?", "type": "rating", "range": [1, 5]},
        {"question": "Any new symptoms?", "type": "multi_select", 
         "options": ["Fever", "Pain", "Fatigue", "Dizziness", "None"]},
        {"question": "Taking medication as prescribed?", "type": "boolean"},
        {"question": "Additional notes", "type": "text", "optional": True}
    ],
    "medication_adherence": [
        {"question": "Did you take today's medication?", "type": "boolean"},
        {"question": "Any side effects?", "type": "multi_select",
         "options": ["Nausea", "Headache", "Drowsiness", "None", "Other"]},
        {"question": "Remaining pills count", "type": "number"}
    ],
    "recovery_check": [
        {"question": "Pain level (1-10)", "type": "rating", "range": [1, 10]},
        {"question": "Temperature (if applicable)", "type": "number", "unit": "F"},
        {"question": "Upload wound photo", "type": "image", "optional": True},
        {"question": "Any concerns?", "type": "text", "optional": True}
    ]
}
```

### 6.2 Outcome Analytics
```sql
-- Follow-up success rate by type
SELECT 
    follow_up_type,
    COUNT(*) as total,
    SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) as completed,
    ROUND(100.0 * SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) / COUNT(*), 1) as completion_rate,
    SUM(CASE WHEN status = 'missed' THEN 1 ELSE 0 END) as missed,
    SUM(CASE WHEN status = 'no_show' THEN 1 ELSE 0 END) as no_show,
    AVG(reminder_count) as avg_reminders_sent
FROM follow_ups
WHERE created_at >= NOW() - INTERVAL '30 days'
GROUP BY follow_up_type;

-- Escalation tracking
SELECT 
    fu.follow_up_type,
    COUNT(fo.outcome_id) as total_escalations,
    AVG(fo.escalation_level) as avg_escalation_level,
    COUNT(CASE WHEN fo.outcome_type = 'condition_worsened' THEN 1 END) as worsened_count
FROM follow_up_outcomes fo
JOIN follow_ups fu ON fo.follow_up_id = fu.follow_up_id
WHERE fo.escalation_level > 0
GROUP BY fu.follow_up_type;
```

## 7. CONFIGURATION

```yaml
# Follow-up module configuration
follow_up_config:
  defaults:
    reminder_chain: [-7, -3, -1, -2/24, -15/60]  # In days
    no_response_timeout: "24h"
    max_reminders: 5
    preferred_channel: "whatsapp"
    fallback_channel: "sms"
  
  scheduling:
    auto_schedule: true
    min_notice_hours: 24      # Minimum hours before scheduling
    slot_preference: "morning"  # morning, afternoon, evening
    avoid_weekends: false
    buffer_between_slots: 5    # minutes
  
  escalation:
    auto_escalate_after_missed: 2
    notify_doctor_on_escalation: true
    notify_admin_on_critical: true
    max_daily_reminders: 3
  
  analytics:
    track_outcomes: true
    auto_generate_reports: true
    report_frequency: "weekly"
    report_recipients: ["admin", "doctors"]
```

## 8. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| Multi-touch reminder chain | Single reminder often missed; graduated approach improves attendance |
| Channel escalation (WhatsApp -> SMS -> Voice) | Each step more intrusive; starts least invasive |
| Type-specific outcome collection | Structured data for analytics vs generic free text |
| Graduated no-show response | Fair to first-time offenders, strict with repeat offenders |
| Template-driven follow-up rules | Doctors can define patterns without development |
| Recurring follow-up support | Essential for chronic disease management |
| Follow-up templates per specialty | Different departments have different follow-up needs |
| Escalation with severity levels | Critical cases get immediate attention, not batch processing |
