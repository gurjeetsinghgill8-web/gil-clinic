---
file_id: "0602"
module_name: "Patient Tracking"
version: "2.0"
status: "Draft"
phase: "Phase 6 — Patient Experience"
dependencies: ["0100_QUEUE_ENGINE.md", "0601_PATIENT_TIMELINE.md"]
related_files: ["0600_PATIENT_APP.md", "0601_PATIENT_TIMELINE.md", "0101_WORKFLOW_ENGINE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "tracking", "live", "realtime", "location", "gps", "beacon"]
---

# GHOS - Real-Time Patient Tracking

## 1. PURPOSE
Real-time tracking of a patient's current location and status within the hospital. Tracks department transitions, time spent per department, queue position, and generates delay alerts. Accessible without app installation via QR code and WhatsApp link.

## 2. TRACKING INFRASTRUCTURE

```
[BLE Beacons]    [QR Codes]     [Staff Scanner]
      │               │               │
      ▼               ▼               ▼
[Edge Gateway] ──> [Location Service] ──> [Queue Engine]
                                                │
                                                ▼
                                        [WebSocket Server]
                                                │
                                    ┌───────────┼───────────┐
                                    ▼           ▼           ▼
                              [Patient Web]  [Dashboard]  [Staff App]
```

### 2.1 Location Detection Methods
| Method | Accuracy | Battery Impact | Infrastructure | Use Case |
|--------|----------|----------------|----------------|----------|
| BLE Beacon | 1-3m | Low | Beacons per room | Precise indoor tracking |
| QR Scan | Exact point | None | Printed QR at stations | Check-in/check-out |
| Staff Scan | Exact point | None | Staff handheld | Manual routing update |
| WiFi RSSI | 5-10m | Low | Existing AP | Coarse location |
| GPS (outside) | 3-5m | High | None | Arrival detection |
| Manual Entry | N/A | None | None | Fallback for errors |

### 2.2 Hardware Requirements
```yaml
beacon_specification:
  protocol: "BLE 5.0 (iBeacon + Eddystone)"
  battery_life: "2-3 years (CR2477)"
  range: "1-10m configurable"
  placement:
    - "Every consultation room door"
    - "Every department entrance"
    - "Waiting area zones (1 per 100 sq ft)"
    - "Key corridor junctions"
    - "Pharmacy counter"
    - "Billing counter"
    - "Lab sample collection"
    - "Exit points"
  density: "~20 beacons per 1000 sq ft clinic"
```

## 3. TRACKING DATA MODEL

```sql
-- Current location snapshot (single active record per patient)
CREATE TABLE patient_current_location (
    patient_id          UUID PRIMARY KEY,
    visit_id            UUID NOT NULL REFERENCES visits(visit_id),
    current_department  UUID REFERENCES departments(department_id),
    current_zone        VARCHAR(50),             -- room, waiting_area, corridor, billing, pharmacy
    current_room        VARCHAR(50),
    entered_at          TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    last_heartbeat      TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    estimated_wait_min  INTEGER,
    status              VARCHAR(30) NOT NULL DEFAULT 'in_progress',
    source_method       VARCHAR(20),             -- beacon, qr, staff_scan, wifi, manual
    accuracy_meters     DECIMAL(5,2)
);

-- Department transition log
CREATE TABLE patient_dept_transitions (
    transition_id       UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id          UUID NOT NULL REFERENCES patients(patient_id),
    visit_id            UUID NOT NULL REFERENCES visits(visit_id),
    from_department     UUID REFERENCES departments(department_id),
    to_department       UUID REFERENCES departments(department_id),
    from_location       VARCHAR(100),
    to_location         VARCHAR(100),
    entered_at          TIMESTAMPTZ NOT NULL,
    exited_at           TIMESTAMPTZ,
    duration_seconds    INTEGER GENERATED ALWAYS AS (
        CASE WHEN exited_at IS NOT NULL 
             THEN EXTRACT(EPOCH FROM (exited_at - entered_at)) 
             ELSE NULL END
    ) STORED,
    route_reason        VARCHAR(50),             -- auto_routed, staff_directed, patient_moved
    transition_type     VARCHAR(20)              -- normal, bypass, revisit, wrong_dept
);

-- Time audit per department
CREATE VIEW dept_time_summary AS
SELECT 
    patient_id,
    visit_id,
    to_department AS department_id,
    COUNT(*) AS visit_count,
    SUM(duration_seconds) AS total_seconds,
    AVG(duration_seconds) AS avg_seconds,
    MAX(duration_seconds) AS max_seconds,
    MIN(duration_seconds) AS min_seconds
FROM patient_dept_transitions
WHERE duration_seconds IS NOT NULL
GROUP BY patient_id, visit_id, to_department;
```

## 4. ACCESS METHODS

### 4.1 QR Code (Primary)
```
┌─────────────────────────────────────┐
│  ┌──────────────────────────────┐   │
│  │        ░▒▓█ QR █▓▒░          │   │
│  │   Track your visit           │   │
│  │   Scan with phone camera     │   │
│  │                              │   │
│  │   Token: DOC-042             │   │
│  │   https://gil.app/t/abc123   │   │
│  └──────────────────────────────┘   │
│                                     │
│  Print: 80mm x 50mm thermal paper  │
│  Issued: At reception on check-in  │
└─────────────────────────────────────┘

Flow:
1. Reception prints QR slip at check-in
2. Patient scans with native camera (no app needed)
3. Tracking page opens in browser
4. Page auto-updates via WebSocket
5. Slip also has token number printed below QR
```

### 4.2 WhatsApp Link (Secondary)
```
Registration -> Auto-send WhatsApp message:
"Hi {patient_name}! 👋
Your visit is being tracked. Tap below to follow your progress:
🔗 Track My Visit: https://gil.app/t/{token}
Token: {token_number}
Estimated wait: {wait_time} minutes"

WhatsApp Flow:
1. Patient receives message post-registration
2. Taps link -> opens tracking in WhatsApp in-app browser
3. Same WebSocket real-time updates
4. Call alerts also sent via WhatsApp
```

### 4.3 Mobile Entry (Fallback)
```
Clinic website / PWA -> Enter phone number
-> OTP sent via SMS
-> Enter OTP
-> Select active visit (if multiple)
-> Tracking page loads
```

## 5. TRACKING PAGE COMPONENTS

```
┌──────────────────────────────────────────────┐
│  🏥 GIL Clinic - Live Tracking              │
├──────────────────────────────────────────────┤
│                                              │
│  ┌─ Status Card ──────────────────────────┐  │
│  │  🔵 Currently in: Consultation Room 3  │  │
│  │  ⏳ Waiting since: 5 min               │  │
│  │  Token: DOC-042                        │  │
│  │  Patients ahead: 2                     │  │
│  │  Est. wait: ~12 minutes                │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  ┌─ Journey Timeline ─────────────────────┐  │
│  │  09:15 ✅ Registration                 │  │
│  │  09:18 ✅ Waiting Area                 │  │
│  │  09:30 🔵 Doctor - Room 3 (You Here)   │  │
│  │  09:45 ⏳ ECG - Lab 2F                 │  │
│  │  10:00 ⬜ Pharmacy                      │  │
│  │  10:15 ⬜ Billing                       │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  ┌─ Alerts ──────────────────────────────┐  │
│  │  ⚠️ Doctor running 10 min behind      │  │
│  │  📱 You will be alerted when called    │  │
│  └────────────────────────────────────────┘  │
│                                              │
│  [🔔 Call Alert] [📞 Call Clinic] [🗺️ Map]  │
└──────────────────────────────────────────────┘
```

## 6. REAL-TIME UPDATE SYSTEM

### 6.1 WebSocket Protocol
```python
# WebSocket event types sent to tracking clients
TRACKING_EVENTS = {
    "queue.position_changed": {
        "description": "Patient moved up/down in queue",
        "payload": {
            "new_position": 3,
            "patients_ahead": 2,
            "estimated_wait_min": 12,
            "previous_wait_min": 15
        }
    },
    "queue.department_changed": {
        "description": "Patient routed to different department",
        "payload": {
            "from_department": "Waiting Area",
            "to_department": "Consultation Room 3",
            "reason": "Doctor called",
            "auto_navigate": True  # Scroll timeline to new position
        }
    },
    "queue.call_alert": {
        "description": "Patient is being called",
        "payload": {
            "department": "Doctor",
            "room": "Room 3",
            "message": "Please proceed to Consultation Room 3",
            "sound": "alert_tone_1.mp3",
            "vibration_pattern": [200, 100, 200, 100, 500]
        }
    },
    "queue.delay_alert": {
        "description": "Service delay detected",
        "payload": {
            "department": "Doctor",
            "expected_delay_min": 10,
            "reason": "Previous consultation taking longer",
            "new_estimated_time": "09:45"
        }
    },
    "queue.completed": {
        "description": "Visit completed",
        "payload": {
            "total_time_min": 45,
            "feedback_prompt": True,
            "thank_you_message": "Thank you for visiting!"
        }
    }
}
```

### 6.2 Heartbeat Mechanism
```python
# Client-side heartbeat to track page activity
heartbeat_config = {
    "interval_ms": 10000,           # Send every 10 seconds
    "timeout_ms": 30000,            # Mark inactive after 30s no heartbeat
    "max_missed": 6,                # Auto-close after 60s missed (6 * 10)
    "on_timeout": "send_sms_link",  # Send SMS with tracking link if tab closed
}
```

## 7. LOCATION TRANSITION ENGINE

### 7.1 Transition Detection Logic
```python
class TransitionEngine:
    """
    Detects when a patient moves between departments/zones.
    Uses multiple signals to determine transitions.
    """
    
    def detect_transition(self, patient_id, signal):
        current = get_current_location(patient_id)
        
        # BLE Beacon signal
        if signal.type == 'beacon':
            new_zone = beacon_to_zone(signal.beacon_id)
            if new_zone != current.current_zone:
                return self._create_transition(patient_id, current.current_zone, new_zone)
        
        # QR scan at station
        elif signal.type == 'qr_scan':
            station = resolve_qr_station(signal.qr_data)
            return self._create_transition(patient_id, current.current_zone, station.zone)
        
        # Staff routed
        elif signal.type == 'staff_route':
            return self._create_transition(
                patient_id, 
                current.current_zone, 
                signal.target_department,
                reason='staff_directed'
            )
    
    def _create_transition(self, patient_id, from_zone, to_zone, reason='auto'):
        # Close previous transition
        self._close_active_transition(patient_id)
        
        # Create new transition
        transition = {
            'patient_id': patient_id,
            'from_department': from_zone,
            'to_department': to_zone,
            'entered_at': utcnow(),
            'route_reason': reason
        }
        
        # Update current location
        update_current_location(patient_id, {
            'current_zone': to_zone,
            'entered_at': utcnow()
        })
        
        # Publish event
        publish_event('queue.department_changed', transition)
        
        return transition
```

### 7.2 Department Transition Rules
| Rule | Description | Implementation |
|------|-------------|----------------|
| Sequential | Standard flow: Reception -> Doctor -> Lab -> Pharmacy -> Billing | Enforced by workflow engine, overridable |
| Skip | Patient can skip a department (e.g., no tests needed) | Marked as 'skipped' in transition log |
| Revisit | Patient returns to previous department | Allowed with 'revisit' flag, triggers alert |
| Wrong Dept | Patient goes to incorrect department | Staff alert generated, redirect suggested |
| Express | Emergency cases skip queue | Priority flag on patient record |
| Bypass | VIP/special cases skip to front | Configurable per clinic settings |

## 8. DELAY DETECTION AND ALERTS

### 8.1 Delay Thresholds
```yaml
delay_thresholds:
  registration:
    warning: "5 min"
    critical: "10 min"
  
  waiting_area:
    warning: "15 min"
    critical: "30 min"
  
  doctor_consultation:
    warning: "10 min (beyond avg)"
    critical: "20 min (beyond avg)"
  
  lab_tests:
    warning: "15 min"
    critical: "25 min"
  
  pharmacy:
    warning: "10 min"
    critical: "20 min"
  
  billing:
    warning: "10 min"
    critical: "15 min"
```

### 8.2 Alert Channels
| Alert Type | Patient | Staff Dashboard | Admin Report |
|------------|---------|----------------|--------------|
| Warning Delay | Notification in tracking | Yellow indicator | Logged in analytics |
| Critical Delay | Push + WhatsApp alert | Red indicator + sound | High-priority alert |
| Wait Time Update | Live in tracking | Dashboard update | Trend analysis |
| Doctor Behind Schedule | Banner on tracking page | Dashboard alert | Supervisor notified |
| Resource Bottleneck | N/A | Dashboard alert | Admin escalation |

### 8.3 Delay Escalation Matrix
```python
class DelayEscalation:
    LEVELS = {
        1: {  # Warning
            'threshold_min': 5,
            'action': 'notify_patient_tracking',
            'escalate_to': None
        },
        2: {  # Moderate
            'threshold_min': 10,
            'action': 'send_whatsapp_alert',
            'escalate_to': 'department_head'
        },
        3: {  # Critical
            'threshold_min': 20,
            'action': 'send_voice_call',
            'escalate_to': 'operations_manager'
        },
        4: {  # Emergency
            'threshold_min': 30,
            'action': 'alert_admin',
            'escalate_to': 'hospital_admin'
        }
    }
```

## 9. ANALYTICS AND REPORTING

```sql
-- Average time spent per department (last 30 days)
SELECT 
    d.department_name,
    AVG(dt.duration_seconds) as avg_seconds,
    PERCENTILE_CONT(0.5) WITHIN GROUP (ORDER BY dt.duration_seconds) as median_seconds,
    COUNT(*) as total_visits,
    SUM(CASE WHEN dt.duration_seconds > (SELECT threshold FROM delay_thresholds WHERE dept_id = dt.to_department) 
        THEN 1 ELSE 0 END) as delay_count
FROM patient_dept_transitions dt
JOIN departments d ON dt.to_department = d.department_id
WHERE dt.entered_at >= NOW() - INTERVAL '30 days'
GROUP BY d.department_name;

-- Bottleneck detection query
SELECT 
    d.department_name,
    AVG(EXTRACT(EPOCH FROM (exited_at - entered_at))) as avg_time,
    COUNT(*) as patient_count,
    COUNT(*) FILTER (WHERE transition_type = 'revisit') as revisit_count,
    COUNT(*) FILTER (WHERE route_reason = 'wrong_dept') as wrong_dept_count
FROM patient_dept_transitions dt
JOIN departments d ON dt.to_department = d.department_id
WHERE dt.entered_at >= NOW() - INTERVAL '7 days'
GROUP BY d.department_name
ORDER BY avg_time DESC;
```

## 10. KEY DESIGN DECISIONS
| Decision | Rationale |
|----------|-----------|
| No app install required for tracking | Removes friction, higher adoption |
| BLE beacons over GPS for indoor | Better accuracy, lower battery, no permission issues |
| QR code as primary access method | Universally supported, no NFC dependency |
| WebSocket over polling | Real-time updates, lower bandwidth, server push |
| Heartbeat mechanism | Detects when patient leaves tracking page |
| Multiple location methods with fallback | Resilient to hardware failures |
| Separate transition log table | Audit trail, analytics, bottleneck identification |
| Delay escalation matrix | Proactive issue resolution before patient complains |
