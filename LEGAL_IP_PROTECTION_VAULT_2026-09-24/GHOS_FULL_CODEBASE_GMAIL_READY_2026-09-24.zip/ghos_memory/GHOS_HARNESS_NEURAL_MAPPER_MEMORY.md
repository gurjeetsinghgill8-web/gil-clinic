# 🧠 GIL CLINIC HMS — Graphified Neural Architect & Harness Memory File

> **Version**: v3.2 (Phase 2 Master Repair Edition)  
> **Updated**: August 2026  
> **Protocol**: Graphify Protocol + Lego-Block System Architecture + Harness Engineering  

---

## 🎯 Role: The Neural Architect & Harness Orchestrator

This memory file encapsulates the core engineering rules, system interrelations, competitor analysis, and Lego-block implementation strategy for **GIL Clinic HMS (CardioQueue & Smart OPD)**.

---

## 🧱 Phase 2 Master Lego-Block Roadmap

| Block # | Name | Scope & Responsibilities | Status |
| :--- | :--- | :--- | :--- |
| **Brick 1** | **Universal WhatsApp Sanitizer** | Phone number cleaning (+91 auto-prefix), sanitized `wa.me` links. | ✅ **DONE** |
| **Brick 2** | **Reception Action Center** | Instant WhatsApp token generator & queue status alerts. | ✅ **DONE** |
| **Brick 3** | **Inter-Department Event Bus** | Real-time queue state synchronization across ECG, Echo, TMT, OPD, Dietitian, Reception. | ✅ **DONE** |
| **Brick 4** | **Photo-to-EMR Vision OCR** | Groq Llama-Vision snap-to-digital prescription conversion. | ✅ **DONE** |
| **Brick 5** | **EkaScribe Ambient Voice EMR** | Groq Whisper speech-to-text dictation. | ✅ **DONE** |
| **Brick 6** | **Patient PWA Live Tracker** | Zero-login patient web status portal & WhatsApp desk bridge. | ✅ **DONE** |
| **Brick A** | **Patient Search & Recall Engine** | Multi-field search by Name, Phone, Disease/Diagnosis, and Token ID (`/opd/api/search`). | ⏳ **IN PLAN** |
| **Brick B** | **Doctor OPD Live Queue Sync** | `loadQueuePatients()` implementation for live Reception -> OPD queue sidebar. | ⏳ **IN PLAN** |
| **Brick C** | **Diagnostic Prominent Controls** | Front-and-center 📢 WhatsApp Call Patient & 🔄 Recall Patient buttons in ECG/Echo/TMT. | ⏳ **IN PLAN** |
| **Brick D** | **Multi-Report Batch Scan AI** | Batch OCR for handwritten prescriptions + pathology reports from reference repos. | ⏳ **IN PLAN** |

---

## 📜 Master Behavioral Rules

1. **Think-Before-Act**: Always break complex problems into Lego-blocks before touching code.
2. **Graphify Neural Protocol**: Every update must specify its upstream dependencies and downstream effects.
3. **No Brittle Patches**: Fix root causes (e.g., missing API routes or JS functions) rather than masking symptoms.
