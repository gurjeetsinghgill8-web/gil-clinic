---
file_id: "0309"
module_name: "Pharmacy Department Module"
version: "1.0"
status: "Draft"
phase: "Phase 3 - Clinical Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0401_INVENTORY.md"]
related_files: ["0207_PHARMACIST.md", "0406_INDENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "pharmacy", "dispensing", "medicines", "inventory", "batch", "expiry", "indent"]
---

# GHOS - Pharmacy Department Module

## 1. PURPOSE
The Pharmacy Department module manages the operational workflow of a hospital pharmacy/dispensary, distinct from the individual pharmacist user login. It handles prescription queue management from all ordering sources (OPD, IPD, emergency), medicine dispensing with inventory reservation, batch/lot tracking, expiry management, low-stock alerts, and the indent/requisition workflow for procuring stock from suppliers or central warehouse.

---

## 2. SYSTEM ARCHITECTURE

```
┌──────────────────────────────────────────────────────────────────────────────────┐
│                        PHARMACY DEPARTMENT MODULE (0309)                          │
├──────────────────────────────────────────────────────────────────────────────────┤
│                                                                                   │
│  ┌────────────────┐     ┌───────────────────┐     ┌────────────────────────┐     │
│  │ Prescription    │────>│ Pending Queue      │────>│ Dispensing Workflow   │     │
│  │ Sources:        │     │ (Sort by urgency)  │     │ - Verify Prescription │     │
│  │ - OPD           │     │                   │     │ - Check Inventory     │     │
│  │ - IPD (HIS)     │     │ ┌───────────────┐ │     │ - Allocate Batch/Lot  │     │
│  │ - Emergency     │     │ │ Ready         │ │     │ - Generate Label      │     │
│  └────────────────┘     │ │ Collected      │ │     │ - Dispense to Patient │     │
│                          │ │ Hold / Query   │ │     └──────────┬─────────────┘     │
│                          │ └───────────────┘ │                │                    │
│                          └───────────────────┘                v                    │
│                                               ┌────────────────────────┐          │
│                          ┌────────────────┐   │ Inventory Integration  │          │
│                          │ Stock Alerts    │◄──│ - Reserved Stock      │          │
│                          │ - Low Stock     │   │ - Batch / Lot Track   │          │
│                          │ - Expiry Soon   │   │ - Expiry Tracking      │          │
│                          │ - Out of Stock  │   │ - Real-time Deduction  │          │
│                          └────────────────┘   └──────────┬─────────────┘          │
│                                                          │                        │
│                                                          v                        │
│                          ┌────────────────────────────────────────────┐          │
│                          │ Indent / Requisition Workflow              │          │
│                          │ - Create Indent (Pharmacy → Warehouse)     │          │
│                          │ - Approve / Reject                         │          │
│                          │ - Receive / Verify Goods                   │          │
│                          │ - Update Inventory                         │          │
│                          └────────────────────────────────────────────┘          │
│                                                                                   │
└──────────────────────────────────────────────────────────────────────────────────┘
```

---

## 3. PRESCRIPTION QUEUE MANAGEMENT

### 3.1 Queue Flow

```
                     Prescription Received
                              │
                              v
                    ┌─────────────────────┐
                    │  PENDING            │
                    │  (Awaiting Review)   │
                    └────────┬────────────┘
                             │
              ┌──────────────┼──────────────┐
              │              │              │
              v              v              v
      ┌───────────┐  ┌────────────┐  ┌───────────┐
      │ READY     │  │ HOLD       │  │ QUERY     │
      │ (In Stock)│  │ (Need More │  │ (Clarify  │
      │           │  │  Info)     │  │  with Dr) │
      └─────┬─────┘  └─────┬──────┘  └─────┬─────┘
            │              │               │
            v              │               │
      ┌───────────┐       │               │
      │ COLLECTED │<──────┘               │
      │ (Closed)  │<──────────────────────┘
      └───────────┘
```

### 3.2 Queue Display Configuration

```yaml
pharmacy_queue:
  pending:
    title: "Pending Prescriptions"
    sort_by: "urgency DESC, ordered_at ASC"
    filterable_by:
      - source (OPD/IPD/ER)
      - urgency (routine/urgent/stat)
      - pharmacist_assigned
    display_columns:
      - ticket_number
      - patient_name
      - prescribed_by
      - item_count
      - urgency_badge
      - ordered_at
      - actions [dispense, hold, query]

  ready:
    title: "Ready for Collection"
    sort_by: "prepared_at ASC"
    display_columns:
      - ticket_number
      - patient_name
      - item_count
      - total_cost
      - prepared_by
      - prepared_at
      - actions [mark_collected]

  collected:
    title: "Collected"
    sort_by: "collected_at DESC"
    display_columns:
      - ticket_number
      - patient_name
      - item_count
      - collected_by
      - collected_at
```

---

## 4. DISPENSING WORKFLOW

```
                    Dispensing Process
                    ┌──────────────────────────────────┐
                    │  1. Scan / Enter Prescription ID │
                    │  2. Verify Patient Identity       │
                    │     (Name, DOB, UHID)             │
                    │  3. Review Prescribed Items       │
                    │     - Drug name, dosage, route    │
                    │     - Quantity, duration          │
                    │     - Doctor's signature          │
                    ├──────────────────────────────────┤
                    │  4. Check Inventory               │
                    │     - Available stock             │
                    │     - Suitable batch/lot          │
                    │     - Expiry date validation      │
                    │                                  │
                    │     IF short stock:               │
                    │     - Show alternatives           │
                    │       (same generic, diff brand)  │
                    │     - Allow partial dispensing    │
                    │     - Back-order remainder        │
                    ├──────────────────────────────────┤
                    │  5. Select Batch/Lot              │
                    │     - Auto-suggest nearest expiry │
                    │     - Manual override allowed     │
                    ├──────────────────────────────────┤
                    │  6. Print / Generate Label        │
                    │     - Patient name, drug, dose    │
                    │     - Batch/Lot, Expiry           │
                    │     - Barcode for verification    │
                    ├──────────────────────────────────┤
                    │  7. Dispense & Reserve            │
                    │     - Deduct from inventory       │
                    │     - Set status -> READY         │
                    │     - Notify patient              │
                    ├──────────────────────────────────┤
                    │  8. Collect (Handover)            │
                    │     - Patient signs               │
                    │     - Status -> COLLECTED         │
                    │     - Audit log entry             │
                    └──────────────────────────────────┘
```

---

## 5. DATA MODEL

### 5.1 SQL Schema

```sql
-- ============================================================================
-- Prescription (Incoming from Doctor Module / OPD / IPD)
-- ============================================================================
CREATE TABLE pharmacy_prescriptions (
    prescription_id     BIGINT PRIMARY KEY AUTO_INCREMENT,
    ticket_number       VARCHAR(20) NOT NULL UNIQUE,       -- e.g. PH-20260709-0001
    patient_id          BIGINT NOT NULL REFERENCES patients(patient_id),
    doctor_id           BIGINT NOT NULL REFERENCES users(user_id),
    source              ENUM('OPD','IPD','ER') NOT NULL,
    urgency             ENUM('routine','urgent','stat') NOT NULL DEFAULT 'routine',
    status              ENUM('pending','hold','query','ready','collected','cancelled','partial')
                            NOT NULL DEFAULT 'pending',
    total_items         INT NOT NULL DEFAULT 0,
    total_cost          DECIMAL(12,2) DEFAULT 0.00,
    assigned_pharmacist BIGINT NULL REFERENCES users(user_id),
    clinical_notes      TEXT,
    ordered_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    prepared_at         TIMESTAMP NULL,
    collected_at        TIMESTAMP NULL,
    collected_by        BIGINT NULL REFERENCES users(user_id),
    cancelled_at        TIMESTAMP NULL,
    cancel_reason       TEXT,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_patient (patient_id),
    INDEX idx_source (source),
    INDEX idx_ticket (ticket_number)
);

-- ============================================================================
-- Prescription Line Items
-- ============================================================================
CREATE TABLE pharmacy_prescription_items (
    item_id             BIGINT PRIMARY KEY AUTO_INCREMENT,
    prescription_id     BIGINT NOT NULL REFERENCES pharmacy_prescriptions(prescription_id),
    medicine_id         BIGINT NOT NULL REFERENCES medicines(medicine_id),
    medicine_name       VARCHAR(200) NOT NULL,              -- denormalized for display
    dosage              VARCHAR(100) NOT NULL,               -- e.g. "500mg"
    form                VARCHAR(50),                         -- tablet, capsule, injection, syrup
    route               VARCHAR(50),                         -- oral, IV, IM, topical
    frequency           VARCHAR(100),                        -- "twice daily", "8 hourly"
    duration_days       INT,
    quantity_prescribed DECIMAL(10,2) NOT NULL,
    quantity_dispensed  DECIMAL(10,2) DEFAULT 0.00,
    unit                VARCHAR(20) DEFAULT 'tab',           -- tab, ml, vial, puff
    instructions        TEXT,                                -- special instructions
    is_controlled       BOOLEAN DEFAULT FALSE,               -- narcotic / controlled substance
    status              ENUM('pending','dispensed','partial','cancelled') NOT NULL DEFAULT 'pending',
    sort_order          INT DEFAULT 0,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_prescription (prescription_id),
    INDEX idx_medicine (medicine_id)
);

-- ============================================================================
-- Dispensing Records (per item, per batch)
-- ============================================================================
CREATE TABLE pharmacy_dispensing (
    dispensing_id       BIGINT PRIMARY KEY AUTO_INCREMENT,
    prescription_id     BIGINT NOT NULL REFERENCES pharmacy_prescriptions(prescription_id),
    item_id             BIGINT NOT NULL REFERENCES pharmacy_prescription_items(item_id),
    inventory_id        BIGINT NOT NULL REFERENCES inventory_batches(inventory_id),
    batch_number        VARCHAR(100) NOT NULL,
    quantity_dispensed  DECIMAL(10,2) NOT NULL,
    unit                VARCHAR(20) NOT NULL,
    expiry_date         DATE NOT NULL,
    mrp_per_unit        DECIMAL(10,2),
    cost_per_unit       DECIMAL(10,2),
    label_printed       BOOLEAN DEFAULT FALSE,
    dispensed_by        BIGINT NOT NULL REFERENCES users(user_id),
    dispensed_at        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_prescription (prescription_id),
    INDEX idx_inventory (inventory_id),
    INDEX idx_batch (batch_number)
);

-- ============================================================================
-- Inventory Batches (Critical for Expiry & Lot Tracking)
-- ============================================================================
CREATE TABLE inventory_batches (
    inventory_id        BIGINT PRIMARY KEY AUTO_INCREMENT,
    medicine_id         BIGINT NOT NULL REFERENCES medicines(medicine_id),
    batch_number        VARCHAR(100) NOT NULL,
    supplier_id         BIGINT NULL REFERENCES suppliers(supplier_id),
    purchase_price      DECIMAL(12,2),
    mrp                 DECIMAL(12,2),
    quantity_initial    DECIMAL(10,2) NOT NULL,
    quantity_remaining  DECIMAL(10,2) NOT NULL,
    unit                VARCHAR(20) NOT NULL,
    manufacturing_date  DATE,
    expiry_date         DATE NOT NULL,
    location            VARCHAR(100),                        -- e.g. "Rack A3, Shelf 2"
    is_active           BOOLEAN DEFAULT TRUE,
    received_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_updated        TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_medicine_expiry (medicine_id, expiry_date),
    INDEX idx_batch (batch_number)
);

-- ============================================================================
-- Stock Alerts (Materialized / Event-driven)
-- ============================================================================
CREATE TABLE pharmacy_stock_alerts (
    alert_id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    medicine_id         BIGINT NOT NULL REFERENCES medicines(medicine_id),
    alert_type          ENUM('low_stock','out_of_stock','expiry_soon','expired') NOT NULL,
    threshold_value     DECIMAL(10,2),                      -- for low_stock: configured minimum
    current_stock       DECIMAL(10,2),
    batch_number        VARCHAR(100),                        -- for expiry-related alerts
    expiry_date         DATE,                                -- for expiry-related alerts
    is_resolved         BOOLEAN DEFAULT FALSE,
    resolved_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_medicine (medicine_id),
    INDEX idx_resolved (is_resolved)
);

-- ============================================================================
-- Indent / Requisition (Pharmacy → Warehouse/Supplier)
-- ============================================================================
CREATE TABLE pharmacy_indents (
    indent_id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    indent_number       VARCHAR(30) NOT NULL UNIQUE,         -- e.g. IND-20260709-001
    requested_by        BIGINT NOT NULL REFERENCES users(user_id),
    approved_by         BIGINT NULL REFERENCES users(user_id),
    status              ENUM('draft','submitted','approved','rejected',
                             'partially_received','received','cancelled') NOT NULL DEFAULT 'draft',
    source              ENUM('warehouse','supplier') NOT NULL DEFAULT 'warehouse',
    supplier_id         BIGINT NULL REFERENCES suppliers(supplier_id),
    notes               TEXT,
    submitted_at        TIMESTAMP NULL,
    approved_at         TIMESTAMP NULL,
    received_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_status (status),
    INDEX idx_indent_number (indent_number)
);

CREATE TABLE pharmacy_indent_items (
    indent_item_id      BIGINT PRIMARY KEY AUTO_INCREMENT,
    indent_id           BIGINT NOT NULL REFERENCES pharmacy_indents(indent_id),
    medicine_id         BIGINT NOT NULL REFERENCES medicines(medicine_id),
    quantity_requested  DECIMAL(10,2) NOT NULL,
    quantity_approved   DECIMAL(10,2),
    quantity_received   DECIMAL(10,2) DEFAULT 0,
    unit                VARCHAR(20) NOT NULL,
    batch_number        VARCHAR(100),                        -- populated on receipt
    expiry_date         DATE,                                -- populated on receipt
    received_at         TIMESTAMP NULL,
    INDEX idx_indent (indent_id)
);
```

### 5.2 YAML Domain Model

```yaml
pharmacy:
  prescription:
    fields:
      - name: prescription_id
        type: bigint
        pk: true
      - name: ticket_number
        type: string(20)
        unique: true
      - name: status
        type: enum
        values: [pending, hold, query, ready, collected, cancelled, partial]
      - name: urgency
        type: enum
        values: [routine, urgent, stat]
      - name: source
        type: enum
        values: [OPD, IPD, ER]
    state_machine:
      initial: pending
      transitions:
        - from: pending
          to: [hold, query, ready, cancelled]
        - from: hold
          to: [pending, ready, cancelled]
        - from: query
          to: [pending, cancelled]
        - from: ready
          to: [collected]
        - from: partial
          to: [ready, collected]

  indent:
    fields:
      - name: indent_id
        type: bigint
        pk: true
      - name: status
        type: enum
        values: [draft, submitted, approved, rejected, partially_received, received, cancelled]
    state_machine:
      initial: draft
      transitions:
        - from: draft
          to: [submitted, cancelled]
        - from: submitted
          to: [approved, rejected]
        - from: approved
          to: [partially_received, received, cancelled]
        - from: partially_received
          to: [received]

  stock_alert:
    thresholds:
      low_stock_multiple: 1.5     # Alert when stock < (avg_monthly_consumption * 1.5)
      expiry_warn_days: 90        # Warn when expiry is within 90 days
      expiry_critical_days: 30    # Critical alert when expiry is within 30 days
```

---

## 6. INVENTORY INTEGRATION & STOCK ALERTS

### 6.1 Stock Deduction Flow

```python
from dataclasses import dataclass
from typing import List, Tuple


@dataclass
class BatchAllocation:
    """Represents allocation of a specific batch to a prescription item."""
    inventory_id: int
    batch_number: str
    quantity: float
    expiry_date: str


class DispensingEngine:
    """
    Handles inventory reservation, batch allocation, and stock deduction
    during the dispensing workflow.
    """

    def __init__(self, db_session: "Session"):
        self.db = db_session

    def allocate_batches(
        self, medicine_id: int, quantity_needed: float
    ) -> Tuple[List[BatchAllocation], float]:
        """
        Allocate batches for a given medicine using FIFO/FEFO strategy.
        Returns list of batch allocations and the total allocated quantity.

        Strategy: FEFO (First Expiry, First Out) — allocates from batches
        with the nearest expiry date first, minimizing wastage.
        """
        query = """
            SELECT inventory_id, batch_number, quantity_remaining, expiry_date
            FROM inventory_batches
            WHERE medicine_id = ?
              AND quantity_remaining > 0
              AND expiry_date >= CURDATE()
              AND is_active = TRUE
            ORDER BY expiry_date ASC, received_at ASC
        """
        rows = self.db.execute(query, (medicine_id,)).fetchall()
        if not rows:
            return [], 0.0

        allocations: List[BatchAllocation] = []
        allocated_so_far = 0.0

        for row in rows:
            inv_id, batch, qty_avail, expiry = row
            take = min(qty_avail, quantity_needed - allocated_so_far)
            if take <= 0:
                break
            allocations.append(BatchAllocation(
                inventory_id=inv_id,
                batch_number=batch,
                quantity=take,
                expiry_date=expiry.isoformat(),
            ))
            allocated_so_far += take
            if allocated_so_far >= quantity_needed:
                break

        return allocations, allocated_so_far

    def dispense(
        self, prescription_item_id: int, allocations: List[BatchAllocation],
        dispensed_by: int
    ) -> bool:
        """
        Execute dispensing: deduct from inventory, create dispensing records.
        Transactional — all or nothing.
        """
        try:
            self.db.begin()
            for alloc in allocations:
                # Deduct from batch
                self.db.execute("""
                    UPDATE inventory_batches
                    SET quantity_remaining = quantity_remaining - ?
                    WHERE inventory_id = ? AND quantity_remaining >= ?
                """, (alloc.quantity, alloc.inventory_id, alloc.quantity))

                # Create dispensing record
                self.db.execute("""
                    INSERT INTO pharmacy_dispensing
                        (prescription_id, item_id, inventory_id, batch_number,
                         quantity_dispensed, unit, expiry_date, dispensed_by)
                    VALUES (?, ?, ?, ?, ?, (SELECT unit FROM inventory_batches
                             WHERE inventory_id = ?), ?, ?)
                """, (
                    0, prescription_item_id, alloc.inventory_id, alloc.batch_number,
                    alloc.quantity, alloc.inventory_id, alloc.expiry_date,
                    dispensed_by,
                ))

            # Update prescription item status
            self.db.execute("""
                UPDATE pharmacy_prescription_items
                SET quantity_dispensed = quantity_dispensed + ?,
                    status = 'dispensed'
                WHERE item_id = ?
            """, (sum(a.quantity for a in allocations), prescription_item_id))

            self.db.commit()
            return True
        except Exception:
            self.db.rollback()
            raise


class StockAlertEngine:
    """
    Evaluates stock levels periodically and on inventory mutations.
    Creates alerts for low stock, out-of-stock, and near-expiry items.
    """

    def evaluate(self, medicine_id: int) -> List[dict]:
        alerts = []

        # Check total remaining stock across all batches
        row = self.db.execute("""
            SELECT SUM(quantity_remaining), COUNT(*)
            FROM inventory_batches
            WHERE medicine_id = ? AND is_active = TRUE AND expiry_date >= CURDATE()
        """, (medicine_id,)).fetchone()

        total_stock = row[0] or 0
        batch_count = row[1]

        # Low stock threshold (configurable per medicine)
        threshold = self._get_threshold(medicine_id)
        if total_stock == 0:
            alerts.append({
                "medicine_id": medicine_id,
                "alert_type": "out_of_stock",
                "current_stock": 0,
                "threshold": threshold,
            })
        elif total_stock <= threshold:
            alerts.append({
                "medicine_id": medicine_id,
                "alert_type": "low_stock",
                "current_stock": total_stock,
                "threshold": threshold,
            })

        # Expiry checks per batch
        expiry_rows = self.db.execute("""
            SELECT inventory_id, batch_number, expiry_date, quantity_remaining
            FROM inventory_batches
            WHERE medicine_id = ?
              AND is_active = TRUE
              AND expiry_date BETWEEN CURDATE() AND DATE_ADD(CURDATE(), INTERVAL 90 DAY)
        """, (medicine_id,)).fetchall()

        for row in expiry_rows:
            _, batch, expiry, qty = row
            days_to_expiry = (expiry - __import__("datetime").date.today()).days
            alert_type = "expired" if days_to_expiry <= 0 else "expiry_soon"
            alerts.append({
                "medicine_id": medicine_id,
                "alert_type": alert_type,
                "batch_number": batch,
                "expiry_date": expiry.isoformat(),
                "current_stock": qty,
            })

        # Persist alerts
        for alert in alerts:
            self.db.execute("""
                INSERT INTO pharmacy_stock_alerts
                    (medicine_id, alert_type, current_stock, threshold_value,
                     batch_number, expiry_date)
                VALUES (?, ?, ?, ?, ?, ?)
            """, (
                alert["medicine_id"], alert["alert_type"],
                alert.get("current_stock"), alert.get("threshold"),
                alert.get("batch_number"), alert.get("expiry_date"),
            ))

        return alerts
```

---

## 7. INDENT / REQUISITION WORKFLOW

```
                    Indent Workflow
                    ┌──────────────────────────────────┐
                    │  1. Pharmacist creates indent    │
                    │     - Auto-suggest: items below  │
                    │       low stock threshold        │
                    │     - Manual: any medicine       │
                    │     - Quantities: based on avg   │
                    │       monthly consumption        │
                    ├──────────────────────────────────┤
                    │  2. Submit for approval           │
                    │     - Status: draft -> submitted  │
                    │     - Notification to approver    │
                    ├──────────────────────────────────┤
                    │  3. Approver reviews              │
                    │     - Can modify quantities       │
                    │     - Approve / Reject            │
                    │     - Reason if rejected          │
                    ├──────────────────────────────────┤
                    │  4. Goods Receipt                 │
                    │     - Receive full or partial     │
                    │     - Record batch/lot numbers    │
                    │     - Record expiry dates         │
                    │     - Update inventory batches    │
                    ├──────────────────────────────────┤
                    │  5. Close indent                  │
                    │     - Status: received            │
                    │     - Trigger stock alert refresh │
                    └──────────────────────────────────┘
```

---

## 8. API ENDPOINTS

### 8.1 Prescription Management

| Method | Endpoint                                             | Description                              |
|--------|------------------------------------------------------|------------------------------------------|
| GET    | /api/pharmacy/prescriptions                          | List prescriptions (query: status)       |
| GET    | /api/pharmacy/prescriptions/:id                      | Get prescription with items              |
| PUT    | /api/pharmacy/prescriptions/:id/status               | Update status (hold/query/ready/collect) |
| POST   | /api/pharmacy/prescriptions/:id/assign               | Assign to pharmacist                     |

### 8.2 Dispensing

| Method | Endpoint                                             | Description                              |
|--------|------------------------------------------------------|------------------------------------------|
| POST   | /api/pharmacy/dispense                               | Dispense a prescription (full)           |
| POST   | /api/pharmacy/dispense/partial                       | Partial dispensing                       |
| POST   | /api/pharmacy/dispense/{itemId}/allocate              | Allocate batch(es) to an item            |
| GET    | /api/pharmacy/dispense/history                       | Dispensing history (query: date range)   |

### 8.3 Inventory & Batches

| Method | Endpoint                                             | Description                              |
|--------|------------------------------------------------------|------------------------------------------|
| GET    | /api/pharmacy/inventory                              | Current inventory snapshot               |
| GET    | /api/pharmacy/inventory/:medicineId                  | Inventory for specific medicine          |
| POST   | /api/pharmacy/inventory/batches                      | Add new batch (stock in)                 |
| PUT    | /api/pharmacy/inventory/batches/:id                  | Update batch (adjust, deactivate)        |
| GET    | /api/pharmacy/inventory/expiring                     | List expiring batches                    |

### 8.4 Stock Alerts

| Method | Endpoint                                             | Description                              |
|--------|------------------------------------------------------|------------------------------------------|
| GET    | /api/pharmacy/alerts                                 | List active alerts                       |
| POST   | /api/pharmacy/alerts/:id/resolve                     | Resolve an alert                         |
| POST   | /api/pharmacy/alerts/evaluate                        | Trigger evaluation for all medicines     |

### 8.5 Indent / Requisition

| Method | Endpoint                                             | Description                              |
|--------|------------------------------------------------------|------------------------------------------|
| POST   | /api/pharmacy/indents                                | Create indent                            |
| GET    | /api/pharmacy/indents                                | List indents                             |
| GET    | /api/pharmacy/indents/:id                            | Get indent details with items            |
| PUT    | /api/pharmacy/indents/:id/status                     | Update indent status (submit/approve/...)|
| POST   | /api/pharmacy/indents/:id/receive                    | Goods receipt (full or partial)          |
| GET    | /api/pharmacy/indents/auto-suggest                   | Suggest items for reorder                |

---

## 9. QUEUE CONFIGURATION

```yaml
queue_config:
  pharmacy_pending:
    source_module: "0309_PHARMACY"
    event_triggers:
      - "prescription.created"
      - "prescription.released_from_hold"
    display_fields:
      - ticket_number
      - patient_name
      - source
      - urgency
      - item_count
      - ordered_at
      - assigned_pharmacist
    sort_by: "urgency DESC, ordered_at ASC"
    actions:
      - "Open & Dispense"
      - "Place on Hold"
      - "Query Doctor"
      - "Print Label"

  pharmacy_ready:
    source_module: "0309_PHARMACY"
    event_triggers:
      - "prescription.dispensed"
    display_fields:
      - ticket_number
      - patient_name
      - item_count
      - total_cost
      - prepared_by
      - prepared_at
    sort_by: "prepared_at ASC"

  pharmacy_alerts:
    source_module: "0309_PHARMACY"
    event_triggers:
      - "stock.alert.created"
      - "stock.alert.resolved"
    display_fields:
      - medicine_name
      - alert_type
      - current_stock
      - threshold / expiry
      - created_at
    sort_by: "created_at DESC"
```

---

## 10. KEY DESIGN DECISIONS

1. **Prescription queue vs pharmacist user module**: This module (0309) handles the department-level operational workflow (queues, inventory, indents), while the pharmacist user module (0207) handles the individual login, role permissions, and session management for pharmacy staff. The two are separate concerns.

2. **FEFO (First Expiry, First Out) allocation**: The dispensing engine automatically allocates batches with the nearest expiry date first. This minimizes medicine wastage and ensures patients receive medicines with the longest remaining shelf life.

3. **Batch/lot tracking at dispensing level**: Every dispensing event records the exact batch number and expiry date. This enables full traceability for recalls, adverse event investigations, and audit compliance.

4. **Partial dispensing support**: When stock is insufficient for the full quantity, the system allows partial dispensing (dispensing what is available, back-ordering the rest). The prescription status becomes "partial" until the remainder is fulfilled.

5. **Auto-suggest for indents**: When creating an indent/requisition, the system suggests medicines that have fallen below the low-stock threshold, calculated as a multiple (default 1.5x) of the average monthly consumption. This prevents stockouts proactively.

6. **Expiry alert thresholds**: Two-tier expiry alerts: "expiry_soon" at 90 days and "expired" when past expiry. Expired batches are automatically excluded from dispensing but retained for audit trail purposes (not deleted).

7. **Controlled substance flag**: Prescription items for narcotics/controlled substances are flagged, requiring additional verification steps during dispensing (dual-sign-off, separate log) that must be configured in the pharmacist user module's permissions.

8. **Ticket numbering**: Each prescription receives a unique human-readable ticket number (`PH-YYYYMMDD-XXXX`) that is printed on labels and used for patient communication and collection verification.
