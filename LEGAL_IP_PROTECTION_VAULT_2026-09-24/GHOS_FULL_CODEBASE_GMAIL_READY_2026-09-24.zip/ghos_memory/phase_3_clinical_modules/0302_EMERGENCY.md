---
file_id: "0302"
module_name: "Emergency Module"
version: "2.0"
status: "Draft"
phase: "Phase 3 — Clinical Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0101_WORKFLOW_ENGINE.md", "0103_NOTIFICATION_ENGINE.md", "0108_REPORT_ENGINE.md", "0201_DOCTOR_MODULE.md", "0204_NURSE_MODULE.md"]
related_files: ["0300_OPD.md", "0301_IPD.md", "0303_LAB.md", "0309_PHARMACY.md", "0304_ECG.md", "0305_ECHO.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "emergency", "casualty", "triage", "ambulance", "critical-care"]
---

# GHOS — Emergency Module

> Emergency and casualty management with highest system-wide queue priority and rapid response workflows.

---

## 1. PURPOSE

The Emergency module manages all patients arriving at the emergency/casualty department. It provides triage-level-based routing, ambulance tracking, critical alert broadcasting, and seamless handoff to IPD, OPD, or discharge.

---

## 2. TRIAGE SYSTEM

### 2.1 Triage Levels (Manchester Triage System)

| Level | Acronym | Color | Max Response Time | Description |
|-------|---------|-------|-------------------|-------------|
| 1 | Immediate | Red | 0 min (Immediate) | Life-threatening — cardiac arrest, severe trauma, anaphylaxis |
| 2 | Urgent | Orange | 10 min | Very urgent — chest pain, severe bleeding, stroke symptoms |
| 3 | Less Urgent | Yellow | 30 min | Semi-urgent — fractures, moderate pain, fever with chills |
| 4 | Non-Urgent | Green | 60 min | Standard — minor cuts, cold symptoms, mild fever |
| 5 | Walk-in | Blue | 120 min | Minimal — prescription refill, minor bruise |

### 2.2 Triage Assessment Data Model

```sql
CREATE TABLE triage_assessments (
    id                  UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id            UUID NOT NULL REFERENCES visits(id),
    triage_level        INTEGER NOT NULL CHECK (triage_level BETWEEN 1 AND 5),
    triage_color        VARCHAR(20) NOT NULL,       -- red, orange, yellow, green, blue
    triage_notes        TEXT,
    vitals_at_triage    JSONB NOT NULL,             -- {bp, pulse, temp, spo2, rr, gcs, pain_scale}
    chief_complaint     TEXT NOT NULL,
    mechanism_of_injury TEXT,                        -- for trauma cases
    allergies           TEXT,
    comorbidities       JSONB,                      -- known conditions
    triage_nurse_id     UUID REFERENCES nurses(id),
    triage_doctor_id    UUID REFERENCES doctors(id),
    triage_time         TIMESTAMP NOT NULL DEFAULT NOW(),
    reassessment_time   TIMESTAMP,                  -- next reassessment based on triage level
    outcome             VARCHAR(30),                -- admitted, discharged, referred, died
    created_at          TIMESTAMP DEFAULT NOW(),
    updated_at          TIMESTAMP DEFAULT NOW()
);
```

### 2.3 Triage Reassessment Schedule

```yaml
triage_reassessment:
  level_1_red:
    interval_minutes: 5
    action: "Continuous monitoring, immediate resuscitation"
  level_2_orange:
    interval_minutes: 10
    action: "Doctor assessment within 10 min, vitals every 10 min"
  level_3_yellow:
    interval_minutes: 30
    action: "Doctor assessment within 30 min, vitals every 30 min"
  level_4_green:
    interval_minutes: 60
    action: "Doctor assessment within 60 min"
  level_5_blue:
    interval_minutes: 120
    action: "Doctor assessment within 120 min"
```

---

## 3. EMERGENCY QUEUE

### 3.1 Queue Priority Behavior

The emergency queue interacts with all other department queues through a **global priority override**:

```
Emergency Queue (separate)         Department Queues (OPD, Lab, etc.)
┌─────────────────────┐            ┌──────────────────────┐
│ Red   → Score: 0    │            │ Normal    → Score: N │
│ Orange→ Score: 1000 │            │ Senior    → Score: N │
│ Yellow→ Score: 2000 │            │ VIP       → Score: N │
│ Green → Score: 3000 │            └──────────────────────┘
│ Blue  → Score: 4000 │
└─────────────────────┘

When an emergency patient is routed to ANY department:
  → Their queue score is set to (triage_level * -500 + -1)
  → This places them ahead of ALL non-emergency patients
  → Emergency patients are always dequeued first
```

### 3.2 Emergency Queue Engine Integration

```python
async def enqueue_emergency(
    visit_id: UUID,
    triage_level: int,
    department_id: Optional[UUID] = None
) -> QueueEntry:
    """
    Enqueue an emergency patient. Uses inverted priority scoring
    to ensure emergency patients always precede normal patients.
    """
    # Emergency priority score: lower triage level = higher priority
    # Score = (triage_level * -500) -1   → Red=-501, Orange=-1001, ..., Blue=-2001
    # This ensures emergency patients score lower than any normal patient (score >= 0)
    priority_score = (triage_level * -500) - 1

    target_dept = department_id or get_emergency_department_id()

    entry = await QueueEntry.create(
        visit_id=visit_id,
        department_id=target_dept,
        token_number=await generate_emergency_token(target_dept),
        status='waiting',
        priority=2,                               # emergency priority tier
        priority_score=priority_score,
        entered_at=datetime.utcnow(),
        is_emergency=True,
        triage_level=triage_level
    )

    await redis.zadd(
        f"queue:{target_dept}:{today()}",
        {str(entry.id): priority_score}
    )

    # Broadcast critical alert for Red/Orange triage
    if triage_level <= 2:
        await broadcast_emergency_alert(visit_id, triage_level)

    # Notify emergency team
    await publish_event("emergency.enqueued", {
        "visit_id": visit_id,
        "triage_level": triage_level,
        "department_id": target_dept,
        "token": entry.token_number,
        "priority_score": priority_score
    })

    return entry
```

---

## 4. EMERGENCY WORKFLOW

### 4.1 Complete Emergency Flow

```
Patient Arrives (Walk-in / Ambulance / Referral)
        │
        ▼
   ┌─────────────┐
   │ Registration │──→ Rapid registration (minimal fields)
   └──────┬──────┘
          │
          ▼
   ┌──────────────┐
   │Triage Nurse   │──→ Assess, assign triage level, record vitals
   └──────┬───────┘
          │
          ▼
   ┌──────────────┐
   │Emergency Queue│──→ Enqueued with priority = triage-based score
   └──────┬───────┘
          │
          ▼
   ┌──────────────┐
   │Doctor Review  │──→ Rapid assessment, diagnose, plan
   └──────┬───────┘
          │
     ┌────┴────┐
     │         │
     ▼         ▼
  ┌────────┐ ┌──────────────────┐
  │Resus   │ │Investigation/Rx  │──→ Lab, ECG, X-Ray, Pharmacy
  │Citation │ │                  │    (with emergency priority)
  └────────┘ └────────┬─────────┘
                      │
                 ┌────┴─────┐
                 │          │
                 ▼          ▼
           ┌────────┐ ┌──────────┐
           │Admit   │ │Discharge │
           │to IPD  │ │or        │
           │/ICU    │ │Observation│
           └────────┘ └──────────┘
```

### 4.2 Rapid Registration

```python
async def rapid_registration(
    name: str,
    phone: str,
    age: int,
    gender: str,
    chief_complaint: str,
    triage_level: int
) -> Visit:
    """
    Minimal registration for emergency patients.
    Full demographics can be collected later.
    Only requires name, phone, age, gender, and complaint.
    """
    # 1. Find or create patient record
    patient = await Patient.find(phone=phone).first()
    if not patient:
        patient = await Patient.create(
            name=name,
            phone=phone,
            age=age,
            gender=gender,
            registration_type='emergency_rapid',
            is_emergency_untracked=True
        )

    # 2. Create visit with emergency context
    visit = await Visit.create(
        patient_id=patient.id,
        visit_type='emergency',
        source='emergency',
        status='active',
        chief_complaint=chief_complaint,
        triage_level=triage_level
    )

    # 3. Enqueue in emergency department
    await enqueue_emergency(visit.id, triage_level)

    return visit
```

---

## 5. CRITICAL ALERT SYSTEM

### 5.1 Alert Types

| Alert Type | Trigger | Recipients | Channel |
|-----------|---------|-----------|---------|
| CODE_BLUE | Cardiac / respiratory arrest | Resuscitation team | Broadcast + Mobile push |
| CODE_RED | Mass casualty / disaster | All available staff | Broadcast + SMS + Siren |
| TRAUMA_ALERT | Major trauma incoming | Trauma team, OT standby | Broadcast + Mobile push |
| STROKE_ALERT | Suspected stroke | Neuro team, CT standby | Broadcast + Mobile push |
| MI_ALERT | Suspected MI / STEMI | Cardio team, Cath lab | Broadcast + Mobile push |
| PEDI_ALERT | Critical pediatric | Pediatric team | Broadcast + Mobile push |

### 5.2 Alert Broadcast Implementation

```python
async def broadcast_emergency_alert(
    visit_id: UUID,
    triage_level: int,
    alert_type: Optional[str] = None
):
    """
    Broadcast a critical alert to all relevant stakeholders.
    Red triage → CODE_BLUE broadcast
    Orange triage → Department-specific alerts
    """
    visit = await Visit.get(visit_id)
    alert_channel = f"emergency_alerts:{visit.hospital_id}"

    if triage_level == 1:
        alert_type = alert_type or "CODE_BLUE"
        message = {
            "type": alert_type,
            "severity": "critical",
            "visit_id": str(visit_id),
            "patient_name": visit.patient.name,
            "location": "Emergency Resus Bay",
            "chief_complaint": visit.chief_complaint,
            "timestamp": datetime.utcnow().isoformat(),
            "action_required": "Immediate resuscitation team response"
        }

        # 1. WebSocket broadcast to emergency dashboard
        await publish_event("emergency.code_blue", message)

        # 2. Push notification to all on-call doctors and nurses
        on_call_staff = await get_on_call_staff(visit.hospital_id, 'emergency')
        for staff in on_call_staff:
            await send_push_notification(
                user_id=staff.id,
                title=f"🚨 {alert_type} - Emergency Department",
                body=f"{visit.patient.name} - {visit.chief_complaint[:50]}"
            )

        # 3. SMS to senior doctors (configurable)
        if config.emergency.sms_on_code_blue:
            await send_sms_broadcast(on_call_staff)

        # 4. Activate public address system
        await trigger_pa_announcement(visit.hospital_id, alert_type)

    elif triage_level == 2:
        # Department-specific alerts (less urgent broadcast)
        relevant_depts = await determine_alert_teams(visit.chief_complaint)
        for dept in relevant_depts:
            await publish_event(f"emergency.alert.{dept}", {
                "visit_id": str(visit_id),
                "triage_level": triage_level,
                "chief_complaint": visit.chief_complaint
            })
```

---

## 6. AMBULANCE TRACKING

### 6.1 Ambulance Data Model

```sql
CREATE TABLE ambulances (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id           UUID NOT NULL REFERENCES hospitals(id),
    vehicle_number        VARCHAR(50) NOT NULL UNIQUE,
    vehicle_type          VARCHAR(30) NOT NULL,       -- basic, advanced, micu
    driver_name           VARCHAR(100),
    driver_phone          VARCHAR(20),
    contact_number        VARCHAR(20),
    equipment_level       VARCHAR(50),                -- basic_life_support, advanced_life_support
    status                VARCHAR(30) DEFAULT 'available', -- available, en_route, at_location, returning, maintenance
    current_lat           DECIMAL(10,7),
    current_lng           DECIMAL(10,7),
    last_location_update  TIMESTAMP,
    is_active             BOOLEAN DEFAULT TRUE,
    created_at            TIMESTAMP DEFAULT NOW(),
    updated_at            TIMESTAMP DEFAULT NOW()
);

CREATE TABLE ambulance_runs (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    ambulance_id          UUID NOT NULL REFERENCES ambulances(id),
    visit_id              UUID REFERENCES visits(id),
    patient_name          VARCHAR(100),
    patient_phone         VARCHAR(20),
    pickup_location       TEXT NOT NULL,
    pickup_lat            DECIMAL(10,7),
    pickup_lng            DECIMAL(10,7),
    dropoff_location      TEXT,                       -- hospital emergency
    dispatch_time         TIMESTAMP DEFAULT NOW(),
    arrival_time          TIMESTAMP,
    hospital_arrival_time TIMESTAMP,
    return_time           TIMESTAMP,
    status                VARCHAR(30) DEFAULT 'dispatched', -- dispatched, arrived_pickup, en_route_hospital, arrived_hospital, completed
    run_notes             TEXT,
    created_at            TIMESTAMP DEFAULT NOW(),
    updated_at            TIMESTAMP DEFAULT NOW()
);
```

### 6.2 Ambulance Dispatch

```python
async def dispatch_ambulance(
    hospital_id: UUID,
    pickup_location: str,
    pickup_lat: float,
    pickup_lng: float,
    patient_info: dict = None,
    vehicle_type: str = 'basic'
) -> AmbulanceRun:
    """
    Dispatch the nearest available ambulance to a pickup location.
    """
    # 1. Find nearest available ambulance
    nearest = await find_nearest_ambulance(
        hospital_id, pickup_lat, pickup_lng, vehicle_type
    )

    if not nearest:
        raise NoAmbulanceAvailableError("No ambulance available at this time")

    # 2. Create ambulance run
    run = await AmbulanceRun.create(
        ambulance_id=nearest.id,
        patient_name=patient_info.get('name') if patient_info else None,
        patient_phone=patient_info.get('phone') if patient_info else None,
        pickup_location=pickup_location,
        pickup_lat=pickup_lat,
        pickup_lng=pickup_lng,
        status='dispatched'
    )

    # 3. Update ambulance status
    nearest.status = 'en_route'
    await nearest.save()

    # 4. Notify driver
    await send_push_notification(
        user_id=nearest.driver_phone,
        title="New Dispatch",
        body=f"Pickup: {pickup_location}"
    )

    # 5. Track in real-time dashboard
    await publish_event("ambulance.dispatched", {
        "run_id": str(run.id),
        "ambulance_id": str(nearest.id),
        "vehicle_number": nearest.vehicle_number,
        "eta_seconds": await estimate_eta(nearest, pickup_lat, pickup_lng)
    })

    return run
```

---

## 7. EMERGENCY REPORT

### 7.1 Emergency Department Report

```sql
CREATE TABLE emergency_reports (
    id                    UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id              UUID NOT NULL REFERENCES visits(id),
    patient_id            UUID NOT NULL REFERENCES patients(id),
    triage_assessment_id  UUID REFERENCES triage_assessments(id),
    doctor_id             UUID REFERENCES doctors(id),
    arrival_mode          VARCHAR(30) NOT NULL,       -- walk_in, ambulance, referral, transfer
    arrival_time          TIMESTAMP NOT NULL DEFAULT NOW(),
    triage_time           TIMESTAMP,
    doctor_assessment_time TIMESTAMP,
    disposition_time      TIMESTAMP,
    disposition           VARCHAR(30),               -- admitted, discharged, referred, died, observation
    admitted_to           VARCHAR(30),               -- ward, icu, hdu, nicu
    admitting_doctor      UUID REFERENCES doctors(id),
    diagnosis             TEXT,
    procedures_done       JSONB,                    -- list of procedures
    medications_administered JSONB,
    investigations_ordered JSONB,
    notes                 TEXT,
    follow_up_advice      TEXT,
    finalized             BOOLEAN DEFAULT FALSE,
    created_at            TIMESTAMP DEFAULT NOW(),
    updated_at            TIMESTAMP DEFAULT NOW()
);
```

---

## 8. API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/emergency/register` | Rapid registration for emergency patient |
| POST | `/api/v1/emergency/triage` | Perform triage assessment |
| GET | `/api/v1/emergency/queue` | View emergency queue |
| GET | `/api/v1/emergency/queue/next` | Dequeue next emergency patient |
| POST | `/api/v1/emergency/report` | Create emergency report |
| GET | `/api/v1/emergency/report/{id}` | Get emergency report |
| PUT | `/api/v1/emergency/report/{id}` | Update emergency report |
| POST | `/api/v1/emergency/alert` | Trigger critical alert |
| GET | `/api/v1/emergency/alerts/active` | Get active alerts |
| POST | `/api/v1/emergency/ambulance/dispatch` | Dispatch ambulance |
| PATCH | `/api/v1/emergency/ambulance/runs/{id}` | Update ambulance run status |
| GET | `/api/v1/emergency/ambulance/tracking/{id}` | Get ambulance real-time location |
| GET | `/api/v1/emergency/dashboard` | Emergency department dashboard |
| POST | `/api/v1/emergency/admit/{visit_id}` | Admit emergency patient to IPD |

---

## 9. KEY DESIGN DECISIONS

1. **Negative priority scoring** in the queue engine guarantees emergency patients always precede normal patients without changing the core queue algorithm.
2. **Rapid registration** with minimal fields (name, phone, age, gender, complaint) reduces registration time to under 30 seconds.
3. **Separate triage_assessments table** preserves the triage history independently from the emergency report.
4. **Alert types mapped to triage levels** — Red automatically triggers CODE_BLUE; Orange triggers department-specific alerts.
5. **Ambulance tracking is real-time** with location updates via WebSocket for live ETA display.
6. **Reassessment intervals** enforced by cron jobs; missed reassessments generate alerts.
7. **Observation status** allows holding patients in emergency for up to 24 hours without formal admission.

---

## 10. YAML CONFIGURATION

```yaml
emergency:
  rapid_registration_min_fields: true
  enable_ambulance_tracking: true
  ambulance_location_poll_interval_seconds: 10
  auto_code_blue_on_triage_level_1: true
  sms_on_code_blue: false
  pa_announcement_on_code_blue: true
  default_observation_hold_hours: 24
  max_observation_bed_count: 10
  enable_triage_reassessment_alerts: true

  triage_levels:
    red:    { level: 1, color: "#FF0000", max_response_minutes: 0,  requires_resus_bay: true }
    orange: { level: 2, color: "#FF9800", max_response_minutes: 10, requires_resus_bay: false }
    yellow: { level: 3, color: "#FFEB3B", max_response_minutes: 30, requires_resus_bay: false }
    green:  { level: 4, color: "#4CAF50", max_response_minutes: 60, requires_resus_bay: false }
    blue:   { level: 5, color: "#2196F3", max_response_minutes: 120,requires_resus_bay: false }

  ambulance_types:
    basic:  { label: "Basic Life Support", equipment: ["stretcher", "oxygen", "first_aid"] }
    advanced:{label: "Advanced Life Support", equipment: ["ventilator", "defibrillator", "monitor"] }
    micu:   { label: "Mobile ICU",          equipment: ["ventilator", "monitor", "infusion_pump", "ultrasound"] }

  critical_alerts:
    - { code: "CODE_BLUE",     triage_level: 1, channels: ["websocket", "push", "pa"] }
    - { code: "CODE_RED",      triage_level: 1, channels: ["websocket", "push", "sms", "pa"], condition: "mass_casualty" }
    - { code: "TRAUMA_ALERT",  triage_level: 1, channels: ["websocket", "push"],             condition: "major_trauma" }
    - { code: "STROKE_ALERT",  triage_level: 2, channels: ["websocket", "push"],             condition: "stroke_symptoms" }
    - { code: "MI_ALERT",      triage_level: 2, channels: ["websocket", "push"],             condition: "chest_pain_suspect_mi" }
    - { code: "PEDI_ALERT",    triage_level: 1, channels: ["websocket", "push"],             condition: "pediatric_critical" }
```
