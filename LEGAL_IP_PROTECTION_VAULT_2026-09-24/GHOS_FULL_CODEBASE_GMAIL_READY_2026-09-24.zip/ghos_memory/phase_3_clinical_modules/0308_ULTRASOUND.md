---
file_id: "0308"
module_name: "Ultrasound / USG Module"
version: "1.0"
status: "Draft"
phase: "Phase 3 - Clinical Modules"
dependencies: ["0100_QUEUE_ENGINE.md", "0402_STORAGE_ENGINE.md"]
related_files: ["0205_DOCTOR.md", "0307_XRAY.md", "0403_DICOM_GATEWAY.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "ultrasound", "usg", "sonography", "imaging", "obstetrics", "doppler"]
---

# GHOS - Ultrasound / USG Module

## 1. PURPOSE
The Ultrasound (USG) module manages ultrasound examinations across multiple scan types (abdomen, pelvis, obstetrics, thyroid, musculoskeletal, vascular Doppler). It handles order placement, real-time image capture and annotation, structured measurement recording per study type, report generation with integrated images and measurements, and comparison with prior scans.

---

## 2. SYSTEM ARCHITECTURE

```
┌──────────────────────────────────────────────────────────────────────────┐
│                     ULTRASOUND MODULE (0308)                             │
├──────────────────────────────────────────────────────────────────────────┤
│                                                                          │
│  ┌──────────────┐    ┌────────────────┐     ┌───────────────────────┐    │
│  │  Order Entry  │───>│  USG Queue      │───>│  Scan Capture & Live  │    │
│  │  (Clinician)  │    │  (By Scan Type) │    │  Annotation           │    │
│  └──────────────┘    └────────────────┘     └───────────┬───────────┘    │
│                                                          │                │
│                                                          v                │
│  ┌───────────────────┐     ┌────────────────┐     ┌──────────────────┐   │
│  │  Report Generation │<────│  Measurements   │<────│  Image Gallery   │   │
│  │  (Findings + Img)  │     │  (Structured)   │     │  (Captured Cines)│   │
│  └────────┬──────────┘     └────────────────┘     └──────────────────┘   │
│           │                                                              │
│           v                                                              │
│  ┌──────────────────────────────────────────────────────────────────┐   │
│  │  Comparison Engine (Prior Studies, Growth Charts in Obstetrics)  │   │
│  └──────────────────────────────────────────────────────────────────┘   │
│                                                                          │
└──────────────────────────────────────────────────────────────────────────┘
```

---

## 3. SCAN TYPES & MEASUREMENTS

### 3.1 Supported Study Types

```yaml
ultrasound_study_types:
  abdomen:
    label: "Abdomen (Whole)"
    measurements:
      - liver_size_cm
      - spleen_size_cm
      - pancreas_head_cm
      - pancreas_body_cm
      - pancreatic_duct_mm
      - gallbladder_wall_mm
      - cbd_mm                          # common bile duct
      - portal_vein_mm
      - right_kidney_length_cm
      - left_kidney_length_cm
      - aorta_diameter_cm
      - ivc_diameter_cm

  pelvis:
    label: "Pelvis (Gynecology)"
    measurements:
      - uterus_length_cm
      - uterus_width_cm
      - uterus_height_cm
      - endometrium_thickness_mm
      - right_ovary_length_cm
      - right_ovary_width_cm
      - right_ovary_height_cm
      - left_ovary_length_cm
      - left_ovary_width_cm
      - left_ovary_height_cm
      - bladder_wall_thickness_mm

  obstetric:
    label: "Obstetric (Obstetrics)"
    sub_types:
      - first_trimester
      - second_trimester
      - third_trimester
      - growth_scan
      - anomaly_scan
    measurements:
      - gestational_sac_mm
      - crl_mm                         # crown-rump length
      - bpd_mm                          # biparietal diameter
      - hc_mm                           # head circumference
      - ac_mm                           # abdominal circumference
      - fl_mm                           # femur length
      - hl_mm                           # humerus length
      - estimated_fetal_weight_g        # calculated from HC/AC/FL/BPD
      - amniotic_fluid_index_cm
      - umbilical_artery_pi             # pulsatility index
      - umbilical_artery_ri             # resistive index
      - fetal_heart_rate_bpm
      - placental_grade                 # 0-3
      - placental_position              # anterior/posterior/fundal

  thyroid:
    label: "Thyroid"
    measurements:
      - right_lobe_length_cm
      - right_lobe_width_cm
      - right_lobe_height_cm
      - right_lobe_volume_cc
      - left_lobe_length_cm
      - left_lobe_width_cm
      - left_lobe_height_cm
      - left_lobe_volume_cc
      - isthmus_mm
      - total_volume_cc

  musculoskeletal:
    label: "Musculoskeletal"
    measurements:
      - tendon_thickness_mm
      - fluid_collection_volume_cc
      - mass_size_cm

  vascular_doppler:
    label: "Vascular / Doppler"
    measurements:
      - vessel_name
      - peak_systolic_velocity_cm_s
      - end_diastolic_velocity_cm_s
      - resistive_index
      - pulsatility_index
      - diameter_mm
      - stenosis_percentage
```

---

## 4. DATA MODEL

### 4.1 SQL Schema

```sql
-- ============================================================================
-- Ultrasound Study / Order
-- ============================================================================
CREATE TABLE ultrasound_studies (
    study_id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    accession_number    VARCHAR(30) NOT NULL UNIQUE,
    patient_id          BIGINT NOT NULL REFERENCES patients(patient_id),
    referring_doctor_id BIGINT NOT NULL REFERENCES users(user_id),
    study_type          VARCHAR(30) NOT NULL,             -- abdomen, pelvis, obstetric, thyroid, msK, doppler
    sub_type            VARCHAR(50),                      -- for obstetric: first_trimester, etc.
    clinical_indication TEXT,
    urgency             ENUM('routine','urgent','stat') NOT NULL DEFAULT 'routine',
    status              ENUM('ordered','scheduled','in_progress','completed',
                             'reported','cancelled') NOT NULL DEFAULT 'ordered',
    sonographer_id      BIGINT NULL REFERENCES users(user_id),
    radiologist_id      BIGINT NULL REFERENCES users(user_id),
    ordered_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    performed_at        TIMESTAMP NULL,
    completed_at        TIMESTAMP NULL,
    reported_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_patient (patient_id),
    INDEX idx_type_status (study_type, status),
    INDEX idx_accession (accession_number)
);

-- ============================================================================
-- Captured Images / Cines (DICOM or Video)
-- ============================================================================
CREATE TABLE ultrasound_images (
    image_id            BIGINT PRIMARY KEY AUTO_INCREMENT,
    study_id            BIGINT NOT NULL REFERENCES ultrasound_studies(study_id),
    image_type          ENUM('static','cine_loop','doppler_trace') NOT NULL DEFAULT 'static',
    image_label         VARCHAR(200),                      -- e.g. "Liver longitudinal", "Fetal head BPD"
    dicom_instance_uid  VARCHAR(64) UNIQUE,
    file_path           VARCHAR(500),
    file_size_bytes     BIGINT,
    metadata            JSON,                              -- imaging parameters, gain, depth, freq
    is_primary          BOOLEAN DEFAULT FALSE,
    captured_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_study (study_id)
);

-- ============================================================================
-- Structured Measurements
-- ============================================================================
CREATE TABLE ultrasound_measurements (
    measurement_id      BIGINT PRIMARY KEY AUTO_INCREMENT,
    study_id            BIGINT NOT NULL REFERENCES ultrasound_studies(study_id),
    parameter_name      VARCHAR(60) NOT NULL,              -- e.g. "crl_mm", "bpd_mm"
    parameter_label     VARCHAR(200),                      -- e.g. "Crown-Rump Length"
    value_numeric       DECIMAL(10,2),                     -- measured numeric value
    value_unit          VARCHAR(20) DEFAULT 'mm',          -- mm, cm, g, bpm, etc.
    is_calculated       BOOLEAN DEFAULT FALSE,             -- EFW is calculated, not directly measured
    formula_used        VARCHAR(100),                      -- e.g. "Hadlock-1985" for EFW
    percentile          DECIMAL(5,2),                      -- for growth charts (obstetric)
    z_score             DECIMAL(5,2),
    image_id            BIGINT NULL REFERENCES ultrasound_images(image_id),
    measured_by         BIGINT NOT NULL REFERENCES users(user_id),
    notes               TEXT,
    measured_at         TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_study_param (study_id, parameter_name)
);

-- ============================================================================
-- Key Image Annotations (Measurements drawn on image)
-- ============================================================================
CREATE TABLE ultrasound_annotations (
    annotation_id       BIGINT PRIMARY KEY AUTO_INCREMENT,
    image_id            BIGINT NOT NULL REFERENCES ultrasound_images(image_id),
    measurement_id      BIGINT NULL REFERENCES ultrasound_measurements(measurement_id),
    annotation_type     ENUM('distance','area','angle','ellipse','point','text') NOT NULL,
    coordinates         JSON NOT NULL,                     -- {"x1":..., "y1":..., "x2":..., "y2":...}
    value_numeric       DECIMAL(10,2),
    value_unit          VARCHAR(20),
    color               VARCHAR(20) DEFAULT '#FFFF00',
    label               VARCHAR(100),
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_image (image_id)
);

-- ============================================================================
-- Ultrasound Report
-- ============================================================================
CREATE TABLE ultrasound_reports (
    report_id           BIGINT PRIMARY KEY AUTO_INCREMENT,
    study_id            BIGINT NOT NULL UNIQUE REFERENCES ultrasound_studies(study_id),
    radiologist_id      BIGINT NOT NULL REFERENCES users(user_id),
    findings            TEXT NOT NULL,
    impression          TEXT NOT NULL,
    comparison_study_id BIGINT NULL REFERENCES ultrasound_studies(study_id),
    is_abnormal         BOOLEAN DEFAULT NULL,
    report_status       ENUM('draft','final','amended','verified') NOT NULL DEFAULT 'draft',
    finalized_at        TIMESTAMP NULL,
    verified_at         TIMESTAMP NULL,
    created_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at          TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
```

### 4.2 YAML Domain Model

```yaml
ultrasound:
  study:
    fields:
      - name: study_id
        type: bigint
        pk: true
      - name: accession_number
        type: string(30)
        unique: true
      - name: patient_id
        type: bigint
        ref: patients.patient_id
      - name: study_type
        type: string(30)
        constraint: "IN (abdomen, pelvis, obstetric, thyroid, msK, doppler)"
      - name: sub_type
        type: string(50)
        nullable: true
      - name: status
        type: enum
        values: [ordered, scheduled, in_progress, completed, reported, cancelled]

  measurements:
    fields:
      - name: measurement_id
        type: bigint
        pk: true
      - name: parameter_name
        type: string(60)
      - name: value_numeric
        type: decimal(10,2)
      - name: value_unit
        type: string(20)
      - name: is_calculated
        type: boolean
      - name: formula_used
        type: string(100)
      - name: percentile
        type: decimal(5,2)
    constraints:
      - "parameter_name must be a known key for the study_type"
```

---

## 5. REPORT GENERATION PIPELINE

```
                    Report Assembly Flow
                    ┌──────────────────────────────────────┐
                    │                                      │
                    │  Study Completed Event                │
                    │          │                            │
                    │          v                            │
                    │  ┌─────────────────┐                  │
                    │  │ Gather All Data  │                 │
                    │  │ - Images list    │                 │
                    │  │ - Measurements   │                 │
                    │  │ - Annotations    │                 │
                    │  └────────┬────────┘                  │
                    │           v                           │
                    │  ┌─────────────────┐                  │
                    │  │ Pre-fill Report  │                 │
                    │  │ Template:        │                 │
                    │  │ - Patient info   │                 │
                    │  │ - Study details  │                 │
                    │  │ - Measurement    │                 │
                    │  │   table (auto)   │                 │
                    │  │ - Image gallery  │                 │
                    │  │   thumbnails     │                 │
                    │  └────────┬────────┘                  │
                    │           v                           │
                    │  ┌─────────────────┐                  │
                    │  │ Radiologist      │                 │
                    │  │ adds findings &  │                 │
                    │  │ impression       │                 │
                    │  └────────┬────────┘                  │
                    │           v                           │
                    │  ┌─────────────────┐                  │
                    │  │ Finalize Report  │                 │
                    │  │ Notify Clinician │                 │
                    │  └─────────────────┘                  │
                    │                                      │
                    └──────────────────────────────────────┘
```

### 5.1 Measurement Table in Report (Example: Obstetric)

```
═══════════════════════════════════════════════════════════════
  OBSTETRIC MEASUREMENTS (2nd Trimester)
═══════════════════════════════════════════════════════════════
  Parameter          Value    GA (wks)   Percentile    Status
  ───────────────────────────────────────────────────────────
  BPD                45.2 mm    19+3        58%        Normal
  HC                 165 mm     19+2        42%        Normal
  AC                 140 mm     19+4        62%        Normal
  FL                 32.1 mm    19+3        55%        Normal
  EFW                320 g      19+3        50%        Normal
  AFI                12.8 cm      -          -         Normal
────────────────────────────────────────────────────────────
  Estimated Gestational Age: 19 weeks 3 days
  Estimated Due Date: 2026-11-28
────────────────────────────────────────────────────────────
```

---

## 6. IMAGE CAPTURE WORKFLOW

### 6.1 Real-Time Capture Process

```python
from enum import Enum
from dataclasses import dataclass, field
from typing import List, Optional


class CaptureMode(Enum):
    STATIC = "static"
    CINE_LOOP = "cine_loop"          # short video clip
    DOPPLER_TRACE = "doppler_trace"  # spectral doppler waveform


@dataclass
class ImageCaptureSession:
    """
    Manages a live ultrasound image capture session.
    Images are buffered locally and batch-uploaded to storage.
    """
    study_id: int
    capture_mode: CaptureMode = CaptureMode.STATIC
    captured_images: List[dict] = field(default_factory=list)

    def capture_frame(self, raw_data: bytes, label: str = "") -> dict:
        """
        Capture a single frame from the ultrasound machine.
        - Converts raw video frame to DICOM or PNG
        - Assigns SOP Instance UID
        - Stores metadata (gain, depth, frequency, zoom)
        """
        image_entry = {
            "image_id": len(self.captured_images) + 1,
            "label": label,
            "sop_instance_uid": f"1.2.840.10008.{self.study_id}.{len(self.captured_images) + 1}",
            "timestamp": __import__("datetime").datetime.utcnow().isoformat(),
            "size_bytes": len(raw_data),
            "metadata": {
                "gain": None,       # populated by modality interface
                "depth_cm": None,
                "frequency_mhz": None,
            },
        }
        self.captured_images.append(image_entry)
        return image_entry

    def upload_session(self, storage_client: "StorageClient") -> int:
        """
        Batch-upload all captured images to the storage backend.
        Returns count of successfully uploaded images.
        """
        count = 0
        for img in self.captured_images:
            success = storage_client.store(
                study_id=self.study_id,
                sop_uid=img["sop_instance_uid"],
                data=img.get("raw"),
                metadata=img["metadata"],
            )
            if success:
                count += 1
        return count


class MeasurementHelper:
    """
    Provides standard measurement templates per study type.
    """

    STUDY_TEMPLATES = {
        "obstetric": [
            "crl_mm", "bpd_mm", "hc_mm", "ac_mm", "fl_mm",
            "hl_mm", "afb_mm", "umbilical_artery_pi",
        ],
        "abdomen": [
            "liver_size_cm", "spleen_size_cm", "pancreas_head_cm",
            "cbd_mm", "portal_vein_mm",
        ],
        "pelvis": [
            "uterus_length_cm", "endometrium_thickness_mm",
            "right_ovary_length_cm", "left_ovary_length_cm",
        ],
    }

    @classmethod
    def get_template(cls, study_type: str) -> List[str]:
        return cls.STUDY_TEMPLATES.get(study_type, [])

    @classmethod
    def calculate_efw(
        cls, bpd_mm: float, hc_mm: float, ac_mm: float, fl_mm: float,
        formula: str = "hadlock_1985"
    ) -> float:
        """
        Calculate Estimated Fetal Weight using Hadlock's formula.
        Hadlock (1985): log10(EFW) = 1.3596 + 0.0064*HC + 0.0424*AC + 0.174*FL + 0.00061*BPD*AC - 0.00386*AC*FL
        Returns weight in grams.
        """
        if formula == "hadlock_1985":
            import math
            log_efw = (
                1.3596
                + 0.0064 * hc_mm
                + 0.0424 * ac_mm
                + 0.174 * fl_mm
                + 0.00061 * bpd_mm * ac_mm
                - 0.00386 * ac_mm * fl_mm
            )
            return round(math.pow(10, log_efw), 2)
        raise ValueError(f"Unknown formula: {formula}")
```

---

## 7. COMPARISON WORKFLOW

- **Prior studies**: Same study type for the same patient, ordered by date descending.
- **Obstetric growth tracking**: Serial measurements plotted on standard growth charts (Hadlock, WHO, INTERGROWTH-21st).
- **Side-by-side display**: Prior images displayed alongside current images in the viewer.
- **Measurement delta**: Automatic calculation of change between current and prior measurements (e.g., "Liver size increased from 14.2 cm to 15.8 cm").

---

## 8. API ENDPOINTS

### 8.1 Study Management

| Method | Endpoint                              | Description                          |
|--------|---------------------------------------|--------------------------------------|
| POST   | /api/usg/studies                      | Create new ultrasound order          |
| GET    | /api/usg/studies                      | List studies (query: status, type)   |
| GET    | /api/usg/studies/:id                  | Get study details                    |
| PUT    | /api/usg/studies/:id/status           | Update study status                  |
| DELETE | /api/usg/studies/:id                  | Cancel study                         |

### 8.2 Image & Annotation

| Method | Endpoint                                       | Description                     |
|--------|------------------------------------------------|---------------------------------|
| POST   | /api/usg/studies/:id/images                   | Upload image(s)                |
| GET    | /api/usg/studies/:id/images                   | List images for study          |
| GET    | /api/usg/images/:id                           | Get image + metadata           |
| DELETE | /api/usg/images/:id                           | Remove image                   |
| POST   | /api/usg/images/:id/annotations               | Add annotation to image        |
| GET    | /api/usg/images/:id/annotations               | Get annotations for image      |

### 8.3 Measurements

| Method | Endpoint                                       | Description                       |
|--------|------------------------------------------------|-----------------------------------|
| POST   | /api/usg/studies/:id/measurements             | Record a measurement              |
| PUT    | /api/usg/measurements/:id                     | Update a measurement              |
| GET    | /api/usg/studies/:id/measurements             | Get all measurements for study    |
| DELETE | /api/usg/measurements/:id                     | Remove a measurement              |
| GET    | /api/usg/studies/:id/measurements/summary     | Get formatted summary table       |

### 8.4 Report

| Method | Endpoint                                       | Description                       |
|--------|------------------------------------------------|-----------------------------------|
| POST   | /api/usg/studies/:id/report                   | Create report                     |
| GET    | /api/usg/reports/:id                          | Get report                        |
| PUT    | /api/usg/reports/:id                          | Update report (save draft)        |
| POST   | /api/usg/reports/:id/finalize                 | Finalize report                   |
| POST   | /api/usg/reports/:id/verify                   | Verify/approve report             |

### 8.5 Comparison

| Method | Endpoint                                           | Description                           |
|--------|----------------------------------------------------|---------------------------------------|
| GET    | /api/usg/patients/:pid/priors                      | Get prior USG studies for patient     |
| GET    | /api/usg/studies/:id/comparison                    | Get comparison with prior study       |
| GET    | /api/usg/patients/:pid/growth                      | Get growth chart data (obstetric)     |

---

## 9. QUEUE CONFIGURATION

```yaml
queue_config:
  usg_pending:
    source_module: "0308_ULTRASOUND"
    event_triggers:
      - "usg.order.created"
    display_fields:
      - accession_number
      - patient_name
      - study_type
      - urgency
      - ordered_at
    sort_by: "urgency DESC, ordered_at ASC"
    group_by: "study_type"

  usg_reporting:
    source_module: "0308_ULTRASOUND"
    event_triggers:
      - "usg.study.completed"
    display_fields:
      - accession_number
      - patient_name
      - study_type
      - measurements_count
      - image_count
      - performed_at
    sort_by: "performed_at ASC"
```

---

## 10. KEY DESIGN DECISIONS

1. **Study-type-specific measurement templates**: Rather than a generic measurement table, the system defines parameter templates per study type. This ensures data integrity and enables structured reporting with automatic percentile/growth-chart calculations.

2. **Calculated vs measured values**: The `is_calculated` flag distinguishes directly measured parameters (e.g., BPD) from derived ones (e.g., EFW). The `formula_used` field traces which algorithm produced the derived value (Hadlock, Merz, etc).

3. **Image annotations linked to measurements**: Annotations (lines, angles, ellipses) drawn on images are stored in a separate table and optionally linked to a measurement record. This preserves the visual context of each measurement for audit/review.

4. **Growth chart integration for obstetrics**: The comparison engine for obstetric studies retrieves prior measurements and plots them against standard growth curves, flagging measurements below the 5th or above the 95th percentile.

5. **Cine loop support**: The image table supports `cine_loop` type for short video clips, stored as DICOM multiframe or compressed MP4, with the storage backend providing streaming capability.

6. **Sonographer attribution**: Both sonographer (technician who performed the scan) and radiologist (who interpreted) are tracked independently, supporting separate workflow roles.

7. **Doppler waveform storage**: Spectral Doppler traces are stored as both image (waveform screenshot) and structured measurement data (PSV, EDV, RI, PI) for quantitative analysis.
