---
file_id: "0402"
module_name: "Purchase Module"
version: "2.0"
status: "Draft"
phase: "Phase 4 — Admin"
dependencies: ["0401_INVENTORY.md", "0403_VENDOR.md"]
related_files: ["0400_BILLING.md", "0205_STORE_KEEPER.md", "0407_GST.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "purchase", "procurement", "po", "grn", "invoice-matching"]
---

# GHOS — Purchase Module

## 1. PURPOSE

Manage the full procurement lifecycle — from purchase order generation (auto-triggered by
low stock or manual) through vendor selection, goods receipt, invoice matching (3-way match:
PO + GRN + Invoice), and payment tracking. Supports multi-vendor price comparison,
purchase order lifecycle states, and integration with inventory (stock-in on GRN) and
billing (invoice matching for accounts payable).

```
┌─────────────────────────────────────────────────────────────────────┐
│                       PURCHASE MODULE                                │
│                                                                     │
│  Low Stock Alert ──→ Auto-PO ──→ ┌─────────────┐ ──→ Vendor ──→    │
│  Manual Request ───→ Draft PO ──→│  PURCHASE    │                  │
│                                   │  ORDER       │                   │
│  Price Comparison ←── RFQ ───────│  ENGINE      │                   │
│                                   └─────────────┘                   │
│                                           ↓                         │
│  Goods Receipt (GRN) ──→ Stock In ──→ ┌─────────────┐              │
│                                       │  MATCH       │              │
│  Vendor Invoice ─────────────────────→│  3-WAY       │              │
│                                       │  MATCH       │              │
│  PO Details ─────────────────────────→│              │              │
│                                       └─────────────┘              │
│                                              ↓                      │
│  Matched ──→ Accounts Payable ──→ Payment ──→ PO Closed            │
│  Discrepancy ──→ Hold / Query                                       │
└─────────────────────────────────────────────────────────────────────┘
```

## 2. PURCHASE ORDER LIFECYCLE

### States

```
  ┌───────┐    ┌──────┐    ┌──────┐    ┌──────────┐    ┌───────────┐    ┌──────────┐
  │ DRAFT │───→│ SENT │───→│ CON- │───→│ RECEIVED │───→│ PARTIALLY │───→│ CLOSED   │
  │       │    │      │    │ FIRM │    │ (FULL)   │    │ RECEIVED  │    │          │
  └───────┘    └──────┘    └──────┘    └──────────┘    └──────────┘    └──────────┘
      │                                            │
      │  CANCELLED (any state)                     │  ON_HOLD (dispute)
      └─────────────────────────────────────────────┘
```

| State | Description | Allowed Actions |
|-------|-------------|-----------------|
| DRAFT | Being authored, not yet sent | Edit items, delete, submit |
| SENT | Dispatched to vendor, awaiting confirmation | Cancel, re-send |
| CONFIRMED | Vendor accepted the PO | Await delivery, cancel (with penalty) |
| PARTIALLY_RECEIVED | Some items GRN-ed, others pending | Receive remaining, close |
| RECEIVED | Full GRN completed | Route to invoice matching |
| ON_HOLD | Discrepancy found, pending resolution | Query vendor, adjust, release |
| CLOSED | Fully received + invoice matched + paid (or cancelled) | Archive |
| CANCELLED | Voided before completion | No further actions |

```python
class PurchaseOrder:
    """
    Represents a single purchase order with lifecycle management.
    """
    VALID_TRANSITIONS = {
        "DRAFT":               ["SENT", "CANCELLED"],
        "SENT":                ["CONFIRMED", "CANCELLED"],
        "CONFIRMED":           ["PARTIALLY_RECEIVED", "RECEIVED", "CANCELLED", "ON_HOLD"],
        "PARTIALLY_RECEIVED":  ["RECEIVED", "CANCELLED", "ON_HOLD"],
        "RECEIVED":            ["CLOSED", "ON_HOLD"],
        "ON_HOLD":             ["RECEIVED", "CLOSED", "CANCELLED"],
        "CLOSED":              [],
        "CANCELLED":           [],
    }

    def __init__(self, po_id: str, vendor_id: str, items: list):
        self.po_id = po_id
        self.vendor_id = vendor_id
        self.items = items  # list of POItem
        self.status = "DRAFT"
        self.created_at = datetime.utcnow()
        self.total_amount = sum(it.total for it in items)

    def transition_to(self, new_status: str, user: str) -> dict:
        if new_status not in self.VALID_TRANSITIONS[self.status]:
            raise InvalidTransitionError(
                f"Cannot transition from {self.status} to {new_status}"
            )
        self.status = new_status
        return {"po_id": self.po_id, "status": self.status, "changed_by": user, "timestamp": datetime.utcnow()}
```

## 3. AUTO-PO GENERATION AT LOW STOCK THRESHOLD

```python
class AutoPOGenerator:
    """
    Triggered by Inventory low-stock alert engine.
    Creates a PO for configured reorder quantity.
    """

    def generate_from_alert(self, sku_code: str, alert_level: str) -> dict:
        item = self._get_inventory_item(sku_code)
        if not item["reorder_qty"]:
            return {"status": "skipped", "reason": "No reorder_qty configured"}

        preferred_vendors = self._get_preferred_vendors(sku_code)
        if not preferred_vendors:
            return {"status": "skipped", "reason": "No active vendor for this SKU"}

        # Pick lowest-cost vendor as default
        best_vendor = min(preferred_vendors, key=lambda v: v["last_quoted_rate"])

        po = PurchaseOrder(
            po_id=self._generate_po_id(),
            vendor_id=best_vendor["vendor_id"],
            items=[{
                "sku_code": sku_code,
                "item_name": item["item_name"],
                "quantity": item["reorder_qty"],
                "unit_rate": best_vendor["last_quoted_rate"],
            }],
        )
        po.transition_to("DRAFT", "system")
        # Auto-submit if critical; stay draft if low/advisory
        if alert_level == "CRITICAL":
            po.transition_to("SENT", "system")
            self._notify_vendor(po.po_id, best_vendor)
        return {
            "po_id": po.po_id,
            "status": po.status,
            "vendor": best_vendor["vendor_name"],
            "total_amount": po.total_amount,
        }

    def _get_preferred_vendors(self, sku_code):
        # Query vendor_sku_map for active vendors supplying this SKU
        return [
            {"vendor_id": "V001", "vendor_name": "MediSupply Co.", "last_quoted_rate": 0.48},
            {"vendor_id": "V002", "vendor_name": "PharmaDistributors Inc.", "last_quoted_rate": 0.52},
        ]
```

## 4. MANUAL PO CREATION

```python
class ManualPO:
    """
    Raised by store_keeper or department head.
    """

    def create_po(self, vendor_id: str, items: list, created_by: str,
                  urgent: bool = False, notes: str = "") -> PurchaseOrder:
        # Validate vendor is active
        vendor = self._get_vendor(vendor_id)
        if not vendor or not vendor.get("is_active"):
            raise ValueError(f"Vendor {vendor_id} is inactive or not found")

        # Validate items have current rates
        for item in items:
            if not item.get("unit_rate"):
                last_rate = self._get_last_purchase_rate(item["sku_code"], vendor_id)
                item["unit_rate"] = last_rate if last_rate else 0
                if item["unit_rate"] == 0:
                    raise ValueError(f"No rate available for {item['sku_code']} from {vendor_id}")

        po = PurchaseOrder(
            po_id=f"PO-{datetime.now():%Y%m%d}-{self._next_seq():04d}",
            vendor_id=vendor_id,
            items=[PurchaseOrderItem(**it) for it in items],
        )
        po.created_by = created_by
        po.notes = notes

        if urgent:
            # Escalate: auto-approve and send
            po.transition_to("SENT", created_by)
        return po
```

## 5. MULTI-VENDOR PRICE COMPARISON

### RFQ (Request for Quotation) Workflow

```
Draft RFQ → Send to N vendors → Receive Quotes → 
→ Compare (unit rate + delivery + payment terms) → Select → Convert to PO
```

```yaml
price_comparison:
  default_vendors_per_sku: 3
  comparison_dimensions:
    - unit_rate
    - delivery_days
    - payment_terms
    - gst_inclusive
    - minimum_order_qty
  auto_select: "lowest_rate"
  require_approval_if_not_lowest: true
```

```python
class PriceComparison:
    def generate_comparison(self, sku_code: str, quantity: int) -> list:
        vendors = self._get_vendors_for_sku(sku_code)
        quotes = []
        for v in vendors:
            quote = self._request_quote(v["vendor_id"], sku_code, quantity)
            quotes.append({
                "vendor_id": v["vendor_id"],
                "vendor_name": v["vendor_name"],
                "unit_rate": quote["rate"],
                "delivery_days": quote.get("delivery_days", 7),
                "payment_terms": quote.get("payment_terms", "30 days"),
                "gst_inclusive": quote.get("gst_inclusive", True),
                "moq": quote.get("moq", 1),
                "total": quote["rate"] * quantity,
            })
        quotes.sort(key=lambda q: q["total"])
        return {
            "sku_code": sku_code,
            "quantity": quantity,
            "quotes": quotes,
            "recommended_vendor": quotes[0]["vendor_id"] if quotes else None,
            "savings_vs_highest": quotes[-1]["total"] - quotes[0]["total"] if len(quotes) > 1 else 0,
        }
```

## 6. GOODS RECEIPT NOTE (GRN)

### GRN Flow

```
PO Received → Inspect Goods → Create GRN → Update Inventory → 
→ Mark PO line items as received → Trigger 3-way match
```

```python
class GoodsReceiptNote:
    def create_grn(self, po_id: str, received_items: list,
                   received_by: str, grn_date: date = None) -> dict:
        po = self._get_po(po_id)
        if po.status not in ("CONFIRMED", "PARTIALLY_RECEIVED"):
            raise ValueError(f"PO {po_id} in state {po.status} — cannot receive")

        if grn_date is None:
            grn_date = date.today()

        grn_id = f"GRN-{datetime.now():%Y%m%d}-{self._next_seq():04d}"
        discrepancies = []

        for rec in received_items:
            po_item = next((i for i in po.items if i["sku_code"] == rec["sku_code"]), None)
            if po_item is None:
                discrepancies.append({"sku": rec["sku_code"], "issue": "Not on PO"})
                continue
            if rec["quantity"] > po_item["quantity"]:
                discrepancies.append({
                    "sku": rec["sku_code"],
                    "issue": f"Excess delivery: ordered {po_item['quantity']}, received {rec['quantity']}"
                })

        grn = {
            "grn_id": grn_id,
            "po_id": po_id,
            "vendor_id": po.vendor_id,
            "received_date": grn_date.isoformat(),
            "received_by": received_by,
            "items": received_items,
            "discrepancies": discrepancies,
            "status": "completed" if not discrepancies else "quarantined",
        }

        # If no discrepancies, update inventory
        if not discrepancies:
            for rec in received_items:
                self._add_to_inventory(rec, po_id, grn_id)
            po.transition_to(
                "RECEIVED" if self._all_received(po) else "PARTIALLY_RECEIVED",
                "system"
            )
        # Attach GRN to PO
        po.grn_refs.append(grn_id)
        return grn

    def _add_to_inventory(self, item: dict, po_id: str, grn_id: str):
        # Create new batch record in inventory
        # POST /api/v1/inventory/batches
        pass
```

## 7. THREE-WAY INVOICE MATCHING

### Matching Logic

```python
class ThreeWayMatch:
    """
    Verifies that PO, GRN, and Vendor Invoice are consistent.
    """

    def match(self, po_id: str, grn_id: str, invoice: dict) -> dict:
        po = self._get_po(po_id)
        grn = self._get_grn(grn_id)
        results = []

        for inv_item in invoice["items"]:
            po_item = next((i for i in po.items if i["sku_code"] == inv_item["sku_code"]), None)
            grn_item = next((i for i in grn["items"] if i["sku_code"] == inv_item["sku_code"]), None)

            row = {
                "sku_code": inv_item["sku_code"],
                "po_qty": po_item["quantity"] if po_item else 0,
                "grn_qty": grn_item["quantity"] if grn_item else 0,
                "inv_qty": inv_item["quantity"],
                "po_rate": po_item["unit_rate"] if po_item else 0,
                "inv_rate": inv_item["unit_rate"],
                "qty_match": False,
                "rate_match": False,
                "amount_match": False,
                "status": "mismatch",
            }

            # Qty check: GRN qty vs Invoice qty
            row["qty_match"] = (row["grn_qty"] == row["inv_qty"])

            # Rate check: PO rate vs Invoice rate
            tolerance = 0.01  # 1% price tolerance
            row["rate_match"] = abs(row["po_rate"] - row["inv_rate"]) / max(row["po_rate"], 1) <= tolerance

            # Amount check
            expected_amount = row["grn_qty"] * row["po_rate"]
            invoiced_amount = row["inv_qty"] * row["inv_rate"]
            row["amount_match"] = abs(expected_amount - invoiced_amount) <= 0.50  # 50 paise tolerance

            if row["qty_match"] and row["rate_match"] and row["amount_match"]:
                row["status"] = "matched"
            else:
                row["status"] = "mismatch"

            results.append(row)

        match_summary = {
            "po_id": po_id,
            "grn_id": grn_id,
            "invoice_no": invoice["invoice_no"],
            "items": results,
            "overall_status": "MATCHED" if all(r["status"] == "matched" for r in results) else "MISMATCH",
            "excess_qty": sum(r["inv_qty"] - r["grn_qty"] for r in results if r["inv_qty"] > r["grn_qty"]),
            "short_qty": sum(r["grn_qty"] - r["inv_qty"] for r in results if r["grn_qty"] > r["inv_qty"]),
            "rate_variance": sum(r["inv_rate"] - r["po_rate"] for r in results if r["status"] == "mismatch"),
            "matched_at": datetime.utcnow(),
        }

        if match_summary["overall_status"] == "MATCHED":
            self._flag_for_payment(po_id, match_summary)
        else:
            self._flag_for_review(po_id, match_summary)

        return match_summary
```

### Tolerance Rules

| Dimension | Tolerance | Action on Breach |
|-----------|-----------|------------------|
| Quantity | 0 (exact) | Hold invoice, query vendor |
| Unit Rate | +/- 1% | Auto-adjust if within; hold if outside |
| Amount | +/- Rs 0.50 | Auto-adjust (rounding) |
| Tax (GST) | Exact match with PO/GRN | Hold if mismatch |
| Missing GRN Item | N/A | Flag item as "not received" |

## 8. PAYMENT TRACKING

### Payment States per PO

| State | Description |
|-------|-------------|
| PENDING | PO matched, awaiting payment run |
| SCHEDULED | Payment date assigned |
| PROCESSED | Payment initiated (cheque issued / NEFT done) |
| CLEARED | Payment confirmed received by vendor |
| DISPUTED | Vendor claims non-receipt; investigation |

```python
class PaymentTracker:
    def schedule_payment(self, po_id: str, payment_date: date, mode: str) -> dict:
        po = self._get_po(po_id)
        if po.status != "CLOSED":
            po.transition_to("CLOSED", "system")  # Auto-close when payment scheduled
        return {
            "po_id": po_id,
            "vendor_id": po.vendor_id,
            "amount": po.total_amount,
            "payment_date": payment_date.isoformat(),
            "mode": mode,
            "status": "SCHEDULED",
        }

    def record_payment(self, po_id: str, ref_number: str,
                       paid_amount: float, paid_date: date) -> dict:
        return {
            "po_id": po_id,
            "ref_number": ref_number,
            "paid_amount": paid_amount,
            "paid_date": paid_date.isoformat(),
            "status": "CLEARED",
        }
```

## 9. DATA MODEL

### Table: purchase_orders

```sql
CREATE TABLE purchase_orders (
    po_id           VARCHAR(32) PRIMARY KEY,
    po_date         DATE NOT NULL DEFAULT CURRENT_DATE,
    vendor_id       VARCHAR(16) NOT NULL REFERENCES vendors(vendor_id),
    status          VARCHAR(24) NOT NULL DEFAULT 'DRAFT',
    total_amount    DECIMAL(14,2) NOT NULL DEFAULT 0.00,
    discount_total  DECIMAL(12,2) DEFAULT 0.00,
    tax_total       DECIMAL(12,2) DEFAULT 0.00,
    grand_total     DECIMAL(14,2) GENERATED ALWAYS AS (total_amount - discount_total + tax_total) STORED,
    payment_terms   VARCHAR(64),
    delivery_date   DATE,
    urgency         VARCHAR(16) DEFAULT 'normal',
    created_by      VARCHAR(64) NOT NULL,
    approved_by     VARCHAR(64),
    approved_at     TIMESTAMP,
    sent_at         TIMESTAMP,
    confirmed_at    TIMESTAMP,
    closed_at       TIMESTAMP,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_po_status CHECK (
        status IN ('DRAFT','SENT','CONFIRMED','PARTIALLY_RECEIVED','RECEIVED','ON_HOLD','CLOSED','CANCELLED')
    )
);

CREATE INDEX idx_po_vendor ON purchase_orders(vendor_id);
CREATE INDEX idx_po_status ON purchase_orders(status);
CREATE INDEX idx_po_date ON purchase_orders(po_date);
```

### Table: po_items

```sql
CREATE TABLE po_items (
    po_item_id      VARCHAR(32) PRIMARY KEY,
    po_id           VARCHAR(32) NOT NULL REFERENCES purchase_orders(po_id) ON DELETE CASCADE,
    sku_code        VARCHAR(32) NOT NULL REFERENCES inventory_items(sku_code),
    item_name       VARCHAR(128) NOT NULL,
    quantity        INTEGER NOT NULL,
    unit_rate       DECIMAL(12,2) NOT NULL,
    discount_pct    DECIMAL(5,2) DEFAULT 0.00,
    tax_pct         DECIMAL(5,2) DEFAULT 0.00,
    line_total      DECIMAL(14,2) GENERATED ALWAYS AS (quantity * unit_rate * (1 - discount_pct/100) * (1 + tax_pct/100)) STORED,
    received_qty    INTEGER DEFAULT 0,
    pending_qty     INTEGER GENERATED ALWAYS AS (quantity - received_qty) STORED,
    uom             VARCHAR(16) DEFAULT 'NOS',
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_poi_po ON po_items(po_id);
CREATE INDEX idx_poi_sku ON po_items(sku_code);
```

### Table: goods_receipts

```sql
CREATE TABLE goods_receipts (
    grn_id          VARCHAR(32) PRIMARY KEY,
    po_id           VARCHAR(32) NOT NULL REFERENCES purchase_orders(po_id),
    vendor_id       VARCHAR(16) NOT NULL REFERENCES vendors(vendor_id),
    grn_date        DATE NOT NULL DEFAULT CURRENT_DATE,
    received_by     VARCHAR(64) NOT NULL,
    status          VARCHAR(16) NOT NULL DEFAULT 'completed',
    invoice_ref     VARCHAR(64),
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_grn_po ON goods_receipts(po_id);
CREATE INDEX idx_grn_vendor ON goods_receipts(vendor_id);
CREATE INDEX idx_grn_date ON goods_receipts(grn_date);
```

### Table: grn_items

```sql
CREATE TABLE grn_items (
    grn_item_id     VARCHAR(32) PRIMARY KEY,
    grn_id          VARCHAR(32) NOT NULL REFERENCES goods_receipts(grn_id) ON DELETE CASCADE,
    po_item_id      VARCHAR(32) NOT NULL REFERENCES po_items(po_item_id),
    sku_code        VARCHAR(32) NOT NULL,
    batch_id        VARCHAR(32) REFERENCES inventory_batches(batch_id),
    quantity        INTEGER NOT NULL,
    unit_rate       DECIMAL(12,2) NOT NULL,
    mfg_date        DATE,
    expiry_date     DATE,
    batch_no        VARCHAR(48),   -- vendor's batch/lot number
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_grni_grn ON grn_items(grn_id);
CREATE INDEX idx_grni_po_item ON grn_items(po_item_id);
```

### Table: invoice_matches

```sql
CREATE TABLE invoice_matches (
    match_id        VARCHAR(32) PRIMARY KEY,
    po_id           VARCHAR(32) NOT NULL REFERENCES purchase_orders(po_id),
    grn_id          VARCHAR(32) NOT NULL REFERENCES goods_receipts(grn_id),
    vendor_invoice_no VARCHAR(64) NOT NULL,
    vendor_invoice_date DATE,
    invoice_amount  DECIMAL(14,2) NOT NULL,
    matched_amount  DECIMAL(14,2),
    status          VARCHAR(16) NOT NULL DEFAULT 'pending',
    match_details   JSONB,
    reviewed_by     VARCHAR(64),
    reviewed_at     TIMESTAMP,
    payment_ref     VARCHAR(64),
    payment_date    DATE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_match_status CHECK (
        status IN ('pending','matched','mismatch','reviewed','paid')
    )
);

CREATE INDEX idx_im_po ON invoice_matches(po_id);
CREATE INDEX idx_im_status ON invoice_matches(status);
```

### Table: purchase_payments

```sql
CREATE TABLE purchase_payments (
    payment_id      VARCHAR(32) PRIMARY KEY,
    po_id           VARCHAR(32) NOT NULL REFERENCES purchase_orders(po_id),
    match_id        VARCHAR(32) REFERENCES invoice_matches(match_id),
    amount          DECIMAL(14,2) NOT NULL,
    payment_mode    VARCHAR(20) NOT NULL,
    ref_number      VARCHAR(64),
    payment_date    DATE NOT NULL,
    status          VARCHAR(16) DEFAULT 'pending',
    processed_by    VARCHAR(64) NOT NULL,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_pp_po ON purchase_payments(po_id);
```

### Table: vendor_sku_map

```sql
CREATE TABLE vendor_sku_map (
    map_id          VARCHAR(32) PRIMARY KEY,
    vendor_id       VARCHAR(16) NOT NULL REFERENCES vendors(vendor_id),
    sku_code        VARCHAR(32) NOT NULL REFERENCES inventory_items(sku_code),
    vendor_sku_code VARCHAR(64),       -- vendor's internal code
    last_quoted_rate DECIMAL(12,2),
    last_quoted_date DATE,
    preferred       BOOLEAN DEFAULT FALSE,
    is_active       BOOLEAN DEFAULT TRUE,
    lead_time_days  INTEGER,
    moq             INTEGER DEFAULT 1,
    UNIQUE(vendor_id, sku_code)
);
```

## 10. API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/purchase/orders` | List purchase orders (filterable) |
| POST | `/api/v1/purchase/orders` | Create manual PO |
| GET | `/api/v1/purchase/orders/{po_id}` | Get PO details |
| PUT | `/api/v1/purchase/orders/{po_id}` | Update PO items |
| POST | `/api/v1/purchase/orders/{po_id}/send` | Send PO to vendor |
| POST | `/api/v1/purchase/orders/{po_id}/confirm` | Vendor confirms PO |
| POST | `/api/v1/purchase/orders/{po_id}/cancel` | Cancel PO |
| POST | `/api/v1/purchase/orders/{po_id}/hold` | Place PO on hold |
| POST | `/api/v1/purchase/auto-po` | Trigger auto-PO generation |
| POST | `/api/v1/purchase/rfq` | Create RFQ |
| POST | `/api/v1/purchase/rfq/{rfq_id}/send` | Send RFQ to vendors |
| POST | `/api/v1/purchase/rfq/{rfq_id}/compare` | Get price comparison |
| POST | `/api/v1/purchase/rfq/{rfq_id}/select-vendor` | Select vendor from quotes |
| POST | `/api/v1/purchase/grn` | Create goods receipt note |
| GET | `/api/v1/purchase/grn/{grn_id}` | Get GRN details |
| POST | `/api/v1/purchase/match` | Run 3-way match (PO + GRN + Invoice) |
| GET | `/api/v1/purchase/match/{match_id}` | Get match result |
| POST | `/api/v1/purchase/match/{match_id}/approve` | Approve matched invoice |
| POST | `/api/v1/purchase/payment` | Record payment to vendor |
| GET | `/api/v1/purchase/payments/{po_id}` | Get payment history for PO |
| GET | `/api/v1/purchase/vendor-sku/{vendor_id}` | Get SKU rates for vendor |

## 11. KEY DESIGN DECISIONS

1. **Auto-PO only at CRITICAL level**: Automatic PO generation is reserved for CRITICAL stock alerts. LOW-level alerts generate notifications only, requiring manual PO creation. This prevents runaway auto-procurement for minor fluctuations.

2. **3-way match before payment**: No payment is released until PO, GRN, and vendor invoice are matched. Discrepancies place the PO in ON_HOLD until resolved. Quantity and rate mismatches are tracked independently.

3. **Batch and expiry captured at GRN**: When receiving goods, the GRN captures batch number, mfg date, and expiry date. This data flows directly into inventory batch records, ensuring traceability from vendor batch to patient dispense.

4. **Partial receiving tracked via pending_qty**: Each PO line item tracks `received_qty` and `pending_qty` (generated column). This enables partial deliveries without creating new POs for balance quantities.

5. **Preferred vendor per SKU via vendor_sku_map**: The mapping table stores last-quoted rate and preferred flag per vendor-SKU pair. Auto-PO selects the lowest-cost preferred vendor, while manual PO allows override via the RFQ comparison UI.

6. **PO lifecycle as explicit state machine**: The `VALID_TRANSITIONS` dictionary enforces valid state changes. No ad-hoc status mutations are permitted, ensuring audit integrity. Timestamps per transition (sent_at, confirmed_at, etc.) provide a full timeline.

7. **Invoice matching tolerance at line-item level**: Tolerances (1% rate, 50 paise amount) are configurable per hospital. Any breach flags the entire PO for review rather than auto-rejecting, allowing pragmatic resolution of minor rounding differences.
