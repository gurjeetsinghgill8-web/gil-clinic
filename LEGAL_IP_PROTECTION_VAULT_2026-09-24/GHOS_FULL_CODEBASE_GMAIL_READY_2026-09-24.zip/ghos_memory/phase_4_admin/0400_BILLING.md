---
file_id: "0400"
module_name: "Billing Module"
version: "2.0"
status: "Draft"
phase: "Phase 4 — Admin"
dependencies: ["0100_QUEUE_ENGINE.md", "0102_PATIENT_REGISTRATION.md"]
related_files: ["0208_ACCOUNTANT.md", "0407_GST.md", "0309_PHARMACY.md", "0401_INVENTORY.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "billing", "invoice", "payment", "settlement", "discount"]
---

# GHOS — Billing Module

## 1. PURPOSE

Handle all financial transactions within the hospital — fee configuration, bill generation,
payment collection, discount approval, refunds, invoice printing, daily settlement, and
integration with insurance/TPA workflows.

```
┌──────────────────────────────────────────────────────────────┐
│                    BILLING MODULE                             │
│                                                              │
│  Queue → Encounter →  ┌──────────┐  → Payment → Invoice     │
│                       │ BILLING  │                           │
│  Departments ───────→ │  ENGINE  │  → Discounts → Approval   │
│                       └──────────┘                           │
│                                                              │
│  Settlement ←── Daily Closure ←── Reports ←── Refunds        │
└──────────────────────────────────────────────────────────────┘
```

## 2. FEE STRUCTURE CONFIG

Fees are defined per hospital, per department, per service item.

### Configuration YAML

```yaml
fee_structure:
  hospital_id: "H001"
  default_currency: "INR"
  gst_applicable: true
  service_items:
    - code: "CONS-GEN"
      name: "General Consultation"
      category: "consultation"
      base_fee: 500
      gst_slab: "5%"
      department: "OPD"
    - code: "CONS-SPEC"
      name: "Specialist Consultation"
      category: "consultation"
      base_fee: 1000
      gst_slab: "5%"
      department: "OPD"
    - code: "ECG"
      name: "Electrocardiogram"
      category: "diagnostic"
      base_fee: 350
      gst_slab: "5%"
      department: "Cardiology"
    - code: "CBC"
      name: "Complete Blood Count"
      category: "lab"
      base_fee: 300
      gst_slab: "5%"
      department: "Lab"
    - code: "ECHO"
      name: "Echocardiogram"
      category: "diagnostic"
      base_fee: 1500
      gst_slab: "5%"
      department: "Cardiology"
    - code: "TMT"
      name: "Treadmill Test"
      category: "diagnostic"
      base_fee: 1200
      gst_slab: "5%"
      department: "Cardiology"
    - code: "XRAY-CHEST"
      name: "Chest X-Ray"
      category: "radiology"
      base_fee: 400
      gst_slab: "5%"
      department: "Radiology"
    - code: "IPD-SEMI"
      name: "Semi-Private Room (per day)"
      category: "room_rent"
      base_fee: 2000
      gst_slab: "0%"
      department: "IPD"
    - code: "IPD-PVT"
      name: "Private Room (per day)"
      category: "room_rent"
      base_fee: 5000
      gst_slab: "0%"
      department: "IPD"
  package_master:
    - code: "PKG-FBC"
      name: "Full Body Checkup"
      items: ["CBC", "ECG", "XRAY-CHEST", "LFT", "KFT", "LIPID"]
      package_fee: 2500
      savings_text: "Save Rs 1200"
    - code: "PKG-CARDIO"
      name: "Cardiac Assessment"
      items: ["ECG", "ECHO", "TMT", "LIPID"]
      package_fee: 3500
      savings_text: "Save Rs 2000"
  room_category_map:
    general: { daily_fee: 1000, nursing_charges: 300 }
    semi_private: { daily_fee: 2000, nursing_charges: 500 }
    private: { daily_fee: 5000, nursing_charges: 800 }
    icu: { daily_fee: 8000, nursing_charges: 1500 }
```

### Fee Modification Rules

| Scenario | Rule |
|----------|------|
| Time-based surcharge | Night/Emergency: +25% on consultation |
| Weekend/holiday | +15% on consultation fees |
| Senior citizen (60+) | 10% discount on base fee |
| Staff discount | Configurable flat % per employee tier |
| Corporate tie-up | Pre-negotiated rates per corporate code |

## 3. BILL TYPES

```
┌─────────────────────────────────────────────────────────────┐
│  BILL TYPES                                                 │
│                                                             │
│  OPD ─── Consultation + Diagnostics + Pharmacy (walk-in)    │
│                                                             │
│  IPD ─── Room Rent + Procedures + Medicines + Visits        │
│         (per-day accrual, final bill at discharge)          │
│                                                             │
│  PACKAGE ── Pre-defined bundle at discounted rate           │
│                                                             │
│  INSURANCE ── Claim-linked; TPA verification before billing │
│                                                             │
│  CREDIT ── Hospital credit or corporate account deferred    │
│                                                             │
│  ESTIMATE ── Quotation / pre-auth, not a final bill         │
└─────────────────────────────────────────────────────────────┘
```

### Bill Type Behaviors

- **OPD**: Generated in real-time; consolidated per visit. Pharmacy items auto-pulled from dispense.
- **IPD**: Interim bills can be generated periodically (weekly); final bill at discharge includes all accrued charges.
- **Package**: Items outside the package are billed separately at standard rates.
- **Insurance**: Requires pre-auth number, TPA approval reference, and policy ceiling check. Co-pay captured separately.
- **Credit**: Deferred payment with due date; generates receivables ledger entry.

## 4. PAYMENT MODES

| Mode | Code | Processing | Notes |
|------|------|------------|-------|
| Cash | CASH | Instant | Receipt printed immediately |
| UPI | UPI | Instant | UPI transaction ID mandatory |
| Credit Card | CARD-CR | Instant | Terminal ID, auth code required |
| Debit Card | CARD-DR | Instant | Terminal ID, auth code required |
| Net Banking | NET | Delayed (T+1) | Reference number required |
| Insurance | INS | TPA settlement | Claim ref, TPA approval no. |
| Hospital Credit | CREDIT | Deferred | Due date, approved by admin |
| Cheque | CHQ | Delayed (clearance) | Cheque no., bank, date |
| Corporate Account | CORP | Deferred | PO reference, corporate code |

### Payment Processing Flow

```python
class PaymentProcessor:
    """
    Routes payment through the appropriate gateway or ledger.
    Returns payment_id + status.
    """
    def process_payment(self, bill_id: str, mode: str, amount: float, details: dict) -> dict:
        if mode in ("CASH", "UPI", "CARD-CR", "CARD-DR"):
            return self._process_instant(bill_id, mode, amount, details)
        elif mode in ("NET", "CHQ"):
            return self._process_deferred(bill_id, mode, amount, details)
        elif mode == "INS":
            return self._process_insurance(bill_id, amount, details)
        elif mode in ("CREDIT", "CORP"):
            return self._process_credit(bill_id, amount, details)
        else:
            raise ValueError(f"Unknown payment mode: {mode}")

    def _process_instant(self, bill_id, mode, amount, details):
        # Validate with payment gateway / terminal
        # Create payment record
        # Update bill payment status
        return {"payment_id": uuid4(), "status": "completed", "mode": mode}

    def _process_deferred(self, bill_id, mode, amount, details):
        return {"payment_id": uuid4(), "status": "pending_clearing", "mode": mode}

    def _process_insurance(self, bill_id, amount, details):
        # Validate TPA approval, policy ceiling
        return {"payment_id": uuid4(), "status": "tpa_pending", "mode": "INS"}

    def _process_credit(self, bill_id, amount, details):
        return {"payment_id": uuid4(), "status": "deferred", "mode": mode}
```

## 5. DISCOUNT MANAGEMENT

### Discount Types

| Type | Scope | Calculation |
|------|-------|-------------|
| Percentage | Per item or bill total | `item_fee * (pct / 100)` |
| Fixed Amount | Bill total | Flat deduction in Rs |
| Round-off | Bill total | `round(bill_total)` |
| Waive-off | Specific charge item | Full item fee = 0 |

### Approval Workflow & Limits

```yaml
discount_approval:
  staff_role_limits:
    - role: "receptionist"
      max_pct: 5
      max_amount: 200
      needs_approval_above: { pct: 5, amount: 200 }
    - role: "senior_receptionist"
      max_pct: 10
      max_amount: 500
      needs_approval_above: { pct: 10, amount: 500 }
    - role: "accountant"
      max_pct: 15
      max_amount: 2000
      needs_approval_above: { pct: 15, amount: 2000 }
    - role: "admin"
      max_pct: 100
      max_amount: 100000
      needs_approval_above: null
  auto_discounts:
    - name: "Senior Citizen"
      pct: 10
      applies_when: { patient_age_gt: 60 }
      stackable: false
    - name: "Staff Discount"
      pct: 15
      applies_when: { patient_type: "staff" }
      stackable: false
    - name: "Early Bird"
      pct: 5
      applies_when: { bill_time_before: "09:00" }
      stackable: true
```

## 6. BILLING QUEUE

Patients flow into the billing queue after all ordered departments are completed.

```
┌──────────┐    ┌──────────┐    ┌──────────┐    ┌──────────┐
│ Waiting  │───→│ In-Queue │───→│ Billing  │───→│ Complete │
│ (dept    │    │ (ready)  │    │ In-Prog  │    │ (paid)   │
│  done)   │    │          │    │          │    │          │
└──────────┘    └──────────┘    └──────────┘    └──────────┘
```

### Queue States

| State | Meaning |
|-------|---------|
| PENDING_DEPT | Departments not yet completed |
| READY | All departments done, waiting for billing |
| BILLING | Staff is creating/modifying the bill |
| PENDING_PAYMENT | Bill generated, awaiting payment |
| PAID | Payment completed |
| PARTIALLY_PAID | Partial payment collected |
| DISPUTED | Patient raised billing query |
| REFUNDED | Full refund processed |

## 7. CONSOLIDATED BILLING WORKFLOW

```python
class BillingWorkflow:
    """
    End-to-end bill generation for an encounter.
    """
    def generate_bill(self, encounter_id: str, bill_type: str) -> dict:
        # 1. Fetch all services rendered
        services = self._get_encounter_services(encounter_id)

        # 2. Apply fee structure rates
        line_items = []
        for svc in services:
            fee = self._lookup_fee(svc["code"], svc.get("modifier"))
            line_items.append(self._build_item(svc, fee))

        # 3. For IPD, calculate room + nursing days
        if bill_type == "IPD":
            room_charges = self._calc_ipd_room_charges(encounter_id)
            line_items.extend(room_charges)

        # 4. Apply package consolidation if applicable
        if bill_type == "PACKAGE":
            line_items = self._consolidate_package_items(line_items)

        # 5. Calculate subtotal, taxes, discount placeholder
        subtotal = sum(li["line_total"] for li in line_items)
        taxes = self._calculate_taxes(line_items)
        bill = {
            "encounter_id": encounter_id,
            "bill_type": bill_type,
            "line_items": line_items,
            "subtotal": subtotal,
            "tax_total": taxes,
            "discount_total": 0,
            "grand_total": subtotal + taxes,
            "status": "PENDING_PAYMENT"
        }
        return bill

    def _get_encounter_services(self, encounter_id):
        # Query clinical_procedures, pharmacy_dispenses, room_stays
        # for this encounter
        return []

    def _lookup_fee(self, code, modifier=None):
        # Fetch from fee_structure config
        return {"code": code, "base_fee": 500, "gst": 0.05}
```

## 8. BILL SPLITTING

### Split Scenarios

| Scenario | Behavior |
|----------|----------|
| Multi-mode payment | e.g., Rs 5000 via Card + Rs 2000 via Cash |
| Insurance + Patient | Co-pay = patient pays, remainder = insurance |
| Corporate + Personal | Corporate covers Rs X, patient pays remainder |

### Split Data Model

```python
bill_split = {
    "bill_id": "BILL-20260709-001",
    "splits": [
        {"mode": "CASH",    "amount": 2000, "status": "paid",       "ref_id": "RCPT-0001"},
        {"mode": "INS",     "amount": 8000, "status": "tpa_pending","ref_id": "TPA-REF-789"},
        {"mode": "CORP",    "amount": 5000, "status": "deferred",   "ref_id": "PO-2026-042"},
    ],
    "total": 15000
}
```

## 9. REFUND PROCESSING

### Refund Flow

```
Raise Refund Request → Approve (role-gated) → Reverse Payment → 
→ Cancel Invoice → Notify Patient → Ledger Entry
```

### Refund Rules

| Condition | Refund Type |
|-----------|-------------|
| Full cancellation (before service) | 100% refund |
| Partial cancellation (OPD item) | Prorated refund of that item |
| IPD discharge before expected | Prorated room rent refund |
| Wrong billing / duplicate | Full refund of errored amount |
| Patient no-show | Partial refund (minus processing fee) |

### Approval Matrix for Refunds

| Amount Range | Approval Required |
|--------------|-------------------|
| Up to Rs 500 | Accountant |
| Rs 501 - Rs 5000 | Senior Accountant |
| Rs 5001 - Rs 25000 | Admin |
| Above Rs 25000 | Director / Owner |

```python
class RefundProcessor:
    def process_refund(self, bill_id: str, items: list, reason: str, requested_by: str):
        bill = self._get_bill(bill_id)
        refund_amount = self._calculate_refund(bill, items)
        approval = self._check_approval(refund_amount, requested_by)
        if not approval["approved"]:
            return {"status": "pending_approval", "approval_required": approval["required_role"]}
        # Reverse payment records
        self._reverse_payments(bill_id, refund_amount)
        # Generate credit note
        credit_note = self._generate_credit_note(bill_id, refund_amount)
        # Update ledger
        self._update_ledger(bill_id, refund_amount, "refund")
        return {"status": "refunded", "credit_note_id": credit_note["id"], "amount": refund_amount}
```

## 10. INVOICE GENERATION

### Invoice Format (GST-compliant)

```yaml
invoice:
  header:
    hospital_name: "GIL Clinic"
    address: "123, Healthcare Avenue, City"
    gstin: "29ABCDE1234F1Z5"
    invoice_no: "INV-{YYYYMMDD}-{SEQ:05d}"
    invoice_date: "{ISO_DATE}"
    place_of_supply: "Karnataka"
  patient:
    name: "Patient Name"
    upin: "UPIN-00001"
    uh_id: "UHID-00001"
    address: "Patient Address"
    gstin: ""  # blank for individuals
  items:
    - sl_no: 1
      description: "General Consultation"
      hsn_sac: "998312"
      qty: 1
      rate: 500.00
      gst_pct: 5.0
      cgst: 12.50
      sgst: 12.50
      total: 525.00
  summary:
    taxable_amount: 500.00
    cgst_total: 12.50
    sgst_total: 12.50
    grand_total: 525.00
    amount_in_words: "Rupees Five Hundred and Twenty Five Only"
    payment_mode: "CASH"
    settled: true
```

## 11. DAILY SETTLEMENT

### Settlement Process

```python
class DailySettlement:
    """
    Run at end of business day. Generates X-report and Z-report.
    """
    def settle_day(self, settlement_date: str, hospital_id: str) -> dict:
        bills = self._get_bills_for_date(settlement_date, hospital_id)
        summary = {
            "date": settlement_date,
            "total_bills": len(bills),
            "total_collected": sum(b["amount_collected"] for b in bills),
            "total_gst": sum(b["tax_total"] for b in bills),
            "total_discount": sum(b["discount_total"] for b in bills),
            "pending_payments": [b for b in bills if b["status"] in ("PENDING_PAYMENT", "PARTIALLY_PAID")],
            "by_mode": self._group_by_mode(bills),
            "refunds_processed": self._get_refunds_for_date(settlement_date),
            "cash_in_hand": self._calculate_cash_position(),
        }
        summary["difference"] = summary["total_collected"] - summary["cash_in_hand"]
        # Generate X-Report (mid-day) or Z-Report (end-of-day reset)
        report_type = "Z" if self._is_end_of_day() else "X"
        self._generate_settlement_report(summary, report_type)
        return summary

    def _group_by_mode(self, bills):
        from collections import Counter
        mode_counter = Counter()
        for b in bills:
            for split in b.get("splits", []):
                mode_counter[split["mode"]] += split["amount"]
        return dict(mode_counter)
```

### Settlement Reports

| Report | Type | Content |
|--------|------|---------|
| X-Report | Interim | Mid-day snapshot (non-resetting) |
| Z-Report | Final | End-of-day (resets counter, fiscal lock) |
| Physician Summary | Per doctor | Consultations by doctor for the day |
| Department Summary | Per dept | Revenue grouped by department |

## 12. DATA MODEL

### Table: bills

```sql
CREATE TABLE bills (
    bill_id         VARCHAR(32) PRIMARY KEY,
    encounter_id    VARCHAR(32) NOT NULL REFERENCES encounters(encounter_id),
    patient_upin    VARCHAR(16) NOT NULL REFERENCES patients(upin),
    bill_type       VARCHAR(20) NOT NULL CHECK (bill_type IN ('OPD','IPD','PACKAGE','INSURANCE','CREDIT','ESTIMATE')),
    bill_date       TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
    status          VARCHAR(24) NOT NULL DEFAULT 'PENDING_PAYMENT',
    subtotal        DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    discount_total  DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    tax_total       DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    grand_total     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    amount_paid     DECIMAL(12,2) NOT NULL DEFAULT 0.00,
    balance         DECIMAL(12,2) GENERATED ALWAYS AS (grand_total - amount_paid) STORED,
    settled         BOOLEAN NOT NULL DEFAULT FALSE,
    settlement_date DATE,
    created_by      VARCHAR(64) NOT NULL,
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bills_encounter ON bills(encounter_id);
CREATE INDEX idx_bills_date ON bills(bill_date);
CREATE INDEX idx_bills_status ON bills(status);
CREATE INDEX idx_bills_settlement ON bills(settlement_date);
```

### Table: bill_items

```sql
CREATE TABLE bill_items (
    item_id         VARCHAR(32) PRIMARY KEY,
    bill_id         VARCHAR(32) NOT NULL REFERENCES bills(bill_id) ON DELETE CASCADE,
    service_code    VARCHAR(32) NOT NULL,
    service_name    VARCHAR(128) NOT NULL,
    category        VARCHAR(32),
    department_id   VARCHAR(16),
    quantity        DECIMAL(8,2) NOT NULL DEFAULT 1,
    unit_rate       DECIMAL(12,2) NOT NULL,
    discount_pct    DECIMAL(5,2) DEFAULT 0.00,
    discount_amount DECIMAL(12,2) DEFAULT 0.00,
    taxable_amount  DECIMAL(12,2) GENERATED ALWAYS AS (unit_rate * quantity - discount_amount) STORED,
    gst_slab        VARCHAR(8),
    cgst_amount     DECIMAL(12,2) DEFAULT 0.00,
    sgst_amount     DECIMAL(12,2) DEFAULT 0.00,
    line_total      DECIMAL(12,2) NOT NULL,
    is_package      BOOLEAN DEFAULT FALSE,
    package_code    VARCHAR(16),
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_bill_items_bill ON bill_items(bill_id);
```

### Table: payments

```sql
CREATE TABLE payments (
    payment_id      VARCHAR(32) PRIMARY KEY,
    bill_id         VARCHAR(32) NOT NULL REFERENCES bills(bill_id),
    payment_mode    VARCHAR(20) NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'pending',
    ref_number      VARCHAR(64),
    gateway_response JSONB,
    collected_by    VARCHAR(64) NOT NULL,
    collected_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    settlement_id   VARCHAR(32),
    notes           TEXT
);

CREATE INDEX idx_payments_bill ON payments(bill_id);
CREATE INDEX idx_payments_mode ON payments(payment_mode);
```

### Table: refunds

```sql
CREATE TABLE refunds (
    refund_id       VARCHAR(32) PRIMARY KEY,
    bill_id         VARCHAR(32) NOT NULL REFERENCES bills(bill_id),
    credit_note_no  VARCHAR(32) UNIQUE NOT NULL,
    amount          DECIMAL(12,2) NOT NULL,
    reason          TEXT NOT NULL,
    items_refunded  JSONB,
    approved_by     VARCHAR(64),
    approved_at     TIMESTAMP,
    processed_by    VARCHAR(64) NOT NULL,
    processed_at    TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    status          VARCHAR(16) DEFAULT 'pending'
);
```

### Table: daily_settlements

```sql
CREATE TABLE daily_settlements (
    settlement_id   VARCHAR(32) PRIMARY KEY,
    settlement_date DATE NOT NULL,
    report_type     CHAR(1) CHECK (report_type IN ('X','Z')),
    total_bills     INTEGER NOT NULL,
    total_collected DECIMAL(14,2) NOT NULL,
    total_tax       DECIMAL(14,2) NOT NULL,
    total_discount  DECIMAL(14,2) NOT NULL,
    total_refunds   DECIMAL(14,2) DEFAULT 0.00,
    net_collected   DECIMAL(14,2) GENERATED ALWAYS AS (total_collected - total_refunds) STORED,
    cash_in_hand    DECIMAL(14,2),
    difference      DECIMAL(10,2),
    mode_breakdown  JSONB,
    settled_by      VARCHAR(64) NOT NULL,
    settled_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_final        BOOLEAN DEFAULT FALSE,
    UNIQUE(settlement_date, report_type)
);
```

## 13. API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/billing/fee-structure` | Get service fee list |
| PUT | `/api/v1/billing/fee-structure` | Update fee structure (admin) |
| POST | `/api/v1/billing/queue/{encounter_id}/ready` | Mark encounter ready for billing |
| GET | `/api/v1/billing/queue` | List billing queue |
| POST | `/api/v1/billing/generate` | Generate bill for encounter |
| GET | `/api/v1/billing/{bill_id}` | Get bill details |
| PUT | `/api/v1/billing/{bill_id}` | Update bill (add/remove items) |
| POST | `/api/v1/billing/{bill_id}/discount` | Apply discount to bill |
| POST | `/api/v1/billing/{bill_id}/approve-discount` | Approve discount (role-gated) |
| POST | `/api/v1/billing/{bill_id}/payment` | Record payment |
| POST | `/api/v1/billing/{bill_id}/split` | Split payment across modes |
| POST | `/api/v1/billing/{bill_id}/refund` | Process refund |
| GET | `/api/v1/billing/{bill_id}/invoice` | Generate/retrieve invoice PDF |
| GET | `/api/v1/billing/settlement/day/{date}` | Get daily settlement for date |
| POST | `/api/v1/billing/settlement/day/{date}/close` | Close and finalize day |

## 14. KEY DESIGN DECISIONS

1. **Bill splitting at payment level**: A single bill can have multiple payment records (splits). Each split independently tracks status (paid, pending, deferred). This naturally handles insurance co-pay and multi-mode payments.

2. **Discount as a separate workflow**: Discount is not embedded in `bill_items`. A discount approval chain applies AFTER the gross bill is built but BEFORE payments. This ensures audit trail and role-based control.

3. **Settlement date vs bill date**: Bills can be paid/settled on a different day than generated. The `settled` flag on `bills` and the `settlement_date` ensure daily closure reports capture actual inflow, not accrual.

4. **IPD interim billing via encounter service aggregation**: IPD bills are regenerative — they pull current room days + procedures at any point. The final bill at discharge freezes the line items and closes the encounter for billing.

5. **GST computed at line-item level**: Each `bill_items` row carries its own CGST/SGST, enabling fine-grained tax reporting per HSN/SAC code, which is required for GSTR-1 filing.

6. **No soft-delete on bills**: Once a bill is generated, it cannot be deleted — only voided with a credit note via the refund workflow. This ensures fiscal integrity.
