---
file_id: "0401"
module_name: "Inventory Module"
version: "2.0"
status: "Draft"
phase: "Phase 4 — Admin"
dependencies: ["0402_PURCHASE.md", "0403_VENDOR.md"]
related_files: ["0309_PHARMACY.md", "0400_BILLING.md", "0205_STORE_KEEPER.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "inventory", "stock", "medicines", "batches", "expiry", "barcode"]
---

# GHOS — Inventory Module

## 1. PURPOSE

Manage hospital inventory across all departments — pharmacy stock tracking with batch and
expiry awareness, consumption auto-deduction at point of dispense, stock transfers between
departments, low-stock alerts, expiry alerts (30/60/90 day lookahead), barcode/RFID scanning,
periodic stock-taking/audit, and inventory category management.

```
┌───────────────────────────────────────────────────────────────────┐
│                       INVENTORY MODULE                             │
│                                                                   │
│  Purchase → Goods Receipt → ┌────────────┐ → Pharmacy Dispense    │
│                             │  STOCK     │ → Dept Consumption      │
│  Stock Transfer ←────────── │  ENGINE    │ → Wastage / Expiry      │
│                             └────────────┘                        │
│  Alerts: Low Stock ──→ Auto-PO Trigger                            │
│  Alerts: Expiry  ───→ Expiry Report                               │
│  Audit: Stock Take ──→ Variance Report                            │
└───────────────────────────────────────────────────────────────────┘
```

## 2. INVENTORY CATEGORIES

### Category Hierarchy

```yaml
inventory_categories:
  - id: "MED"
    name: "Medicines & Drugs"
    subcategories:
      - id: "MED-TAB"
        name: "Tablets"
        requires_batch: true
        requires_expiry: true
        requires_prescription: true
      - id: "MED-SYR"
        name: "Syrups & Suspensions"
        requires_batch: true
        requires_expiry: true
      - id: "MED-INJ"
        name: "Injections & Vaccines"
        requires_batch: true
        requires_expiry: true
        cold_chain: true
      - id: "MED-OINT"
        name: "Ointments & Creams"
        requires_batch: true
        requires_expiry: true
      - id: "MED-IV"
        name: "IV Fluids"
        requires_batch: true
        requires_expiry: true

  - id: "CONS"
    name: "Consumables"
    subcategories:
      - id: "CONS-GLOVES"
        name: "Gloves"
        requires_batch: false
        requires_expiry: false
      - id: "CONS-SYRINGE"
        name: "Syringes & Needles"
        requires_batch: true
        requires_expiry: true
      - id: "CONS-BANDAGE"
        name: "Bandages & Dressings"
        requires_batch: false
        requires_expiry: true
      - id: "CONS-MASK"
        name: "Masks & PPE"
        requires_batch: false
        requires_expiry: false

  - id: "SURG"
    name: "Surgical Instruments"
    subcategories:
      - id: "SURG-STERILE"
        name: "Sterile Packs"
        requires_batch: true
        requires_expiry: true
        sterile: true
      - id: "SURG-NONSTER"
        name: "Non-Sterile Instruments"
        requires_batch: false
        requires_expiry: false

  - id: "LAB"
    name: "Lab Reagents"
    subcategories:
      - id: "LAB-REAG"
        name: "Reagents & Chemicals"
        requires_batch: true
        requires_expiry: true
        cold_chain: true
      - id: "LAB-CONS"
        name: "Lab Consumables"
        requires_batch: false
        requires_expiry: false
```

## 3. STOCK TRACKING (BATCH-WISE & EXPIRY-AWARE)

Every stock-keeping unit (SKU) is tracked at the batch level.

```
┌─────────────────────────────────────────────────────────────┐
│  SKU                                                         │
│  Paracetamol 500mg Tablet                                   │
│                                                             │
│  ├── Batch: BATCH-001   Mfg: 2026-01-10  Exp: 2028-01-09   │
│  │   Qty: 5000   Rate/Unit: Rs 0.50   Location: Rack-A-12  │
│  │                                                          │
│  ├── Batch: BATCH-002   Mfg: 2026-06-15  Exp: 2028-06-14   │
│  │   Qty: 2000   Rate/Unit: Rs 0.55   Location: Rack-A-12  │
│  │                                                          │
│  └── Total Stock: 7000                                      │
└─────────────────────────────────────────────────────────────┘
```

### Batch Attributes

| Attribute | Description | Validation |
|-----------|-------------|------------|
| Batch ID | Unique identifier per batch | Auto-generated (BAT-{YYYYMM}-{SEQ}) |
| SKU Code | References `inventory_items` | FK not null |
| MRP | Maximum Retail Price | > 0 |
| Unit Rate | Purchase cost per unit | > 0 |
| Quantity | Current stock in base units | >= 0 |
| Mfg Date | Date of manufacture | <= expiry_date |
| Expiry Date | Date of expiry | > mfg_date |
| Location | Rack/shelf/shelf identifier | Free text |
| Cold Chain | Requires refrigerated storage | Boolean |
| Received Date | Date batch entered stock | Default today |

## 4. LOW STOCK ALERTS

### Configurable Thresholds

```yaml
low_stock_config:
  enabled: true
  check_interval_minutes: 15
  alert_channels: ["in_app", "email", "whatsapp"]
  default_thresholds:
    critical:
      qty: 5
      alert_color: "RED"
      action: "AUTO_PO + SMS to store_keeper + admin"
    low:
      qty: 20
      alert_color: "YELLOW"
      action: "Alert store_keeper + optional PO trigger"
    reorder_point:
      formula: "avg_daily_consumption * lead_time_days + safety_stock"
      alert_action: "Generate Pending PO flag"
  sku_override:
    - sku_code: "MED-INJ-INSULIN"
      critical_qty: 10
      low_qty: 50
      reason: "Life-saving drug, higher safety stock"
    - sku_code: "LAB-REAG-CBC"
      critical_qty: 2
      low_qty: 10
      reason: "Bulk reagent, 500 tests per unit"
```

### Alert Engine

```python
class StockAlertEngine:
    """
    Periodically evaluates stock levels and triggers alerts.
    """

    ALERT_LEVELS = {
        "CRITICAL": {"color": "red",    "requires_ack": True, "auto_po": True},
        "LOW":      {"color": "yellow", "requires_ack": False, "auto_po": False},
        "ADVISORY": {"color": "blue",   "requires_ack": False, "auto_po": False},
    }

    def evaluate(self) -> list[dict]:
        alerts = []
        for item in self._get_all_stock_items():
            total_qty = self._get_total_quantity(item["sku_code"])
            thresholds = self._get_thresholds(item["sku_code"])
            if total_qty <= thresholds["critical"]:
                level = "CRITICAL"
            elif total_qty <= thresholds["low"]:
                level = "LOW"
            elif total_qty <= thresholds["reorder_point"]:
                level = "ADVISORY"
            else:
                continue
            alert = self._create_alert(item, level, total_qty)
            alerts.append(alert)
            if level == "CRITICAL" and self.config["auto_po"]:
                self._trigger_automatic_po(item["sku_code"])
        return alerts

    def _get_total_quantity(self, sku_code):
        # Sum of all non-expired batch quantities for this SKU
        return 750

    def _get_thresholds(self, sku_code):
        # Check sku_override first, then default
        return {"critical": 5, "low": 20, "reorder_point": 100}

    def _create_alert(self, item, level, qty):
        return {
            "alert_id": f"STK-ALERT-{uuid4().hex[:8].upper()}",
            "sku_code": item["sku_code"],
            "item_name": item["item_name"],
            "current_qty": qty,
            "level": level,
            "color": self.ALERT_LEVELS[level]["color"],
            "timestamp": datetime.utcnow(),
            "requires_acknowledgement": self.ALERT_LEVELS[level]["requires_ack"],
        }

    def _trigger_automatic_po(self, sku_code):
        # Calls Purchase Module to generate PO
        # POST /api/v1/purchase/auto-po
        pass
```

## 5. AUTO-DEDUCTION ON PHARMACY DISPENSE

```python
class AutoDeductionEngine:
    """
    When pharmacy dispenses medication, auto-deduct from inventory
    using FIFO (first-expiry-first-out) strategy.
    """

    def deduct(self, dispense_item: dict) -> dict:
        """
        dispense_item = {sku_code, quantity, encounter_id}
        Returns consumption record.
        """
        batches = self._get_available_batches(dispense_item["sku_code"])
        # Sort by expiry date ascending (FEFO)
        batches.sort(key=lambda b: b["expiry_date"])
        remaining = dispense_item["quantity"]
        deductions = []
        for batch in batches:
            if remaining <= 0:
                break
            take = min(remaining, batch["qty"])
            deductions.append({
                "batch_id": batch["batch_id"],
                "qty_taken": take,
                "unit_rate": batch["unit_rate"],
            })
            remaining -= take
            self._update_batch_qty(batch["batch_id"], batch["qty"] - take)
        if remaining > 0:
            raise InsufficientStockError(
                f"Only dispensed {dispense_item['quantity'] - remaining} "
                f"of {dispense_item['quantity']} requested for {dispense_item['sku_code']}"
            )
        # Record movement
        movement = self._record_movement(
            sku_code=dispense_item["sku_code"],
            qty=-dispense_item["quantity"],
            movement_type="dispense",
            reference_id=dispense_item.get("encounter_id"),
            batch_deductions=deductions,
        )
        # Trigger low-stock evaluation
        self._trigger_alert_evaluation(dispense_item["sku_code"])
        return movement
```

## 6. STOCK TRANSFER BETWEEN DEPARTMENTS

### Transfer Flow

```
Request Transfer → Approve (if needed) → Source Dept Deduct → 
→ Destination Dept Receive → Movement Recorded
```

```python
class StockTransfer:
    def create_transfer(self, from_dept: str, to_dept: str,
                        items: list, requested_by: str) -> dict:
        transfer = {
            "transfer_id": f"TRF-{datetime.now():%Y%m%d-%H%M%S}",
            "from_department": from_dept,
            "to_department": to_dept,
            "items": items,
            "status": "pending_approval",
            "requested_by": requested_by,
            "created_at": datetime.utcnow(),
        }
        # Check if transfer requires approval
        if self._requires_approval(from_dept, items):
            # Notify department head
            pass
        else:
            transfer = self._execute_transfer(transfer)
        return transfer

    def _execute_transfer(self, transfer: dict) -> dict:
        for item in transfer["items"]:
            # Deduct from source
            self.auto_deduction.deduct({
                "sku_code": item["sku_code"],
                "quantity": item["qty"],
                "encounter_id": None,
            })
            # Add to destination (as new batch record)
            self._add_to_destination(transfer["to_dept"], item)
            # Record inter-dept movement
            self._record_movement(
                sku_code=item["sku_code"],
                qty=-item["qty"],
                movement_type="transfer_out",
                reference_id=transfer["transfer_id"],
            )
        transfer["status"] = "completed"
        transfer["executed_at"] = datetime.utcnow()
        return transfer
```

## 7. EXPIRY REPORTING (30/60/90 DAY ALERTS)

```yaml
expiry_alerts:
  lookahead_days: [30, 60, 90]
  alert_channels: ["in_app", "email"]
  report_formats: ["PDF", "XLSX"]
  actions:
    30_days: "URGENT — Contact vendor for return/replacement or plan expedited usage"
    60_days: "WARNING — Review consumption velocity; consider discount sale to patients"
    90_days: "ADVISORY — Include in next purchase planning to avoid overstock"
```

```python
class ExpiryReport:
    def generate_report(self, lookahead_days: int = None) -> dict:
        if lookahead_days is None:
            lookahead_days = [30, 60, 90]
        today = datetime.utcnow().date()
        report = {"generated_at": datetime.utcnow(), "buckets": {}}
        for days in lookahead_days:
            cutoff = today + timedelta(days=days)
            expiring = self._query_expiring_batches(today, cutoff)
            total_value = sum(b["qty"] * b["unit_rate"] for b in expiring)
            report["buckets"][f"{days}_days"] = {
                "count": len(expiring),
                "total_value": total_value,
                "batches": expiring,
            }
            if days == 30 and expiring:
                self._send_urgent_alert(expiring)
        return report

    def _query_expiring_batches(self, start_date, end_date):
        # SELECT from inventory_batches
        # WHERE expiry_date BETWEEN start_date AND end_date
        # AND qty > 0
        return []
```

## 8. BARCODE / RFID SUPPORT

### Barcode Schema

```yaml
barcode_schemas:
  sku_barcode:
    format: "CODE128"
    encoding: "{sku_code}-{batch_id}"
    example: "MED-TAB-PCM500-BAT-202607-001"
    human_readable: true
  location_barcode:
    format: "CODE39"
    encoding: "LOC-{floor}-{zone}-{rack}"
    example: "LOC-01-A-12"
  patient_wristband:
    format: "CODE128"
    encoding: "{uhid}"
    example: "UHID-000042"
```

### RFID Integration Points

| Point | Use Case | Hardware |
|-------|----------|----------|
| Goods Receipt | Auto-scan incoming batch + update stock | RFID tunnel / handheld |
| Dispense Counter | Verify medication before dispensing | RFID pad + barcode scanner |
| Stock Take | Bulk scan all items in location | UHF RFID handheld |
| Transfer Out | Scan items being moved | RFID handheld |
| Expiry Check | Bulk scan near-expiry location | UHF RFID handheld |

```python
class BarcodeService:
    def generate_barcode(self, sku_code: str, batch_id: str) -> str:
        raw = f"{sku_code}-{batch_id}"
        # Generate barcode image (CODE128) as PNG
        return f"data:image/png;base64,{self._encode(raw)}"

    def scan_and_lookup(self, barcode: str) -> dict:
        parts = barcode.split("-")
        if len(parts) >= 4:
            sku_code = "-".join(parts[:-1])
            batch_id = parts[-1]
            return self._get_batch_info(sku_code, batch_id)
        return {"error": "Invalid barcode format"}
```

## 9. STOCK TAKING / AUDIT

### Stock Take Cycle

```
┌──────────┐    ┌──────────────┐    ┌──────────────┐    ┌──────────┐
│ Schedule │───→│ Physical     │───→│ Variance     │───→│ Adjust & │
│ Audit    │    │ Count        │    │ Analysis     │    │ Close    │
└──────────┘    └──────────────┘    └──────────────┘    └──────────┘
```

### Audit Types

| Type | Frequency | Scope |
|------|-----------|-------|
| Full Inventory | Quarterly | All SKUs, all locations |
| Cyclical | Weekly | Rotating subset (A/B/C classification) |
| Spot Check | Ad-hoc | Specific SKU or location |
| Event-based | On trigger | After large damage/theft/return |

### Variance Resolution

```python
class StockAudit:
    def run_audit(self, audit_scope: list) -> dict:
        audit_id = f"AUD-{datetime.now():%Y%m%d-%H%M%S}"
        discrepancies = []
        for item in audit_scope:
            system_qty = self._get_system_qty(item["sku_code"], item.get("batch_id"))
            physical_qty = item["counted_qty"]
            variance = physical_qty - system_qty
            if variance != 0:
                discrepancies.append({
                    "sku_code": item["sku_code"],
                    "batch_id": item.get("batch_id"),
                    "system_qty": system_qty,
                    "physical_qty": physical_qty,
                    "variance": variance,
                    "variance_pct": round(variance / system_qty * 100, 2) if system_qty else None,
                })
        return {
            "audit_id": audit_id,
            "scope_count": len(audit_scope),
            "discrepancies": discrepancies,
            "status": "pending_review",
        }

    def resolve_discrepancy(self, audit_id: str, sku_code: str,
                            reason: str, approved_by: str) -> dict:
        if reason in ("damage", "theft", "counting_error", "system_error"):
            adjustment = self._create_adjustment(sku_code, variance, reason, approved_by)
            self._update_stock(sku_code, variance)  # negative for loss
            self._record_movement(
                sku_code=sku_code,
                qty=variance,
                movement_type="audit_adjustment",
                reference_id=audit_id,
            )
            return {"status": "resolved", "adjustment_id": adjustment["id"]}
        return {"status": "pending_investigation"}
```

## 10. DATA MODEL

### Table: inventory_items

```sql
CREATE TABLE inventory_items (
    sku_code        VARCHAR(32) PRIMARY KEY,
    item_name       VARCHAR(128) NOT NULL,
    category_id     VARCHAR(16) NOT NULL REFERENCES inventory_categories(id),
    subcategory_id  VARCHAR(16) NOT NULL,
    manufacturer    VARCHAR(128),
    package_unit    VARCHAR(16) NOT NULL DEFAULT 'NOS',
    package_size    DECIMAL(8,2),  -- e.g., 10 (for strip of 10 tablets)
    reorder_qty     INTEGER NOT NULL DEFAULT 0,
    lead_time_days  INTEGER DEFAULT 3,
    safety_stock    INTEGER DEFAULT 0,
    is_active       BOOLEAN DEFAULT TRUE,
    is_narcotic     BOOLEAN DEFAULT FALSE,
    is_cold_chain   BOOLEAN DEFAULT FALSE,
    hsn_code        VARCHAR(16),
    gst_slab        VARCHAR(8),
    max_discount_pct DECIMAL(5,2) DEFAULT 0,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_inv_category ON inventory_items(category_id);
CREATE INDEX idx_inv_active ON inventory_items(is_active);
```

### Table: inventory_batches

```sql
CREATE TABLE inventory_batches (
    batch_id        VARCHAR(32) PRIMARY KEY,
    sku_code        VARCHAR(32) NOT NULL REFERENCES inventory_items(sku_code),
    supplier_id     VARCHAR(16) REFERENCES vendors(vendor_id),
    mrp             DECIMAL(12,2) NOT NULL,
    unit_rate       DECIMAL(12,2) NOT NULL,
    quantity        INTEGER NOT NULL DEFAULT 0,
    mfg_date        DATE NOT NULL,
    expiry_date     DATE NOT NULL,
    location        VARCHAR(32),
    cold_chain      BOOLEAN DEFAULT FALSE,
    grn_ref         VARCHAR(32),
    received_date   DATE NOT NULL DEFAULT CURRENT_DATE,
    status          VARCHAR(16) DEFAULT 'active',
    is_deleted      BOOLEAN DEFAULT FALSE,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT chk_dates CHECK (mfg_date < expiry_date)
);

CREATE INDEX idx_batches_sku ON inventory_batches(sku_code);
CREATE INDEX idx_batches_expiry ON inventory_batches(expiry_date);
CREATE INDEX idx_batches_status ON inventory_batches(status);
CREATE INDEX idx_batches_location ON inventory_batches(location);
```

### Table: stock_movements

```sql
CREATE TABLE stock_movements (
    movement_id     VARCHAR(32) PRIMARY KEY,
    sku_code        VARCHAR(32) NOT NULL REFERENCES inventory_items(sku_code),
    batch_id        VARCHAR(32) REFERENCES inventory_batches(batch_id),
    movement_type   VARCHAR(24) NOT NULL,
    quantity        INTEGER NOT NULL,  -- negative for out, positive for in
    unit_rate       DECIMAL(12,2),
    total_value     DECIMAL(14,2) GENERATED ALWAYS AS (ABS(quantity) * unit_rate) STORED,
    reference_type  VARCHAR(24),   -- 'dispense', 'purchase', 'transfer_out', 'transfer_in', 'adjustment', 'wastage'
    reference_id    VARCHAR(32),   -- FK to relevant module
    department_id   VARCHAR(16),
    performed_by    VARCHAR(64) NOT NULL,
    notes           TEXT,
    moved_at        TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX idx_movements_sku ON stock_movements(sku_code);
CREATE INDEX idx_movements_type ON stock_movements(movement_type);
CREATE INDEX idx_movements_date ON stock_movements(moved_at);
CREATE INDEX idx_movements_ref ON stock_movements(reference_type, reference_id);
```

### Table: stock_audits

```sql
CREATE TABLE stock_audits (
    audit_id        VARCHAR(32) PRIMARY KEY,
    audit_type      VARCHAR(16) NOT NULL,
    scheduled_date  DATE,
    completed_date  DATE,
    status          VARCHAR(16) DEFAULT 'planned',
    items_counted   INTEGER,
    discrepancies   INTEGER,
    variance_value  DECIMAL(14,2),
    conducted_by    VARCHAR(64),
    approved_by     VARCHAR(64),
    notes           TEXT,
    created_at      TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```

### Table: inventory_categories

```sql
CREATE TABLE inventory_categories (
    id              VARCHAR(16) PRIMARY KEY,
    name            VARCHAR(64) NOT NULL,
    parent_id       VARCHAR(16) REFERENCES inventory_categories(id),
    requires_batch  BOOLEAN DEFAULT TRUE,
    requires_expiry BOOLEAN DEFAULT TRUE,
    cold_chain      BOOLEAN DEFAULT FALSE,
    is_active       BOOLEAN DEFAULT TRUE,
    sort_order      INTEGER DEFAULT 0
);
```

## 11. API ENDPOINTS

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/inventory/items` | List all inventory items (paginated) |
| POST | `/api/v1/inventory/items` | Add new inventory item |
| GET | `/api/v1/inventory/items/{sku_code}` | Get item details |
| PUT | `/api/v1/inventory/items/{sku_code}` | Update item master |
| GET | `/api/v1/inventory/items/{sku_code}/batches` | List batches for SKU |
| POST | `/api/v1/inventory/batches` | Add new batch (goods receipt) |
| GET | `/api/v1/inventory/batches/{batch_id}` | Get batch details |
| GET | `/api/v1/inventory/stock/{sku_code}` | Get current stock (all batches) |
| GET | `/api/v1/inventory/stock/low` | Get low-stock items |
| GET | `/api/v1/inventory/stock/expiring` | Get expiry report (query param: days=30,60,90) |
| POST | `/api/v1/inventory/transfer` | Create stock transfer |
| PUT | `/api/v1/inventory/transfer/{id}/approve` | Approve pending transfer |
| POST | `/api/v1/inventory/audit` | Start a stock audit |
| POST | `/api/v1/inventory/audit/{id}/count` | Submit physical count |
| POST | `/api/v1/inventory/audit/{id}/resolve` | Resolve discrepancy |
| GET | `/api/v1/inventory/movements` | List stock movements (filterable) |
| GET | `/api/v1/inventory/alerts` | Get current stock alerts |
| POST | `/api/v1/inventory/alerts/{id}/ack` | Acknowledge alert |

## 12. KEY DESIGN DECISIONS

1. **FEFO (First Expiry First Out) for consumption**: Dispense always picks the soonest-expiring batch first, minimizing expiry wastage. This is enforced at the auto-deduction engine level.

2. **Batch-level tracking with location**: Every batch records a physical location (rack-shelf). This enables quick retrieval and stock-take efficiency. Location barcodes can be scanned during audit.

3. **Negative stock prevention**: The system never allows stock to go below zero. Any dispense/transfer/consumption that would result in negative stock is rejected, and partial fulfillment is returned with a `shortfulfillment` flag.

4. **Separate movement audit trail**: Every stock change (in/out/transfer/adjustment) is a row in `stock_movements`. This provides a complete, non-repudiable audit trail for all inventory activity.

5. **Threshold override per SKU**: Critical and low thresholds can be overridden per SKU (e.g., life-saving drugs have higher safety stock). This prevents false positives for fast-moving items.

6. **Barcode schema includes batch**: The barcode encodes both SKU and batch ID, enabling scanning at receipt, dispense, and audit to immediately identify exact batch without manual lookup.

7. **Cold chain tracking**: Items requiring cold storage carry a `cold_chain` flag at both item and batch level. Alerts fire if a cold-chain batch is moved to a non-cold location.
