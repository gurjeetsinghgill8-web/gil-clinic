---
file_id: "0405"
module_name: "Payroll Module"
version: "2.0"
status: "Approved"
phase: "Phase 4 — Admin"
dependencies: ["0404_HR.md", "0406_FINANCE.md"]
related_files: ["0407_GST.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "payroll", "salary", "pf", "esi", "tds", "payslip", "compensation"]
---

# GHOS — Payroll Module

> Automated salary calculation, statutory compliance (PF/ESI/TDS), payslip generation, and bank file export.

---

## 1. PURPOSE

Calculate and disburse employee salaries every month with zero manual calculation. Handles attendance-linked proration, statutory deductions, tax withholding, and generates compliance-ready reports and bank transfer files.

---

## 2. PAYROLL PROCESSING FLOW

```
    Month N-1                   Month N                          Month N+1
       │                           │                                │
       ▼                           ▼                                ▼
┌──────────────┐          ┌──────────────┐                 ┌──────────────┐
│ EMPLOYEE     │          │ ATTENDANCE   │                 │ PAYSLIP      │
│ MASTER       │─────────▶│ DATA (1-N)   │───────────────▶│ GENERATED    │
│ (salary,     │          │ (auto from   │                 │ (download,   │
│  bank, PF,   │          │  0404_HR)    │                 │  email)      │
│  deduction)  │          └──────┬───────┘                 └──────┬───────┘
└──────────────┘                 │                                │
                                 ▼                                ▼
                         ┌──────────────┐                 ┌──────────────┐
                         │ LEAVE DATA    │                 │ BANK FILE    │
                         │ (approved     │                 │ EXPORT       │
                         │  leaves)      │                 │ (TXT/CSV)    │
                         └──────┬───────┘                 └──────┬───────┘
                                │                                │
                                ▼                                ▼
                         ┌──────────────┐                 ┌──────────────┐
                         │ LOP           │                 │ PF/ESI       │
                         │ CALCULATION   │                 │ CHALLAN      │
                         │ (loss of pay)  │                 │ GENERATION   │
                         └──────┬───────┘                 └──────┬───────┘
                                │                                │
                                ▼                                ▼
                         ┌──────────────┐                       ...
                         │ GROSS TO NET │
                         │ (PF/ESI/TDS) │
                         └──────┬───────┘
                                │
                    ┌───────────┴───────────┐
                    │                       │
                    ▼                       ▼
            ┌──────────────┐       ┌──────────────┐
            │ TDS RETURN    │       │ SALARY       │
            │ DATA PREP     │       │ DISBURSAL    │
            └──────────────┘       │ (bank file)  │
                                   └──────────────┘
```

### 2.1 Monthly Runbook

```yaml
payroll_runbook:
  day_1_to_5:
    - task: "Finalize attendance for previous month"
      owner: hr_admin
    - task: "Import approved leaves and mark LOP"
      owner: payroll_admin

  day_5_to_7:
    - task: "Run payroll calculation"
      owner: payroll_admin
      auto: true

  day_7_to_8:
    - task: "Review payroll summary report"
      owner: finance_manager
    - task: "Approve / flag corrections"

  day_8_to_9:
    - task: "Generate payslips"
      owner: payroll_admin
      auto: true

  day_9_to_10:
    - task: "Generate bank file for salary transfer"
      owner: payroll_admin
    - task: "Generate PF challan"
      owner: payroll_admin
    - task: "Generate ESI challan"
      owner: payroll_admin
    - task: "Generate TDS payable report"
      owner: payroll_admin

  day_10:
    - task: "Disburse salaries (upload bank file)"
      owner: finance_manager
    - task: "Send payslips to employees"
      auto: true
```

---

## 3. DATA MODEL

### 3.1 salary_structures Table

```sql
CREATE TABLE salary_structures (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES employees(id) ON DELETE CASCADE,
    effective_from  DATE NOT NULL,
    effective_to    DATE,                               -- NULL = currently active
    ctc_annual      DECIMAL(12,2) NOT NULL,             -- Cost to Company per year
    basic_pct       DECIMAL(5,2) NOT NULL DEFAULT 40.00, -- % of gross
    hra_pct         DECIMAL(5,2) NOT NULL DEFAULT 50.00, -- % of basic
    conveyance      DECIMAL(10,2) DEFAULT 1600.00,
    medical         DECIMAL(10,2) DEFAULT 1250.00,
    special_allowance DECIMAL(10,2) DEFAULT 0.00,
    other_allowances JSONB DEFAULT '{}',
                    -- {"uniform": 500, "mobile": 1000}
    bonus_annual    DECIMAL(12,2) DEFAULT 0.00,         -- Annual bonus (prorated monthly)
    pf_applicable   BOOLEAN DEFAULT TRUE,
    esi_applicable  BOOLEAN DEFAULT TRUE,               -- Applicable if gross <= 21000
    professional_tax_state VARCHAR(50) DEFAULT 'Karnataka',
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT unique_employee_active UNIQUE (employee_id, effective_from)
);

CREATE INDEX idx_salary_employee ON salary_structures(employee_id);
CREATE INDEX idx_salary_active ON salary_structures(effective_to);
```

### 3.2 payroll_runs Table

```sql
CREATE TABLE payroll_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    month           INTEGER NOT NULL CHECK (month BETWEEN 1 AND 12),
    year            INTEGER NOT NULL,
    status          VARCHAR(30) NOT NULL DEFAULT 'draft',
                    -- draft | calculated | reviewed | approved | disbursed | archived
    total_employees INTEGER,
    total_gross     DECIMAL(14,2),
    total_deductions DECIMAL(14,2),
    total_net_pay   DECIMAL(14,2),
    total_employer_pf DECIMAL(14,2),
    total_employer_esi DECIMAL(14,2),
    total_tds       DECIMAL(14,2),
    approved_by     UUID REFERENCES employees(id),
    approved_at     TIMESTAMP,
    disbursed_at    TIMESTAMP,
    bank_file_url   TEXT,
    created_by      UUID NOT NULL REFERENCES employees(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT unique_payroll_period UNIQUE (month, year)
);
```

### 3.3 payroll_entries Table

```sql
CREATE TABLE payroll_entries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payroll_run_id  UUID NOT NULL REFERENCES payroll_runs(id) ON DELETE CASCADE,
    employee_id     UUID NOT NULL REFERENCES employees(id),
    salary_structure_id UUID NOT NULL REFERENCES salary_structures(id),

    -- Working days calculation
    total_working_days     INTEGER NOT NULL,
    days_present           INTEGER NOT NULL,
    days_absent            INTEGER NOT NULL,
    days_leave_paid        INTEGER NOT NULL,
    days_lop               INTEGER NOT NULL DEFAULT 0,   -- Loss of pay days

    -- Earnings
    basic                 DECIMAL(10,2) NOT NULL,
    hra                   DECIMAL(10,2) NOT NULL,
    conveyance            DECIMAL(10,2) NOT NULL,
    medical               DECIMAL(10,2) NOT NULL,
    special_allowance     DECIMAL(10,2) NOT NULL,
    other_allowances      DECIMAL(10,2) NOT NULL,
    bonus                 DECIMAL(10,2) DEFAULT 0.00,
    arrears               DECIMAL(10,2) DEFAULT 0.00,   -- Previous period corrections
    overtime_pay          DECIMAL(10,2) DEFAULT 0.00,
    gross_pay             DECIMAL(10,2) GENERATED ALWAYS AS
                          (basic + hra + conveyance + medical + special_allowance +
                           other_allowances + bonus + arrears + overtime_pay) STORED,

    -- Deductions
    employee_pf           DECIMAL(10,2) DEFAULT 0.00,
    employer_pf           DECIMAL(10,2) DEFAULT 0.00,
    employee_esi          DECIMAL(10,2) DEFAULT 0.00,
    employer_esi          DECIMAL(10,2) DEFAULT 0.00,
    professional_tax      DECIMAL(10,2) DEFAULT 0.00,
    tds                   DECIMAL(10,2) DEFAULT 0.00,
    loan_emi              DECIMAL(10,2) DEFAULT 0.00,
    advance_recovery      DECIMAL(10,2) DEFAULT 0.00,
    other_deductions      DECIMAL(10,2) DEFAULT 0.00,
    total_deductions      DECIMAL(10,2) GENERATED ALWAYS AS
                          (employee_pf + employee_esi + professional_tax +
                           tds + loan_emi + advance_recovery + other_deductions) STORED,

    -- Net
    net_pay               DECIMAL(10,2) GENERATED ALWAYS AS
                          (gross_pay - total_deductions) STORED,

    -- Bank details (snapshot at time of processing)
    bank_account_no       VARCHAR(30),
    ifsc_code             VARCHAR(11),
    bank_name             VARCHAR(100),

    status                VARCHAR(20) DEFAULT 'calculated',
    remarks               TEXT,
    created_at            TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT unique_employee_payroll UNIQUE (payroll_run_id, employee_id)
);

CREATE INDEX idx_payroll_entries_run ON payroll_entries(payroll_run_id);
CREATE INDEX idx_payroll_entries_employee ON payroll_entries(employee_id);
```

### 3.4 payroll_arrears Table

```sql
CREATE TABLE payroll_arrears (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_id     UUID NOT NULL REFERENCES employees(id),
    for_month       INTEGER NOT NULL CHECK (for_month BETWEEN 1 AND 12),
    for_year        INTEGER NOT NULL,
    amount          DECIMAL(10,2) NOT NULL,
    reason          VARCHAR(200) NOT NULL,
                    -- salary_revision | correction | late_joining | increment_retro
    processed_in_payroll_id UUID REFERENCES payroll_runs(id),
    status          VARCHAR(20) DEFAULT 'pending',
                    -- pending | processed
    approved_by     UUID REFERENCES employees(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
```

### 3.5 payslips Table

```sql
CREATE TABLE payslips (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    payroll_entry_id UUID NOT NULL UNIQUE REFERENCES payroll_entries(id) ON DELETE CASCADE,
    employee_id     UUID NOT NULL REFERENCES employees(id),
    month           INTEGER NOT NULL,
    year            INTEGER NOT NULL,
    pdf_url         TEXT,                               -- Generated PDF on S3
    emailed_at      TIMESTAMP,
    downloaded_at   TIMESTAMP,
    generated_at    TIMESTAMP NOT NULL DEFAULT NOW()
);
```

---

## 4. SALARY CALCULATION ENGINE

```python
async def calculate_salary(employee_id: UUID, month: int, year: int) -> PayrollEntry:
    """
    Calculate one employee's salary for a given month.
    Called by the batch process for all active employees.
    """
    # 1. Fetch salary structure
    struct = await SalaryStructure.find_one({
        "employee_id": employee_id,
        "effective_from": {"$lte": date(year, month, 1)},
        "$or": [
            {"effective_to": None},
            {"effective_to": {"$gte": date(year, month, 1)}}
        ]
    })
    if not struct:
        raise ValidationError(f"No active salary structure for employee {employee_id}")

    # 2. Compute working days
    total_days = calendar.monthrange(year, month)[1]
    holidays = await get_holidays(month, year)
    working_days = total_days - len(holidays)

    # 3. Fetch attendance for the month
    attendance_records = await Attendance.find({
        "employee_id": employee_id,
        "date": {
            "$gte": date(year, month, 1),
            "$lte": date(year, month, total_days)
        }
    }).to_list()

    present_days = sum(1 for a in attendance_records
                       if a.status in ("present", "late"))
    absent_days = sum(1 for a in attendance_records
                      if a.status == "absent")

    # 4. Fetch approved leaves
    leaves = await LeaveRequest.find({
        "employee_id": employee_id,
        "status": "approved",
        "from_date": {"$lte": date(year, month, total_days)},
        "to_date": {"$gte": date(year, month, 1)}
    }).to_list()

    paid_leave_days = sum(l.total_days for l in leaves)
    lop_days = max(0, absent_days - paid_leave_days)

    # 5. Calculate monthly gross components
    monthly_ctc = struct.ctc_annual / 12
    gross_monthly = monthly_ctc / (1 + 0.12 + 0.0475)  # Removing PF & gratuity loading

    basic = round(gross_monthly * struct.basic_pct / 100, 2)
    hra = round(basic * struct.hra_pct / 100, 2)
    conveyance = struct.conveyance
    medical = struct.medical
    special = struct.special_allowance

    # Other allowances
    other_allow = sum(struct.other_allowances.values())

    # 6. Apply LOP proration
    if lop_days > 0:
        per_day = gross_monthly / working_days
        lop_amount = round(per_day * lop_days, 2)

        # Deduct proportionally from components
        lop_factor = lop_days / working_days
        basic = round(basic * (1 - lop_factor), 2)
        hra = round(hra * (1 - lop_factor), 2)
        conveyance = round(conveyance * (1 - lop_factor), 2)
        medical = round(medical * (1 - lop_factor), 2)
        special = round(special * (1 - lop_factor), 2)
        other_allow = round(other_allow * (1 - lop_factor), 2)

    # 7. Calculate deductions
    pf_ee, pf_er = calculate_pf(basic, struct.pf_applicable)
    esi_ee, esi_er = calculate_esi(gross_monthly, struct.esi_applicable)
    pt = calculate_professional_tax(gross_monthly, struct.professional_tax_state)
    tds = await calculate_tds(employee_id, gross_monthly, month, year)

    # 8. Build entry
    entry = PayrollEntry(
        employee_id=employee_id,
        total_working_days=working_days,
        days_present=present_days,
        days_absent=absent_days,
        days_leave_paid=paid_leave_days,
        days_lop=lop_days,
        basic=basic,
        hra=hra,
        conveyance=conveyance,
        medical=medical,
        special_allowance=special,
        other_allowances=other_allow,
        arrears=0,
        overtime_pay=0,
        employee_pf=pf_ee,
        employer_pf=pf_er,
        employee_esi=esi_ee,
        employer_esi=esi_er,
        professional_tax=pt,
        tds=tds,
        loan_emi=0,
        advance_recovery=0
    )
    return entry
```

---

## 5. STATUTORY COMPLIANCE

### 5.1 PF Calculation

```python
def calculate_pf(basic_da: float, applicable: bool) -> tuple:
    """
    Employee PF: 12% of basic (capped at 15,000)
    Employer PF: 13% (12% PF + 0.5% EPS + 0.5% EDLIS)
    """
    if not applicable:
        return (0.0, 0.0)

    pf_wage = min(basic_da, 15000.0)  # Statutory ceiling
    employee_contribution = round(pf_wage * 0.12, 2)
    employer_pf = round(pf_wage * 0.12, 2)   # 3.67% PF + 8.33% EPS
    employer_eps = round(pf_wage * 0.0833, 2)  # EPS capped at 1,250
    employer_edlis = round(pf_wage * 0.005, 2)

    employer_total = round(employer_pf + employer_eps + employer_edlis, 2)
    return (employee_contribution, employer_total)
```

### 5.2 ESI Calculation

```python
def calculate_esi(gross_monthly: float, applicable: bool) -> tuple:
    """
    ESI applicable if gross <= 21,000 per month (25,000 for persons with disability)
    Employee: 0.75% of gross
    Employer: 3.25% of gross
    """
    if not applicable or gross_monthly > 21000:
        return (0.0, 0.0)

    employee_esi = round(gross_monthly * 0.0075, 2)
    employer_esi = round(gross_monthly * 0.0325, 2)
    return (employee_esi, employer_esi)
```

### 5.3 TDS Calculation

```python
async def calculate_tds(employee_id: UUID, current_month_gross: float,
                        month: int, year: int) -> float:
    """
    Calculate monthly TDS based on projected annual income.
    Uses previous months' actuals + projections for remaining months.
    """
    # 1. Sum actual gross for months already processed this financial year
    fy_start = 4 if month >= 4 else 4  # April start
    fy_year = year if month >= 4 else year - 1

    past_entries = await PayrollEntry.find({
        "employee_id": employee_id,
        "payroll_run_id": {
            "$in": await get_fy_payroll_run_ids(fy_year)
        }
    }).to_list()

    actual_gross = sum(e.gross_pay for e in past_entries)

    # 2. Project remaining months
    months_elapsed = month - fy_start + 1 if month >= fy_start else month + 12 - fy_start + 1
    months_remaining = 12 - months_elapsed
    projected_annual = actual_gross + (current_month_gross * months_remaining)

    # 3. Apply standard deduction
    std_deduction = 50000  # Standard deduction under new regime
    taxable_income = max(0, projected_annual - std_deduction)

    # 4. Apply old/new regime (default: new regime)
    tax = 0
    slabs = [
        (300000, 0.00),
        (300000, 0.05),   # 3-6L
        (300000, 0.10),   # 6-9L
        (300000, 0.15),   # 9-12L
        (300000, 0.20),   # 12-15L
        (float('inf'), 0.30)  # Above 15L
    ]

    remaining = taxable_income
    for slab_amount, rate in slabs:
        if remaining <= 0:
            break
        slab_taxable = min(remaining, slab_amount)
        tax += slab_taxable * rate
        remaining -= slab_taxable

    # 5. Add 4% health & education cess
    tax = round(tax * 1.04, 2)

    # 6. Monthly TDS = (total_tax - already_deducted) / remaining_months
    already_deducted = sum(e.tds for e in past_entries)
    remaining_tax = max(0, tax - already_deducted)
    monthly_tds = round(remaining_tax / months_remaining, 2) if months_remaining > 0 else 0

    return monthly_tds
```

---

## 6. BANK FILE EXPORT

### 6.1 Format Support

```yaml
bank_file_formats:
  icici:
    type: "CSV"
    columns: [Employee Name, Account Number, IFSC Code, Amount, Narrative]
    delimiter: ","
    header: true
  hdfc:
    type: "TXT"
    columns: [Account Number, IFSC, Amount, Beneficiary Name, Narration]
    fixed_width: true
    widths: [20, 11, 12, 30, 50]
  sbi:
    type: "XLSX"
    template: "SBI_SALARY_TEMPLATE.xlsx"
  generic_nach:
    type: "CSV"
    columns: [Beneficiary Code, Account Number, IFSC, Amount, Beneficiary Name]
```

### 6.2 Bank File Generator

```python
async def generate_bank_file(payroll_run_id: UUID,
                             bank_format: str = "icici") -> str:
    """
    Generate a bank transfer file for all employees in a payroll run.
    Returns URL to the generated file.
    """
    entries = await PayrollEntry.find({
        "payroll_run_id": payroll_run_id,
        "net_pay": {"$gt": 0}
    }).populate("employee_id").to_list()

    format_config = BANK_FORMATS[bank_format]
    rows = []

    for entry in entries:
        emp = entry.employee_id
        rows.append({
            "Employee Name": f"{emp.first_name} {emp.last_name}",
            "Account Number": entry.bank_account_no or emp.bank_account,
            "IFSC Code": entry.ifsc_code or emp.ifsc_code,
            "Amount": entry.net_pay,
            "Narrative": f"Salary {payroll_run.month}/{payroll_run.year}"
        })

    file_path = f"salary_bank_files/{payroll_run_id}_{bank_format}.csv"
    csv_content = generate_csv(rows, format_config["columns"])

    # Upload to cloud storage
    url = await upload_to_s3(file_path, csv_content)

    # Update payroll run record
    await PayrollRun.find_one({"_id": payroll_run_id}).update({
        "$set": {"bank_file_url": url}
    })

    return url
```

---

## 7. PAYSLIP GENERATION

```python
async def generate_payslip(entry_id: UUID) -> str:
    """
    Generate a PDF payslip for a payroll entry.
    Returns S3 URL of the generated PDF.
    """
    entry = await PayrollEntry.get(entry_id)
    emp = await Employee.get(entry.employee_id)
    struct = await SalaryStructure.get(entry.salary_structure_id)

    # Build payslip data
    data = {
        "hospital_name": "GIL Clinic",
        "employee_name": f"{emp.first_name} {emp.last_name}",
        "employee_code": emp.employee_code,
        "designation": emp.designation,
        "department": emp.department,
        "pan": emp.pan,
        "bank_account": entry.bank_account_no,
        "uan": emp.uan,                       # PF account number
        "month": entry.payroll_run_id.month,
        "year": entry.payroll_run_id.year,
        "working_days": {
            "total": entry.total_working_days,
            "present": entry.days_present,
            "absent": entry.days_absent,
            "paid_leave": entry.days_leave_paid,
            "lop": entry.days_lop
        },
        "earnings": {
            "Basic": entry.basic,
            "HRA": entry.hra,
            "Conveyance": entry.conveyance,
            "Medical": entry.medical,
            "Special Allowance": entry.special_allowance,
            "Other Allowances": entry.other_allowances,
            "Arrears": entry.arrears,
            "Overtime": entry.overtime_pay,
            "Gross Pay": entry.gross_pay
        },
        "deductions": {
            "Employee PF": entry.employee_pf,
            "Employer PF": entry.employer_pf,
            "Employee ESI": entry.employee_esi,
            "Employer ESI": entry.employer_esi,
            "Professional Tax": entry.professional_tax,
            "TDS": entry.tds,
            "Loan EMI": entry.loan_emi,
            "Advance Recovery": entry.advance_recovery,
            "Total Deductions": entry.total_deductions
        },
        "net_pay": entry.net_pay,
        "net_pay_words": number_to_words(int(entry.net_pay))
    }

    # Render PDF from template
    pdf_bytes = await render_pdf_template("payslip.html", data)
    file_path = f"payslips/{entry.payroll_run_id.year}/{entry.payroll_run_id.month}/{emp.employee_code}.pdf"

    url = await upload_to_s3(file_path, pdf_bytes)

    # Save payslip record
    await Payslip(
        payroll_entry_id=entry.id,
        employee_id=emp.id,
        month=entry.payroll_run_id.month,
        year=entry.payroll_run_id.year,
        pdf_url=url
    ).insert()

    return url
```

---

## 8. API ENDPOINTS

```yaml
salary_structure:
  list:
    method: GET
    path: /api/v1/payroll/salary-structures
    query_params: [employee_id, is_active, page, limit]
    roles: [admin, finance, hr_admin]

  create:
    method: POST
    path: /api/v1/payroll/salary-structures
    body: SalaryStructureInput
    roles: [admin, finance]

  get:
    method: GET
    path: /api/v1/payroll/salary-structures/{id}
    roles: [admin, finance, hr_admin, self]

payroll_run:
  init:
    method: POST
    path: /api/v1/payroll/runs
    body: { month, year }
    roles: [finance, admin]

  calculate:
    method: POST
    path: /api/v1/payroll/runs/{id}/calculate
    roles: [finance, admin]

  review:
    method: GET
    path: /api/v1/payroll/runs/{id}/summary
    roles: [admin, finance, hr_admin]

  approve:
    method: PATCH
    path: /api/v1/payroll/runs/{id}/approve
    roles: [admin, finance_manager]

  list:
    method: GET
    path: /api/v1/payroll/runs
    query_params: [year, status, page, limit]
    roles: [admin, finance, hr_admin]

payroll_entries:
  list:
    method: GET
    path: /api/v1/payroll/runs/{id}/entries
    query_params: [employee_id, department, page, limit]
    roles: [admin, finance, hr_admin]

  get:
    method: GET
    path: /api/v1/payroll/entries/{id}
    roles: [admin, finance, self]

payslip:
  generate_all:
    method: POST
    path: /api/v1/payroll/runs/{id}/payslips/generate
    roles: [finance, admin]

  my_payslip:
    method: GET
    path: /api/v1/payroll/payslips/my
    query_params: [month, year]
    roles: [all_employees]

  download:
    method: GET
    path: /api/v1/payroll/payslips/{id}/download
    roles: [admin, self, finance]

  email:
    method: POST
    path: /api/v1/payroll/payslips/{id}/email
    roles: [finance]

bank_file:
  generate:
    method: POST
    path: /api/v1/payroll/runs/{id}/bank-file
    query_params: [format]
    roles: [finance, admin]

  download:
    method: GET
    path: /api/v1/payroll/bank-files/{file_id}/download
    roles: [finance, admin]

arrears:
  create:
    method: POST
    path: /api/v1/payroll/arrears
    roles: [finance, admin]

  list:
    method: GET
    path: /api/v1/payroll/arrears
    query_params: [employee_id, status, page, limit]
    roles: [finance, admin, hr_admin]

compliance:
  pf_challan:
    method: GET
    path: /api/v1/payroll/compliance/pf/{run_id}
    roles: [finance, admin]

  esi_challan:
    method: GET
    path: /api/v1/payroll/compliance/esi/{run_id}
    roles: [finance, admin]

  tds_report:
    method: GET
    path: /api/v1/payroll/compliance/tds
    query_params: [quarter, year]
    roles: [finance, admin]

  form_16:
    method: GET
    path: /api/v1/payroll/compliance/form16/{employee_id}
    query_params: [year]
    roles: [self, finance, admin]
```

---

## 9. CONFIGURATION

```yaml
payroll_module:
  processing:
    auto_calculate: true
    require_approval: true          # Payroll must be approved before bank file
    payslip_auto_email: true
    payslip_email_day: 10

  pf:
    ceiling: 15000                  # Statutory PF wage ceiling
    employee_rate: 12.0             # %
    employer_pf_rate: 12.0
    employer_eps_rate: 8.33
    employer_edlis_rate: 0.5
    employer_admin_charges: 0.5
    auto_generate_challan: true

  esi:
    wage_limit: 21000               # Gross limit for ESI applicability
    employee_rate: 0.75
    employer_rate: 3.25
    auto_generate_challan: true

  professional_tax:
    enabled: true
    slabs:
      Karnataka:
        - max_gross: 15000
          amount: 0
        - max_gross: 20000
          amount: 150
        - max_gross: float('inf')
          amount: 200
      Maharashtra:
        - max_gross: 10000
          amount: 0
        - max_gross: 75000
          amount: 175
        - max_gross: float('inf')
          amount: 300

  tds:
    regime: "new"                   # new | old
    standard_deduction: 50000
    cess_rate: 4.0

  rounding:
    net_pay: "floor"                # floor | round | ceil
    deduction: "ceil"

  bank_file:
    default_format: "icici"
    encrypt_file: true
    password_protect: true
```

---

## 10. KEY DESIGN DECISIONS

1. **Attendance-driven proration** -- Salary is prorated based on actual working days using LOP (Loss of Pay) logic. Paid leaves do not reduce salary; only absent days beyond approved leave balance trigger LOP. This is calculated at the per-day component level, not just on gross.

2. **TDS is projected, not retrospective** -- Monthly TDS is calculated by projecting annual income (actual past months + remaining months estimate). This prevents a large tax burden in the last month of the financial year and keeps monthly take-home pay consistent.

3. **Salary structures are temporal with effective dates** -- `effective_from` and `effective_to` allow salary revisions mid-year. The payroll run picks the structure active on the 1st of the processing month. Historical payroll entries retain a snapshot of the structure used.

4. **Bank details are snapshotted per payroll entry** -- Rather than reading the employee's current bank account at disbursal time, the bank account and IFSC are copied into the payroll entry at calculation time. This prevents payment to the wrong account if the employee changes bank details after payroll is approved.

5. **Employer PF/ESI contributions are tracked separately** -- The payroll entry includes both employee and employer statutory contributions. This enables generation of PF/ESI challans and form reporting without separate calculation.

6. **Payslip generation is decoupled from calculation** -- Payslips are generated as a distinct step after payroll approval. This allows regeneration (e.g., if the template changes) without recalculating the payroll.

7. **Arrears are a separate table** -- Salary corrections from prior periods are tracked via the `payroll_arrears` table and added as a line item in the current month's payroll. Each arrears entry specifies the original period, reason, and approval trail.

8. **Rounding rules are explicit** -- Net pay is floored to the nearest paisa (not rounded) so the total disbursed never exceeds the computed total. Deductions are ceiling-rounded so the employee never owes a shortfall.
