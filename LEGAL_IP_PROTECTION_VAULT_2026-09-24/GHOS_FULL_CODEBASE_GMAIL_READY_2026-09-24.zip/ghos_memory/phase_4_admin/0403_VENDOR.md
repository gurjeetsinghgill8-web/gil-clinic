---
file_id: "0403"
module_name: "Vendor Module"
version: "2.0"
status: "Approved"
phase: "Phase 4 — Admin"
dependencies: ["0402_PURCHASE.md", "0401_INVENTORY.md"]
related_files: ["0406_FINANCE.md", "0407_GST.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "vendor", "supplier", "supply-chain", "gst", "procurement"]
---

# GHOS — Vendor Module

> Manages vendor/supplier lifecycle from registration through performance rating, price negotiation, and GST-compliant procurement.

---

## 1. PURPOSE

Centralize all vendor-related data and workflows so procurement, finance, and GST compliance teams operate from a single source of truth. Every purchase order in [0402_PURCHASE.md] references a vendor registered here.

---

## 2. VENDOR LIFECYCLE

```
        ┌──────────────┐
        │ APPLICATION  │  ← Vendor submits registration request
        └──────┬───────┘
               │ admin approves (GSTIN + PAN + bank verification)
               ▼
        ┌──────────────┐
        │ ACTIVE       │  ← Can receive POs, supply items
        └──────┬───────┘
               │
     ┌─────────┼──────────┐
     │         │          │
     ▼         ▼          ▼
  SUSPENDED  BLACKLISTED  INACTIVE
  (temp)     (permanent)  (voluntary)
```

### 2.1 Vendor Registration (Self-Service Portal)

```python
async def register_vendor(data: VendorRegistrationInput) -> Vendor:
    """
    Register a new vendor. Performs automatic GSTIN/PAN verification
    before creating the record.
    """
    # 1. Verify GSTIN via GST API
    gst_valid = await verify_gstin(data.gstin)
    if not gst_valid:
        raise ValidationError("Invalid or inactive GSTIN")

    # 2. Verify PAN via income-tax API
    pan_valid = await verify_pan(data.pan)
    if not pan_valid:
        raise ValidationError("PAN does not match GSTIN")

    # 3. Check for existing vendor with same GSTIN
    existing = await Vendor.find_one({"gstin": data.gstin})
    if existing:
        raise ConflictError("Vendor with this GSTIN already exists")

    # 4. Geocode address for delivery zone tagging
    geo = await geocode(f"{data.address}, {data.city}, {data.state}")

    # 5. Create vendor record
    vendor = Vendor(
        name=data.name,
        legal_name=data.legal_name,
        gstin=data.gstin,
        pan=data.pan,
        contact_person=data.contact_person,
        email=data.email,
        phone=data.phone,
        alternative_phone=data.alternative_phone,
        address=data.address,
        city=data.city,
        state=data.state,
        pincode=data.pincode,
        latitude=geo.lat,
        longitude=geo.lng,
        delivery_zone=infer_zone(geo),
        payment_terms=data.payment_terms,  # e.g. "NET30", "NET45", "COD"
        bank_account=data.bank_account,
        ifsc_code=data.ifsc_code,
        bank_name=data.bank_name,
        categories=data.categories,  # e.g. ["Lab Reagents", "Stationery"]
        status="active",
        rating=0.0,
        total_orders=0,
        created_at=datetime.utcnow()
    )
    await vendor.insert()

    # 6. Send welcome notification
    await notify_vendor(vendor.id, "welcome", {
        "vendor_name": vendor.name,
        "vendor_code": vendor.code
    })

    return vendor
```

---

## 3. DATA MODEL

### 3.1 vendors Table (PostgreSQL)

```sql
CREATE TABLE vendors (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(20) UNIQUE NOT NULL,       -- Auto-generated, e.g. VND-00042
    name            VARCHAR(200) NOT NULL,
    legal_name      VARCHAR(200) NOT NULL,
    gstin           VARCHAR(15) UNIQUE NOT NULL,       -- 15-char GST number
    pan             VARCHAR(10) NOT NULL,              -- 10-char PAN
    contact_person  VARCHAR(100),
    email           VARCHAR(200) NOT NULL,
    phone           VARCHAR(20) NOT NULL,
    alternative_phone VARCHAR(20),
    address         TEXT NOT NULL,
    city            VARCHAR(100) NOT NULL,
    state           VARCHAR(100) NOT NULL,
    pincode         VARCHAR(10) NOT NULL,
    latitude        DECIMAL(10,7),
    longitude       DECIMAL(10,7),
    delivery_zone   VARCHAR(50),                       -- "north", "south", "east", "west", "pan-india"
    payment_terms   VARCHAR(20) NOT NULL DEFAULT 'NET30',
    credit_limit    DECIMAL(12,2) DEFAULT 0,
    bank_account    VARCHAR(30),
    ifsc_code       VARCHAR(11),
    bank_name       VARCHAR(100),
    categories      TEXT[],                             -- Array of category slugs
    status          VARCHAR(20) NOT NULL DEFAULT 'active',
                    -- active | suspended | blacklisted | inactive
    rating          DECIMAL(3,2) DEFAULT 0.00,          -- 0.00 to 5.00
    total_orders    INTEGER DEFAULT 0,
    total_amount    DECIMAL(14,2) DEFAULT 0.00,
    last_order_date TIMESTAMP,
    notes           TEXT,
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vendors_gstin ON vendors(gstin);
CREATE INDEX idx_vendors_status ON vendors(status);
CREATE INDEX idx_vendors_city ON vendors(city);
CREATE INDEX idx_vendors_categories ON vendors USING GIN(categories);
CREATE INDEX idx_vendors_rating ON vendors(rating DESC);
```

### 3.2 vendor_price_list Table

```sql
CREATE TABLE vendor_price_list (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id       UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    item_id         UUID NOT NULL REFERENCES inventory_items(id),
    unit_price      DECIMAL(12,2) NOT NULL,
    moq             INTEGER DEFAULT 1,                 -- Minimum Order Quantity
    lead_time_days  INTEGER,                            -- Days to deliver
    discount_pct    DECIMAL(5,2) DEFAULT 0.00,
    effective_from  DATE NOT NULL,
    effective_to    DATE,                               -- NULL = currently active
    is_active       BOOLEAN DEFAULT TRUE,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW(),

    CONSTRAINT unique_vendor_item_active
        UNIQUE (vendor_id, item_id, effective_from)
);

CREATE INDEX idx_vpl_vendor ON vendor_price_list(vendor_id);
CREATE INDEX idx_vpl_item ON vendor_price_list(item_id);
CREATE INDEX idx_vpl_active ON vendor_price_list(is_active);
```

### 3.3 vendor_ratings Table

```sql
CREATE TABLE vendor_ratings (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id       UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    purchase_order_id UUID NOT NULL REFERENCES purchase_orders(id),
    delivery_time_score  INTEGER CHECK (delivery_time_score BETWEEN 1 AND 5),
    quality_score        INTEGER CHECK (quality_score BETWEEN 1 AND 5),
    price_score          INTEGER CHECK (price_score BETWEEN 1 AND 5),
    overall_score        DECIMAL(3,2) GENERATED ALWAYS AS (
        (delivery_time_score + quality_score + price_score) / 3.0
    ) STORED,
    comments        TEXT,
    rated_by        UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMP NOT NULL DEFAULT NOW()
);

CREATE INDEX idx_vendor_ratings_vendor ON vendor_ratings(vendor_id);
```

### 3.4 vendor_payments Table

```sql
CREATE TABLE vendor_payments (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id       UUID NOT NULL REFERENCES vendors(id),
    purchase_order_id UUID REFERENCES purchase_orders(id),
    invoice_number  VARCHAR(100),
    invoice_date    DATE NOT NULL,
    invoice_amount  DECIMAL(12,2) NOT NULL,
    tds_amount      DECIMAL(12,2) DEFAULT 0.00,
    net_payable     DECIMAL(12,2) GENERATED ALWAYS AS
                    (invoice_amount - tds_amount) STORED,
    payment_status  VARCHAR(20) NOT NULL DEFAULT 'pending',
                    -- pending | approved | paid | cancelled
    payment_date    DATE,
    payment_mode    VARCHAR(30),                       -- bank_transfer | cheque | cash | upi
    transaction_ref VARCHAR(200),
    paid_amount     DECIMAL(12,2),
    due_date        DATE NOT NULL,
    created_at      TIMESTAMP NOT NULL DEFAULT NOW(),
    updated_at      TIMESTAMP NOT NULL DEFAULT NOW()
);
```

### 3.5 vendor_documents Table

```sql
CREATE TABLE vendor_documents (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id       UUID NOT NULL REFERENCES vendors(id) ON DELETE CASCADE,
    document_type   VARCHAR(50) NOT NULL,
                    -- gst_certificate | cancelled_cheque | pan_card |
                    -- msme_certificate | agreement | other
    document_url    TEXT NOT NULL,                      -- S3/Cloudinary URL
    document_number VARCHAR(100),                       -- e.g. GSTIN
    verified        BOOLEAN DEFAULT FALSE,
    verified_by     UUID REFERENCES users(id),
    verified_at     TIMESTAMP,
    uploaded_at     TIMESTAMP NOT NULL DEFAULT NOW(),
    expiry_date     DATE                               -- For certificates that expire
);
```

---

## 4. VENDOR RATING ALGORITHM

```python
async def recalculate_vendor_rating(vendor_id: UUID) -> float:
    """
    Calculate the weighted average rating across all completed POs.
    Recent ratings (last 90 days) get 2x weight.
    """
    ratings = await VendorRating.find(
        {"vendor_id": vendor_id}
    ).sort("created_at", -1).to_list()

    if not ratings:
        return 0.0

    total_weight = 0
    weighted_sum = 0
    cutoff = datetime.utcnow() - timedelta(days=90)

    for r in ratings:
        weight = 2 if r.created_at >= cutoff else 1
        weighted_sum += r.overall_score * weight
        total_weight += weight

    final_rating = round(weighted_sum / total_weight, 2)

    # Update vendor record
    await Vendor.find_one({"_id": vendor_id}).update(
        {"$set": {"rating": final_rating}}
    )

    return final_rating
```

---

## 5. PRICE LIST MANAGEMENT

### 5.1 Price Revision Workflow

```yaml
price_revision:
  triggers:
    - vendor_submits_new_price
    - contract_renewal
    - market_rate_change_detected
  approval_flow:
    - step: 1
      role: "purchase_manager"
      action: "review_price_change"
    - step: 2
      role: "finance_manager"
      action: "approve"  # auto-approve if change < 10%
    - step: 3
      role: "admin"
      action: "final_approval"  # required if change > 20%
  effective:
    from_date: "negotiated"
    to_date: "next_revision_or_contract_end"
  notification:
    - procurement_team
    - inventory_manager
```

### 5.2 Best Price Selection

```python
async def get_best_vendor(item_id: UUID, quantity: int,
                          delivery_pincode: str) -> dict:
    """
    Find the best vendor for an item based on price, rating,
    lead time, and delivery zone coverage.
    """
    candidates = await VendorPriceList.find({
        "item_id": item_id,
        "is_active": True,
        "effective_from": {"$lte": date.today()},
        "$or": [
            {"effective_to": None},
            {"effective_to": {"$gte": date.today()}}
        ]
    }).populate("vendor").to_list()

    scored = []
    for cpl in candidates:
        vendor = cpl.vendor
        if vendor.status != "active":
            continue

        # Skip if vendor doesn't cover this pincode's zone
        if not covers_zone(vendor.delivery_zone, delivery_pincode):
            continue

        # Skip if quantity below MOQ
        if quantity < cpl.moq:
            continue

        # Composite score: lower is better
        price_score = cpl.unit_price * (1 - cpl.discount_pct / 100)
        rating_factor = (5 - vendor.rating) / 5  # higher rating = lower factor
        lead_time_factor = cpl.lead_time_days / 30  # normalized to month

        composite = (price_score * 0.6 +
                     rating_factor * 100 * 0.25 +
                     lead_time_factor * 0.15)

        scored.append({
            "vendor_id": vendor.id,
            "vendor_name": vendor.name,
            "unit_price": cpl.unit_price,
            "discounted_price": price_score,
            "rating": vendor.rating,
            "lead_time_days": cpl.lead_time_days,
            "composite_score": round(composite, 2)
        })

    scored.sort(key=lambda x: x["composite_score"])
    return scored[:3]  # Top 3 recommendations
```

---

## 6. GST COMPLIANCE

### 6.1 Vendor GSTIN Verification

```python
async def verify_gstin(gstin: str) -> dict:
    """
    Verify GSTIN against the Government GST portal API.
    Returns taxpayer details if valid.
    """
    # GSTIN format: 2-digit state + 10-char PAN + 1-entity + 1-blank + 1-check
    if not re.match(r'^[0-9]{2}[A-Z]{5}[0-9]{4}[A-Z]{1}[1-9A-Z]{1}Z[0-9A-Z]{1}$', gstin):
        return {"valid": False, "error": "Invalid GSTIN format"}

    # Call GST API (mock implementation)
    response = await http_client.post(
        "https://api.gst.gov.in/verification",
        json={"gstin": gstin},
        headers={"Authorization": f"Bearer {GST_API_KEY}"}
    )

    if response.status_code != 200:
        return {"valid": False, "error": "GST API unavailable"}

    data = response.json()
    return {
        "valid": data["status"] == "ACTIVE",
        "legal_name": data["legalName"],
        "trade_name": data.get("tradeName"),
        "state": data["state"],
        "registration_date": data.get("registrationDate"),
        "last_return_filed": data.get("lastReturnFiled"),
        "taxpayer_type": data.get("taxpayerType")  # Regular, Composition, etc.
    }
```

### 6.2 TDS on Vendor Payments

```yaml
tds_rules:
  section_194C:
    threshold_per_contract: 30000   # TDS applicable if > 30,000 per contract
    threshold_aggregate: 100000     # or > 1,00,000 annually
    rate_individual_huf: 1.0        # 1% for individual/HUF
    rate_others: 2.0                # 2% for others
  section_194J:
    description: "Professional/Technical services"
    threshold: 30000
    rate: 10.0                      # 10% for professional services
  section_194H:
    description: "Commission/Brokerage"
    threshold: 15000
    rate: 5.0
```

---

## 7. VENDOR CATEGORIES

```yaml
vendor_categories:
  lab_reagents:
    description: "Chemicals, reagents, test kits"
    requires_license: true
    requires_quality_cert: true
  medical_equipment:
    description: "Machines, instruments, devices"
    requires_license: true
    warranty_required: true
  pharmaceuticals:
    description: "Medicines, vaccines, supplements"
    requires_drug_license: true
    requires_gmp_cert: true
  consumables:
    description: "Gloves, syringes, masks, disposables"
    requires_license: false
  stationery:
    description: "Paper, pens, office supplies"
    requires_license: false
  it_services:
    description: "Software, hardware, support"
    requires_license: false
  facility_maintenance:
    description: "Cleaning, plumbing, electrical, AMC"
    requires_license: false
  food_and_catering:
    description: "Patient meals, staff canteen"
    requires_fssai: true
```

---

## 8. API ENDPOINTS

```yaml
vendors:
  list:
    method: GET
    path: /api/v1/vendors
    query_params: [status, category, city, search, rating_min, page, limit]
    roles: [purchase_manager, admin, finance]

  create:
    method: POST
    path: /api/v1/vendors
    body: VendorRegistrationInput
    roles: [admin, purchase_manager]

  get:
    method: GET
    path: /api/v1/vendors/{id}
    roles: [purchase_manager, admin, finance, lab_technician]

  update:
    method: PUT
    path: /api/v1/vendors/{id}
    roles: [admin]

  change_status:
    method: PATCH
    path: /api/v1/vendors/{id}/status
    body: { status: "suspended" | "active" | "blacklisted" }
    roles: [admin]

vendor_price_list:
  list:
    method: GET
    path: /api/v1/vendors/{id}/prices
    query_params: [item_id, is_active, page, limit]
    roles: [purchase_manager, admin, inventory_manager]

  add:
    method: POST
    path: /api/v1/vendors/{id}/prices
    body: PriceListEntryInput
    roles: [purchase_manager, admin]

  update:
    method: PUT
    path: /api/v1/vendors/{id}/prices/{price_id}
    roles: [purchase_manager, admin]

  best_price:
    method: GET
    path: /api/v1/vendors/best-price
    query_params: [item_id, quantity, pincode]
    roles: [purchase_manager, admin, inventory_manager]

vendor_ratings:
  rate:
    method: POST
    path: /api/v1/purchase-orders/{po_id}/rate-vendor
    body: VendorRatingInput
    roles: [purchase_manager, lab_technician]

  history:
    method: GET
    path: /api/v1/vendors/{id}/ratings
    roles: [purchase_manager, admin]

vendor_payments:
  list:
    method: GET
    path: /api/v1/vendors/{id}/payments
    query_params: [status, from_date, to_date, page, limit]
    roles: [finance, admin]

  create:
    method: POST
    path: /api/v1/vendor-payments
    body: VendorPaymentInput
    roles: [finance]

  update_status:
    method: PATCH
    path: /api/v1/vendor-payments/{id}/status
    body: { payment_status, transaction_ref, payment_date }
    roles: [finance]

vendor_documents:
  upload:
    method: POST
    path: /api/v1/vendors/{id}/documents
    body: multipart/form-data (file + document_type)
    roles: [vendor_admin, admin]

  verify:
    method: PATCH
    path: /api/v1/vendors/{id}/documents/{doc_id}/verify
    roles: [admin]

gst_verification:
  verify:
    method: POST
    path: /api/v1/gst/verify
    body: { gstin }
    roles: [purchase_manager, admin, finance]
```

---

## 9. CONFIGURATION

```yaml
vendor_module:
  auto_generate_code: true
  code_prefix: "VND-"
  code_padding: 5

  gst:
    verification_enabled: true
    api_endpoint: "https://api.gst.gov.in/v1/verification"
    cache_ttl_hours: 24
    auto_block_on_expiry: true  # Block vendor if GSTIN lapses

  rating:
    auto_calculate: true
    weight_recent_90_days: 2.0
    min_ratings_for_display: 3

  credit_limit:
    enabled: true
    default_limit: 500000
    hard_cap: 5000000

  notifications:
    on_blacklist: true
    on_document_expiry: true  # 30-day before expiry reminder
    on_gstin_expiry: true
    on_payment_due: true      # 7-day before due date
    on_price_revision: true
```

---

## 10. KEY DESIGN DECISIONS

1. **GSTIN as unique identifier** -- Each vendor must have a unique GSTIN. We verify it against the Government GST portal at registration and cache the result for 24 hours.

2. **Composite vendor score** -- Best-price selection uses a weighted formula (60% price, 25% rating, 15% lead time) rather than pure price comparison, preventing a pattern of choosing the cheapest vendor despite poor reliability.

3. **Temporal price lists** -- Price lists have `effective_from` and `effective_to` dates so historical pricing is preserved for audit and cost analysis. Only rows with `is_active=true` and dates covering today are considered for procurement.

4. **Delivery zone tagging** -- Vendors are geocoded and assigned a delivery zone at registration. This filters out vendors who can't deliver to the clinic's pincode before scoring.

5. **TDS calculation is configurable per section** -- Rather than hardcoding TDS rates, the system reads thresholds and rates from configuration so changes in tax law don't require a deployment.

6. **Document expiry tracking** -- Vendor documents (GST certificate, MSME cert) have expiry dates. The system auto-notifies the vendor 30 days before expiry and can suspend the vendor if documents lapse.

7. **Rating recency weighting** -- Vendor ratings from the last 90 days count double, so a vendor who has improved (or degraded) recently is rated more accurately than one with stale scores.
