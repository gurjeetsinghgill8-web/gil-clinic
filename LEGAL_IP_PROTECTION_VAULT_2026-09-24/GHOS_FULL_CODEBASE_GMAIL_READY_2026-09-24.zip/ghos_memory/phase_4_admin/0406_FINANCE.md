---
file_id: "0406"
module_name: "Finance Module"
version: "2.0"
status: "Approved"
phase: "Phase 4 — Admin"
dependencies: ["0400_BILLING.md", "0405_PAYROLL.md", "0402_PURCHASE.md"]
related_files: ["0407_GST.md", "0403_VENDOR.md", "0401_PATIENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "finance", "accounting", "books", "p&l", "balance-sheet", "cash-flow", "reconciliation"]
---

# GHOS — Finance & Accounting Module

```
  ___ _                 _           ___ _   _ _   ___ ___  ___
 | __(_)___ _ _   __ _| |___ ___  | __/_\ | \ | | / __/ _ \|   \ ___ ___
 | _|| / -_) ' \ / _` | / -_|_-<  | _/ _ \|  \| || (_| (_) | |) / -_|_-<
 |_| |_\___|_||_|\__,_|_\___/__/  |_/_/ \_\_|\__| \___\___/|___/\___/__/
```

## 1. PURPOSE

Provide a complete double-entry accounting engine for the clinic — fully automated journal posting from billing, purchases, payroll, and receipts. Generates financial statements (P&L, Balance Sheet, Cash Flow) and supports day-to-day bookkeeping operations (day book, ledger, bank reconciliation, expense tracking). Designed for India GAAP with optional IFRS mapping.

## 2. SCOPE

| Area                    | Covered |
|-------------------------|---------|
| Chart of Accounts       | Full    |
| Journal Entries         | Full    |
| Profit & Loss Statement | Full    |
| Balance Sheet           | Full    |
| Cash Flow Statement     | Full    |
| Day Book / Ledger       | Full    |
| Bank Reconciliation     | Full    |
| Expense Tracking        | Full    |
| Accounts Receivable     | Full    |
| Accounts Payable        | Full    |
| Financial Period Close  | Full    |
| Audit Trail / Logging   | Full    |
| Multi-currency          | Phase 5 |

## 3. DATA MODEL

### 3.1 Chart of Accounts

```sql
CREATE TABLE chart_of_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_code    VARCHAR(20) NOT NULL UNIQUE,        -- e.g., "1010", "4010"
    account_name    VARCHAR(120) NOT NULL,
    account_type    VARCHAR(30) NOT NULL CHECK (account_type IN (
                        'ASSET','LIABILITY','EQUITY','INCOME','EXPENSE'
                    )),
    is_control      BOOLEAN NOT NULL DEFAULT FALSE,     -- control account flag
    parent_id       UUID REFERENCES chart_of_accounts(id),
    is_active       BOOLEAN NOT NULL DEFAULT TRUE,
    normal_balance  VARCHAR(5) NOT NULL CHECK (normal_balance IN ('DR','CR')),
    gst_applicable  BOOLEAN NOT NULL DEFAULT FALSE,
    hsn_sac_code    VARCHAR(20),                         -- for revenue/expense accounts
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_coa_type ON chart_of_accounts(account_type);
CREATE INDEX idx_coa_code ON chart_of_accounts(account_code);
```

### 3.2 Journal Entries

```sql
CREATE TABLE journal_batches (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_ref       VARCHAR(30) NOT NULL UNIQUE,         -- "JV-20260709-001"
    source_module   VARCHAR(30) NOT NULL,                -- 'BILLING','PURCHASE','PAYROLL','MANUAL'
    source_ref_id   UUID,                                -- ID in source table
    description     TEXT NOT NULL,
    entry_date      DATE NOT NULL,
    fiscal_period   VARCHAR(10) NOT NULL,                -- "2026-07"
    posted_by       UUID NOT NULL REFERENCES users(id),
    posted_at       TIMESTAMPTZ NOT NULL DEFAULT now(),
    is_adjustment   BOOLEAN NOT NULL DEFAULT FALSE,
    status          VARCHAR(20) NOT NULL DEFAULT 'POSTED' CHECK (status IN (
                        'DRAFT','POSTED','REVERSED'
                    ))
);

CREATE TABLE journal_entries (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    batch_id        UUID NOT NULL REFERENCES journal_batches(id) ON DELETE CASCADE,
    account_id      UUID NOT NULL REFERENCES chart_of_accounts(id),
    debit_amount    NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    credit_amount   NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    narration       TEXT,
    line_order      INT NOT NULL,
    CHECK (debit_amount >= 0 AND credit_amount >= 0),
    CHECK ((debit_amount > 0 AND credit_amount = 0) OR
           (debit_amount = 0 AND credit_amount > 0))
);

CREATE INDEX idx_je_batch ON journal_entries(batch_id);
CREATE INDEX idx_je_account ON journal_entries(account_id);
CREATE INDEX idx_jb_date ON journal_batches(entry_date);
CREATE INDEX idx_jb_period ON journal_batches(fiscal_period);
```

### 3.3 Accounts Receivable / Payable

```sql
CREATE TABLE accounts_receivable (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id      UUID NOT NULL REFERENCES invoices(id),
    patient_id      UUID REFERENCES patients(id),
    total_amount    NUMERIC(14,2) NOT NULL,
    paid_amount     NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    due_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
                        'PENDING','PARTIAL','PAID','OVERDUE','WRITTEN_OFF'
                    )),
    aging_bucket    VARCHAR(20) GENERATED ALWAYS AS (
                        CASE
                            WHEN due_date >= CURRENT_DATE THEN 'CURRENT'
                            WHEN due_date >= CURRENT_DATE - INTERVAL '30 days' THEN '1-30'
                            WHEN due_date >= CURRENT_DATE - INTERVAL '60 days' THEN '31-60'
                            WHEN due_date >= CURRENT_DATE - INTERVAL '90 days' THEN '61-90'
                            ELSE '90+'
                        END
                    ) STORED
);

CREATE TABLE accounts_payable (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    purchase_id     UUID REFERENCES purchases(id),
    vendor_id       UUID NOT NULL REFERENCES vendors(id),
    total_amount    NUMERIC(14,2) NOT NULL,
    paid_amount     NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    due_date        DATE NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'PENDING' CHECK (status IN (
                        'PENDING','PARTIAL','PAID','OVERDUE'
                    ))
);
```

### 3.4 Bank Reconciliation

```sql
CREATE TABLE bank_accounts (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    account_name    VARCHAR(100) NOT NULL,
    bank_name       VARCHAR(100) NOT NULL,
    account_number  VARCHAR(30) NOT NULL UNIQUE,
    ifsc_code       VARCHAR(20),
    opening_balance NUMERIC(14,2) NOT NULL DEFAULT 0.00,
    as_of_date      DATE NOT NULL,
    is_active       BOOLEAN NOT NULL DEFAULT TRUE
);

CREATE TABLE bank_transactions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bank_account_id UUID NOT NULL REFERENCES bank_accounts(id),
    txn_date        DATE NOT NULL,
    reference_no    VARCHAR(50),
    description     TEXT NOT NULL,
    amount          NUMERIC(14,2) NOT NULL,              -- positive = deposit, negative = withdrawal
    reconciled      BOOLEAN NOT NULL DEFAULT FALSE,
    reconciled_at   TIMESTAMPTZ,
    matched_journal_entry_id UUID REFERENCES journal_entries(id)
);

CREATE TABLE reconciliation_runs (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    bank_account_id UUID NOT NULL REFERENCES bank_accounts(id),
    statement_date  DATE NOT NULL,
    closing_balance NUMERIC(14,2) NOT NULL,
    difference      NUMERIC(14,2) NOT NULL,
    status          VARCHAR(20) NOT NULL DEFAULT 'IN_PROGRESS' CHECK (status IN (
                        'IN_PROGRESS','COMPLETE','DISCREPANCY'
                    )),
    reconciled_by   UUID REFERENCES users(id),
    reconciled_at   TIMESTAMPTZ
);
```

### 3.5 Expense Tracking

```sql
CREATE TABLE expenses (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    vendor_id       UUID REFERENCES vendors(id),
    category_id     UUID NOT NULL REFERENCES chart_of_accounts(id),
    amount          NUMERIC(14,2) NOT NULL,
    expense_date    DATE NOT NULL,
    payment_mode    VARCHAR(20) CHECK (payment_mode IN ('CASH','BANK','UPI','CARD','CHEQUE')),
    receipt_url     TEXT,
    notes           TEXT,
    is_billable     BOOLEAN NOT NULL DEFAULT FALSE,
    project_id      UUID REFERENCES projects(id),
    created_by      UUID NOT NULL REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);
```

### 3.6 Financial Period & Closing

```sql
CREATE TABLE fiscal_periods (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    fiscal_year     VARCHAR(10) NOT NULL,                -- "2026-2027"
    period_month    INT NOT NULL CHECK (period_month BETWEEN 1 AND 12),
    start_date      DATE NOT NULL,
    end_date        DATE NOT NULL,
    is_closed       BOOLEAN NOT NULL DEFAULT FALSE,
    closed_by       UUID REFERENCES users(id),
    closed_at       TIMESTAMPTZ,
    UNIQUE(fiscal_year, period_month)
);
```

## 4. AUTO-POSTING RULES

Every billing/sale event auto-generates journal entries:

| Source Event           | Debit Account         | Credit Account        | Notes                          |
|------------------------|-----------------------|-----------------------|--------------------------------|
| Invoice (Patient)      | Accounts Receivable   | Revenue / Income      | Service revenue recognised     |
| Invoice (Patient)      | Receivable (GST)      | Output GST Payable    | GST component split            |
| Payment Received       | Bank / Cash           | Accounts Receivable   | Realisation                     |
| Purchase (Vendor)      | Expense / Asset       | Accounts Payable      | Expense recognition            |
| Purchase (Vendor)      | Input GST Credit      | Payable (GST)         | ITC claimed                    |
| Payment to Vendor      | Accounts Payable      | Bank / Cash           | Settlement                     |
| Payroll Run            | Salary Expense        | Salary Payable        | Accrual                        |
| Payroll Payment        | Salary Payable        | Bank                  | Disbursement                   |
| Depreciation           | Depreciation Expense  | Accum. Depreciation   | Period-end                     |
| Period Close           | Revenue Summary       | Retained Earnings     | P&L closure                    |

## 5. FINANCIAL STATEMENTS (Python Engine)

```python
"""finance_statements.py — Financial statement generators for GHOS Finance Module."""

from dataclasses import dataclass, field
from datetime import date, datetime
from decimal import Decimal
from typing import Optional
import json


@dataclass
class FinancialPeriod:
    fiscal_year: str
    start_date: date
    end_date: date


@dataclass
class TrialBalanceRow:
    account_code: str
    account_name: str
    account_type: str
    debit_total: Decimal
    credit_total: Decimal

    @property
    def balance(self) -> Decimal:
        return self.debit_total - self.credit_total


@dataclass
class ProfitAndLossItem:
    label: str
    amount: Decimal
    is_total: bool = False
    children: list['ProfitAndLossItem'] = field(default_factory=list)


@dataclass
class BalanceSheetItem:
    label: str
    amount: Decimal
    is_total: bool = False
    children: list['BalanceSheetItem'] = field(default_factory=list)


class FinancialStatementEngine:
    """
    Generates P&L, Balance Sheet, and Cash Flow from journal entry data.
    All amounts in INR. Uses accrual basis — India GAAP compliant.
    """

    COA_GROUPS = {
        'INCOME': {
            'ranges': ['4000', '4999'],
            'exclude': ['4500']  # e.g., other income mapped separately
        },
        'EXPENSE': {
            'ranges': ['5000', '5999', '6000', '6999'],
        },
        'ASSET': {
            'ranges': ['1000', '1999'],
        },
        'LIABILITY': {
            'ranges': ['2000', '2999'],
        },
        'EQUITY': {
            'ranges': ['3000', '3999'],
        },
    }

    def generate_trial_balance(
        self,
        conn,
        period: FinancialPeriod
    ) -> list[TrialBalanceRow]:
        """Fetch period-ending trial balance from posted journal entries."""
        query = """
            SELECT
                coa.account_code,
                coa.account_name,
                coa.account_type,
                COALESCE(SUM(je.debit_amount), 0) AS debit_total,
                COALESCE(SUM(je.credit_amount), 0) AS credit_total
            FROM journal_entries je
            JOIN journal_batches jb ON je.batch_id = jb.id
            JOIN chart_of_accounts coa ON je.account_id = coa.id
            WHERE jb.entry_date BETWEEN %s AND %s
              AND jb.status = 'POSTED'
            GROUP BY coa.account_code, coa.account_name, coa.account_type
            ORDER BY coa.account_code;
        """
        # Execute with conn.cursor() — omitted for brevity
        rows: list[dict] = []  # placeholder — real DB call
        return [TrialBalanceRow(**r) for r in rows]

    def generate_profit_and_loss(
        self,
        conn,
        period: FinancialPeriod
    ) -> ProfitAndLossItem:
        """Generate hierarchical P&L statement."""
        trial = self.generate_trial_balance(conn, period)
        income = [r for r in trial if r.account_type == 'INCOME']
        expense = [r for r in trial if r.account_type == 'EXPENSE']

        total_income = sum(r.balance for r in income)
        total_expense = sum(r.balance for r in expense)
        net_profit = total_income - total_expense

        return ProfitAndLossItem(
            label='Profit & Loss Statement',
            amount=Decimal('0.00'),
            is_total=False,
            children=[
                ProfitAndLossItem(
                    label='Revenue',
                    amount=Decimal('0.00'),
                    children=[ProfitAndLossItem(
                        label=r.account_name,
                        amount=r.balance
                    ) for r in income if r.balance != 0]
                ),
                ProfitAndLossItem(
                    label='Total Revenue',
                    amount=total_income,
                    is_total=True
                ),
                ProfitAndLossItem(
                    label='Expenses',
                    amount=Decimal('0.00'),
                    children=[ProfitAndLossItem(
                        label=r.account_name,
                        amount=r.balance
                    ) for r in expense if r.balance != 0]
                ),
                ProfitAndLossItem(
                    label='Total Expenses',
                    amount=total_expense,
                    is_total=True
                ),
                ProfitAndLossItem(
                    label='Net Profit / (Loss)',
                    amount=net_profit,
                    is_total=True
                ),
            ]
        )

    def generate_balance_sheet(
        self,
        conn,
        as_of_date: date
    ) -> BalanceSheetItem:
        """Generate balance sheet as of a given date."""
        query = """
            SELECT
                coa.account_code,
                coa.account_name,
                coa.account_type,
                COALESCE(SUM(je.debit_amount), 0) -
                COALESCE(SUM(je.credit_amount), 0) AS balance
            FROM journal_entries je
            JOIN journal_batches jb ON je.batch_id = jb.id
            JOIN chart_of_accounts coa ON je.account_id = coa.id
            WHERE jb.entry_date <= %s AND jb.status = 'POSTED'
            GROUP BY coa.account_code, coa.account_name, coa.account_type
            ORDER BY coa.account_code;
        """
        # Execute — placeholder
        rows: list[dict] = []

        assets = [r for r in rows if r['account_type'] == 'ASSET' and r['balance'] > 0]
        liabilities = [r for r in rows if r['account_type'] == 'LIABILITY' and r['balance'] < 0]
        equity = [r for r in rows if r['account_type'] == 'EQUITY']

        return BalanceSheetItem(
            label='Balance Sheet',
            amount=Decimal('0.00'),
            children=[
                BalanceSheetItem(
                    label='Assets',
                    amount=Decimal('0.00'),
                    children=[BalanceSheetItem(
                        label=r['account_name'],
                        amount=abs(r['balance'])
                    ) for r in assets]
                ),
                BalanceSheetItem(
                    label='Total Assets',
                    amount=sum(abs(r['balance']) for r in assets),
                    is_total=True
                ),
                BalanceSheetItem(
                    label='Liabilities',
                    amount=Decimal('0.00'),
                    children=[BalanceSheetItem(
                        label=r['account_name'],
                        amount=abs(r['balance'])
                    ) for r in liabilities]
                ),
                BalanceSheetItem(
                    label='Total Liabilities',
                    amount=sum(abs(r['balance']) for r in liabilities),
                    is_total=True
                ),
                BalanceSheetItem(
                    label="Shareholders' Equity",
                    amount=Decimal('0.00'),
                    children=[BalanceSheetItem(
                        label=r['account_name'],
                        amount=r['balance']
                    ) for r in equity]
                ),
            ]
        )

    def generate_cash_flow(
        self,
        conn,
        period: FinancialPeriod
    ) -> dict:
        """Generate cash flow statement (indirect method)."""
        return {
            'operating': {
                'net_profit': Decimal('0.00'),
                'adjustments': [],
                'net_cash_operating': Decimal('0.00'),
            },
            'investing': {
                'items': [],
                'net_cash_investing': Decimal('0.00'),
            },
            'financing': {
                'items': [],
                'net_cash_financing': Decimal('0.00'),
            },
            'net_increase': Decimal('0.00'),
            'opening_balance': Decimal('0.00'),
            'closing_balance': Decimal('0.00'),
        }
```

## 6. API ENDPOINTS

```
Finance Module — REST API (prefix: /api/v1/finance)

### Chart of Accounts
GET    /api/v1/finance/coa                     — List all accounts (tree structure)
POST   /api/v1/finance/coa                     — Create account
GET    /api/v1/finance/coa/:id                 — Get account detail
PUT    /api/v1/finance/coa/:id                 — Update account
DELETE /api/v1/finance/coa/:id                 — Deactivate account (soft)

### Journal Entries
GET    /api/v1/finance/journal-entries          — List batches + entries (filter by period, source)
POST   /api/v1/finance/journal-entries          — Manual journal entry with auto-balance check
GET    /api/v1/finance/journal-entries/:id      — Get journal batch detail with lines
PUT    /api/v1/finance/journal-entries/:id      — Update draft entry
POST   /api/v1/finance/journal-entries/:id/reverse  — Reverse a posted entry

### Financial Statements
GET    /api/v1/finance/statements/trial-balance        ?period=2026-07
GET    /api/v1/finance/statements/profit-and-loss       ?period=2026-07&format=json|csv|pdf
GET    /api/v1/finance/statements/balance-sheet         ?as_of=2026-07-09
GET    /api/v1/finance/statements/cash-flow             ?period=2026-07

### Day Book / Ledger
GET    /api/v1/finance/day-book       ?date=2026-07-09
GET    /api/v1/finance/ledger/:coa_id ?from=&to=&page=1&limit=50

### Bank Reconciliation
GET    /api/v1/finance/bank-accounts                    — List bank accounts
POST   /api/v1/finance/bank-accounts                    — Add bank account
GET    /api/v1/finance/bank-accounts/:id/transactions   — List bank transactions
POST   /api/v1/finance/bank-accounts/:id/reconcile      — Run reconciliation
GET    /api/v1/finance/bank-accounts/:id/reconciliations — History

### Accounts Receivable / Payable
GET    /api/v1/finance/ar            ?status=PENDING&aging=1-30
GET    /api/v1/finance/ar/:id
POST   /api/v1/finance/ar/:id/write-off
GET    /api/v1/finance/ap            ?status=PENDING
GET    /api/v1/finance/ap/:id

### Expenses
GET    /api/v1/finance/expenses      ?category=&vendor=&from=&to=
POST   /api/v1/finance/expenses
GET    /api/v1/finance/expenses/:id
PUT    /api/v1/finance/expenses/:id

### Fiscal Periods
GET    /api/v1/finance/periods
POST   /api/v1/finance/periods/:id/close     — Close period (locks entries)
POST   /api/v1/finance/periods/:id/reopen    — Reopen (admin only)

### Reports
GET    /api/v1/finance/reports/aging-summary      — AR aging summary
GET    /api/v1/finance/reports/expense-by-category — Expense breakdown
GET    /api/v1/finance/reports/day-book-summary     — Daily transaction summary
```

## 7. YAML CONFIGURATION

```yaml
# finance_config.yaml
finance:
  general:
    fiscal_year_start: "2026-04-01"         # India financial year
    base_currency: INR
    auto_post_journals: true
    require_batch_approval: false
    default_revenue_account: "4010"
    default_receivable_account: "1010"
    default_payable_account: "2010"
    default_cash_account: "1020"
    default_bank_account: "1030"
    default_sales_tax_payable: "2020"
    default_input_tax_credit: "1025"

  period_close:
    prevent_edits_after_close: true
    require_manager_approval: true
    run_depreciation_before_close: true
    generate_statements_on_close: true

  aging:
    buckets:
      - label: "Current"
        days: 0
      - label: "1-30"
        days: 30
      - label: "31-60"
        days: 60
      - label: "61-90"
        days: 90
      - label: "90+"
        days: 9999
    overdue_reminder_days: [30, 45, 60]

  reconciliation:
    auto_match_threshold_days: 3
    auto_match_amount_tolerance: 100.00
    require_supervisor_review: true
```

## 8. KEY DESIGN DECISIONS

1. **Double-entry enforced at DB level** — Every journal_entry row must have either DR or CR (not both, not zero). Batches must balance before posting. The CHECK constraints prevent orphaned entries.

2. **Aging buckets as generated columns** — Receivable aging is computed via SQL `GENERATED ALWAYS AS`, avoiding stale computed data and eliminating the need for a cron job to recalculate.

3. **Source-module traceability** — `journal_batches.source_module` and `source_ref_id` enable drill-down from any journal entry back to the originating invoice, purchase order, or payroll run. This is critical for audit.

4. **Separation of AR/AP from journal entries** — While the general ledger stores every movement, dedicated AR and AP tables track outstanding balances, due dates, and aging independently for operational follow-up (dunning, payment reminders).

5. **Auto-posting via triggers, not application code** — PostgreSQL triggers on `invoices`, `payments`, `purchases` fire to insert journal batches automatically. The application layer never manually creates journal entries except for manual adjustments.

6. **Period closing is irreversible in normal flow** — Once a fiscal period is closed, no new entries can be posted to it. A reopen function exists but logs the action and requires admin privileges, maintaining audit integrity.

7. **Cash flow via indirect method** — Starts with net profit and adjusts for non-cash items (depreciation, accruals, working capital changes). Direct method support can be added in Phase 5.

8. **India GAAP as default, IFRS mapping optional** — The chart of accounts uses Indian conventions. An optional mapping table can translate to IFRS categories for consolidated reporting if needed later.
```

## 9. AUDIT TRAIL

```sql
CREATE TABLE finance_audit_log (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name      VARCHAR(50) NOT NULL,
    record_id       UUID NOT NULL,
    action          VARCHAR(20) NOT NULL,   -- INSERT, UPDATE, DELETE, REVERSE, CLOSE
    old_values      JSONB,
    new_values      JSONB,
    changed_by      UUID NOT NULL REFERENCES users(id),
    changed_at      TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX idx_fin_audit_table ON finance_audit_log(table_name, record_id);
CREATE INDEX idx_fin_audit_time ON finance_audit_log(changed_at);
```
