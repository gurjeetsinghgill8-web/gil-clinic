---
file_id: "0004"
module_name: "System Architecture"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: ["0000_PROJECT_IDENTITY.md", "0001_GHOS_MEMORY.md"]
related_files: ["0100_QUEUE_ENGINE.md", "0101_WORKFLOW_ENGINE.md", "0105_AUTH_ENGINE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "architecture", "system-design", "layers", "microservices"]
---

# 🏗️ GHOS — System Architecture

---

## 1. HIGH-LEVEL ARCHITECTURE

```
┌──────────────────────────────────────────────────────────────┐
│                    PATIENT / USER LAYER                       │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌─────────────┐ │
│  │ Mobile   │  │   PWA    │  │  Web     │  │ WhatsApp    │ │
│  │ App      │  │ Browser  │  │ Desktop  │  │ Chatbot     │ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └──────┬──────┘ │
└───────┼──────────────┼─────────────┼────────────────┼────────┘
        │              │             │                │
┌───────┼──────────────┼─────────────┼────────────────┼────────┐
│       │              │             │                │        │
│  ┌────▼──────────────▼─────────────▼────────────────▼──────┐ │
│  │                 API GATEWAY (Nginx / Traefik)            │ │
│  │         ┌──────────────────────────────────────┐        │ │
│  │         │  Rate Limiting → Auth → Validation   │        │ │
│  │         └──────────────────────────────────────┘        │ │
│  └────────────────────────┬─────────────────────────────────┘ │
│                           │                                   │
│  ┌────────────────────────▼──────────────────────────────────┐│
│  │                   MICROSERVICES LAYER                      ││
│  │                                                            ││
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐ ││
│  │  │ Auth     │ │ Queue    │ │ Patient  │ │ Notification │ ││
│  │  │ Service  │ │ Engine   │ │ Service  │ │ Service      │ ││
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────────┘ ││
│  │  ┌──────────┐ ┌──────────┐ ┌──────────┐ ┌──────────────┐ ││
│  │  │ Doctor   │ │ Billing  │ │ Pharmacy │ │ AI Service   │ ││
│  │  │ Service  │ │ Service  │ │ Service  │ │ (FastAPI)    │ ││
│  │  └──────────┘ └──────────┘ └──────────┘ └──────────────┘ ││
│  └────────────────────────┬──────────────────────────────────┘│
│                           │                                   │
│  ┌────────────────────────▼──────────────────────────────────┐│
│  │                 DATA LAYER                                 ││
│  │  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────┐ ││
│  │  │PostgreSQL│  │  Redis   │  │  S3 /    │  │  Search  │ ││
│  │  │ (Primary)│  │ (Cache)  │  │  MinIO   │  │ (ES/Meil)│ ││
│  │  └──────────┘  └──────────┘  └──────────┘  └──────────┘ ││
│  └───────────────────────────────────────────────────────────┘│
└───────────────────────────────────────────────────────────────┘
```

---

## 2. THE 7-LAYER MODEL

GHOS is organized into 7 logical layers:

```
Layer 1: Identity (Who)      → Hospital, Branch, Doctor, Staff, Patient
Layer 2: Queue (When)        → Queue Engine, Token, Status
Layer 3: Communication (How) → SMS, Voice, WhatsApp, Push, Email
Layer 4: Clinical (What)     → OPD, Lab, ECG, Echo, Pharmacy
Layer 5: Billing (Value)     → Invoice, Payment, GST, Insurance
Layer 6: Analytics (Insight) → Reports, Dashboards, BI
Layer 7: AI (Intelligence)   → Voice Agent, Triage, Follow-up
```

---

## 3. COMPONENT DIAGRAM

### Frontend (React/Next.js PWA)

```
┌──────────────────────────────────────────────────┐
│                 NEXT.JS APP                       │
│  ┌──────────────┐  ┌──────────────┐              │
│  │ Patient App  │  │ Staff Portal │              │
│  │ (Public)     │  │ (Auth Req'd) │              │
│  └──────────────┘  └──────────────┘              │
│  ┌──────────────┐  ┌──────────────┐              │
│  │ Admin Panel  │  │ Doctor Dash  │              │
│  └──────────────┘  └──────────────┘              │
│  ┌──────────────────────────────────────────┐    │
│  │           Shared Components              │    │
│  │  QueueCard | PatientTimeline | TokenBadge │    │
│  └──────────────────────────────────────────┘    │
│  ┌──────────────────────────────────────────┐    │
│  │           State (Zustand Stores)         │    │
│  │  useAuth | useQueue | usePatient | useWS │    │
│  └──────────────────────────────────────────┘    │
│  ┌──────────────────────────────────────────┐    │
│  │     WebSocket Client (Socket.io)         │    │
│  └──────────────────────────────────────────┘    │
└──────────────────────────────────────────────────┘
```

### Backend (FastAPI Microservices)

```
┌──────────────────────────────────────────────────┐
│              API GATEWAY (Port 8000)              │
│  ┌────────────────────────────────────────────┐  │
│  │  Middleware: Auth → Logging → Rate Limit   │  │
│  └────────────────────────────────────────────┘  │
└──────────┬──────────────────────────┬────────────┘
           │                          │
┌──────────▼──────────┐  ┌──────────▼────────────┐
│  Auth Service       │  │  Queue Engine Service │
│  :8001              │  │  :8002                │
│  - Register/Login   │  │  - Enqueue/Dequeue    │
│  - OTP Generation   │  │  - Status Update      │
│  - Token Validation │  │  - Wait Time Calc     │
└─────────────────────┘  └───────────────────────┘
┌──────────▼──────────┐  ┌──────────▼────────────┐
│  Patient Service    │  │  Doctor Service       │
│  :8003              │  │  :8004                │
│  - CRUD Patients    │  │  - Dashboard          │
│  - Visit Management │  │  - Next/Skip/Recall   │
│  - Timeline Events  │  │  - Report Status      │
└─────────────────────┘  └───────────────────────┘
┌──────────▼──────────┐  ┌──────────▼────────────┐
│  Notification Svc   │  │  AI Service           │
│  :8005              │  │  :8006                │
│  - SMS/WhatsApp     │  │  - S2T / T2S          │
│  - Push/Voice       │  │  - LLM Integration    │
│  - Templates        │  │  - RAG Pipeline       │
└─────────────────────┘  └───────────────────────┘
```

---

## 4. DATA FLOW — PATIENT JOURNEY

```
1. Patient arrives at clinic
     │
2. Reception creates visit (offline-capable)
     │
3. Queue Engine assigns token
     │
4. Patient receives QR link (WhatsApp / Paper)
     │
5. Patient waits → Live tracking on phone
     │
6. Queue Engine notifies: "Your turn in 2 patients"
     │
7. Doctor clicks "Next Patient"
     │      │
     │      ├── WebSocket push to patient phone: "Called"
     │      ├── WebSocket push to department: "In Progress"
     │      └── Notification: "Room 3, Dr. Sharma"
     │
8. Doctor completes consultation
     │      │
     │      ├── Sends to Lab/ECG/Pharmacy (one click)
     │      ├── Queue Engine routes to next department
     │      └── Patient timeline updated
     │
9. Patient moves to next department → repeats from step 5
     │
10. All departments done → Billing (if applicable)
     │
11. Visit completed → Feedback request sent
```

---

## 5. REALTIME ARCHITECTURE (WebSocket)

```
┌──────────┐     ┌──────────────┐     ┌───────────┐
│ Patient  │────▶│ WebSocket    │◀────│ Doctor    │
│ Phone    │     │ Server       │     │ Dashboard │
└──────────┘     │ (Redis Pub)  │     └───────────┘
                 └──────┬───────┘
                        │
                 ┌──────▼───────┐
                 │  Queue       │
                 │  Engine Svc  │
                 └──────────────┘

Events:
  queue.token_assigned     → {patient_id, token, dept}
  queue.patient_called     → {patient_id, room, doctor}
  queue.patient_skipped    → {patient_id, reason}
  queue.patient_completed  → {patient_id, department}
  queue.wait_time_updated  → {department, avg_wait}
  queue.delay_alert        → {departmen
