---
file_id: "0003"
module_name: "AI Rulebook"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: ["0000_PROJECT_IDENTITY.md", "0001_GHOS_MEMORY.md", "0002_PRODUCT_DNA.md"]
related_files: ["0004_SYSTEM_ARCHITECTURE.md", "0005_DEVELOPMENT_GUIDE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "ai-rules", "coding-rules", "decision-rules"]
---

# 🤖 GHOS — AI Rulebook

---

## 1. PURPOSE

This file defines the rules that any AI (including this one) must follow when generating code, making decisions, or suggesting changes to the GHOS project.

---

## 2. CODING RULES

### CR1: Read Before Write
Before generating code for any module, the AI MUST read:
1. The module's own `.md` file from the `ghos_memory/` directory
2. Any files listed in its `dependencies` metadata
3. `0003_AI_RULEBOOK.md` (this file)
4. `0005_DEVELOPMENT_GUIDE.md` (coding standards)

### CR2: No Streamlit in Production
- Streamlit code is strictly for prototyping
- All production code must use: **React/Next.js (Frontend) + FastAPI (Backend)**
- If existing Streamlit code exists, it must be rewritten before production deployment

### CR3: Type Annotations Required
Every Python function must have:
- Type hints for all parameters
- Type hints for return values
- Docstrings explaining purpose, parameters, and returns

### CR4: Tests Before Features
- Every new feature must have at least one test
- Tests must pass before code is merged
- Use pytest for Python, Jest for JavaScript

### CR5: Error Handling
- Every API endpoint must handle:
  - 400: Bad request (validation error)
  - 401: Unauthorized (invalid auth)
  - 403: Forbidden (insufficient permissions)
  - 404: Not found
  - 500: Internal server error
- Never expose raw error messages to the client
- Log all errors with traceback

### CR6: Security First
- Never store plain text passwords
- Never expose API keys in frontend code
- Always validate user input on both client and server
- Always check permissions before executing an action
- Use parameterized queries (never string concatenation for SQL)

### CR7: Performance Awareness
- Database queries must have proper indexes
- N+1 query patterns are prohibited
- WebSocket messages must be lightweight (no full objects, use IDs)
- API responses should support pagination for lists

### CR8: Documentation
- Every API endpoint must have OpenAPI/Swagger documentation
- Every database migration must be reversible
- Every configuration change must be documented

---

## 3. DECISION RULES

### DR1: Simplicity Over Cleverness
When there are two approaches, choose the simpler one. Avoid premature optimization. A readable solution is better than a clever one-liner.

### DR2: Consistency Over Preference
When there are multiple valid patterns in the codebase, follow the existing pattern — even if you personally prefer another.

### DR3: Data Integrity Over Performance
When there is a trade-off between data integrity and performance, choose integrity. We can optimize later. We cannot recover corrupted data.

### DR4: Free Core First
When designing a feature, first ask: "Does this belong in the free tier?" If yes, prioritize it. Premium features come after core is solid.

### DR5: Mobile UX Over Desktop UX
When a design choice affects both mobile and desktop, optimize for mobile first. Desktop can have reduced functionality. Mobile cannot.

### DR6: Offline Over Online
When designing a feature, first ensure it works offline. Online-only features are secondary.

---

## 4. AI RESTRICTIONS

### AR1: No Medical Decisions
AI must never:
- Suggest a diagnosis
- Recommend medication
- Interpret medical reports
- Override a doctor's prescription

### AR2: No Pricing Decisions
AI must never:
- Set prices for services
- Determine subscription tiers
- Decide billing amounts
- Only suggest pricing structures for human review

### AR3: No Patient Data Exposure
AI must never:
- Suggest logging sensitive patient data in plain text
- Recommend encryption-less data storage
- Propose sharing patient data with third parties

### AR4: No Architecture Changes Without Review
AI must never:
- Change the database schema without documenting the migration
- Add a new external dependency without justification
- Remove existing functionality without migration path

---

## 5. AI BEHAVIOR RULES

### BR1: When Uncertain, Ask
If a requirement is ambiguous, the AI should list the possible interpretations and ask for clarification rather than guessing.

### BR2: Explain Trade-offs
When suggesting a solution, the AI should briefly mention what alternatives were considered and why the chosen approach is preferred.

### BR3: Flag Breaking Changes
When a change would break existing functionality or require data migration, the AI must flag this explicitly.

### BR4: Size Awareness
If a task would generate more than 200 lines of code, the AI should suggest splitting it into multiple files and planning the approach before writing code.

### BR5: Progressive Disclosure
Present complex information in layers:
1. Summary (what and why)
2. Details (how)
3. Code (implementation)

---

## 6. CODE REVIEW CHECKLIST (for AI reviews)

- [ ] Follows `0005_DEVELOPMENT_GUIDE.md` conventions
- [ ] Type annotations present on all functions
- [ ] Error handling for all failure modes
- [ ] No hardcoded values (use config/env)
- [ ] No sensitive data in logs
- [ ] Proper permission checks
- [ ] Offline-compatible
- [ ] Mobile-responsive
- [ ] Bilingual-ready (Hindi + English)
- [ ] Test exists for new functionality

---

## 7. AI PROMPT TEMPLATE

When asked to generate code for a new module, the AI should use this template:

```
## Module: [MODULE_NAME]
## Context: [BRIEF DESCRIPTION]

### Requirements
- Bullet list of what this module must do

### Constraints
- Must work offline
- Must be mobile-first
- Must support Hindi/English

### Dependencies
- Files this depends on

### Files to create/modify
- List of files

### Implementation
- Code with full type annotations
- Error handling included
- Tests included
```

---

*"Code with care. Build for scale."*
