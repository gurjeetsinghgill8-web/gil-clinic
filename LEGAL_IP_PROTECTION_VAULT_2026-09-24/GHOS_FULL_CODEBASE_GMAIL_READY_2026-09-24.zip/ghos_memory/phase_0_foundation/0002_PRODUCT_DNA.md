---
file_id: "0002"
module_name: "Product DNA"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: ["0000_PROJECT_IDENTITY.md", "0001_GHOS_MEMORY.md"]
related_files: ["0003_AI_RULEBOOK.md", "0004_SYSTEM_ARCHITECTURE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "product-dna", "philosophy", "design-principles"]
---

# 🧬 Gill Hospital OS — Product DNA

---

## 1. THE CORE PHILOSOPHY

GHOS is built on **three foundational beliefs**:

### Belief 1: The Queue is the Heartbeat of a Hospital

Everything in a hospital revolves around who is next. If you get the queue right:
- Patients stop crowding the reception
- Doctors stop wasting time finding next patient
- Staff stops running around manually coordinating
- The hospital becomes calm, organized, and efficient

**=> Queue Engine is not a feature. It is the platform.**

### Belief 2: The Patient Journey is the Single Source of Truth

A patient's visit is a journey through multiple touchpoints:
```
Reception → Doctor → Lab → ECG → Doctor again → Pharmacy → Billing → Exit
```

Every single step must be recorded in one unified timeline — visible to the patient, the doctor, and the staff simultaneously. No silos. No manual handoffs.

### Belief 3: AI Should Assist, Not Replace

- AI should answer calls so receptionists can focus on patients in front of them
- AI should summarize reports so doctors can focus on diagnosis
- AI should send reminders so patients don't miss appointments
- AI should never make a medical diagnosis or replace a doctor's judgment

---

## 2. DESIGN PRINCIPLES

### DP1: Mobile First, Always
- Every screen designed for 6-inch smartphone first
- Desktop is a secondary concern
- Touch targets minimum 44x44px
- No hover-dependent interactions

### DP2: Zero Learning Curve
- A receptionist should be productive in under 5 minutes
- A doctor should see their first patient in under 2 minutes
- Buttons have clear labels (not icons alone)
- Hindi + English for all patient-facing text

### DP3: Offline is a Feature, Not a Bug
- Registration must work without internet
- Queue must update locally even if cloud is unreachable
- Sync happens automatically when connection restores
- No data loss during network interruptions

### DP4: Real-time by Default
- When a doctor clicks "Next", the patient's phone must update within 1 second
- When a test is completed, the doctor's dashboard must reflect immediately
- No manual refresh buttons on any screen

### DP5: Configurable, Not Hardcoded
- Test types, departments, rooms, timings — all configurable from admin panel
- No code changes needed to add a new department
- No developer needed to customize for a new specialty

### DP6: LEGO Block Architecture
- Each module is independent
- Kal ko dental clinic aaye → Sirf dental wala block add
- Eye hospital aaye → Sirf ophthalmology block add
- Software wahi rahega, blocks badalte rahenge

### DP7: Free is Not a Trial
- Core features are free forever — not a 30-day trial
- Free clinics get unlimited patients, unlimited queue
- Premium is for advanced features (SMS, AI, Analytics)
- This is not a charity. It's a business model. Free users become paid users when they scale.

### DP8: Every Click Must Have a Purpose
- No confirmation dialogs for common actions
- Undo is preferred over "Are you sure?"
- Every screen must answer: "What should I do next?"

---

## 3. WHAT WE BUILD VS WHAT WE DON'T BUILD

| We Build | We Don't Build |
|----------|----------------|
| Queue management | Appointment booking only |
| Patient journey tracking | Just a dashboard |
| AI-assisted workflows | Fully automated decision making |
| Real-time communication | Batch processing |
| Configurable modules | Hardcoded features |
| Mobile-first PWA | Desktop-only app |
| What works offline | Cloud-dependent only |
| Bilingual (HI+EN) | English-only |

---

## 4. THE THREE LAWS OF GHOS

1. **The Queue Engine must never go down.** Everything else can fail, but the queue must keep running — even offline.
2. **The Patient Timeline must never have gaps.** Every state change, every movement, every communication must be recorded.
3. **The System must never lose data.** If a request fails, it must be queued for retry. No silent failures.

---

## 5. PRODUCT PERSONALITY

If GHOS was a person, it would be:

- **Reliable** — Always available, never crashes
- **Fast** — No waiting, no loading spinners
- **Simple** — Doesn't show off, just works
- **Bilingual** — Speaks Hindi and English fluently
- **Helpful** — Proactive reminders, suggestions, alerts
- **Humble** — Works in the background, never in the way

---

## 6. EMOTIONAL DESIGN GOALS

When a patient uses GHOS:
- "I know exactly where I am in the journey"
- "I know how much longer I need to wait"
- "I feel the hospital is organized"
- "I don't need to ask anyone for help"

When a doctor uses GHOS:
- "I can see my next patient without looking up"
- "I can send patients to departments with one click"
- "I spend less time on paperwork"
- "I see more patients in less time"

When a receptionist uses GHOS:
- "Registration takes 30 seconds"
- "I can see the full queue at a glance"
- "Patients don't crowd my desk asking 'when is my turn?'"

---

*"Queue First. Patient Always. AI Assist."*
