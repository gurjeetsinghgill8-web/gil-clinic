---
file_id: "0000"
module_name: "Project Identity"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: []
related_files: ["0001_GHOS_MEMORY.md", "0002_PRODUCT_DNA.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "identity", "vision", "mission", "foundation"]
---

# 🏥 Gill Hospital OS (GHOS) — Project Identity

---

## 1. PROJECT NAME

**Gill Hospital Operating System (GHOS)**

- Short Name: `GHOS`
- Pronounced: "G-H-O-S" or "Ghost"
- Product Tagline: *"One Patient. One Journey. One Platform."*
- Internal Codename: `cardioqueue` (legacy — will be deprecated)

---

## 2. VISION

**To power every clinic and hospital in India with an intelligent, affordable, and unified operating system that puts the patient journey at the center.**

We are not building just software. We are building the **operating system for Indian healthcare**.

---

## 3. MISSION

1. **Democratize hospital management** — Make enterprise-grade clinic software free for every small and medium clinic in India.
2. **Eliminate patient waiting** — Real-time queue intelligence that reduces average waiting time by 70%.
3. **Enable doctors to focus on patients, not paperwork** — AI-assisted workflows that automate 80% of administrative tasks.
4. **Scale from 1 clinic to 10,000+** — Microservices architecture designed for growth from day one.

---

## 4. PHILOSOPHY

| Principle | Meaning |
|-----------|---------|
| **Patient First** | Every decision starts with "How does this help the patient?" |
| **Queue First** | The queue is the heart of the hospital. Get it right, everything else follows. |
| **AI Assist, Never Replace** | AI should empower doctors and staff, not replace human judgment. |
| **Microservices over Monolith** | Small, independent services that can be mixed and matched like LEGO blocks. |
| **Local-First, Cloud-Connected** | Works offline. Syncs when online. No internet dependency for core operations. |
| **Free at the Core** | Core hospital operations should be free forever. Premium is for advanced features. |
| **Mobile Native** | Designed for mobile first. India runs on smartphones, not desktops. |

---

## 5. TARGET MARKET

### Primary Market (Year 1-2)
- **Single-specialty clinics** (Cardiology, Dental, Eye, ENT, Ortho, Skin)
- **Multi-specialty clinics** (2-10 doctors)
- **Small nursing homes** (10-30 beds)

### Secondary Market (Year 2-3)
- **Medium hospitals** (30-100 beds)
- **Diagnostic centers**
- **Polyclinics**

### Tertiary Market (Year 3-5)
- **Large hospitals** (100-500 beds)
- **Hospital chains** (multi-branch)
- **Government health centers**

---

## 6. PRODUCT DNA

- **Not a booking app** — It's a hospital operating system.
- **Not a dashboard** — It's a journey orchestrator.
- **Not a billing software** — It's a complete clinical and administrative platform.
- **Not a replacement for doctors** — It's an AI assistant that makes doctors faster.

---

## 7. CORE UNIQUE SELLING PROPOSITIONS (USPs)

| # | USP | Description |
|---|-----|-------------|
| 1 | **Free Core** | Registration, queue, tracking, and basic doctor dashboard — always free |
| 2 | **Real-time Everywhere** | WebSocket-powered live updates across all devices |
| 3 | **Patient Timeline** | Universal visual timeline accessible to patient, doctor, and staff |
| 4 | **Queue Engine (Heart)** | Intelligent queue that routes patients across departments automatically |
| 5 | **AI Voice Receptionist** | Answers calls, books appointments, answers queries — 24/7 |
| 6 | **Multi-Tenant SaaS** | One codebase, thousands of clinics, isolated data |
| 7 | **Offline-First** | Core operations work without internet |
| 8 | **WhatsApp Native** | All patient communication via WhatsApp (India's primary messaging platform) |

---

## 8. COMPETITIVE POSITIONING

| Against | GHOS Advantage |
|---------|----------------|
| **Practo / Lybrate** | Not just booking — full clinic OS with queue, billing, pharmacy, AI |
| **Insta / MyClinic** | Free core, AI capabilities, multi-branch from day one |
| **Custom ERP** | 10x cheaper, 10x faster deployment, no implementation fee |
| **Paper-based** | Zero learning curve, mobile-first, QR-based |

---

## 9. BUSINESS MODEL

- **Freemium SaaS** — Core features free forever
- **Premium features** — SMS, Voice, AI, Billing, Analytics, Multi-branch
- **White-label** — Custom branding for enterprise clients
- **Revenue split** — Optional payment gateway integration (small transaction fee)

---

## 10. SCALING ROADMAP

```
2026: 1 clinic (pilot)
  ↓
2027: 100 clinics (local)
  ↓
2028: 1,000 clinics (regional)
  ↓
2029: 5,000 clinics (national)
  ↓
2030: 10,000+ clinics (global)
```

---

## 11. SUCCESS METRICS

| Metric | Year 1 Target | Year 3 Target |
|--------|---------------|---------------|
| Active clinics | 100 | 1,000 |
| Patients served/month | 50,000 | 500,000 |
| Average wait time reduction | 50% | 70% |
| Staff time saved/day | 2 hours | 4 hours |
| Patient satisfaction score | 4.2/5 | 4.5/5 |
| Uptime | 99.5% | 99.9% |

---

*"Not just software. An operating system for healthcare."*
