---
file_id: "0001"
module_name: "GHOS Memory & AI Context"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: ["0000_PROJECT_IDENTITY.md"]
related_files: ["0002_PRODUCT_DNA.md", "0003_AI_RULEBOOK.md", "0004_SYSTEM_ARCHITECTURE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "memory", "context", "overview", "ai-context"]
---

# 🧠 GHOS — Complete Project Memory & AI Context

---

## 1. WHAT IS THIS FILE?

This file is the **single source of truth** for AI agents working on the GHOS project. It contains the complete context an AI needs to understand the project before writing any code or making any decision.

---

## 2. PROJECT OVERVIEW

| Attribute | Value |
|-----------|-------|
| Project | Gill Hospital OS (GHOS) |
| Type | Hospital Operating System / Clinic Management Platform |
| Architecture | Microservices (LEGO block approach) |
| Frontend | React / Next.js (PWA) — mobile-first |
| Backend | Python (FastAPI) |
| Database | PostgreSQL |
| Realtime | WebSockets |
| Auth | OTP-based (primary) + Password (secondary) |
| Hosting | Start free → Scale to VPS |
| Target | 1 clinic → 10,000+ clinics |

---

## 3. BUSINESS RULES (NON-NEGOTIABLE)

These rules must be followed by any code generated for GHOS:

| # | Rule | Rationale |
|---|------|-----------|
| R1 | **Never use Streamlit for production** | Streamlit is for prototyping only. Production must use React/Next.js + FastAPI |
| R2 | **Queue Engine is the heart** | Every department, every module, every workflow connects through the Queue Engine |
| R3 | **Patient Journey is the single source of truth** | All modules must read/write to the patient's unified timeline |
| R4 | **Free core forever** | Patient registration, queue tracking, and basic doctor dashboard must always be free |
| R5 | **Microservices, not monolith** | Each module must be independently deployable. No circular dependencies |
| R6 | **Mobile-first always** | Every UI must work perfectly on a 6-inch smartphone screen |
| R7 | **Offline-first core** | Registration, queue, and basic operations must work without internet |
| R8 | **No hardcoding test types** | Departments and test types must be configurable from admin panel |
| R9 | **Bilingual by default** | All patient-facing communication must support Hindi + English (more languages later) |
| R10 | **Audit everything** | Every state change must be logged with timestamp, user ID, and IP address |

---

## 4. KEY ARCHITECTURAL DECISIONS

| Decision | Choice | Why |
|----------|--------|-----|
| Frontend Framework | React / Next.js (PWA) | Best mobile experience, SEO-friendly, ecosystem |
| State Management | Zustand (lightweight) | Simpler than Redux, perfect for mid-size apps |
| API Protocol | REST + WebSocket | REST for CRUD, WebSocket for real-time queue updates |
| Auth Strategy | OTP via SMS/WhatsApp | India's mobile-first population, no password friction |
| Database | PostgreSQL | ACID compliance, JSON support, excellent ecosystem |
| ORM | SQLAlchemy 2.0 (async) | Mature, async support, great with FastAPI |
| Background Tasks | Celery + Redis | SMS, Voice calls, scheduled reminders |
| Cache | Redis | Session management, queue state, rate limiting |
| File Storage | Cloud object storage (S3/MinIO) | Reports, images, prescriptions |
| Monitoring | Prometheus + Grafana | Free, battle-tested, self-hostable |

---

## 5. CORE DATA ENTITIES

```
Hospital ── has_many ──> Branches
Branch ── has_many ──> Departments
Department ── has_many ──> Doctors
Department ── has_many ──> Staff
Hospital ── has_many ──> Patients
Patient ── has_many ──> Visits
Visit ── has_one ──> Token
Visit ── has_many ──> Queue_Entries
Visit ── has_many ──> Prescriptions
Visit ── has_many ──> Investigations
Visit ── has_many ──> Bills
Visit ── has_many ──> Timeline_Events
```

---

## 6. PHASE DEVELOPMENT ROADMAP

```
Phase 0 (Foundation)    → Architecture, Identity, Rules
Phase 1 (Core Engine)   → Queue, Workflow, Token, Auth
Phase 2 (User Modules)  → Reception, Doctor, Patient, Admin
Phase 3 (Clinical)      → OPD, Lab, ECG, Echo, Pharmacy
Phase 4 (Admin)         → Billing, Inventory, HR
Phase 5 (AI)            → Voice Receptionist, Triage, Follow-up
Phase 6 (Patient Exp.)  → App, Timeline, Tracking
Phase 7 (Communication) → SMS, WhatsApp, Voice, Push
Phase 8 (Security)      → Encryption, Audit, Compliance
Phase 9 (Mobile)        → Android, iOS, PWA
Phase 10 (SaaS)         → Multi-tenant, Subscriptions
Phase 11 (DevOps)       → Deployment, CI/CD, Monitoring
Phase 12 (Future)       → Roadmap, Ideas, Expansion
```

---

## 7. TECHNOLOGY CONSTRAINTS

| Constraint | Value |
|------------|-------|
| Python version | 3.11+ |
| Node.js version | 20 LTS+ |
| Database | PostgreSQL 15+ |
| Cache | Redis 7+ |
| Container | Docker + docker-compose |
| Cloud | Any (AWS/GCP/Azure/self-host) |
| CI/CD | GitHub Actions |
| Code Quality | Black (formatting), Ruff (linting), MyPy (types) |

---

## 8. COMMUNICATION PREFERENCES

| Channel | Priority | Use Case |
|---------|----------|----------|
| WhatsApp | Primary | Appointment reminders, queue updates, reports |
| SMS | Secondary | Critical alerts (OTP, emergency) |
| Voice Call | Premium | AI receptionist, follow-up calls |
| Push Notification | App only | Real-time queue position updates |
| Email | Documents | Invoice, prescription PDF |
| In-App | Always | Timeline updates, status changes |

---

## 9. AI USAGE POLICY

- **AI may generate code** — But must follow rules in 0003_AI_RULEBOOK.md
- **AI may refactor** — Only if tests pass before and after
- **AI may NOT** — Make decisions about patient data, pricing, or security architecture without human review
- **AI must** — Read the relevant module's MD file before generating code for it

---

## 10. FILE SYSTEM CONTRACT

Every file must start with:
```yaml
---
file_id: "XXXX"
module_name: "..."
version: "1.0"
status: "Draft"
phase: "Phase X"
dependencies: []
related_files: []
last_updated: "YYYY-MM-DD"
priority: "High"
ai_tags: []
---
```

Any AI reading this file must first check if it has read all dependencies listed in the metadata.

---

*"One Patient. One Journey. One Platform."*
