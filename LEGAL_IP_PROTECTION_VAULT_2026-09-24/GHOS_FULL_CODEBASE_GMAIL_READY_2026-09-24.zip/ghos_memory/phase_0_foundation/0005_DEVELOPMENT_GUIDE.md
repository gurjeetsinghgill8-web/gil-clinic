---
file_id: "0005"
module_name: "Development Guide"
version: "1.0"
status: "Approved"
phase: "Phase 0 — Foundation"
dependencies: ["0001_GHOS_MEMORY.md", "0003_AI_RULEBOOK.md", "0004_SYSTEM_ARCHITECTURE.md"]
related_files: []
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "development", "coding-standards", "folder-structure"]
---

# 🛠️ GHOS — Development Guide

---

## 1. PROJECT FOLDER STRUCTURE

```
ghos/
├── frontend/                    # Next.js application
│   ├── public/
│   │   ├── manifest.json
│   │   ├── service-worker.js
│   │   ├── icons/
│   │   └── sounds/
│   ├── src/
│   │   ├── app/                # Next.js App Router pages
│   │   │   ├── (public)/       # Patient-facing routes
│   │   │   │   ├── page.tsx
│   │   │   │   ├── track/[id]/
│   │   │   │   └── appointment/
│   │   │   ├── (auth)/         # Staff/admin routes (login required)
│   │   │   │   ├── login/
│   │   │   │   ├── reception/
│   │   │   │   ├── doctor/
│   │   │   │   ├── admin/
│   │   │   │   └── ...
│   │   │   └── api/            # Next.js API routes (BFF pattern)
│   │   ├── components/         # Shared UI components
│   │   │   ├── ui/             # Base UI (Button, Card, Modal...)
│   │   │   ├── queue/          # Queue-specific (QueueCard, TokenBadge...)
│   │   │   ├── patient/        # Patient-specific (Timeline, Profile...)
│   │   │   └── layout/         # Layout components (Navbar, Sidebar...)
│   │   ├── hooks/              # Custom React hooks
│   │   │   ├── useQueue.ts
│   │   │   ├── useAuth.ts
│   │   │   ├── useWebSocket.ts
│   │   │   └── useOffline.ts
│   │   ├── stores/             # Zustand state stores
│   │   │   ├── authStore.ts
│   │   │   ├── queueStore.ts
│   │   │   └── patientStore.ts
│   │   ├── lib/                # Utilities & helpers
│   │   │   ├── api.ts          # API client
│   │   │   ├── ws.ts           # WebSocket client
│   │   │   ├── db.ts           # IndexedDB (offline)
│   │   │   └── utils.ts
│   │   ├── types/              # TypeScript type definitions
│   │   └── i18n/               # Internationalization (Hindi/English)
│   ├── tests/
│   ├── next.config.js
│   ├── tailwind.config.js
│   └── package.json
│
├── backend/                    # FastAPI microservices
│   ├── services/
│   │   ├── auth/               # Auth Service
│   │   │   ├── app/
│   │   │   │   ├── main.py
│   │   │   │   ├── models.py
│   │   │   │   ├── schemas.py
│   │   │   │   ├── routes/
│   │   │   │   └── utils/
│   │   │   ├── tests/
│   │   │   └── Dockerfile
│   │   ├── queue/              # Queue Engine Service
│   │   │   ├── app/
│   │   │   │   ├── main.py
│   │   │   │   ├── engine.py   # Core queue algorithm
│   │   │   │   ├── models.py
│   │   │   │   ├── schemas.py
│   │   │   │   └── routes/
│   │   │   ├── tests/
│   │   │   └── Dockerfile
│   │   ├── patient/            # Patient Service
│   │   ├── doctor/             # Doctor Service
│   │   ├── notification/       # Notification Service
│   │   ├── billing/            # Billing Service
│   │   ├── pharmacy/           # Pharmacy Service
│   │   └── ai/                 # AI Service
│   ├── shared/                 # Shared libraries
│   │   ├── models/             # Pydantic models
│   │   ├── database/           # DB connection, migrations
│   │   ├── middleware/         # Auth, logging, rate limiting
│   │   └── utils/
│   ├── docker-compose.yml
│   └── Makefile
│
├── database/
│   ├── migrations/             # Alembic migrations
│   ├── seeds/                  # Seed data
│   └── scripts/                # Maintenance scripts
│
├── ghos_memory/                # 🟢 THIS MEMORY SYSTEM
│   ├── GHOS_MASTER_INDEX.md
│   ├── phase_0_foundation/
│   ├── phase_1_core_engine/
│   └── ...
│
├── docs/                       # Additional documentation
├── .github/
│   └── workflows/              # CI/CD pipelines
├── .env.example
├── docker-compose.yml          # Root compose (all services)
└── README.md
```

---

## 2. NAMING CONVENTIONS

### Python (Backend)
| Element | Convention | Example |
|---------|------------|---------|
| Files/Directories | snake_case | `queue_engine.py` |
| Functions | snake_case | `calculate_wait_time()` |
| Classes | PascalCase | `QueueEngine` |
| Variables | snake_case | `current_token` |
| Constants | UPPER_SNAKE | `MAX_QUEUE_DEPTH` |
| Private methods | _prefix | `_validate_token()` |
| Async functions | async def | `async def get_queue()` |

### TypeScript/JavaScript (Frontend)
| Element | Convention | Example |
|---------|------------|---------|
| Files (components) | PascalCase | `QueueCard.tsx` |
| Files (utilities) | camelCase | `formatTime.ts` |
| Functions | camelCase | `calculateWaitTime()` |
| React components | PascalCase | `function PatientTimeline()` |
| Interfaces | PascalCase with I prefix | `IPatient` |
| Types | PascalCase | `QueueStatus` |
| Variables | camelCase | `currentToken` |
| Constants | UPPER_SNAKE | `MAX_RETRY_COUNT` |

### Database
| Element | Convention | Example |
|---------|------------|---------|
| Tables | snake_case, plural | `patients`, `queue_entries` |
| Columns | snake_case | `patient_id`, `token_number` |
| Primary keys | `id` (auto-increment UUID) | `id` |
| Foreign keys | `{table}_id` | `patient_id` |
| Indexes | `idx_{table}_{column}` | `idx_patients_mobile` |
| Enums | UPPER_SNAKE | `QUEUE_STATUS` |

---

## 3. GIT BRANCH STRATEGY

```
main                  → Production-ready code
├── develop           → Integration branch
│   ├── feature/*     → New features (feature/queue-engine)
│   ├── fix/*         → Bug fixes (fix/double-token)
│   └── refactor/*    → Code refactoring
├── release/*         → Release candidates
└── hotfix/*          → Emergency production fixes
```

### Commit Convention
```
type(scope): description

Types: feat | fix | refactor | docs | test | chore | perf
Scope: queue | auth | patient | ui | api | db | ai

Examples:
  feat(queue): add priority-based dequeue algorithm
  fix(auth): handle expired OTP tokens
  refactor(api): extract common middleware
  docs(ghos): update system architecture diagram
```

---

## 4. CODING STANDARDS

### Python
- **Formatter:** Black (line length: 88)
- **Linter:** Ruff (all rules enabled)
- **Type Checker:** MyPy (strict mode)
- **Test Runner:** pytest with coverage
- **Minimum Coverage:** 80%

### TypeScript
- **Formatter:** Prettier (semi: true, singleQuote: true)
- **Linter:** ESLint with TypeScript rules
- **Type Checker:** TypeScript strict mode
- **Test Runner:** Jest + React Testing Library
- **Minimum Coverage:** 80%

### Docker
- Multi-stage builds for production
- Non-root user in containers
- Health checks on all services
- .dockerignore for each service

---

## 5. API STANDARDS

### Response Format
```json
{
  "success": true,
  "data": { ... },
  "error": null,
  "meta": {
    "page": 1,
    "per_page": 20,
    "total": 100
  }
}
```

### Error Format
```json
{
  "success": false,
  "data": null,
  "error": {
    "code": "PATIENT_NOT_FOUND",
    "message": "Patient with ID CQ-20260709-042 not found",
    "details": null
  },
  "meta": null
}
```

### HTTP Status Codes
- 200: Success
- 201: Created
- 204: No Content (delete)
- 400: Bad Request (validation)
- 401: Unauthorized
- 403: Forbidden
- 404: Not Found
- 409: Conflict (duplicate)
- 422: Unprocessable Entity
- 429: Too Many Requests
- 500: Internal Server Error

---

## 6. DATABASE MIGRATION POLICY

- All migrations via Alembic
- Each migration must be reversible (upgrade + downgrade)
- Migration naming: `YYYY_MM_DD_HHMM_{description}.py`
- Never modify a committed migration (create a new one)
- Test downgrade before merging

---

## 7. ENVIRONMENT VARIABLES

```env
# App
APP_NAME=GHOS
ENVIRONMENT=development
DEBUG=true

# Database
DATABASE_URL=postgresql+asyncpg://user:pass@localhost:5432/ghos
REDIS_
