---
file_id: "0903"
module_name: "Offline Mode"
version: "2.0"
status: "Draft"
phase: "Phase 9 -- Mobile"
dependencies: ["0902_PWA.md"]
related_files: ["0900_ANDROID.md", "0901_IOS.md", "0600_PATIENT_APP.md", "0300_QUEUE_MANAGEMENT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "offline", "sync", "conflict-resolution", "indexeddb", "work-manager", "background-sync"]
---

# GHOS -- Offline Mode

> "Core operations work without internet. Syncs seamlessly when the connection restores. The user should never lose data or productivity."

---

## 1. OFFLINE ARCHITECTURE

### 1.1 Offline-First Design

```
  +----------------+       +-------------------+       +------------------+
  |                |       |                   |       |                  |
  |   LOCAL DB     | <---> |   SYNC ENGINE     | <---> |   REMOTE API     |
  | (IndexedDB /   |       |   (Background     |       |   (REST / WS)    |
  |  Room /        |       |    Sync Worker)   |       |                  |
  |  CoreData)     |       |                   |       |                  |
  |                |       |                   |       |                  |
  | Single Source  |       | Push local changes |       | Server of truth  |
  | of Truth (app) |       | Pull remote changes|       |                  |
  +----------------+       +-------------------+       +------------------+
         |                          |                           |
         | Write-Through            | Conflict Resolution       | Version Vectors
         | (write local,            | (LWW + Merge)             | (server_timestamp)
         |  queue for sync)         |                           |
         v                          v                           v
  +----------------+       +-------------------+
  | UI reads via   |       | Change Log Table  |
  | Observables /  |       | op_id | entity    |
  | Flows /        |       | entity_id | op    |
  | Subscriptions  |       | payload | status  |
  +----------------+       +-------------------+
```

### 1.2 Data Flow per Operation Type

```
WRITE OPERATION (e.g., enqueue patient):
  User Action
      |
      v
  Write to Local DB (optimistic)
      |
      +--> UI updates immediately (optimistic state)
      |
      v
  Append Change Log:
    { entity_type: "queue_entry", operation: "INSERT", payload: {...}, status: "pending" }
      |
      +--> Sync Engine triggers (if online) OR queues (if offline)
      |
      v
  API call to remote server
      |
      +--> Success: update local with server response, mark change log as "synced"
      +--> Failure: keep in change log; retry with exponential backoff

READ OPERATION (e.g., view queue):
  User Action
      |
      v
  Read from Local DB (always)
      |
      +--> UI renders immediately
      |
      v
  In background (if online):
    Fetch remote data -> Update Local DB -> UI re-renders via observer pattern
    If offline: Show stale data with "Last updated: 15 min ago" badge

DELETE OPERATION (e.g., cancel appointment):
  User Action
      |
      v
  Mark as "cancelled" in Local DB (soft delete)
      |
      v
  Append Change Log:
    { entity_type: "appointment", operation: "DELETE", payload: { id }, status: "pending" }
      |
      v
  On sync: DELETE request to remote
      |
      +--> Success: tombstone locally
      +--> Failure: keep pending
```

---

## 2. OFFLINE CAPABILITIES MATRIX

### 2.1 Full Operation Table

| # | Operation | Offline Support | Sync Direction | Conflict Resolution | Priority |
|---|---|---|---|---|---|
| 1 | Patient Registration | Yes (local + queue) | Push | Server wins (merge phone dupes) | High |
| 2 | Queue Enqueue | Yes (local + pending) | Push | Server wins (validate token sequence) | High |
| 3 | Queue Call / Recall | Yes (local update) | Push | Server wins (prevent double-call) | High |
| 4 | Queue Display | Yes (cached state) | Pull | N/A (read-only) | High |
| 5 | Complete Test / Vitals | Yes (local + pending) | Push | Server wins (clinical record authoritative) | High |
| 6 | Appointment Booking | Yes (local + pending) | Push | LWW (server timestamp) | Medium |
| 7 | View Patient Timeline | Yes (cached) | Pull | N/A (read-only) | Medium |
| 8 | Edit Patient Details | Yes (local + pending) | Push | Three-way merge (non-conflicting fields) | Medium |
| 9 | View Lab Results | Yes (cached; not synced) | Pull | N/A (read-only; no offline create) | Low |
| 10 | Billing / Payment | Partial (view only) | Push (online only) | Server wins (financial integrity) | Critical |
| 11 | Discharge Summary | Yes (draft locally) | Push | Server wins (clinical sign-off) | High |
| 12 | Prescription Refill | Yes (request queued) | Push | Server wins (pharmacy validation) | Medium |
| 13 | Settings / Preferences | Yes (local only) | N/A | N/A (device-local only) | Low |
| 14 | Notification History | Yes (cached) | Pull | N/A (append-only) | Low |
| 15 | Token NFC Write | Yes (local + pending) | Push | Server wins (token sequence) | Medium |
| 16 | User Profile Update | Yes (local + pending) | Push | LWW (server timestamp) | Low |

### 2.2 Sync Direction Legend

```
Push:    Local changes sent TO server (write operations)
Pull:    Remote changes fetched FROM server (read operations)
Both:    Bidirectional sync
Push (online only): Operation requires live server (financial/clinical integrity)
Local only: Never synced; device-specific settings
```

---

## 3. SYNC ENGINE

### 3.1 Change Log Structure

```typescript
interface ChangeLogEntry {
  change_id: number;            // auto-increment primary key
  entity_type: string;          // patient | queue_entry | appointment | vital | test_result | billing
  entity_id: string;            // UUID of the affected entity
  operation: 'INSERT' | 'UPDATE' | 'DELETE';
  payload: Record<string, any>; // full entity snapshot at time of change
  local_timestamp: number;      // Date.now() when change was recorded
  server_timestamp: number;     // server timestamp after sync (0 = not synced)
  status: 'pending' | 'syncing' | 'synced' | 'conflict' | 'failed';
  retry_count: number;          // incremented on each failed attempt
  last_error: string | null;    // error message from last attempt
  created_at: number;
  updated_at: number;
}
```

### 3.2 Push Protocol

```typescript
class SyncEngine {
  private readonly BATCH_SIZE = 50;
  private readonly MAX_RETRIES = 10;
  private readonly BASE_DELAY = 1000;  // 1 second

  /**
   * Push local changes to server in batches with ordering guarantees.
   * Changes are ordered by entity_type dependency then by created_at.
   * e.g., patient INSERT must precede queue_entry INSERT for that patient.
   */
  async pushChanges(): Promise<SyncResult> {
    const db = await this.getDB();
    const pendingChanges = await db.getAllFromIndex('change_log', 'by_status', 'pending');

    // Sort: by dependency order (patients first, then queue, then results)
    const ordered = this.topologicalSort(pendingChanges);

    let successCount = 0;
    let failCount = 0;

    for (let i = 0; i < ordered.length; i += this.BATCH_SIZE) {
      const batch = ordered.slice(i, i + this.BATCH_SIZE);
      try {
        const response = await this.api.pushChanges({
          changes: batch.map(c => ({
            change_id: c.change_id,
            entity_type: c.entity_type,
            entity_id: c.entity_id,
            operation: c.operation,
            payload: c.payload,
            local_timestamp: c.local_timestamp
          })),
          device_id: this.deviceId
        });

        // Process server responses -- each change has individual status
        for (const result of response.results) {
          if (result.status === 'accepted') {
            await this.markSynced(result.change_id, result.server_timestamp);
            successCount++;
          } else if (result.status === 'conflict') {
            await this.handleConflict(result);
            failCount++;
          } else {
            await this.markFailed(result.change_id, result.error);
            failCount++;
          }
        }
      } catch (error) {
        // Network error -- entire batch fails, retry later
        for (const change of batch) {
          await this.incrementRetry(change.change_id);
          failCount++;
        }
        // Stop pushing if network error (don't waste battery)
        break;
      }
    }

    return { successCount, failCount };
  }

  /**
   * Topological sort: ensure parent entities before child entities.
   * Patient -> Queue Entry -> Vitals -> Test Results
   */
  private topologicalSort(changes: ChangeLogEntry[]): ChangeLogEntry[] {
    const priority: Record<string, number> = {
      'patient': 0,
      'queue_entry': 1,
      'appointment': 1,
      'vital': 2,
      'test_result': 2,
      'billing': 3
    };
    return [...changes].sort((a, b) => {
      const pa = priority[a.entity_type] ?? 99;
      const pb = priority[b.entity_type] ?? 99;
      if (pa !== pb) return pa - pb;
      return a.created_at - b.created_at;
    });
  }

  /**
   * Increment retry count with exponential backoff.
   * Base delay: 1s, 2s, 4s, 8s, ... max 60s
   * Jitter: +/- 20% to avoid thundering herd
   */
  private getBackoffDelay(retryCount: number): number {
    const exponential = Math.min(
      this.BASE_DELAY * Math.pow(2, retryCount),
      60000  // cap at 60 seconds
    );
    const jitter = exponential * (0.8 + Math.random() * 0.4);  // +/- 20%
    return Math.floor(jitter);
  }
}
```

### 3.3 Pull Protocol

```typescript
/**
 * Pull changes from server incrementally.
 * Uses last_sync_timestamp cursor for delta sync.
 * Falls back to full sync if delta sync returns 409 (stale cursor).
 */
async pullChanges(): Promise<void> {
  const lastSync = await this.getLastSyncTimestamp();
  let cursor: string | null = null;

  try {
    // Delta sync
    const response = await this.api.pullChanges({
      since: lastSync,
      cursor: cursor,
      limit: 200
    });

    await this.applyRemoteChanges(response.changes);
    await this.setLastSyncTimestamp(response.server_timestamp);

    // If more pages, paginate
    if (response.next_cursor) {
      cursor = response.next_cursor;
      // Continue fetching in background
      this.schedulePullPage(cursor);
    }
  } catch (error) {
    if ((error as any).status === 409) {
      // Stale cursor -- fall back to full sync
      await this.fullSync();
    }
  }
}

/**
 * Apply remote changes to local DB.
 * For each incoming change, check if local has conflicting pending changes.
 */
async applyRemoteChanges(changes: RemoteChange[]): Promise<void> {
  const db = await this.getDB();
  const tx = db.transaction(['patients', 'queue_entries', 'appointments', 'vitals', 'change_log'], 'readwrite');

  for (const change of changes) {
    switch (change.entity_type) {
      case 'patient':
        await this.applyPatientChange(tx.objectStore('patients'), change);
        break;
      case 'queue_entry':
        await this.applyQueueChange(tx.objectStore('queue_entries'), change);
        break;
      // ... other entity types
    }
  }

  await tx.done;
}

/**
 * Delta sync: only fetch changes since last sync timestamp.
 * Full sync: fetch all data, replace local DB.
 * Delta is default; full sync triggered on:
 *   - First sync after install
 *   - Stale cursor (409 from server)
 *   - Manual "Refresh All" by user
 *   - Recovery after quota exceeded
 */
async fullSync(): Promise<void> {
  const response = await this.api.fullSync({ device_id: this.deviceId });
  await this.replaceLocalDB(response.all_data);
  await this.setLastSyncTimestamp(response.server_timestamp);
}
```

---

## 4. CONFLICT RESOLUTION

### 4.1 Conflict Resolution Strategies

| Strategy | Description | Used For |
|---|---|---|
| **LWW (Last Writer Wins)** | Compare `server_updated_at` values. Higher timestamp wins. | Appointments, Settings, Profile |
| **Server Wins** | Remote data always overwrites local. Essential for clinical integrity. | Queue state, Tests, Billing |
| **Local Wins (optimistic)** | Local data kept; server notified. For non-critical user-generated data. | Draft notes, Local preferences |
| **Three-Way Merge** | Compare local vs remote vs original. Merge non-conflicting fields; flag conflicts. | Patient demographics (address, phone) |
| **Manual Resolution** | Show diff UI; let user choose which version to keep. | Duplicate patient registration |
| **Custom Merge** | Domain-specific logic: e.g., queue token sequencing. | Queue position recalc |

### 4.2 LWW Detailed Flow

```
  Client A                    Server                    Client B
      |                         |                         |
      |--- UPDATE patient ----->|                         |
      |    timestamp: 1000      |                         |
      |                         |--- UPDATE patient ----->|
      |                         |    timestamp: 1000      |
      |                         |                         |
      |<--- OK timestamp: 1000 -|                         |
      |                         |                         |
      |                         |<--- OK timestamp: 1000 -|
      |                         |                         |
      |              (both see same, no conflict)         |
      |                         |                         |
      |--- UPDATE patient ----->|                         |
      |    timestamp: 1200      |                         |
      |                         |<--- UPDATE patient -----|
      |                         |    timestamp: 1100      |
      |                         |                         |
      |                         | Client B has lower ts,  |
      |                         | Server responds 409:     |
      |                         | { status: "conflict",   |
      |<--- OK timestamp: 1200 -|   server_data: {...},   |
      |                         |   server_ts: 1200 }     |
      |                         |                         |
      |                         | Client B receives 409,  |
      |                         | overwrites local with   |
      |                         | server_data (server ts  |
      |                         | 1200 > local ts 1100)   |
```

### 4.3 Conflict Notification UI

```typescript
interface ConflictRecord {
  conflict_id: string;
  entity_type: string;
  entity_id: string;
  local_value: any;
  remote_value: any;
  merged_value: any;
  status: 'unresolved' | 'resolved' | 'dismissed';
  created_at: number;
}

// Conflict dialog shown to user for manual resolution:
// "A change was made to Patient: Rajesh Kumar
//  Your change: Phone: 9876543210
//  Server change: Phone: 9876501234
//  [Keep Mine]  [Keep Server]  [Edit Both]"
```

### 4.4 Conflict Prevention

- **Optimistic locking**: Client sends `expected_server_timestamp` with each write. Server rejects if timestamp has changed.
- **Idempotency keys**: Each mutation has a unique idempotency key. Server deduplicates.
- **Debounced writes**: Auto-save fields (like notes) debounce 2 seconds before queuing to change log.

---

## 5. INDEXEDDB SCHEMA

### 5.1 Object Stores

```typescript
// Database: ghos_offline (version 3)

const DB_VERSION = 3;
const DB_NAME = 'ghos_offline';

interface DatabaseSchema {
  // --- Syncable entities ---
  patients: {
    keyPath: 'patient_id';
    indexes: ['phone', 'name', 'server_updated_at'];
  };
  queue_entries: {
    keyPath: 'entry_id';
    indexes: ['status', 'patient_id', 'server_updated_at'];
  };
  appointments: {
    keyPath: 'appointment_id';
    indexes: ['patient_id', 'slot_date', 'status'];
  };
  vitals: {
    keyPath: 'vital_id';
    indexes: ['patient_id', 'recorded_at'];
  };
  test_results: {
    keyPath: 'result_id';
    indexes: ['patient_id', 'test_type', 'recorded_at'];
  };

  // --- Sync infrastructure ---
  change_log: {
    keyPath: 'change_id';
    autoIncrement: true;
    indexes: ['status', 'entity_type_entity_id', 'created_at'];
  };
  conflicts: {
    keyPath: 'conflict_id';
    indexes: ['status'];
  };
  sync_metadata: {
    keyPath: 'key';  // key-value store
  };

  // --- Application state ---
  settings: {
    keyPath: 'key';
  };
  notifications: {
    keyPath: 'notification_id';
    indexes: ['is_read', 'received_at'];
  };
  pending_uploads: {
    keyPath: 'upload_id';
    indexes: ['status'];
  };
}
```

### 5.2 Version Migration

```typescript
function upgradeDB(db: IDBDatabase, oldVersion: number, newVersion: number) {
  switch (oldVersion) {
    case 0:  // fresh install
      db.createObjectStore('patients', { keyPath: 'patient_id' });
      db.createObjectStore('queue_entries', { keyPath: 'entry_id' });
      db.createObjectStore('appointments', { keyPath: 'appointment_id' });
      db.createObjectStore('vitals', { keyPath: 'vital_id' });
      db.createObjectStore('test_results', { keyPath: 'result_id' });
      db.createObjectStore('change_log', { keyPath: 'change_id', autoIncrement: true });
      db.createObjectStore('conflicts', { keyPath: 'conflict_id' });
      db.createObjectStore('sync_metadata', { keyPath: 'key' });
      db.createObjectStore('settings', { keyPath: 'key' });
      db.createObjectStore('notifications', { keyPath: 'notification_id' });
      db.createObjectStore('pending_uploads', { keyPath: 'upload_id' });
      // fallthrough
    case 1:
      // Added pending_uploads store
      db.createObjectStore('pending_uploads', { keyPath: 'upload_id' });
      // fallthrough
    case 2:
      // Add indexes to change_log
      const changeLogStore = upgradeTransaction.objectStore('change_log');
      changeLogStore.createIndex('by_status', 'status', { unique: false });
      changeLogStore.createIndex('by_entity', ['entity_type', 'entity_id'], { unique: false });
      changeLogStore.createIndex('by_created', 'created_at', { unique: false });
      break;
  }
}
```

---

## 6. NETWORK MONITORING

### 6.1 Online/Offline Detection

```typescript
class OfflineManager {
  private _isOnline: boolean = navigator.onLine;
  private _connectionQuality: 'good' | 'poor' | 'none' = 'good';
  private healthCheckTimer: number | null = null;
  private listeners: Set<(status: ConnectionStatus) => void> = new Set();

  get isOnline(): boolean { return this._isOnline; }
  get connectionQuality(): string { return this._connectionQuality; }

  init(): void {
    window.addEventListener('online', () => this.handleOnline());
    window.addEventListener('offline', () => this.handleOffline());
    this.startHealthCheck();
  }

  private handleOnline(): void {
    this._isOnline = true;
    this.notify({ status: 'online' });
    // Trigger sync
    syncEngine.pushChanges();
    syncEngine.pullChanges();
  }

  private handleOffline(): void {
    this._isOnline = false;
    this._connectionQuality = 'none';
    if (this.healthCheckTimer) {
      clearInterval(this.healthCheckTimer);
    }
    this.notify({ status: 'offline' });
  }

  /**
   * Periodic health check to detect captive portals or degraded connectivity.
   * Pings a lightweight endpoint every 30 seconds.
   */
  private startHealthCheck(): void {
    this.healthCheckTimer = window.setInterval(async () => {
      try {
        const start = performance.now();
        const response = await fetch('/api/v1/health', {
          method: 'HEAD',
          cache: 'no-store'
        });
        const latency = performance.now() - start;
        this._connectionQuality = latency < 500 ? 'good' : 'poor';
        this._isOnline = response.ok;
      } catch {
        this._isOnline = false;
        this._connectionQuality = 'none';
      }
      this.notify({ status: this._isOnline ? 'online' : 'offline', quality: this._connectionQuality });
    }, 30000);
  }

  onStatusChange(callback: (status: ConnectionStatus) => void): () => void {
    this.listeners.add(callback);
    return () => this.listeners.delete(callback);
  }
}
```

### 6.2 Status Indicator UI

```
 +-----------------------+
 |  [green dot] Online   |  -- Normal operation. Full sync active.
 +-----------------------+

 +-----------------------+
 |  [yellow dot] Poor    |  -- Connectivity degraded. Sync delayed.
 |  Connection           |  -- Read from cache; writes queued.
 +-----------------------+

 +-----------------------+
 |  [red dot] Offline    |  -- No connectivity.
 |  Working offline...   |  -- All writes queued locally.
 |  Last sync: 15m ago   |  -- Reads from cache only.
 +-----------------------+

 +-----------------------+
 |  [blue spinner]       |  -- Sync in progress.
 |  Syncing... (3 items) |  -- Shows pending operation count.
 +-----------------------+

 +-----------------------+
 |  [orange exclamation] |  -- Sync conflict detected.
 |  1 conflict to resolve|  -- Tap to open conflict resolution dialog.
 +-----------------------+
```

### 6.3 Graceful Degradation Rules

| Feature | Online | Offline |
|---|---|---|
| View queue | Live WebSocket | Cached snapshot |
| Join queue | Instant | Pending sync badge |
| Patient registration | Submit to server | Local + queued |
| Edit patient | Real-time | Queued change |
| View test results | Latest from server | Cached results |
| Billing / Payment | Full functionality | Hidden (show "Online required") |
| Settings | Read/write | Read/write (local only) |
| Notifications | Push-enabled | Queued; delivered on reconnect |

---

## 7. SYNC UI

### 7.1 Sync Status Badge Component

```typescript
interface SyncStatusBadgeProps {
  pendingCount: number;
  lastSyncTime: Date | null;
  isOnline: boolean;
  isSyncing: boolean;
  conflictCount: number;
  onSync: () => void;
  onConflicts: () => void;
}

function SyncStatusBadge(props: SyncStatusBadgeProps) {
  if (!props.isOnline) {
    return <Badge variant="error" icon="offline">Offline -- Queued: {props.pendingCount}</Badge>;
  }
  if (props.isSyncing) {
    return <Badge variant="info" icon="sync">Syncing {props.pendingCount} items...</Badge>;
  }
  if (props.conflictCount > 0) {
    return <Badge variant="warning" icon="conflict" onClick={props.onConflicts}>
      {props.conflictCount} conflict(s) to resolve
    </Badge>;
  }
  if (props.pendingCount > 0) {
    return <Badge variant="info" icon="pending">{props.pendingCount} pending</Badge>;
  }
  return <Badge variant="success" icon="check">Synced</Badge>;
}
```

### 7.2 Sync History Log

```typescript
interface SyncHistoryEntry {
  timestamp: number;
  type: 'push' | 'pull';
  status: 'success' | 'partial' | 'failed';
  itemsPushed: number;
  itemsPulled: number;
  errors: string[];
  duration: number;  // ms
}

// Displayed in Settings > Sync History
// Each entry shows: time, type, status, item counts
// Tappable for details: list of errors if failed
```

### 7.3 Manual Sync Trigger

```typescript
function SyncControls() {
  const { isOnline, syncEngine, lastSyncTime } = useOffline();

  const handleManualSync = async () => {
    const result = await syncEngine.manualSync();
    toast({
      title: result.success ? 'Sync complete' : 'Sync had errors',
      description: `Pushed: ${result.pushCount}, Pulled: ${result.pullCount}, Errors: ${result.errorCount}`
    });
  };

  return (
    <View>
      <Text>Last synced: {formatRelativeTime(lastSyncTime)}</Text>
      <Button onPress={handleManualSync} disabled={!isOnline}>
        Sync Now
      </Button>
    </View>
  );
}
```

---

## 8. EDGE CASES

### 8.1 Large Payload Chunking

```typescript
// When pushing large payloads (> 1 MB), split into chunks.
// Server reassembles by change_id and chunk_index.

const MAX_CHUNK_SIZE = 512 * 1024;  // 512 KB

async function pushLargePayload(change: ChangeLogEntry): Promise<void> {
  const payloadStr = JSON.stringify(change.payload);
  if (payloadStr.length <= MAX_CHUNK_SIZE) {
    return this.pushSingle(change);
  }

  const chunks = chunkString(payloadStr, MAX_CHUNK_SIZE);
  for (let i = 0; i < chunks.length; i++) {
    await this.api.pushChangeChunk({
      change_id: change.change_id,
      chunk_index: i,
      total_chunks: chunks.length,
      data: chunks[i]
    });
  }
}
```

### 8.2 Sync Ordering for Dependencies

```
Example: Register patient "Rajesh" before adding vitals for that patient.

1. Patient INSERT:     { entity_id: "pat_123", entity_type: "patient", ... }
2. Vital INSERT:       { entity_id: "vit_456", entity_type: "vital", payload: { patient_id: "pat_123" } }

Processing order MUST be [1] before [2]. The topological sort in pushChanges()
guarantees this by entity_type priority.

If [2] arrives at server before [1]:
  Server responds 409 "Parent entity not found"
  Client retries [2] after [1] succeeds.

For DELETE operations, reverse order: delete children before parents.
```

### 8.3 Tombstone Deletion Records

```typescript
// When an entity is deleted offline, a tombstone record is kept:
interface TombstoneRecord {
  entity_type: string;
  entity_id: string;
  deleted_at: number;
}

// Tombstones ensure that after sync:
// 1. The server knows to delete the entity
// 2. The local DB doesn't re-create the entity on next pull sync
// 3. Tombstones are cleaned up 30 days after successful sync

const TOMBSTONE_RETENTION_MS = 30 * 24 * 60 * 60 * 1000;  // 30 days

async function cleanupTombstones(): Promise<void> {
  const db = await openDB();
  const tx = db.transaction('sync_metadata', 'readwrite');
  const store = tx.objectStore('sync_metadata');
  const now = Date.now();

  const cursor = await store.index('by_key').openCursor(IDBKeyRange.bound('tombstone:', 'tombstone:\uffff'));
  while (cursor) {
    const tombstone = cursor.value as TombstoneRecord;
    if (now - tombstone.deleted_at > TOMBSTONE_RETENTION_MS) {
      cursor.delete();
    }
    cursor.continue();
  }
}
```

### 8.4 Quota Management

```typescript
// IndexedDB typically has ~50 MB quota on mobile browsers.
// GHOS monitors usage and evicts old data proactively.

class QuotaManager {
  private readonly MAX_QUOTA_BYTES = 45 * 1024 * 1024;  // 45 MB (leave 5 MB buffer)
  private readonly EVICTION_TARGET_BYTES = 30 * 1024 * 1024;  // evict down to 30 MB

  async checkAndEvictIfNeeded(): Promise<void> {
    const usage = await this.getUsage();
    if (usage > this.MAX_QUOTA_BYTES) {
      await this.evictOldest(this.EVICTION_TARGET_BYTES);
    }
  }

  private async evictOldest(targetBytes: number): Promise<void> {
    const db = await openDB();
    const tx = db.transaction(['patients', 'queue_entries', 'notifications', 'test_results'], 'readwrite');

    // Eviction order: notifications (oldest first), test_results, queue_entries, patients
    const evictionQueue = [
      { store: 'notifications', index: 'received_at', direction: 'prev' },
      { store: 'test_results', index: 'recorded_at', direction: 'prev' },
      { store: 'queue_entries', index: 'server_updated_at', direction: 'prev' },
      { store: 'patients', index: 'server_updated_at', direction: 'prev' }
    ];

    let freedBytes = 0;
    for (const { store: storeName, index: indexName, direction } of evictionQueue) {
      const store = tx.objectStore(storeName);
      const index = store.index(indexName);
      const cursor = await index.openCursor(null, direction as 'prev');

      while (cursor && freedBytes < (this.MAX_QUOTA_BYTES - targetBytes)) {
        const size = new Blob([JSON.stringify(cursor.value)]).size;
        cursor.delete();
        freedBytes += size;
        cursor.continue();
      }
    }

    await tx.done;
  }
}
```

---

## 9. SyncEngine CLASS

```typescript
class SyncEngine {
  private api: GilosApiClient;
  private db: IDBDatabase | null = null;
  private deviceId: string;
  private _isSyncing: boolean = false;

  constructor(api: GilosApiClient, deviceId: string) {
    this.api = api;
    this.deviceId = deviceId;
  }

  async init(): Promise<void> {
    this.db = await openDB(DB_NAME, DB_VERSION, { upgrade: upgradeDB });
    this.startPeriodicSync();
  }

  async pushChanges(): Promise<SyncResult> {
    if (this._isSyncing) return { successCount: 0, failCount: 0 };
    this._isSyncing = true;
    try {
      return await this._doPush();
    } finally {
      this._isSyncing = false;
    }
  }

  async pullChanges(): Promise<SyncResult> {
    if (this._isSyncing) return { successCount: 0, failCount: 0 };
    this._isSyncing = true;
    try {
      return await this._doPull();
    } finally {
      this._isSyncing = false;
    }
  }

  async manualSync(): Promise<{ pushCount: number; pullCount: number; errorCount: number; }> {
    const pushResult = await this.pushChanges();
    const pullResult = await this.pullChanges();
    return {
      pushCount: pushResult.successCount,
      pullCount: pullResult.successCount,
      errorCount: pushResult.failCount + pullResult.failCount
    };
  }

  async resolveConflict(conflictId: string, resolution: 'local' | 'remote' | 'custom', customValue?: any): Promise<void> {
    const conflict = await this.db!.get('conflicts', conflictId);
    if (!conflict) return;

    if (resolution === 'local') {
      // Keep local value, push again
      await this.markUnsynced(conflict.entity_type, conflict.entity_id);
      await this.pushChanges();
    } else if (resolution === 'remote') {
      // Accept server value
      const store = this.db!.transaction(conflict.entity_type, 'readwrite')
        .objectStore(conflict.entity_type);
      await store.put(conflict.remote_value);
    } else if (resolution === 'custom') {
      // Use merged value
      const store = this.db!.transaction(conflict.entity_type, 'readwrite')
        .objectStore(conflict.entity_type);
      await store.put(customValue);
      await this.markUnsynced(conflict.entity_type, conflict.entity_id);
      await this.pushChanges();
    }

    await this.db!.delete('conflicts', conflictId);
  }

  private startPeriodicSync(): void {
    // Every 15 minutes when online
    setInterval(() => {
      if (navigator.onLine) {
        this.pushChanges();
        this.pullChanges();
      }
    }, 15 * 60 * 1000);
  }

  private async _doPush(): Promise<SyncResult> { /* ... implementation from 3.2 ... */ }
  private async _doPull(): Promise<SyncResult> { /* ... implementation from 3.3 ... */ }
}
```

---

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|---|---|---|
| Sync strategy | Push local + Pull remote | Bidirectional; no automatic conflict broadcast needed |
| Change tracking | Append-only change log | Sequential replay, easy debugging, supports undo |
| Conflict resolution | LWW (server timestamp wins) | Simple to implement, predictable behavior |
| Operation ordering | Topological sort by entity type | Prevents foreign-key constraint failures |
| Network detection | navigator.onLine + health check | Handles captive portals and degraded connectivity |
| Retry strategy | Exponential backoff with jitter | Prevents thundering herd on reconnect |
| Local storage | IndexedDB (PWA), Room (Android), CoreData (iOS) | Platform-native; 50 MB quota managed |
| Quota management | LRU eviction by entity priority | Preserves critical patient/queue data over history |
| Sync trigger | Periodic (15 min) + event-driven (connectivity) + manual | Balance between freshness and battery |
| Conflict UI | Non-blocking badge + resolution dialog | User stays productive; resolves when convenient |
| Offline writes | Optimistic (write local immediately, queue sync) | Instant feedback; no loading spinners |

---

## 11. REFERENCES

- IndexedDB Specification: https://www.w3.org/TR/IndexedDB/
- Workbox Background Sync: https://developer.chrome.com/docs/workbox/modules/workbox-background-sync
- Network Information API: https://developer.mozilla.org/en-US/docs/Web/API/Network_Information_API
- Offline Cookbook (Jake Archibald): https://web.dev/offline-cookbook/
- Conflict-Free Replicated Data Types: https://en.wikipedia.org/wiki/Conflict-free_replicated_data_type
- LWCR (Last Writer Wins Register): https://crdt.tech/implementations/last-writer-wins-register
- IndexedDB Best Practices: https://web.dev/indexeddb-best-practices/
