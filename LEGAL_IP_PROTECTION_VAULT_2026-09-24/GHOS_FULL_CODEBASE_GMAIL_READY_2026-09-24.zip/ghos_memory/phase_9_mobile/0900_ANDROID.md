---
file_id: "0900"
module_name: "Android App"
version: "2.0"
status: "Draft"
phase: "Phase 9 -- Mobile"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md", "0300_QUEUE_MANAGEMENT.md", "0500_PATIENT_MANAGEMENT.md"]
related_files: ["0901_IOS.md", "0902_PWA.md", "0903_OFFLINE_MODE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "android", "native", "kotlin", "jetpack-compose", "hilt", "room", "mvvm", "clean-architecture"]
---

# GHOS -- Android Native App

> "A premium, offline-capable Android experience for patients and clinic staff. Every feature of the PWA, plus deep OS integration."

---

## 1. PURPOSE

The GHOS Android app is a **native companion** to the PWA, offering deeper platform integration, offline resilience via Room, biometric authentication, NFC scanning, background location, home-screen widgets, and native push notifications. It follows **Clean Architecture** with **MVVM** presentation and **Hilt** dependency injection.

---

## 2. ARCHITECTURE OVERVIEW

### 2.1 Clean Architecture Layers

```
+----------------------------------------------------------------------+
|                       PRESENTATION LAYER                              |
|  +---------------------------+  +----------------------------------+  |
|  | Jetpack Compose UI        |  | ViewModels (StateFlow)           |  |
|  | - Screens (Composables)   |  | - MainViewModel                  |  |
|  | - Navigation (NavHost)    |  | - AuthViewModel                  |  |
|  | - Custom Components       |  | - QueueViewModel                 |  |
|  | - Themes / Material3      |  | - AppointmentViewModel           |  |
|  +---------------------------+  +----------------------------------+  |
+----------------------------------+-----------------------------------+
                                   |
                           Use Cases (domain)
                                   |
+----------------------------------------------------------------------+
|                        DOMAIN LAYER                                   |
|  +---------------------------+  +----------------------------------+  |
|  | Use Cases / Interactors   |  | Domain Models (entities)         |  |
|  | - GetQueueStatusUseCase   |  | - Patient                       |  |
|  | - RegisterPatientUC       |  | - QueueEntry                    |  |
|  | - SyncQueueUseCase        |  | - Appointment                   |  |
|  | - LoginUseCase            |  | - VitalSign                     |  |
|  +---------------------------+  +----------------------------------+  |
+----------------------------------+-----------------------------------+
                                   |
                            Repository Interfaces
                                   |
+----------------------------------------------------------------------+
|                         DATA LAYER                                    |
|  +-------------------+  +------------------+  +-------------------+   |
|  | Room Database     |  | Retrofit Service  |  | DataStore         |   |
|  | (Local Cache)     |  | (Remote API)      |  | (Preferences)     |   |
|  +-------------------+  +------------------+  +-------------------+   |
|  | Repository Impls  |  | DTOs / Mappers   |  | Auth Interceptor   |   |
|  +-------------------+  +------------------+  +-------------------+   |
+----------------------------------------------------------------------+
```

### 2.2 MVVM Pattern with Data Flow

```
  UI (Composable)
      |  observes StateFlow
      v
  ViewModel
      |  calls suspend functions
      v
  UseCase (domain)
      |  calls repository interface
      v
  RepositoryImpl (data)
      |-- LocalDataSource (Room)  <-- single source of truth
      |-- RemoteDataSource (Retrofit)
      |
      Flow<Result<Model>>  -->  UI
```

### 2.3 Dependency Injection (Hilt)

```kotlin
// App-level module
@Module
@InstallIn(SingletonComponent::class)
object AppModule {
    @Provides @Singleton
    fun provideDatabase(@ApplicationContext ctx: Context): AppDatabase =
        Room.databaseBuilder(ctx, AppDatabase::class.java, "ghos_cache.db")
            .fallbackToDestructiveMigration()
            .build()

    @Provides @Singleton
    fun provideApiService(@AuthInterceptor interceptor: AuthInterceptor): GilosApi =
        Retrofit.Builder()
            .baseUrl(BuildConfig.API_BASE_URL)
            .client(OkHttpClient.Builder()
                .addInterceptor(interceptor)
                .addInterceptor(HttpLoggingInterceptor().apply {
                    level = if (BuildConfig.DEBUG) BODY else NONE
                })
                .addInterceptor(CacheInterceptor(AppCacheUtils.cacheDir))
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build())
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(GilosApi::class.java)

    @Provides @Singleton
    fun provideEncryptedPrefs(@ApplicationContext ctx: Context): EncryptedSharedPreferences =
        EncryptedSharedPreferences.create(
            ctx, "ghos_secure_prefs",
            MasterKey.Builder(ctx).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
            EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
            EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
        )
}
```

---

## 3. FEATURE MODULES

### 3.1 Feature Map

```
com.ghos.android/
  +-- app/
  |     +-- GilosApp.kt              (Application class, Hilt entry)
  |     +-- MainActivity.kt          (Single activity, NavHost)
  |     +-- navigation/
  |           +-- AppNavGraph.kt
  |           +-- Screen.kt           (sealed class routes)
  |
  +-- auth/
  |     +-- AuthViewModel.kt
  |     +-- LoginScreen.kt
  |     +-- BiometricAuthScreen.kt
  |     +-- BiometricHelper.kt        (BiometricPrompt + CryptoObject)
  |
  +-- queue/
  |     +-- QueueViewModel.kt
  |     +-- QueueDashboardScreen.kt
  |     +-- QueueCard.kt
  |     +-- WebSocketManager.kt       (OkHttp WebSocket + reconnection)
  |
  +-- patient/
  |     +-- PatientViewModel.kt
  |     +-- PatientTimelineScreen.kt
  |     +-- PatientDetailScreen.kt
  |
  +-- appointment/
  |     +-- AppointmentViewModel.kt
  |     +-- BookingScreen.kt
  |     +-- SlotPicker.kt
  |
  +-- scanner/
  |     +-- QrCodeScanner.kt          (ML Kit BarcodeScanning)
  |     +-- NfcScannerService.kt      (NFC tag read/write)
  |
  +-- notification/
  |     +-- NotificationService.kt    (FCM messaging service)
  |     +-- NotificationHelper.kt     (channels, importance, deep link)
  |
  +-- widget/
  |     +-- QueueWidgetProvider.kt    (RemoteViews, periodic update)
  |     +-- QueueWidgetConfig.kt
  |
  +-- settings/
  |     +-- SettingsScreen.kt
  |     +-- ThemeViewModel.kt
```

### 3.2 Authentication Flow

```kotlin
// Biometric + PIN fallback
class BiometricHelper(private val activity: FragmentActivity) {
    private val executor = ContextCompat.getMainExecutor(activity)
    private val biometricPrompt = BiometricPrompt(activity, executor, object : BiometricPrompt.AuthenticationCallback() {
        override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
            val cryptoObject = result.cryptoObject
            // Unlock EncryptedSharedPreferences / Android Keystore key
            _authResult.tryEmit(AuthResult.Success)
        }
        override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
            _authResult.tryEmit(AuthResult.Error(errorCode, errString.toString()))
        }
        override fun onAuthenticationFailed() {
            _authResult.tryEmit(AuthResult.Failed)
        }
    })

    fun authenticate(title: String = "Verify identity") {
        val promptInfo = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setSubtitle("Use your fingerprint or face to continue")
            .setAllowedAuthenticators(
                BIOMETRIC_STRONG or DEVICE_CREDENTIAL
            )
            .build()
        biometricPrompt.authenticate(promptInfo)
    }
}
```

### 3.3 Queue Dashboard WebSocket

```kotlin
class WebSocketManager(
    private val okHttpClient: OkHttpClient,
    private val apiBaseUrl: String
) {
    private var webSocket: WebSocket? = null
    private val _queueUpdates = MutableSharedFlow<QueueUpdate>()

    val queueUpdates: SharedFlow<QueueUpdate> = _queueUpdates.asSharedFlow()

    fun connect(token: String, hospitalId: String, queueId: String) {
        val request = Request.Builder()
            .url("wss://$apiBaseUrl/ws/queue/$hospitalId/$queueId?token=$token")
            .build()

        webSocket = okHttpClient.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                Log.i("WS", "Connected to queue feed")
            }
            override fun onMessage(webSocket: WebSocket, text: String) {
                val update = Json.decodeFromString<QueueUpdate>(text)
                _queueUpdates.tryEmit(update)
            }
            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                Log.w("WS", "Connection failed: ${t.message}")
                scheduleReconnect() // exponential backoff: 1s, 2s, 4s, ... max 60s
            }
            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                Log.i("WS", "Connection closed: $reason")
            }
        })
    }

    fun disconnect() {
        webSocket?.close(1000, "Client closing")
        webSocket = null
    }

    private fun scheduleReconnect(delay: Long = 1000L) {
        Handler(Looper.getMainLooper()).postDelayed({
            connect(...)
        }, delay.coerceAtMost(60_000L))
    }
}
```

---

## 4. DATA LAYER

### 4.1 Room Database Schema

```sql
-- Patient cache
CREATE TABLE cached_patients (
    patient_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    phone TEXT NOT NULL,
    age INTEGER,
    gender TEXT,
    aadhaar_hash TEXT,
    blood_group TEXT,
    address TEXT,
    profile_pic_url TEXT,
    last_visit_at TEXT,
    local_updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000),
    server_updated_at INTEGER NOT NULL DEFAULT 0
);

-- Queue cache
CREATE TABLE cached_queue_entries (
    entry_id TEXT PRIMARY KEY,
    token_number INTEGER NOT NULL,
    patient_id TEXT NOT NULL,
    patient_name TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'waiting',  -- waiting | with_doctor | completed | cancelled
    department TEXT,
    doctor_name TEXT,
    priority INTEGER DEFAULT 0,
    called_at TEXT,
    completed_at TEXT,
    local_updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000),
    server_updated_at INTEGER NOT NULL DEFAULT 0,
    FOREIGN KEY (patient_id) REFERENCES cached_patients(patient_id)
);

-- Notification cache
CREATE TABLE cached_notifications (
    notification_id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    body TEXT NOT NULL,
    type TEXT NOT NULL,  -- queue_update | appointment | lab_result | general
    reference_id TEXT,
    is_read INTEGER NOT NULL DEFAULT 0,
    received_at INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000)
);

-- Appointment cache
CREATE TABLE cached_appointments (
    appointment_id TEXT PRIMARY KEY,
    patient_id TEXT NOT NULL,
    doctor_id TEXT,
    doctor_name TEXT,
    department TEXT,
    slot_date TEXT NOT NULL,
    slot_time TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'scheduled',
    reason TEXT,
    local_updated_at INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000),
    server_updated_at INTEGER NOT NULL DEFAULT 0
);

-- Change log (for sync engine)
CREATE TABLE change_log (
    change_id INTEGER PRIMARY KEY AUTOINCREMENT,
    entity_type TEXT NOT NULL,        -- patient | queue_entry | notification | appointment
    entity_id TEXT NOT NULL,
    operation TEXT NOT NULL,          -- INSERT | UPDATE | DELETE
    payload TEXT NOT NULL,            -- JSON blob
    created_at INTEGER NOT NULL DEFAULT (strftime('%s','now') * 1000),
    synced INTEGER NOT NULL DEFAULT 0
);

-- Indexes
CREATE INDEX idx_queue_status ON cached_queue_entries(status);
CREATE INDEX idx_queue_patient ON cached_queue_entries(patient_id);
CREATE INDEX idx_appointment_date ON cached_appointments(slot_date);
CREATE INDEX idx_change_synced ON change_log(synced);
```

### 4.2 Room DAO Example

```kotlin
@Dao
interface QueueDao {
    @Query("SELECT * FROM cached_queue_entries WHERE status = :status ORDER BY priority DESC, token_number ASC")
    fun observeQueueByStatus(status: String): Flow<List<QueueEntryEntity>>

    @Query("SELECT * FROM cached_queue_entries WHERE entry_id = :entryId")
    suspend fun getEntry(entryId: String): QueueEntryEntity?

    @Upsert
    suspend fun upsertAll(entries: List<QueueEntryEntity>)

    @Query("DELETE FROM cached_queue_entries WHERE entry_id NOT IN (SELECT entry_id FROM cached_queue_entries ORDER BY local_updated_at DESC LIMIT 500)")
    suspend fun trimOldEntries()
}
```

### 4.3 Retrofit API Service

```kotlin
interface GilosApi {
    // Auth
    @POST("api/v1/auth/login")
    suspend fun login(@Body request: LoginRequest): LoginResponse

    @POST("api/v1/auth/refresh")
    suspend fun refreshToken(@Body request: RefreshRequest): LoginResponse

    // Patients
    @GET("api/v1/patients/{id}")
    suspend fun getPatient(@Path("id") patientId: String): PatientDto

    @POST("api/v1/patients")
    suspend fun registerPatient(@Body patient: PatientCreateDto): PatientDto

    // Queue
    @GET("api/v1/queue/{hospitalId}")
    suspend fun getQueue(@Path("hospitalId") hospitalId: String,
                          @Query("department") department: String?): QueueDto

    @POST("api/v1/queue/enqueue")
    suspend fun enqueuePatient(@Body request: EnqueueRequest): QueueEntryDto

    @POST("api/v1/queue/{entryId}/call")
    suspend fun callPatient(@Path("entryId") entryId: String): QueueEntryDto

    // Appointments
    @GET("api/v1/appointments")
    suspend fun getAppointments(@Query("patient_id") patientId: String): List<AppointmentDto>

    @POST("api/v1/appointments")
    suspend fun bookAppointment(@Body request: AppointmentCreateDto): AppointmentDto

    // Sync
    @POST("api/v1/sync/push")
    suspend fun pushChanges(@Body changes: List<ChangeLogDto>): SyncResponse

    @GET("api/v1/sync/pull")
    suspend fun pullChanges(@Query("since") lastSyncTimestamp: Long): SyncPayload
}
```

### 4.4 Auth Interceptor (OkHttp)

```kotlin
class AuthInterceptor @Inject constructor(
    private val tokenProvider: TokenProvider
) : Interceptor {
    override fun intercept(chain: Interceptor.Chain): Response {
        val original = chain.request()
        val token = tokenProvider.getAccessToken()
        val request = if (token != null) {
            original.newBuilder()
                .header("Authorization", "Bearer $token")
                .header("X-Device-ID", tokenProvider.getDeviceId())
                .build()
        } else original

        val response = chain.proceed(request)

        if (response.code == 401) {
            tokenProvider.refreshAccessToken()
            val retryRequest = original.newBuilder()
                .header("Authorization", "Bearer ${tokenProvider.getAccessToken()}")
                .build()
            response.close()
            return chain.proceed(retryRequest)
        }
        return response
    }
}
```

### 4.5 Repository Pattern (Offline-First)

```kotlin
class QueueRepositoryImpl @Inject constructor(
    private val localDataSource: QueueDao,
    private val remoteDataSource: GilosApi,
    private val changeLogDao: ChangeLogDao
) : QueueRepository {

    override fun observeQueue(hospitalId: String): Flow<List<QueueEntry>> {
        return localDataSource.observeQueueByStatus("waiting")
            .map { entities -> entities.map { it.toDomainModel() } }
    }

    override suspend fun refreshQueue(hospitalId: String) {
        try {
            val remote = remoteDataSource.getQueue(hospitalId)
            localDataSource.upsertAll(remote.entries.map { it.toEntity() })
        } catch (e: IOException) {
            // Offline -- use cached data
        }
    }

    override suspend fun enqueuePatient(request: EnqueueRequest) {
        val tempId = "temp_${UUID.randomUUID()}"
        val entity = QueueEntryEntity(
            entryId = tempId,
            patientId = request.patientId,
            status = "pending_sync",
            ...
        )
        localDataSource.upsertAll(listOf(entity))
        changeLogDao.insert(
            ChangeLogEntity(
                entityType = "queue_entry",
                entityId = tempId,
                operation = "INSERT",
                payload = Json.encodeToString(request)
            )
        )
        try {
            val remote = remoteDataSource.enqueuePatient(request)
            localDataSource.upsertAll(listOf(remote.toEntity()))
            changeLogDao.markSynced(tempId)
        } catch (e: IOException) {
            // Remains in change log; sync worker pushes later
        }
    }
}
```

---

## 5. NETWORK LAYER

### 5.1 WebSocket Connection (OkHttp)

```kotlin
// Leverages OkHttp's built-in WebSocket support.
// Reconnection uses exponential backoff: initial 1s, cap at 60s, jitter +/- 20%.
// Heartbeat ping every 30s to detect stale connections.
// Auto-subscribe to queue updates for the active hospital/department.
```

### 5.2 Network Status Monitoring

```kotlin
class NetworkMonitor @Inject constructor(
    @ApplicationContext private val context: Context
) {
    val isOnline: StateFlow<Boolean> = callbackFlow {
        val connectivityManager = context.getSystemService<ConnectivityManager>()!!
        val callback = object : ConnectivityManager.NetworkCallback() {
            override fun onAvailable(network: Network) { trySend(true) }
            override fun onLost(network: Network) { trySend(false) }
            override fun onCapabilitiesChanged(network: Network, caps: NetworkCapabilities) {
                trySend(caps.hasCapability(NET_CAPABILITY_INTERNET))
            }
        }
        connectivityManager.registerDefaultNetworkCallback(callback)
        awaitClose { connectivityManager.unregisterNetworkCallback(callback) }
    }.stateIn(CoroutineScope(Dispatchers.Default), SharingStarted.Eagerly, true)
}

// Usage in repositories:
// monitor.isOnline.value  ->  true = fetch remote, false = read cache + queue change
```

---

## 6. SECURITY

### 6.1 EncryptedSharedPreferences

```kotlin
private val masterKey = MasterKey.Builder(context)
    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
    .build()

val securePrefs = EncryptedSharedPreferences.create(
    context,
    "ghos_secure_prefs",
    masterKey,
    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
)

// Store: accessToken, refreshToken, deviceId, biometricKeyAlias
```

### 6.2 Android Keystore (Biometric Keys)

```kotlin
fun generateBiometricKey(keyAlias: String): KeyPair {
    val keyPairGenerator = KeyPairGenerator.getInstance(
        KeyProperties.KEY_ALGORITHM_EC, "AndroidKeyStore"
    )
    keyPairGenerator.initialize(
        KeyGenParameterSpec.Builder(keyAlias,
            KeyProperties.PURPOSE_SIGN or KeyProperties.PURPOSE_VERIFY)
            .setAlgorithmParameterSpec(ECGenParameterSpec("secp256r1"))
            .setUserAuthenticationRequired(true)        // biometric required
            .setUserAuthenticationValidityDurationSeconds(30)  // re-auth every 30s
            .build()
    )
    return keyPairGenerator.generateKeyPair()
}
```

### 6.3 SSL Pinning (OkHttp)

```kotlin
val certificatePinner = CertificatePinner.Builder()
    .add("api.ghos.in", "sha256/AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA=") // production cert hash
    .add("cdn.ghos.in", "sha256/BBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBBB=")
    .build()

val client = OkHttpClient.Builder()
    .certificatePinner(certificatePinner)
    .build()
```

### 6.4 ProGuard / R8 Rules

```
# Keep Retrofit API interfaces
-keep,allowobfuscation interface com.ghos.android.data.remote.** { *; }

# Keep Room entities
-keep class com.ghos.android.data.local.entity.** { *; }

# Keep Kotlin coroutines internals
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}

# Keep Gson serializers
-keepattributes Signature
-keepattributes *Annotation*
-keep class com.google.gson.** { *; }
-keep class * extends com.google.gson.TypeAdapter
-keep class * implements com.google.gson.TypeAdapterFactory
-keep class * implements com.google.gson.JsonSerializer
-keep class * implements com.google.gson.JsonDeserializer
```

---

## 7. OFFLINE STRATEGY

### 7.1 Room as Single Source of Truth

All UI reads come from Room via `Flow`. Network responses write to Room; UI observes Room. This ensures consistency whether online or offline.

```
  UI  <-- Flow<Entity> -- Room  <-- Repository sync -- Retrofit (when online)
                                     Repository insert -- ChangeLog (when offline)
```

### 7.2 Sync with WorkManager

```kotlin
class SyncWorker(
    context: Context,
    params: WorkerParameters
) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result {
        return try {
            val unsyncedChanges = changeLogDao.getUnsyncedChanges()
            if (unsyncedChanges.isNotEmpty()) {
                val response = api.pushChanges(unsyncedChanges.map { it.toDto() })
                changeLogDao.markAllSynced()
            }
            val lastSync = prefs.getLong("last_sync_timestamp", 0)
            val payload = api.pullChanges(lastSync)
            applyRemoteChanges(payload)
            prefs.edit().putLong("last_sync_timestamp", payload.timestamp).apply()
            Result.success()
        } catch (e: IOException) {
            Result.retry()
        }
    }
}

// Constraints: NetworkType.CONNECTED
// Periodic: 15-minute interval, flex interval 5 minutes
// Also triggered: on connectivity restored (via NetworkMonitor + WorkManager enqueue)
```

### 7.3 Conflict Resolution (Server Wins with Local Merge)

| Scenario | Resolution |
|---|---|
| Local INSERT, remote same key | Server response overwrites local |
| Local UPDATE, remote UPDATE | Compare `server_updated_at`. Higher wins. Merge non-conflicting fields. |
| Local DELETE, remote UPDATE | Queue tombstone; delete wins. |
| Remote DELETE, local UPDATE | Delete local; notify user. |
| Duplicate registration | Server returns 409 with existing ID; local temp entity matched by phone. |

---

## 8. TESTING

### 8.1 Unit Tests (JUnit 5 + MockK)

```kotlin
@Test
fun `enqueue patient offline stores in change log`() = runTest {
    val mockApi = mockk<GilosApi>()
    val mockDao = mockk<QueueDao>()
    val mockChangeLog = mockk<ChangeLogDao>()

    coEvery { mockApi.enqueuePatient(any()) } throws IOException("No network")
    every { mockDao.upsertAll(any()) } returns Unit
    every { mockChangeLog.insert(any()) } returns Unit

    val repo = QueueRepositoryImpl(mockDao, mockApi, mockChangeLog)
    repo.enqueuePatient(enqueueRequest)

    verify(exactly = 1) { mockChangeLog.insert(any()) }
}
```

### 8.2 UI Tests (Compose UI Test)

```kotlin
@Test
fun `queue dashboard shows empty state`() {
    composeTestRule.setContent {
        QueueDashboardScreen(
            viewModel = QueueViewModel(fakeQueueRepo),
            onPatientClick = {}
        )
    }
    composeTestRule.onNodeWithText("No patients in queue").assertIsDisplayed()
}
```

### 8.3 Screenshot Tests (Paparazzi)

```kotlin
@Test
fun `patient card renders correctly`() {
    paparazzi.snapshot {
        PatientCard(
            patient = samplePatient,
            position = 3,
            onCall = {}
        )
    }
}
```

---

## 9. BUILD & CI

### 9.1 Build Flavors

```groovy
    flavorDimensions "tier"
    productFlavors {
        free {
            dimension "tier"
            applicationIdSuffix ".free"
            versionNameSuffix "-free"
            buildConfigField "String", "API_BASE_URL", '"https://api.ghos.in"'
        }
        pro {
            dimension "tier"
            applicationIdSuffix ".pro"
            versionNameSuffix "-pro"
            buildConfigField "String", "API_BASE_URL", '"https://api.ghos.in"'
        }
    }
```

### 9.2 GitHub Actions Workflow

```yaml
name: Android CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Set up JDK 17
        uses: actions/setup-java@v4
        with:
          java-version: 17
          distribution: temurin
      - name: Grant execute permission for gradlew
        run: chmod +x gradlew
      - name: Run lint
        run: ./gradlew lint
      - name: Run unit tests
        run: ./gradlew testFreeDebugUnitTest
      - name: Build APK
        run: ./gradlew assembleFreeDebug
      - name: Upload APK
        uses: actions/upload-artifact@v4
        with:
          name: app-free-debug.apk
          path: app/build/outputs/apk/free/debug/
      - name: Firebase App Distribution
        if: github.ref == 'refs/heads/main'
        run: ./gradlew assembleFreeRelease appDistributionUploadFreeRelease
        env:
          FIREBASE_TOKEN: ${{ secrets.FIREBASE_TOKEN }}
```

### 9.3 Firebase App Distribution

Beta builds distributed to internal testers via Firebase App Distribution. Release builds go through Google Play Console (internal testing -> closed track -> open track -> production).

---

## 10. PERFORMANCE

### 10.1 Startup Optimization (Baseline Profiles)

Baseline Profiles generated via Macrobenchmark (Jetpack Startup library) for cold start < 500ms.

```
# baseline-prof.txt (generated from production runs)
HSPLandroidx.compose.foundation.layout.ColumnKt
HSPLandroidx.compose.material3.TextKt
HSPLcom.ghos.android.MainActivity
HSPLcom.ghos.android.navigation.AppNavGraphKt
...
```

### 10.2 Memory Profiling

- LeakCanary integrated for leak detection in debug builds.
- Android Studio Memory Profiler used during QA cycles.
- Heap dumps analyzed for retained fragments, large bitmaps.

### 10.3 APK Size Reduction

| Technique | Savings |
|---|---|
| R8 full mode (proguard-android-optimize.txt) | ~20% |
| Resource shrinking (shrinkResources true) | ~10% |
| WebP for all drawables | ~30% |
| Android App Bundles (AAB) | ~40% per delivery |
| On-demand feature modules | ~15% initial download |

Target: Free variant < 12 MB, Pro variant < 18 MB.

---

## 11. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|---|---|---|
| DI framework | Hilt | First-class Android support, less boilerplate than Dagger |
| Local DB | Room | Type-safe SQL, Flow integration, migration support |
| HTTP client | Retrofit + OkHttp | Interceptor chain for auth/logging/caching, WebSocket support |
| State management | StateFlow (ViewModels) | Lifecycle-aware, no memory leaks vs LiveData for Compose |
| Image loading | Coil | Kotlin-first, coroutine-native, Compose integration |
| Biometric storage | Android Keystore via EncryptedSharedPreferences | Hardware-backed key storage, FIDO2 compliant |
| Sync engine | WorkManager | Guaranteed execution, constraint-aware (network, battery) |
| Navigation | Jetpack Navigation Compose | Type-safe routes, deep link support, animation |
| Min SDK | 26 (Android 8.0) | 95%+ market coverage, modern API access (BiometricPrompt) |
| Target SDK | 34 (Android 14) | Latest privacy, permissions, and security requirements |

---

## 12. REFERENCES

- Android Developers: https://developer.android.com/docs
- Jetpack Compose: https://developer.android.com/jetpack/compose
- Hilt DI: https://developer.android.com/training/dependency-injection/hilt-android
- Room Database: https://developer.android.com/training/data-storage/room
- Android Keystore: https://developer.android.com/training/articles/keystore
- WorkManager: https://developer.android.com/topic/libraries/architecture/workmanager
- Firebase Cloud Messaging: https://firebase.google.com/docs/cloud-messaging
- ML Kit Barcode Scanning: https://developers.google.com/ml-kit/vision/barcode-scanning
- Baseline Profiles: https://developer.android.com/topic/performance/baselineprofiles
