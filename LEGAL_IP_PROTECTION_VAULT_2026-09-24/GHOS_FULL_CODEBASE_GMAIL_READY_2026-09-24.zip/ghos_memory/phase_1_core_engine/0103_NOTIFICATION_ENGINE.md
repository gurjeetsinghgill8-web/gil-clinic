---
file_id: "0103"
module_name: "Notification Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0104_COMMUNICATION_ENGINE.md"]
related_files: ["0700_SMS.md", "0702_WHATSAPP.md", "0703_PUSH_NOTIFICATION.md", "0100_QUEUE_ENGINE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "notification", "alerts", "real-time", "websocket", "push"]
---

# 🔔 GHOS — Notification Engine

> **The Notification Engine is the real-time nerve system of GHOS. It delivers instant alerts to patients and staff across every channel, with automatic failover and delivery guarantees.**

---

## 1. PURPOSE

The Notification Engine manages the complete lifecycle of every notification in GHOS:
- **Trigger** — Any system event (queue call, report ready, appointment reminder)
- **Route** — Pick the best channel based on user presence, preferences, and cost
- **Deliver** — Send with delivery confirmation and retry logic
- **Track** — Log every notification attempt for analytics and debugging

---

## 2. NOTIFICATION TYPES

| Type | Trigger | Channels | Priority | TTL |
|------|---------|----------|----------|-----|
| `patient_called` | Staff clicks "Call" | WebSocket, Push, WhatsApp, Sound/Vibrate | Critical | 5 min |
| `patient_routed` | Patient sent to next dept | WebSocket, WhatsApp | High | 10 min |
| `report_ready` | Doctor signs report | WhatsApp, SMS, Push | High | 30 min |
| `appointment_reminder` | Cron (24h before) | WhatsApp, SMS | Medium | 24h |
| `followup_reminder` | Cron (configurable) | WhatsApp, Voice Call | Medium | 48h |
| `missed_call_alert` | Patient missed call | In-app toast, Sound/Vibrate | High | 2 min |
| `registration` | Patient registered | WhatsApp, SMS | High | 10 min |
| `queue_update` | Queue position changes | WebSocket | Low | continuous |
| `system_alert` | Staff system events | Push, In-app | Medium | 1 hour |
| `payment_reminder` | Pending payment | WhatsApp, SMS | Medium | 24h |

---

## 3. ARCHITECTURE

```
┌──────────────┐     ┌──────────────────┐     ┌──────────────────┐
│ Event Source  │────▶│ Notification     │────▶│ Channel Router   │
│ (Queue Engine)│     │ Orchestrator     │     │                  │
│ (Workflow)    │     │                  │     │ ┌────────────┐   │
│ (Manual)      │     │ • Deduplication  │     │ │ WebSocket  │   │
└──────────────┘     │ • Rate Limiting  │     │ │ Push (FCM) │   │
                     │ • Priority Queue │     │ │ WhatsApp   │   │
                     │ • Batching       │     │ │ SMS        │   │
                     └────────┬─────────┘     │ │ Voice Call │   │
                              │               │ │ Email      │   │
                              │               │ └────────────┘   │
                              ▼               └──────────────────┘
                     ┌──────────────────┐
                     │ Delivery Tracker  │
                     │ • Attempt log     │
                     │ • Status update   │
                     │ • Retry queue     │
                     └──────────────────┘
```

---

## 4. DATABASE SCHEMA

```sql
-- Core notifications table
CREATE TABLE notifications (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    visit_id UUID REFERENCES visits(id) ON DELETE CASCADE,
    patient_id UUID NOT NULL REFERENCES patients(id) ON DELETE CASCADE,
    type VARCHAR(50) NOT NULL,           -- patient_called, report_ready, etc.
    priority INTEGER DEFAULT 0,          -- 0=low, 1=medium, 2=high, 3=critical
    title VARCHAR(200),
    body TEXT,
    template_key VARCHAR(100),
    template_data JSONB,
    data JSONB,                          -- Additional payload (room, department, etc.)
    status VARCHAR(20) DEFAULT 'pending', -- pending, sent, delivered, failed, expired
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    expires_at TIMESTAMP,
    read_at TIMESTAMP
);

-- Delivery attempts log
CREATE TABLE notification_attempts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    notification_id UUID NOT NULL REFERENCES notifications(id) ON DELETE CASCADE,
    channel VARCHAR(20) NOT NULL,         -- websocket, push, sms, whatsapp, voice, email
    status VARCHAR(20) NOT NULL,          -- attempted, sent, delivered, failed
    response_code VARCHAR(20),
    response_body TEXT,
    error_message TEXT,
    attempt_number INTEGER DEFAULT 1,
    attempted_at TIMESTAMP DEFAULT NOW(),
    delivered_at TIMESTAMP,
    failed_at TIMESTAMP
);

-- Indexes for performance
CREATE INDEX idx_notifications_patient ON notifications(patient_id, status);
CREATE INDEX idx_notifications_visit ON notifications(visit_id);
CREATE INDEX idx_notifications_type ON notifications(type, status);
CREATE INDEX idx_notifications_created ON notifications(created_at);
CREATE INDEX idx_attempts_notification ON notification_attempts(notification_id);
CREATE INDEX idx_attempts_status ON notification_attempts(channel, status);
```

---

## 5. NOTIFICATION ORCHESTRATOR

```python
class NotificationOrchestrator:
    """
    Central orchestrator that manages the full notification lifecycle.
    
    Flow:
    1. Validate and deduplicate incoming notification requests
    2. Rate-limit by patient, type, and channel
    3. Persist to database
    4. Route to best available channel(s)
    5. Track delivery and trigger retries on failure
    """
    
    def __init__(self):
        self.channels = {
            "websocket": WebSocketChannel(),
            "push": PushChannel(),
            "whatsapp": WhatsAppChannel(),
            "sms": SMSChannel(),
            "voice": VoiceChannel(),
            "email": EmailChannel(),
        }
        self.rate_limiter = RateLimiter()
        self.delivery_tracker = DeliveryTracker()
    
    async def send(
        self,
        patient_id: UUID,
        notification_type: str,
        data: dict,
        visit_id: UUID = None,
        priority: int = 0,
        preferred_channels: List[str] = None
    ) -> NotificationResult:
        """
        Send a notification to a patient via the best available channels.
        
        Args:
            patient_id: Target patient UUID
            notification_type: Type key (patient_called, report_ready, etc.)
            data: Template variables and payload
            visit_id: Associated visit (optional)
            priority: 0-3 priority level
            preferred_channels: Force specific channel order (default: auto)
        """
        # 1. Deduplicate — prevent sending same notification within window
        dedup_key = f"notif:dedup:{patient_id}:{notification_type}"
        if await redis.exists(dedup_key):
            logger.info(f"Deduplicated {notification_type} for patient {patient_id}")
            return NotificationResult(duplicate=True)
        await redis.setex(dedup_key, 30, "1")  # 30s dedup window
        
        # 2. Rate limit check
        if not await self.rate_limiter.check(patient_id, notification_type):
            logger.warning(f"Rate limited {notification_type} for patient {patient_id}")
            return NotificationResult(rate_limited=True)
        
        # 3. Get patient info and preferences
        patient = await Patient.get(patient_id)
        channels = preferred_channels or self._determine_channels(patient, notification_type, priority)
        
        # 4. Get notification template
        template = get_notification_template(notification_type, patient.language)
        title = template["title"].format(**data)
        body = template["body"].format(**data)
        
        # 5. Persist notification
        notif = await Notification.create(
            patient_id=patient_id,
            visit_id=visit_id,
            type=notification_type,
            priority=priority,
            title=title,
            body=body,
            template_key=notification_type,
            template_data=data,
            data=data,
            expires_at=datetime.now() + timedelta(minutes=TTL_MAP.get(notification_type, 10))
        )
        
        # 6. Try channels in priority order
        final_result = NotificationResult()
        for channel_name in channels:
            channel = self.channels[channel_name]
            try:
                result = await channel.send(patient, title, body, data)
                await self.delivery_tracker.log_attempt(
                    notification_id=notif.id,
                    channel=channel_name,
                    status="sent" if result.success else "failed",
                    response_code=result.code,
                    response_body=result.body,
                    error_message=result.error,
                    attempt_number=final_result.attempts + 1
                )
                final_result.attempts += 1
                
                if result.success:
                    notif.status = "sent"
                    await notif.save()
                    final_result.success = True
                    final_result.channel = channel_name
                    
                    # If critical, send on multiple channels anyway
                    if priority < 3:  # Not critical — stop at first success
                        break
                else:
                    # Log failure and continue to next channel
                    logger.warning(f"Channel {channel_name} failed: {result.error}")
                    
            except Exception as e:
                await self.delivery_tracker.log_attempt(
                    notification_id=notif.id,
                    channel=channel_name,
                    status="failed",
                    error_message=str(e),
                    attempt_number=final_result.attempts + 1
                )
                logger.error(f"Channel {channel_name} exception: {e}", exc_info=True)
        
        if not final_result.success:
            notif.status = "failed"
            await notif.save()
            # Enqueue for retry
            await self._enqueue_retry(notif.id)
        
        return final_result
    
    def _determine_channels(self, patient, notification_type: str, priority: int) -> List[str]:
        """Determine the best channel order based on context."""
        # Critical alerts: try all channels
        if priority >= 3:
            return ["websocket", "push", "whatsapp", "sms", "voice"]
        
        # User is online: websocket first
        if patient.is_online:
            return ["websocket", "push", "whatsapp", "sms"]
        
        # Default: WhatsApp first (free + high open rate)
        return ["whatsapp", "sms", "push"]
```

---

## 6. CHANNEL IMPLEMENTATIONS

### 6.1 WebSocket Channel
```python
class WebSocketChannel:
    """
    Real-time push via persistent WebSocket connection.
    - Patient must be on the status page
    - Used for: patient_called, queue_update, misscall_alert
    - Zero cost, instant delivery
    """
    
    # In-memory map: patient_id → set of active connections
    connections: Dict[UUID, Set[WebSocket]] = defaultdict(set)
    
    async def connect(self, patient_id: UUID, websocket: WebSocket):
        await websocket.accept()
        self.connections[patient_id].add(websocket)
        logger.info(f"WebSocket connected: patient {patient_id}")
    
    async def disconnect(self, patient_id: UUID, websocket: WebSocket):
        self.connections[patient_id].discard(websocket)
        if not self.connections[patient_id]:
            del self.connections[patient_id]
    
    async def send(self, patient, title, body, data) -> ChannelResult:
        if patient.id not in self.connections:
            return ChannelResult(success=False, error="No active connection")
        
        payload = json.dumps({
            "type": data.get("notification_type", "alert"),
            "title": title,
            "body": body,
            "data": data,
            "timestamp": datetime.now().isoformat()
        })
        
        success_count = 0
        failed_connections = []
        
        for ws in self.connections[patient.id]:
            try:
                await ws.send_text(payload)
                success_count += 1
            except WebSocketDisconnect:
                failed_connections.append(ws)
        
        # Clean up dead connections
        for ws in failed_connections:
            self.connections[patient.id].discard(ws)
        
        if success_count > 0:
            return ChannelResult(success=True, code="sent", body=f"Sent to {success_count} connection(s)")
        return ChannelResult(success=False, error="All connections dead")
```

### 6.2 Push Notification Channel (FCM)
```python
class PushChannel:
    """
    Browser push notifications via Firebase Cloud Messaging (FCM).
    - Works when patient is NOT on the page
    - Requires notification permission
    - Used for: patient_called, report_ready, appointment_reminder
    """
    
    def __init__(self):
        self.fcm_key = settings.FCM_SERVER_KEY
        self.fcm_url = "https://fcm.googleapis.com/fcm/send"
    
    async def send(self, patient, title, body, data) -> ChannelResult:
        if not patient.fcm_token:
            return ChannelResult(success=False, error="No FCM token")
        
        payload = {
            "to": patient.fcm_token,
            "notification": {
                "title": title,
                "body": body,
                "icon": "/static/icons/icon-192.png",
                "badge": "/static/icons/badge.png",
                "vibrate": [200, 100, 200],
                "sound": "default",
                "tag": data.get("notification_type", "alert"),
                "requireInteraction": True
            },
            "data": {
                "url": data.get("tracking_url", ""),
                "type": data.get("notification_type", ""),
                "patient_id": str(patient.id)
            }
        }
        
        async with httpx.AsyncClient() as client:
            response = await client.post(
                self.fcm_url,
                json=payload,
                headers={
                    "Authorization": f"key={self.fcm_key}",
                    "Content-Type": "application/json"
                }
            )
            
            result = response.json()
            if result.get("success", 0) > 0:
                return ChannelResult(success=True, code="sent")
            elif result.get("failure", 0) > 0:
                error = result.get("results", [{}])[0].get("error", "Unknown")
                # If token expired, clear it
                if error == "NotRegistered":
                    patient.fcm_token = None
                    await patient.save()
                return ChannelResult(success=False, code=error)
```

### 6.3 In-App Channel (Sound + Vibration)
```python
class InAppChannel:
    """
    Browser-based sound and vibration alerts triggered via WebSocket or URL param.
    - Works within the PWA on patient's phone
    - Used for: patient_called (primary), misscall_alert
    - Uses AudioContext API for sound, Navigator.vibrate for haptic
    """
    
    # This channel is implemented client-side in JavaScript.
    # The server triggers it by:
    #   1. WebSocket event → client JS plays sound
    #   2. URL parameter ?misscall=1 → client detects on page load
    #   3. Streamlit rerun → sessionStorage flag detected by JS
    
    JS_TRIGGER_SCRIPT = """
    <script>
    (function() {
        // Check for misscall trigger via URL parameter
        const params = new URLSearchParams(window.location.search);
        if (params.get('misscall') === '1') {
            sessionStorage.setItem('cq_miss_PID', params.get('patient'));
            window.history.replaceState({}, '', window.location.pathname + window.location.hash);
        }
        
        // Global function called by Streamlit on status change
        window.triggerPatientAlert = function(type, data) {
            // Play sound
            try {
                const ctx = new (window.AudioContext || window.webkitAudioContext)();
                const osc = ctx.createOscillator();
                const gain = ctx.createGain();
                osc.connect(gain);
                gain.connect(ctx.destination);
                
                if (type === 'called') {
                    // Triple ascending beep
                    osc.frequency.setValueAtTime(523, ctx.currentTime);
                    osc.frequency.setValueAtTime(659, ctx.currentTime + 0.15);
                    osc.frequency.setValueAtTime(784, ctx.currentTime + 0.3);
                    gain.gain.setValueAtTime(0.5, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.6);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.6);
                } else if (type === 'misscall') {
                    // Short double beep
                    osc.frequency.setValueAtTime(880, ctx.currentTime);
                    osc.frequency.setValueAtTime(660, ctx.currentTime + 0.1);
                    gain.gain.setValueAtTime(0.4, ctx.currentTime);
                    gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.3);
                    osc.start(ctx.currentTime);
                    osc.stop(ctx.currentTime + 0.3);
                }
                
                // Vibration
                if (navigator.vibrate) {
                    navigator.vibrate(type === 'called' ? [200, 100, 200] : [100, 50, 100]);
                }
            } catch(e) {
                console.log('Audio alert not supported:', e);
            }
            
            // Show banner
            const banner = document.createElement('div');
            banner.className = 'alert-banner';
            banner.innerHTML = `<div class="alert-icon">🔵</div>
                               <div class="alert-text">${data.message || 'Your turn is here!'}</div>`;
            banner.style.cssText = 'position:fixed;top:0;left:0;right:0;z-index:9999;...';
            document.body.appendChild(banner);
            setTimeout(() => banner.remove(), 5000);
        };
    })();
    </script>
    """
    
    async def send(self, patient, title, body, data) -> ChannelResult:
        """Server-side: this is a no-op. Real work happens in client JS."""
        return ChannelResult(success=True, code="handled_by_client")
```

---

## 7. RETRY LOGIC & FAILOVER

```python
class RetryManager:
    """
    Reliable delivery with exponential backoff and channel failover.
    
    Strategy:
    - Level 1 (0-30s):    WebSocket retry every 5s
    - Level 2 (30s-2min): Push notification
    - Level 3 (2min-5min): WhatsApp message
    - Level 4 (5min+):     SMS (always works, universal fallback)
    - Level 5 (10min+):    Voice call (for critical alerts only)
    """
    
    RETRY_CONFIG = {
        "patient_called": {
            "max_retries": 5,
            "backoff_base": 2,          # Exponential: 5, 10, 20, 40, 80 seconds
            "backoff_max": 120,
            "fallback_after": 3,         # After 3 web retries, switch channel
            "channel_order": ["websocket", "push", "whatsapp", "sms"]
        },
        "report_ready": {
            "max_retries": 3,
            "backoff_base": 10,
            "backoff_max": 300,
            "fallback_after": 2,
            "channel_order": ["whatsapp", "sms", "email"]
        },
        "appointment_reminder": {
            "max_retries": 2,
            "backoff_base": 60,
            "backoff_max": 600,
            "fallback_after": 1,
            "channel_order": ["whatsapp", "sms", "voice"]
        }
    }
    
    async def process_retry_queue(self):
        """Background worker: processes the retry queue every 5 seconds."""
        while True:
            retry_items = await redis.zrangebyscore(
                "notif:retry_queue",
                0, datetime.now().timestamp(),
                withscores=True
            )
            
            for item, score in retry_items:
                data = json.loads(item)
                await self._retry_single(data)
                await redis.zrem("notif:retry_queue", item)
            
            await asyncio.sleep(5)
    
    async def _retry_single(self, data: dict):
        notif_id = data["notification_id"]
        notif = await Notification.get(notif_id)
        config = self.RETRY_CONFIG.get(notif.type, self.RETRY_CONFIG["patient_called"])
        
        # Count existing attempts
        attempts = await NotificationAttempt.filter(
            notification_id=notif_id
        ).count()
        
        if attempts >= config["max_retries"]:
            notif.status = "failed"
            await notif.save()
            logger.error(f"Notification {notif_id} failed after {attempts} attempts")
            return
        
        # Determine current channel
        channel_index = min(attempts // config["fallback_after"], len(config["channel_order"]) - 1)
        channel_name = config["channel_order"][channel_index]
        
        # Send via channel
        channel = self.channels[channel_name]
        result = await channel.send(notif.patient, notif.title, notif.body, notif.data)
        
        if result.success:
            notif.status = "sent"
            await notif.save()
        else:
            # Re-enqueue with backoff
            backoff = min(config["backoff_base"] ** attempts, config["backoff_max"])
            retry_at = datetime.now() + timedelta(seconds=backoff)
            await redis.zadd("notif:retry_queue", {json.dumps(data): retry_at.timestamp()})
```

---

## 8. RATE LIMITING

```python
class RateLimiter:
    """
    Prevent notification spam while ensuring critical alerts get through.
    
    Rules:
    - Max 5 notifications/min per patient (all types)
    - Max 2 critical alerts/min per patient
    - Max 1 SMS/minute per patient (cost control)
    - Max 10 WhatsApp messages/hour per patient
    - Max 1 voice call/30min per patient
    - Burst protection: no more than 3 notifications in 10 seconds
    """
    
    RULES = {
        "global":      {"window": 60,  "max": 5},
        "critical":    {"window": 60,  "max": 2},
        "sms":         {"window": 60,  "max": 1},
        "whatsapp":    {"window": 3600, "max": 10},
        "voice":       {"window": 1800, "max": 1},
        "burst":       {"window": 10,  "max": 3},
    }
    
    async def check(self, patient_id: UUID, notification_type: str) -> bool:
        key = f"ratelimit:{patient_id}:{notification_type}"
        count = await redis.incr(key)
        if count == 1:
            await redis.expire(key, self.RULES.get(notification_type, self.RULES["global"])["window"])
        
        max_allowed = self.RULES.get(notification_type, self.RULES["global"])["max"]
        return count <= max_allowed
```

---

## 9. DELIVERY TRACKING & ANALYTICS

```python
class DeliveryTracker:
    """
    Tracks every notification attempt for analytics and debugging.
    
    Metrics tracked:
    - Delivery rate by channel
    - Average delivery time per channel
    - Channel fallback rate
    - Patient notification preferences
    - Peak notification hours
    - Failure reasons breakdown
    """
    
    async def log_attempt(self, **kwargs):
        await NotificationAttempt.create(**kwargs)
    
    async def get_delivery_stats(self, hospital_id: UUID, days: int = 30) -> dict:
        """Returns delivery statistics for dashboard."""
        since = datetime.now() - timedelta(days=days)
        
        # Total by channel
        channel_stats = await NotificationAttempt.filter(
            attempted_at__gte=since
        ).annotate(
            count=Count("id"),
            success=Sum(Case(When(status="sent", then=1), default=0))
        ).group_by("channel").values("channel", "count", "success")
        
        # Delivery rates
        rates = {}
        for stat in channel_stats:
            rates[stat["channel"]] = {
                "total": stat["count"],
                "success": stat["success"],
                "rate": round(stat["success"] / stat["count"] * 100, 1) if stat["count"] > 0 else 0
            }
        
        # Average delivery time
        avg_times = await NotificationAttempt.filter(
            attempted_at__gte=since,
            delivered_at__isnull=False
        ).annotate(
            avg_time=Avg(F("delivered_at") - F("attempted_at"))
        ).values("channel", "avg_time")
        
        return {
            "channel_rates": rates,
            "avg_delivery_times": {t["channel"]: str(t["avg_time"]) for t in avg_times},
            "total_notifications": sum(s["count"] for s in channel_stats)
        }
```

---

## 10. NOTIFICATION TEMPLATES (Bilingual)

All templates support English and Hindi. Templates are stored in the database for admin customization.

```python
# Default templates — can be overridden in admin panel
NOTIFICATION_TEMPLATES = {
    "patient_called": {
        "title": {
            "en": "🔵 Your turn is here!",
            "hi": "🔵 आपकी बारी आ गई है!"
        },
        "body": {
            "en": "Token {token} — Please proceed to {department}, Room {room} immediately.",
            "hi": "टोकन {token} — कृपया तुरंत {department}, कक्ष {room} पर आएं।"
        }
    },
    "patient_routed": {
        "title": {
            "en": "➡️ Please proceed to next department",
            "hi": "➡️ कृपया अगले विभाग में जाएं"
        },
        "body": {
            "en": "Your token {token} is ready at {department}. Estimated wait: {wait_time} min.",
            "hi": "आपका टोकन {token} {department} में तैयार है। अनुमानित प्रतीक्षा: {wait_time} मिनट।"
        }
    },
    "report_ready": {
        "title": {
            "en": "📋 Your report is ready",
            "hi": "📋 आपकी रिपोर्ट तैयार है"
        },
        "body": {
            "en": "Your {report_type} report is ready. Please collect from {department} or view online.",
            "hi": "आपकी {report_type} रिपोर्ट तैयार है। कृपया {department} से प्राप्त करें या ऑनलाइन देखें।"
        }
    },
    "appointment_reminder": {
        "title": {
            "en": "🏥 Appointment Reminder",
            "hi": "🏥 अपॉइंटमेंट रिमाइंडर"
        },
        "body": {
            "en": "Your appointment with Dr. {doctor} is tomorrow at {time}. Please arrive 15 minutes early.",
            "hi": "डॉ. {doctor} के साथ आपकी अपॉइंटमेंट कल {time} पर है। कृपया 15 मिनट पहले आएं।"
        }
    },
    "followup_reminder": {
        "title": {
            "en": "🔄 Follow-up Reminder",
            "hi": "🔄 फॉलो-अप रिमाइंडर"
        },
        "body": {
            "en": "It's time for your follow-up visit with Dr. {doctor}. Please schedule your appointment.",
            "hi": "डॉ. {doctor} के साथ आपके फॉलो-अप का समय है। कृपया अपॉइंटमेंट बुक करें।"
        }
    },
    "registration": {
        "title": {
            "en": "🏥 Welcome to {hospital}",
            "hi": "🏥 {hospital} में आपका स्वागत है"
        },
        "body": {
            "en": "Token: {token}. You are registered at {department}. Track your status: {tracking_url}",
            "hi": "टोकन: {token}. आप {department} में पंजीकृत हैं। स्थिति देखें: {tracking_url}"
        }
    }
}
```

---

## 11. WEBHOOK INTEGRATIONS

```python
class WebhookDispatcher:
    """
    Fires webhooks for external integrations when notifications are sent.
    Used by: analytics, audit logging, third-party integrations.
    """
    
    WEBHOOK_EVENTS = {
        "notification.sent": ["analytics", "audit"],
        "notification.delivered": ["analytics"],
        "notification.failed": ["alerts", "audit"],
        "notification.clicked": ["analytics", "marketing"],
    }
    
    async def dispatch(self, event: str, payload: dict):
        hooks = await Webhook.filter(events__contains=[event], active=True).all()
        async with httpx.AsyncClient() as client:
            for hook in hooks:
                try:
                    await client.post(hook.url, json={
                        "event": event,
                        "timestamp": datetime.now().isoformat(),
                        "data": payload
                    }, timeout=5)
                except Exception as e:
                    logger.error(f"Webhook {hook.id} failed: {e}")
```

---

## 12. AUDIT & COMPLIANCE

- Every notification attempt is logged with timestamp, channel, and result
- Retention: 90 days for delivery logs, 365 days for compliance audit
- Patient consent status checked before sending on paid channels (SMS/Voice)
- DND (Do Not Disturb) registry checked for SMS/Voice between 9 PM and 9 AM
- Exportable audit trail for regulatory compliance

---

## 13. CONFIGURATION

```yaml
# config/notifications.yaml
notification:
  dedup_window_seconds: 30
  default_retry_max: 5
  backoff_base: 2
  backoff_max_seconds: 120
  
  channel_priority:
    critical: ["websocket", "push", "whatsapp", "sms", "voice"]
    high: ["websocket", "whatsapp", "sms"]
    normal: ["whatsapp", "sms"]
    low: ["whatsapp"]
  
  rate_limits:
    global_per_minute: 5
    sms_per_minute: 1
    whatsapp_per_hour: 10
    voice_per_30min: 1
    burst_per_10sec: 3
  
  dnd:
    enabled: true
    start_hour: 21  # 9 PM
    end_hour: 9     # 9 AM
    exempt_types: ["patient_called", "misscall_alert"]
  
  templates:
    editable_by_admin: true
    fallback_language: "en"
```

---

## 14. TYPICAL FLOWS

### Flow A: Patient Called (Happy Path)
```
1. Staff clicks "Call" on dashboard
2. Queue Engine → sends event to Notification Orchestrator
3. Orchestrator checks: patient online? → Yes (WebSocket active)
4. Sends via WebSocket → patient hears sound + sees banner
5. Logs: notification.sent, channel=websocket
6. Done in <500ms
```

### Flow B: Patient Called (Fallback)
```
1. Staff clicks "Call"
2. Queue Engine → Notification Orchestrator
3. Patient offline (no WebSocket)
4. Sends via Push (FCM) → no FCM token
5. Sends via WhatsApp → API returns delivered
6. Logs: notification.sent, channel=whatsapp
7. Done in <3s
```

### Flow C: All Channels Failed
```
1. Staff clicks "Call"
2. WebSocket → no connection
3. Push → token expired
4. WhatsApp → number not on WhatsApp
5. SMS → gateway returns sent (SMS always works)
6. Logs: notification.sent, channel=sms
7. Status: delivered via SMS fallback
```

---

## 15. STATUS & ROADMAP

| Feature | Status | Target |
|---------|--------|--------|
| WebSocket real-time delivery | ✅ Done | v1.0 |
| In-app sound/vibration | ✅ Done | v1.0 |
| WhatsApp integration | ✅ Done | v1.0 |
| Retry logic with backoff | ✅ Done | v1.0 |
| Delivery tracking & logging | ✅ Done | v1.0 |
| FCM Push notifications | ✅ Done | v1.0 |
| SMS fallback (Twilio) | ✅ Done | v1.0 |
| Bilingual templates | ✅ Done | v1.0 |
| Rate limiting | 🔲 Planned | v1.1 |
| Voice call integration | 🔲 Planned | v1.2 |
| Email integration | 🔲 Planned | v1.2 |
| Admin template editor | 🔲 Planned | v1.3 |
| A/B channel testing | 🔲 Planned | v2.0 |
| Notification analytics dashboard | 🔲 Planned | v2.0 |
