---
file_id: "0102"
module_name: "Token Engine"
version: "1.0"
status: "Approved"
phase: "Phase 1 — Core Engine"
dependencies: ["0100_QUEUE_ENGINE.md"]
related_files: ["0101_WORKFLOW_ENGINE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "token-engine", "numbering", "qr-code"]
---

# 🎫 GHOS — Token Engine

---

## 1. PURPOSE

Generates and manages all token numbers, QR codes, and patient identifiers in the system.

---

## 2. TOKEN NUMBERING SYSTEM

### Visit Token (Permanent Patient ID per Visit)

```
Format: GHOS-{YYYYMMDD}-{XXX}

Example: GHOS-20260709-042
         ─────────────────
         │    │        │
         │    │        └── Sequential number (001-999)
         │    └─────────── Date of visit
         └──────────────── Prefix (configurable per hospital)
```

### Department Token (Queue Position per Department)

```
Format: {Department Short Code}-{Daily Sequence}

Examples:
  ECG-028         → 28th patient in ECG today
  DOC-042         → 42nd patient for Doctor today
  LAB-015         → 15th patient in Lab today
  PHA-055         → 55th patient in Pharmacy today
```

### Department Short Codes

| Department | Code | Example |
|------------|------|---------|
| Reception | REC | REC-001 |
| Doctor Consultation | DOC | DOC-042 |
| ECG | ECG | ECG-028 |
| Echo | ECH | ECH-015 |
| TMT | TMT | TMT-010 |
| Lab | LAB | LAB-033 |
| X-Ray | XRY | XRY-022 |
| Ultrasound | USG | USG-018 |
| Pharmacy | PHA | PHA-055 |
| Billing | BIL | BIL-099 |

---

## 3. TOKEN GENERATION

```python
class TokenEngine:
    """Generates and manages all tokens in the system."""

    async def generate_visit_id(self, hospital_id: UUID) -> str:
        """Generate unique visit ID: GHOS-YYYYMMDD-XXX"""
        prefix = await self.get_hospital_prefix(hospital_id)
        date_part = datetime.utcnow().strftime("%Y%m%d")
        sequence = await self.get_next_sequence("visit", hospital_id)
        return f"{prefix}-{date_part}-{sequence:03d}"

    async def generate_department_token(
        self,
        department_id: UUID,
        date: str = None
    ) -> int:
        """
        Generate sequential token number for a department per day.
        Uses Redis atomic increment.
        """
        date = date or datetime.utcnow().strftime("%Y%m%d")
        key = f"token:seq:{department_id}:{date}"
        return await redis.incr(key)  # Atomic increment

    async def get_department_token_display(
        self,
        department_id: UUID,
        token_number: int
    ) -> str:
        """Get formatted token display string."""
        code = await self.get_department_code(department_id)
        return f"{code}-{token_number:03d}"

    async def get_next_sequence(
        self,
        prefix: str,
        hospital_id: UUID
    ) -> int:
        """Get next sequence number for a prefix."""
        date = datetime.utcnow().strftime("%Y%m%d")
        key = f"token:seq:{prefix}:{hospital_id}:{date}"
        return await redis.incr(key)
```

---

## 4. QR CODE GENERATION

```python
import qrcode

class QRCodeEngine:
    """Generates QR codes for patient tracking."""

    def generate_tracking_url(
        self,
        visit_id: str,
        base_url: str = "https://patient.ghos.in"
    ) -> str:
        """Generate patient tracking URL."""
        token = self.encode_visit_id(visit_id)
        return f"{base_url}/track/{token}"

    def generate_qr(self, data: str) -> bytes:
        """Generate QR code image bytes."""
        qr = qrcode.QRCode(
            version=1,
            error_correction=qrcode.constants.ERROR_CORRECT_M,
            box_size=10,
            border=4,
        )
        qr.add_data(data)
        qr.make(fit=True)
        img = qr.make_image(fill_color="black", back_color="white")
        # Return as bytes
        from io import BytesIO
        buffer = BytesIO()
        img.save(buffer, format="PNG")
        return buffer.getvalue()

    def encode_visit_id(self, visit_id: str) -> str:
        """Encode visit ID for URL (simple obfuscation)."""
        # Base64 encode or hash
        import base64
        return base64.urlsafe_b64encode(
            visit_id.encode()
        ).decode().rstrip("=")
```

---

## 5. TOKEN LIFECYCLE

```
1. Visit Created    → Visit token assigned (GHOS-20260709-042)
2. Enqueued         → Department token assigned (ECG-028)
3. Called           → Token displayed on screens
4. Completed        → Token archived for that department
5. Routed           → New department token assigned (DOC-043)
6. Visit Complete   → All tokens finalized
```

---

## 6. TOKEN DISPLAY RULES

| Location | Display Format | Example |
|----------|---------------|---------|
| Patient Phone | Full token | `ECG-028` |
| Department Screen | Current + Next | `Serving: ECG-028 | Next: ECG-029` |
| Doctor Dashboard | Token + Name | `ECG-028 — Rajesh Kumar` |
| Reception Display | All departments | `DOC: 042 | ECG: 028 | LAB: 015` |
| Token Print (Paper) | Full format | `GHOS-20260709-042 | ECG-028` |

---

*"Every patient has a number. Every number tells a story."*
