---
file_id: "0104"
module_name: "Communication Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["0700_SMS.md", "0701_EMAIL.md", "0702_WHATSAPP.md", "0704_VOICE_CALL.md", "0103_NOTIFICATION_ENGINE.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "communication", "sms", "whatsapp", "voice", "templates", "multi-channel"]
---

# 📡 GHOS — Communication Engine

> **The Communication Engine is the multi-channel delivery layer. It takes a rendered message and sends it through any external provider (SMS gateway, WhatsApp Business API, voice call API, email service) with automatic provider failover.**

---

## 1. PURPOSE

The Communication Engine is the lowest-level delivery layer in GHOS. While the Notification Engine (0103) handles *what* to send and *when*, the Communication Engine handles *how* to send it:

- **Provider abstraction** — Unified interface for Twilio, MSG91, WhatsApp Business API, SendGrid, etc.
- **Provider failover** — If one SMS provider is down, try the next
- **Cost tracking** — Per-message cost accounting for analytics
- **Delivery receipts** — Handle DLR (Delivery Receipt) callbacks
- **Template rendering** — Final message formatting with variable substitution
- **Bilingual support** — Hindi and English in every channel

---

## 2. ARCHITECTURE

```
                    ┌─────────────────────────────────────┐
                    │      Communication Engine            │
                    │                                      │
  ┌──────────┐      │  ┌──────────┐  ┌──────────────────┐  │
  │Notification│─────│─▶│ Message  │──│  Provider Router │  │
  │ Engine    │      │  │ Queue    │  │                  │  │
  └──────────┘      │  └──────────┘  │  ┌──────────────┐ │  │
                    │                 │  │ SMS:Twilio   │ │  │
  ┌──────────┐      │                 │  │ SMS:MSG91    │ │  │
  │ Templates│─────│─▶│  Renderer   │  │  │ SMS:Fast2SMS│ │  │
  └──────────┘      │  └─────────────│  ├──────────────┤ │  │
                    │                 │  │ WhatsApp:WABA│ │  │
  ┌──────────┐      │                 │  │ WhatsApp:WATI│ │  │
  │ Cost      │─────│─▶│  Tracker    │  │  ├──────────────┤ │  │
  │ Tracker  │      │  └─────────────│  │  │ Voice:Twilio│ │  │
  └──────────┘      │                 │  │ Voice:Exotel │ │  │
                    │                 │  ├──────────────┤ │  │
                    │                 │  │ Email:SendGrid│ │  │
                    │                 │  │ Email:SES     │ │  │
                    │                 │  └──────────────┘ │  │
                    │                 └──────────────────┘  │
                    └──────────────────────────────────────┘
```

---

## 3. PROVIDER ABSTRACTION LAYER

Every provider implements the same interface, making it easy to add, remove, or swap providers.

```python
class BaseProvider(ABC):
    """Abstract base class for all communication providers."""
    
    @abstractmethod
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        """Send a message and return delivery result."""
        pass
    
    @abstractmethod
    async def get_balance(self) -> float:
        """Return remaining account balance."""
        pass
    
    @abstractmethod
    async def check_health(self) -> bool:
        """Check if provider API is reachable."""
        pass
    
    @property
    @abstractmethod
    def provider_name(self) -> str:
        """Human-readable provider name."""
        pass
    
    @property
    @abstractmethod
    def cost_per_message(self) -> float:
        """Cost per message in INR."""
        pass


class OutgoingMessage:
    """Standardized message object across all channels."""
    
    def __init__(
        self,
        to: str,
        channel: str,        # sms, whatsapp, voice, email
        content: str,         # Rendered message body
        template_name: str = None,
        language: str = "en",
        patient_id: UUID = None,
        hospital_id: UUID = None,
        attachments: List[str] = None,
        priority: int = 0
    ):
        self.to = to
        self.channel = channel
        self.content = content
        self.template_name = template_name
        self.language = language
        self.patient_id = patient_id
        self.hospital_id = hospital_id
        self.attachments = attachments or []
        self.priority = priority
        self.created_at = datetime.now()
        self.message_id = str(uuid4())


@dataclass
class DeliveryResult:
    success: bool
    provider: str
    message_id: str = None          # Provider's message ID
    status: str = None              # sent, queued, delivered, failed
    error_code: str = None
    error_message: str = None
    cost: float = 0.0               # Cost in INR
    raw_response: dict = None
    delivered_at: datetime = None
```

---

## 4. SMS PROVIDERS

### 4.1 Twilio SMS
```python
class TwilioSMSProvider(BaseProvider):
    """Primary SMS provider — best delivery rates in India."""
    
    provider_name = "twilio_sms"
    cost_per_message = 0.09  # ~₹0.09 per SMS in India
    
    def __init__(self):
        self.account_sid = settings.TWILIO_ACCOUNT_SID
        self.auth_token = settings.TWILIO_AUTH_TOKEN
        self.from_number = settings.TWILIO_PHONE_NUMBER
        self.client = Client(self.account_sid, self.auth_token)
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        try:
            twilio_msg = await asyncio.to_thread(
                self.client.messages.create,
                to=message.to,
                from_=self.from_number,
                body=message.content,
                status_callback=settings.WEBHOOK_BASE + "/webhooks/twilio/status"
            )
            return DeliveryResult(
                success=True,
                provider=self.provider_name,
                message_id=twilio_msg.sid,
                status=twilio_msg.status,
                cost=float(twilio_msg.price or 0),
                raw_response={"sid": twilio_msg.sid, "status": twilio_msg.status}
            )
        except TwilioException as e:
            return DeliveryResult(
                success=False,
                provider=self.provider_name,
                error_code=str(e.code),
                error_message=str(e.msg)
            )
    
    async def get_balance(self) -> float:
        account = await asyncio.to_thread(self.client.api.accounts(self.account_sid).fetch)
        return float(account.balance)
    
    async def check_health(self) -> bool:
        try:
            await asyncio.to_thread(self.client.api.accounts(self.account_sid).fetch)
            return True
        except:
            return False
```

### 4.2 MSG91 (India-Focused)
```python
class MSG91Provider(BaseProvider):
    """Secondary SMS provider — better pricing for India, good DLR."""
    
    provider_name = "msg91"
    cost_per_message = 0.07  # ~₹0.07 per SMS (cheaper than Twilio in India)
    
    def __init__(self):
        self.auth_key = settings.MSG91_AUTH_KEY
        self.sender_id = settings.MSG91_SENDER_ID or "GHOSMS"
        self.route = settings.MSG91_ROUTE or 4  # 4=Transactional
        self.base_url = "https://api.msg91.com/api/v5/flow/"
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        payload = {
            "sender": self.sender_id,
            "mobiles": message.to,
            "message": message.content,
            "route": self.route,
            "unicode": self._has_unicode(message.content),
            "flash": 0,
            "DLT_TE_ID": settings.MSG91_DLT_TE_ID  # Mandatory for India TRAI compliance
        }
        
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    self.base_url,
                    json=payload,
                    headers={"authkey": self.auth_key},
                    timeout=10
                )
                data = response.json()
                if data.get("type") == "success":
                    return DeliveryResult(
                        success=True,
                        provider=self.provider_name,
                        message_id=str(data.get("message_id", "")),
                        status="sent",
                        cost=self.cost_per_message,
                        raw_response=data
                    )
                return DeliveryResult(
                    success=False,
                    provider=self.provider_name,
                    error_code=str(data.get("code", "unknown")),
                    error_message=data.get("message", "Unknown error")
                )
            except Exception as e:
                return DeliveryResult(
                    success=False,
                    provider=self.provider_name,
                    error_message=str(e)
                )
    
    def _has_unicode(self, text: str) -> bool:
        """Check if text contains Hindi/Unicode characters."""
        return any(ord(c) > 127 for c in text)
```

### 4.3 Fast2SMS (Emergency Fallback)
```python
class Fast2SMSProvider(BaseProvider):
    """Emergency fallback — simple API, very cheap, no frills."""
    
    provider_name = "fast2sms"
    cost_per_message = 0.05
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        # Simplified implementation — used only as last resort
        ...
```

---

## 5. WHATSAPP PROVIDERS

### 5.1 WhatsApp Business API (Official)
```python
class WhatsAppBusinessProvider(BaseProvider):
    """
    Official WhatsApp Business API (WABA).
    - Requires Meta Business verification
    - Free for initiated conversations (24h window)
    - ₹0.50-1.00 per conversation after window expires
    - Best for: templates, rich media, quick replies
    """
    
    provider_name = "whatsapp_waba"
    cost_per_message = 0.0  # Free within 24h window
    
    def __init__(self):
        self.phone_number_id = settings.WABA_PHONE_NUMBER_ID
        self.access_token = settings.WABA_ACCESS_TOKEN
        self.api_version = "v17.0"
        self.base_url = f"https://graph.facebook.com/{self.api_version}/{self.phone_number_id}/messages"
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        # Check for template requirement (Meta policy)
        if message.template_name:
            return await self._send_template(message)
        else:
            return await self._send_text(message)
    
    async def _send_template(self, message: OutgoingMessage) -> DeliveryResult:
        """Send a pre-approved template message (required for first contact)."""
        payload = {
            "messaging_product": "whatsapp",
            "to": message.to,
            "type": "template",
            "template": {
                "name": message.template_name,
                "language": {"code": message.language},
                "components": [
                    {
                        "type": "body",
                        "parameters": self._extract_params(message.content)
                    }
                ]
            }
        }
        return await self._post(payload)
    
    async def _send_text(self, message: OutgoingMessage) -> DeliveryResult:
        """Send free-form text (only within 24h active window)."""
        payload = {
            "messaging_product": "whatsapp",
            "to": message.to,
            "type": "text",
            "text": {"body": message.content, "preview_url": True}
        }
        return await self._post(payload)
    
    async def _post(self, payload: dict) -> DeliveryResult:
        async with httpx.AsyncClient() as client:
            try:
                response = await client.post(
                    self.base_url,
                    json=payload,
                    headers={
                        "Authorization": f"Bearer {self.access_token}",
                        "Content-Type": "application/json"
                    },
                    timeout=10
                )
                data = response.json()
                if response.status_code == 200 and data.get("messages"):
                    msg = data["messages"][0]
                    return DeliveryResult(
                        success=True,
                        provider=self.provider_name,
                        message_id=msg["id"],
                        status="sent",
                        raw_response=data
                    )
                return DeliveryResult(
                    success=False,
                    provider=self.provider_name,
                    error_code=str(data.get("error", {}).get("code", "")),
                    error_message=data.get("error", {}).get("message", "Unknown")
                )
            except Exception as e:
                return DeliveryResult(
                    success=False,
                    provider=self.provider_name,
                    error_message=str(e)
                )
```

### 5.2 WATI (Alternative WhatsApp Provider)
```python
class WATIProvider(BaseProvider):
    """Alternative WhatsApp provider — no Meta verification needed."""
    
    provider_name = "wati"
    cost_per_message = 0.30  # ₹0.30 per message
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        # Simplified — different API but same interface
        ...
```

---

## 6. VOICE CALL PROVIDERS

### 6.1 Twilio Voice
```python
class TwilioVoiceProvider(BaseProvider):
    """
    Voice call provider for critical notifications.
    - Used for: missed call alerts, critical lab results
    - TTS in English and Hindi
    - Cost: ~₹0.50-1.00 per call
    """
    
    provider_name = "twilio_voice"
    cost_per_message = 0.75  # Average cost per call
    
    def __init__(self):
        self.client = Client(settings.TWILIO_ACCOUNT_SID, settings.TWILIO_AUTH_TOKEN)
        self.from_number = settings.TWILIO_PHONE_NUMBER
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        twiml = f"""
        <Response>
            <Say language="{self._twilio_lang(message.language)}">
                {message.content}
            </Say>
        </Response>
        """
        try:
            call = await asyncio.to_thread(
                self.client.calls.create,
                to=message.to,
                from_=self.from_number,
                twiml=twiml,
                status_callback=settings.WEBHOOK_BASE + "/webhooks/twilio/call-status"
            )
            return DeliveryResult(
                success=True,
                provider=self.provider_name,
                message_id=call.sid,
                status="queued",
                cost=0.75,
                raw_response={"sid": call.sid, "status": call.status}
            )
        except TwilioException as e:
            return DeliveryResult(
                success=False,
                provider=self.provider_name,
                error_code=str(e.code),
                error_message=str(e.msg)
            )
    
    def _twilio_lang(self, lang: str) -> str:
        return "hi-IN" if lang == "hi" else "en-IN"
```

### 6.2 Exotel (India-Focused)
```python
class ExotelVoiceProvider(BaseProvider):
    """India-focused voice provider — better for Indian numbers."""
    
    provider_name = "exotel_voice"
    cost_per_message = 0.50
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        # Exotel API implementation
        ...
```

---

## 7. EMAIL PROVIDERS

### 7.1 SendGrid
```python
class SendGridProvider(BaseProvider):
    """Primary email provider — high deliverability, good analytics."""
    
    provider_name = "sendgrid"
    cost_per_message = 0.0  # 100 emails/day free tier
    
    def __init__(self):
        self.client = SendGridAPIClient(settings.SENDGRID_API_KEY)
        self.from_email = settings.SENDGRID_FROM_EMAIL
    
    async def send(self, message: OutgoingMessage) -> DeliveryResult:
        email = Mail(
            from_email=self.from_email,
            to_emails=message.to,
            subject=message.content[:100],  # First 100 chars as subject
            html_content=message.content
        )
        try:
            response = await asyncio.to_thread(self.client.send, email)
            return DeliveryResult(
                success=True,
                provider=self.provider_name,
                message_id=str(uuid4()),
                status="sent" if response.status_code == 202 else "failed",
                raw_response={"status_code": response.status_code}
            )
        except Exception as e:
            return DeliveryResult(
                success=False,
                provider=self.provider_name,
                error_message=str(e)
            )
```

---

## 8. PROVIDER ROUTER & FAILOVER

```python
class ProviderRouter:
    """
    Routes messages to the best available provider with automatic failover.
    
    Failover Strategy:
    - Primary → Secondary → Tertiary
    - If primary is down (check_health fails), skip to secondary
    - If primary is rate-limited, queue and retry later
    - Track provider success rate over last 5 minutes
    - Auto-disable providers with <80% success rate
    """
    
    PROVIDER_REGISTRY = {
        "sms": [
            TwilioSMSProvider(),
            MSG91Provider(),
            Fast2SMSProvider(),
        ],
        "whatsapp": [
            WhatsAppBusinessProvider(),
            WATIProvider(),
        ],
        "voice": [
            TwilioVoiceProvider(),
            ExotelVoiceProvider(),
        ],
        "email": [
            SendGridProvider(),
            SESProvider(),       # Amazon SES
            SMTPProvider(),      # Direct SMTP fallback
        ]
    }
    
    def __init__(self):
        self.health_cache = {}       # provider_name → (healthy, last_checked)
        self.rate_limiters = {}      # provider_name → RateLimiter
        self.success_tracker = defaultdict(lambda: deque(maxlen=50))
        self.health_check_interval = 60  # seconds
    
    async def route(
        self,
        message: OutgoingMessage,
        preferred_provider: str = None
    ) -> DeliveryResult:
        """Route message through best available provider."""
        providers = self.PROVIDER_REGISTRY.get(message.channel, [])
        if not providers:
            raise ValueError(f"No providers configured for channel: {message.channel}")
        
        # If specific provider requested, try it first
        if preferred_provider:
            provider = next(
                (p for p in providers if p.provider_name == preferred_provider),
                None
            )
            if provider:
                result = await self._try_provider(provider, message)
                if result.success:
                    return result
        
        # Try providers in order until one succeeds
        errors = []
        for provider in providers:
            if preferred_provider and provider.provider_name == preferred_provider:
                continue  # Already tried above
            
            # Quick health check
            if not await self._is_healthy(provider):
                errors.append(f"{provider.provider_name}: unhealthy")
                continue
            
            result = await self._try_provider(provider, message)
            if result.success:
                return result
            errors.append(f"{provider.provider_name}: {result.error_message}")
        
        # All providers failed
        logger.error(f"All providers failed for {message.channel}: {errors}")
        return DeliveryResult(
            success=False,
            provider="all_failed",
            error_message="; ".join(errors)
        )
    
    async def _try_provider(
        self,
        provider: BaseProvider,
        message: OutgoingMessage
    ) -> DeliveryResult:
        """Try sending via a single provider and track result."""
        start = time.time()
        try:
            result = await provider.send(message)
            elapsed = time.time() - start
            
            # Track success/failure
            self.success_tracker[provider.provider_name].append(result.success)
            
            logger.info(
                f"Provider {provider.provider_name}: "
                f"{'✅' if result.success else '❌'} "
                f"in {elapsed:.2f}s"
            )
            
            return result
        except Exception as e:
            self.success_tracker[provider.provider_name].append(False)
            return DeliveryResult(
                success=False,
                provider=provider.provider_name,
                error_message=str(e)
            )
    
    async def _is_healthy(self, provider: BaseProvider) -> bool:
        """Check provider health with caching."""
        now = time.time()
        cached = self.health_cache.get(provider.provider_name)
        
        if cached and (now - cached[1]) < self.health_check_interval:
            return cached[0]
        
        try:
            healthy = await provider.check_health()
        except:
            healthy = False
        
        self.health_cache[provider.provider_name] = (healthy, now)
        return healthy
    
    def get_provider_stats(self) -> dict:
        """Get provider health stats for admin dashboard."""
        stats = {}
        for provider_name, results in self.success_tracker.items():
            total = len(results)
            successes = sum(1 for r in results if r)
            stats[provider_name] = {
                "success_rate": round(successes / total * 100, 1) if total > 0 else 0,
                "total_attempts": total,
                "healthy": self.health_cache.get(provider_name, (False,))[0]
            }
        return stats
```

---

## 9. TEMPLATE RENDERER

```python
class TemplateRenderer:
    """
    Renders bilingual message templates with variable substitution.
    
    Features:
    - Supports Hindi (Devanagari) and English
    - Variable interpolation: {name}, {token}, {doctor}, etc.
    - Conditional blocks: {% if ... %} ... {% endif %}
    - SMS character counting (GSM-7 vs Unicode)
    - Automatic message splitting for long SMS
    - Template versioning with fallback
    """
    
    def __init__(self):
        self.templates = self._load_templates()
        self.env = Environment(
            autoescape=False,
            trim_blocks=True,
            lstrip_blocks=True
        )
    
    def render(
        self,
        template_key: str,
        language: str,
        variables: dict,
        channel: str = "whatsapp"
    ) -> str:
        """
        Render a template for the given language and channel.
        
        Args:
            template_key: Template identifier (e.g., "patient_called")
            language: "en" or "hi"
            variables: Dict of template variables
            channel: Target channel (different channels have different length limits)
        """
        template_data = self.templates.get(template_key, {})
        template_text = template_data.get(language, template_data.get("en", ""))
        
        if not template_text:
            raise ValueError(f"Template {template_key}/{language} not found")
        
        # Use Jinja2 for advanced templating
        jinja_template = self.env.from_string(template_text)
        rendered = jinja_template.render(**variables)
        
        return rendered
    
    def count_sms_parts(self, text: str) -> tuple:
        """
        Count SMS parts (GSM-7: 160 chars, Unicode: 70 chars).
        Returns (parts_count, chars_per_part, is_unicode).
        """
        is_unicode = any(ord(c) > 127 for c in text)
        max_chars = 70 if is_unicode else 160
        parts = math.ceil(len(text) / max_chars)
        return parts, max_chars, is_unicode
    
    def _load_templates(self) -> dict:
        """Load templates from database or file."""
        # Templates defined in notification engine
        from notification_engine import NOTIFICATION_TEMPLATES
        return NOTIFICATION_TEMPLATES
```

---

## 10. COST TRACKING

```python
class CostTracker:
    """
    Tracks communication costs per provider, channel, hospital, and patient.
    
    Metrics:
    - Cost per day/week/month
    - Cost by channel
    - Cost by hospital/branch
    - Cost per patient
    - Projected monthly cost
    - Budget alerts
    """
    
    async def log_cost(
        self,
        message: OutgoingMessage,
        result: DeliveryResult,
        hospital_id: UUID = None
    ):
        """Log a cost entry for a sent message."""
        await CommunicationCost.create(
            hospital_id=hospital_id,
            patient_id=message.patient_id,
            channel=message.channel,
            provider=result.provider,
            message_id=result.message_id,
            cost=result.cost,
            status=result.status,
            sent_at=datetime.now()
        )
    
    async def get_monthly_cost(
        self,
        hospital_id: UUID = None,
        year: int = None,
        month: int = None
    ) -> dict:
        """Get monthly cost breakdown."""
        now = datetime.now()
        year = year or now.year
        month = month or now.month
        
        query = CommunicationCost.filter(
            sent_at__year=year,
            sent_at__month=month
        )
        if hospital_id:
            query = query.filter(hospital_id=hospital_id)
        
        costs = await query.annotate(
            total=Sum("cost"),
            count=Count("id")
        ).group_by("channel").values("channel", "total", "count")
        
        total = sum(c["total"] for c in costs)
        
        return {
            "year": year,
            "month": month,
            "total_cost": round(total, 2),
            "by_channel": {c["channel"]: {"cost": round(c["total"], 2), "count": c["count"]} for c in costs}
        }
```

---

## 11. DELIVERY RECEIPT HANDLING

```python
class DeliveryReceiptHandler:
    """
    Handles delivery receipt (DLR) callbacks from providers.
    
    Providers send DLRs to:
    - /webhooks/twilio/status
    - /webhooks/msg91/dlr
    - /webhooks/whatsapp/status
    
    Common statuses: sent, delivered, read, failed, undelivered
    """
    
    DLR_ENDPOINTS = {
        "twilio": "/webhooks/twilio/status",
        "msg91": "/webhooks/msg91/dlr",
        "waba": "/webhooks/whatsapp/status",
        "sendgrid": "/webhooks/sendgrid/status",
    }
    
    async def handle_dlr(self, provider: str, payload: dict):
        """Process a delivery receipt from any provider."""
        # Map provider-specific status to GHOS status
        status_map = {
            "twilio": {
                "delivered": "delivered",
                "sent": "sent",
                "failed": "failed",
                "undelivered": "failed",
                "read": "read"
            },
            "msg91": {
                "DELIVRD": "delivered",
                "SUBMIT": "sent",
                "REJECTD": "failed",
                "UNDELIV": "failed"
            },
            "waba": {
                "sent": "sent",
                "delivered": "delivered",
                "read": "read",
                "failed": "failed"
            }
        }
        
        message_id = self._extract_message_id(provider, payload)
        status = self._extract_status(provider, payload)
        ghosa_status = status_map.get(provider, {}).get(status, status)
        
        # Update delivery attempt record
        await NotificationAttempt.filter(
            message_id=message_id
        ).update(
            status=ghosa_status,
            delivered_at=datetime.now() if ghosa_status == "delivered" else None,
            failed_at=datetime.now() if ghosa_status == "failed" else None
        )
        
        # Update notification status
        if ghosa_status == "delivered":
            await Notification.filter(
                id=Subquery(
                    NotificationAttempt.filter(
                        message_id=message_id
                    ).values("notification_id")[:1]
                )
            ).update(status="delivered")
    
    def _extract_message_id(self, provider: str, payload: dict) -> str:
        """Extract message ID from provider-specific payload."""
        extractors = {
            "twilio": lambda p: p.get("MessageSid"),
            "msg91": lambda p: p.get("message_id"),
            "waba": lambda p: p.get("statuses", [{}])[0].get("id"),
            "sendgrid": lambda p: p.get("sg_message_id"),
        }
        extractor = extractors.get(provider, lambda p: p.get("id"))
        return extractor(payload)
```

---

## 12. DATABASE SCHEMA

```sql
-- Communication cost tracking
CREATE TABLE communication_costs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID REFERENCES hospitals(id),
    patient_id UUID REFERENCES patients(id),
    channel VARCHAR(20) NOT NULL,       -- sms, whatsapp, voice, email
    provider VARCHAR(50) NOT NULL,       -- twilio, msg91, waba, sendgrid
    message_id VARCHAR(200),             -- Provider's message ID
    cost DECIMAL(10, 4) DEFAULT 0,       -- Cost in INR
    status VARCHAR(20) NOT NULL,         -- sent, delivered, failed
    sent_at TIMESTAMP DEFAULT NOW(),
    delivered_at TIMESTAMP,
    metadata JSONB
);

-- Provider health history
CREATE TABLE provider_health (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    provider VARCHAR(50) NOT NULL,
    healthy BOOLEAN NOT NULL,
    response_time_ms INTEGER,
    error_message TEXT,
    checked_at TIMESTAMP DEFAULT NOW()
);

-- Message log (for debugging)
CREATE TABLE message_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    message_id VARCHAR(200),
    channel VARCHAR(20),
    provider VARCHAR(50),
    to_number VARCHAR(20),
    content TEXT,
    status VARCHAR(20),
    error_message TEXT,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_commcost_hospital ON communication_costs(hospital_id, sent_at);
CREATE INDEX idx_commcost_channel ON communication_costs(channel, sent_at);
CREATE INDEX idx_provider_health ON provider_health(provider, checked_at);
CREATE INDEX idx_message_log_channel ON message_log(channel, created_at);
```

---

## 13. CONFIGURATION

```yaml
# config/communication.yaml
communication:
  sms:
    primary: "twilio"
    secondary: "msg91"
    fallback: "fast2sms"
    max_parts: 3  # Max SMS segments per message
  
  whatsapp:
    primary: "waba"
    fallback: "wati"
    template_namespace: "ghos_"
  
  voice:
    primary: "twilio"
    fallback: "exotel"
    max_duration_seconds: 30
    tts_language: "hi-IN"
  
  email:
    primary: "sendgrid"
    fallback: "ses"
    from_name: "GHOS Hospital"
  
  cost:
    budget_alert_threshold: 5000  # Alert when monthly cost exceeds ₹5000
    max_daily_sms: 1000           # Safety limit per hospital
    max_daily_voice: 50
  
  provider_health:
    check_interval_seconds: 60
    auto_disable_threshold: 0.8   # Disable if <80% success in last 50 attempts
    auto_enable_after_minutes: 30
```

---

## 14. ERROR HANDLING

| Error | Cause | Action |
|-------|-------|--------|
| `ProviderUnavailable` | Provider API is down | Failover to next provider |
| `RateLimited` | Provider rate limit hit | Queue and retry after backoff |
| `InvalidNumber` | Wrong phone format or DND | Log and skip |
| `TemplateRejected` | WhatsApp template not approved | Fallback to text/SMS |
| `InsufficientBalance` | Provider account low balance | Alert admin, switch provider |
| `MessageTooLong` | Exceeds channel limit | Auto-split or truncate |
| `DLRFailure` | No delivery receipt within timeout | Mark as "delivered_unknown" |

---

## 15. SECURITY & COMPLIANCE

- **TRAI DND** — Check DND registry before sending SMS/Voice (9 PM to 9 AM)
- **WhatsApp opt-in** — Only send to numbers that have opted in
- **Message encryption** — Content encrypted at rest (AES-256) and in transit (TLS 1.3)
- **Audit trail** — Every message logged with full trace for 90 days
- **PII masking** — Phone numbers masked in logs after 90 days
- **Consent records** — Patient opt-in/opt-out tracked per channel
- **Template approval** — WhatsApp templates must be Meta-approved before use
- **DLT registration** — All SMS templates registered with TRAI DLT platform
