---
file_id: "0106"
module_name: "Permission Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0105_AUTH_ENGINE.md"]
related_files: ["0804_ROLE_PERMISSION.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "permissions", "rbac", "roles", "access-control", "policies"]
---

# 🛡️ GHOS — Permission Engine

> **The Permission Engine is the authorization layer of GHOS. Every API call, every UI action, every data access is checked against it. It implements a fine-grained Role-Based Access Control (RBAC) system with attribute-based policy extensions.**

---

## 1. PURPOSE

The Permission Engine answers one question: **"Can this user perform this action on this resource?"**

It provides:
- **Role-Based Access Control (RBAC)** — Permissions assigned to roles, roles assigned to users
- **Fine-grained permissions** — Granular action-level control (e.g., `queue.call` vs `queue.view`)
- **Hierarchical roles** — Inherit permissions from parent roles
- **Department scoping** — Doctors see only their patients, accountants their hospital
- **Attribute checks** — Time-based, location-based, and resource-owner checks
- **Audit logging** — Every denied access is logged with reason

---

## 2. PERMISSION MODEL

```
Permission: An atomic action (e.g., "queue.call")
     │
     ▼
Role: A named collection of permissions (e.g., "receptionist")
     │
     ▼
User: Assigned one or more roles + optional department scope
     │
     ▼
Resource: The object being accessed (patient, queue, report, etc.)
     │
     ▼
Check: Does the user's role(s) include the required permission for this resource?
```

### Permission Naming Convention

Permissions follow a hierarchical naming pattern:

```
{domain}.{action}[.{subdomain}]
```

| Domain | Actions | Examples |
|--------|---------|----------|
| `patient` | `view`, `create`, `update`, `delete` | `patient.view`, `patient.create` |
| `queue` | `view`, `call`, `skip`, `complete` | `queue.call`, `queue.skip` |
| `report` | `view`, `create`, `sign`, `delete` | `report.sign`, `report.delete` |
| `billing` | `view`, `create`, `void`, `settle` | `billing.create`, `billing.void` |
| `admin` | `settings`, `users`, `audit` | `admin.users.manage` |
| `doctor` | `prescribe`, `diagnose`, `refer` | `doctor.prescribe` |
| `lab` | `perform`, `verify`, `result` | `lab.verify_result` |
| `inventory` | `view`, `add`, `adjust`, `transfer` | `inventory.adjust` |
| `pharmacy` | `dispense`, `verify`, `return` | `pharmacy.dispense` |

---

## 3. ROLE HIERARCHY & PERMISSION MATRIX

### Role Hierarchy
```
super_admin (GHOS-level, unlimited access)
  └── hospital_admin (single hospital, all admin functions)
        ├── branch_manager (branch oversight, reporting)
        ├── doctor (clinical: prescribe, diagnose, refer)
        │     └── senior_doctor (same + can sign reports)
        ├── nurse (vitals, assist, view)
        ├── receptionist (register, view, queue management)
        ├── lab_technician (perform tests, enter results)
        ├── pharmacist (dispense, verify prescriptions)
        ├── accountant (billing, payments, settlements)
        ├── ecg_technician (ECG-specific tasks)
        ├── echo_technician (Echo-specific tasks)
        ├── tmt_technician (TMT-specific tasks)
        └── patient (self-service only)
```

### Full Permission Matrix

```
                            view  create update delete  call  sign  bill  admin
                            patient       patient        queue

super_admin                 ✅    ✅    ✅    ✅     ✅   ✅    ✅    ✅
hospital_admin              ✅    ✅    ✅    ✅     ✅   ✅    ✅    ✅
branch_manager              ✅    ✅    ❌    ❌     ✅   ❌    ✅    ❌
doctor                      ✅    ❌    ✅    ❌     ✅   ✅    ❌    ❌
senior_doctor               ✅    ❌    ✅    ❌     ✅   ✅    ❌    ❌
nurse                       ✅    ❌    ❌    ❌     ❌   ❌    ❌    ❌
receptionist                ✅    ✅    ✅    ❌     ❌   ❌    ❌    ❌
lab_technician              ✅    ❌    ❌    ❌     ✅   ❌    ❌    ❌
pharmacist                  ✅    ❌    ❌    ❌     ❌   ❌    ❌    ❌
accountant                  ✅    ❌    ❌    ❌     ❌   ❌    ✅    ❌
ecg_technician              ✅    ❌    ❌    ❌     ✅   ❌    ❌    ❌
echo_technician             ✅    ❌    ❌    ❌     ✅   ❌    ❌    ❌
tmt_technician              ✅    ❌    ❌    ❌     ✅   ❌    ❌    ❌
patient                     ⚠️   ❌    ❌    ❌     ❌   ❌    ❌    ❌
```

### Department-Specific Permissions

```
                          ecg.view  ecg.perform  echo.view  echo.perform  report.sign

doctor                    ✅        ❌           ✅         ❌            ✅(own)
senior_doctor             ✅        ❌           ✅         ❌            ✅
ecg_technician            ✅        ✅           ❌         ❌            ❌
echo_technician           ❌        ❌           ✅         ✅            ❌
receptionist              ❌        ❌           ❌         ❌            ❌
nurse                     ✅        ❌           ✅         ❌            ❌
```

---

## 4. DATABASE SCHEMA

```sql
-- Roles
CREATE TABLE roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID REFERENCES hospitals(id),  -- NULL = system-level role
    name VARCHAR(50) NOT NULL,
    description VARCHAR(200),
    parent_role_id UUID REFERENCES roles(id),    -- For role inheritance
    is_system BOOLEAN DEFAULT FALSE,             -- System roles cannot be deleted
    priority INTEGER DEFAULT 0,                  -- Higher = overrides lower on conflict
    created_at TIMESTAMP DEFAULT NOW()
);

-- Permissions
CREATE TABLE permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code VARCHAR(100) UNIQUE NOT NULL,           -- "queue.call", "patient.view"
    name VARCHAR(200) NOT NULL,
    description VARCHAR(500),
    domain VARCHAR(50) NOT NULL,                 -- patient, queue, report, billing, etc.
    action VARCHAR(50) NOT NULL,                 -- view, create, update, delete, call, sign
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Role-Permission mapping
CREATE TABLE role_permissions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    permission_id UUID NOT NULL REFERENCES permissions(id) ON DELETE CASCADE,
    allowed BOOLEAN DEFAULT TRUE,                -- TRUE=allow, FALSE=explicit deny
    conditions JSONB,                            -- Attribute-based conditions
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(role_id, permission_id)
);

-- User-Role assignments
CREATE TABLE user_roles (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,                       -- staff_user.id or patient.id
    user_type VARCHAR(20) NOT NULL,              -- staff, patient
    role_id UUID NOT NULL REFERENCES roles(id) ON DELETE CASCADE,
    department_id UUID REFERENCES departments(id),  -- Scope: optional department restriction
    granted_by UUID REFERENCES staff_users(id),
    expires_at TIMESTAMP,                        -- Temporary role assignment
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(user_id, user_type, role_id, department_id)
);

-- Permission audit log
CREATE TABLE permission_audit (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,
    action VARCHAR(20) NOT NULL,                 -- granted, revoked, denied
    permission_code VARCHAR(100),
    role_name VARCHAR(50),
    resource_type VARCHAR(50),
    resource_id UUID,
    reason VARCHAR(500),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_roles_hospital ON roles(hospital_id);
CREATE INDEX idx_permissions_code ON permissions(code);
CREATE INDEX idx_permissions_domain ON permissions(domain, action);
CREATE INDEX idx_role_perms_role ON role_permissions(role_id);
CREATE INDEX idx_user_roles_user ON user_roles(user_id, user_type);
CREATE INDEX idx_user_roles_role ON user_roles(role_id);
CREATE INDEX idx_perm_audit_user ON permission_audit(user_id, created_at);
CREATE INDEX idx_perm_audit_action ON permission_audit(action, created_at);
```

---

## 5. PERMISSION CHECK FLOW

### Algorithm
1. Super admin? → Allow (fast path)
2. Check Redis cache → return cached decision
3. Load user roles (with parent inheritance)
4. Collect all permissions (allow + deny + conditions)
5. Explicit deny found? → Deny (deny always wins)
6. Explicit allow found? → Evaluate conditions → Allow or Deny
7. No match? → Deny (default deny)

```python
class PermissionEngine:
    """Core permission checking engine with Redis caching."""

    def __init__(self):
        self.cache = RedisCache(ttl=300)

    async def has_permission(self, user_id, user_type, permission_code, resource=None):
        # 1. Super admin bypass
        if await self._is_super_admin(user_id):
            return True

        # 2. Check cache
        cache_key = f"perm:{user_id}:{permission_code}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached == "allow"

        # 3. Get user roles
        roles = await self._get_user_roles(user_id, user_type)
        if not roles:
            await self.cache.set(cache_key, "deny")
            return False

        # 4. Collect permissions (with inheritance)
        all_permissions = await self._collect_role_permissions(roles)

        # 5. Explicit DENY takes precedence
        if permission_code in all_permissions.get("deny", set()):
            await self.cache.set(cache_key, "deny")
            return False

        # 6. Check ALLOW with conditions
        if permission_code in all_permissions.get("allow", set()):
            conditions = all_permissions.get("conditions", {}).get(permission_code, [])
            if await self._evaluate_conditions(conditions, user_id, resource):
                await self.cache.set(cache_key, "allow")
                return True

        # 7. Default: deny
        await self.cache.set(cache_key, "deny")
        await self._log_denied(user_id, permission_code, "no_permission")
        return False

    async def has_any_permission(self, user_id, user_type, permission_codes):
        for code in permission_codes:
            if await self.has_permission(user_id, user_type, code):
                return True
        return False

    async def has_all_permissions(self, user_id, user_type, permission_codes):
        for code in permission_codes:
            if not await self.has_permission(user_id, user_type, code):
                return False
        return True

    async def get_user_permissions(self, user_id, user_type):
        """Get all permissions for a user (for UI rendering/menu visibility)."""
        cache_key = f"user_perms:{user_id}"
        cached = await self.cache.get(cache_key)
        if cached:
            return json.loads(cached)
        roles = await self._get_user_roles(user_id, user_type)
        perms = await self._collect_role_permissions(roles)
        permissions = list(perms.get("allow", set()))
        await self.cache.set(cache_key, json.dumps(permissions))
        return permissions

    async def _get_user_roles(self, user_id, user_type):
        cache_key = f"user_roles:{user_id}"
        cached = await self.cache.get(cache_key)
        if cached:
            return json.loads(cached)
        roles = []
        seen = set()
        assignments = await UserRole.filter(user_id=user_id, user_type=user_type).all()
        for a in assignments:
            if a.expires_at and a.expires_at < datetime.now():
                continue
            role = a.role
            while role and role.id not in seen:
                roles.append({
                    "id": str(role.id),
                    "name": role.name,
                    "dept": str(a.department_id) if a.department_id else None
                })
                seen.add(role.id)
                role = role.parent_role
        await self.cache.set(cache_key, json.dumps(roles))
        return roles

    async def _collect_role_permissions(self, roles):
        role_ids = [r["id"] for r in roles]
        cache_key = f"role_perms:{'-'.join(sorted(role_ids))}"
        cached = await self.cache.get(cache_key)
        if cached:
            return json.loads(cached)
        result = {"allow": set(), "deny": set(), "conditions": {}}
        rps = await RolePermission.filter(role_id__in=role_ids).prefetch_related("permission").all()
        for rp in rps:
            code = rp.permission.code
            if rp.allowed:
                result["allow"].add(code)
                if rp.conditions:
                    result["conditions"][code] = rp.conditions
            else:
                result["deny"].add(code)
        result["allow"] = list(result["allow"])
        result["deny"] = list(result["deny"])
        await self.cache.set(cache_key, json.dumps(result))
        return result

    async def _evaluate_conditions(self, conditions, user_id, resource):
        if not conditions:
            return True
        for c in conditions:
            if c["type"] == "owner" and (not resource or str(resource.owner_id) != str(user_id)):
                return False
            if c["type"] == "department":
                roles = await self._get_user_roles(user_id, "staff")
                depts = {r["dept"] for r in roles if r.get("dept")}
                if not resource or str(resource.department_id) not in depts:
                    return False
            if c["type"] == "time_window":
                now = datetime.now().strftime("%H:%M")
                if not (c["start"] <= now <= c["end"]):
                    return False
        return True

    async def _is_super_admin(self, user_id):
        cache_key = f"superadmin:{user_id}"
        cached = await self.cache.get(cache_key)
        if cached is not None:
            return cached == "1"
        is_super = await UserRole.filter(user_id=user_id, role__name="super_admin").exists()
        await self.cache.set(cache_key, "1" if is_super else "0")
        return is_super

    async def _log_denied(self, user_id, permission_code, reason):
        await PermissionAudit.create(
            user_id=user_id,
            action="denied",
            permission_code=permission_code,
            reason=reason,
            created_at=datetime.now()
        )
```

---

## 6. DECORATORS & MIDDLEWARE

```python
def require_permission(permission_code, resource_param=None):
    """Decorator: check permission before allowing API access."""
    def decorator(handler):
        @functools.wraps(handler)
        async def wrapper(request, *args, **kwargs):
            user = getattr(request.state, "user", None)
            if not user:
                raise HTTPException(401)
            resource = None
            if resource_param and resource_param in kwargs:
                resource = ResourceContext(
                    resource_id=kwargs[resource_param],
                    owner_id=UUID(user["sub"])
                )
            engine = PermissionEngine()
            if not await engine.has_permission(
                UUID(user["sub"]),
                user.get("type", "staff"),
                permission_code,
                resource
            ):
                raise HTTPException(403, f"Permission denied: {permission_code}")
            return await handler(request, *args, **kwargs)
        return wrapper
    return decorator

def require_role(role_name):
    """Simpler decorator for coarse role-based checks."""
    def decorator(handler):
        @functools.wraps(handler)
        async def wrapper(request, *args, **kwargs):
            user = getattr(request.state, "user", None)
            if not user:
                raise HTTPException(401)
            engine = PermissionEngine()
            roles = await engine._get_user_roles(
                UUID(user["sub"]),
                user.get("type", "staff")
            )
            if not any(r["name"] == role_name for r in roles):
                raise HTTPException(403, f"Role required: {role_name}")
            return await handler(request, *args, **kwargs)
        return wrapper
    return decorator
```

---

## 7. ABAC CONDITIONS (Attribute-Based Extensions)

Conditions stored as JSONB in role_permissions allow fine-grained rules:

| Condition | Effect |
|-----------|--------|
| `{"type":"owner","field":"doctor_id"}` | Only access own resources |
| `{"type":"department","field":"dept_id"}` | Only same-department resources |
| `{"type":"time_window","start":"09:00","end":"20:00"}` | Time-limited permission |
| `{"type":"max_count","id":"x","max":100,"period":"daily"}` | Rate-limited permission |

### Examples:
```json
// Doctor can only view their own patients' reports
{"type": "owner", "field": "doctor_id"}

// Nurse only accesses patients in their department
{"type": "department", "field": "department_id"}

// Billing only during business hours
{"type": "time_window", "start": "09:00", "end": "20:00"}

// Receptionist max 100 registrations per day
{"type": "max_count", "id": "daily_registrations", "max": 100}

// Pharmacist dispenses only from assigned inventory
{"type": "attribute_match", "user_field": "assigned_inventory_id", "resource_field": "inventory_id"}
```

---

## 8. DEFAULT ROLES (Auto-Seeded)

When a new hospital is created, these roles are auto-seeded:

| Role | Key Permissions |
|------|----------------|
| hospital_admin | * (wildcard — all permissions) |
| doctor | patient.view/update, queue.view/call/complete, report.view/create/sign, doctor.prescribe |
| senior_doctor | Inherits doctor + unrestricted report.sign |
| receptionist | patient.view/create/update, queue.view, appointment.* |
| ecg_technician | patient.view, queue.view/call, ecg.view/perform/enter_result |
| echo_technician | patient.view, queue.view/call, echo.view/perform/enter_result |
| tmt_technician | patient.view, queue.view/call, tmt.view/perform/enter_result |
| accountant | patient.view, billing.view/create/settle, report.financial |
| nurse | patient.view/update, nurse.vitals |
| pharmacist | patient.view, pharmacy.dispense/verify, inventory.view/adjust |
| lab_technician | patient.view, lab.perform/enter_result |
| patient | patient.view (condition: owner=self) |

---

## 9. AUDIT & SUSPICIOUS ACTIVITY DETECTION

Every denied access is logged. The auditor detects:

- 10+ denials in 5 minutes from one user → possible credential testing
- Permission changes outside business hours → possible compromise
- Escalation attempts (receptionist trying admin actions)

```python
class PermissionAuditor:
    async def detect_suspicious(self):
        recent = datetime.now() - timedelta(minutes=5)
        results = await PermissionAudit.filter(
            action="denied",
            created_at__gte=recent
        ).annotate(
            count=Count("id")
        ).group_by("user_id").having(count__gte=10).all()
        return [{"user_id": str(r.user_id), "denied_count": r.count} for r in results]
```

---

## 10. ADMIN INTERFACE

1. **Role CRUD** — Create/edit/delete roles with permission checkboxes grouped by domain
2. **User-Role Assignment** — Drag-drop with department scope picker
3. **Permission Matrix Viewer** — Read-only grid of all roles x permissions
4. **Audit Log Viewer** — Searchable log of changes and denials
5. **Permission Test Tool** — "Can user X do action Y?" playground
6. **Clone Role** — Duplicate existing role as starting point
7. **Bulk Assign** — Assign role to multiple users at once

---

## 11. CONFIGURATION

```yaml
permissions:
  cache:
    user_roles_ttl: 300
    role_perms_ttl: 300
    user_perms_ttl: 300
  audit:
    log_denied: true
    suspicious_threshold: 10
    suspicious_window_minutes: 5
  defaults:
    auto_seed_roles: true
    auto_seed_permissions: true
  ui:
    show_denied_toast: true
    hide_disabled_buttons: true
```

---

## 12. KEY DESIGN DECISIONS

1. **Deny wins** — Explicit deny overrides any allow, preventing privilege escalation through role accumulation.
2. **Cache aggressively** — 5-min Redis TTL makes permission checks zero-cost on every API call.
3. **Super admin bypass** — Fastest code path, skips all checks.
4. **Wildcard** — "*" grants all permissions, used only for admin roles.
5. **Department scoping** — Same role in different departments = different scope.
6. **ABAC-lite** — Conditions on permissions extend RBAC without a full ABAC engine.
7. **Audit all denials** — Critical for security incident response and forensic analysis.
