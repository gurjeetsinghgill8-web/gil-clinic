---
file_id: "0109"
module_name: "Analytics Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0100_QUEUE_ENGINE.md", "0400_BILLING.md"]
related_files: ["0204_OWNER_MODULE.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "analytics", "dashboard", "metrics", "bi", "reporting"]
---

# 📊 GHOS — Analytics Engine

> **The Analytics Engine provides business intelligence for every level of the hospital — from real-time queue metrics on the reception screen to monthly revenue reports for the owner. It transforms raw operational data into actionable insights.**

---

## 1. PURPOSE

The Analytics Engine answers: **"How is the hospital performing?"**

It provides metrics across five domains:
- **Queue Analytics** — Wait times, throughput, bottlenecks
- **Clinical Analytics** — Doctor productivity, test volumes, diagnosis trends
- **Financial Analytics** — Revenue, billing, collections, payment methods
- **Patient Analytics** — Demographics, satisfaction, retention, peak hours
- **Operational Analytics** — Department utilization, staff performance, resource usage

---

## 2. DASHBOARD HIERARCHY

```
Owner Dashboard (GHOS-level / Multi-hospital)
  └── Hospital Dashboard (Single hospital)
        ├── Real-time Queue Board (Reception)
        ├── Doctor Productivity (Clinical Head)
        ├── Department Dashboard (Dept Head)
        ├── Financial Dashboard (Accountant)
        ├── Patient Experience (Manager)
        └── Admin Dashboard (Admin)
```

---

## 3. METRICS CATALOG

### 3.1 Queue Metrics
| Metric | Definition | Refresh | Audience |
|--------|-----------|---------|----------|
| Current Wait Time | Avg time from registration to being called | Real-time | Reception, Patients |
| Max Wait Today | Longest wait time today | Real-time | Admin |
| Patients Waiting | Currently in queue for each department | Real-time | All |
| Throughput | Patients completed per hour | 5 min | Dept Head |
| No-Show Rate | Registered but left without completing | Daily | Admin |
| Avg Service Time | Avg time per patient in each department | Hourly | Dept Head |
| Bottleneck Score | Dept with highest queue-to-staff ratio | Real-time | Admin |

### 3.2 Clinical Metrics
| Metric | Definition | Refresh | Audience |
|--------|-----------|---------|----------|
| Patients per Doctor | Daily count per doctor | Daily | Clinical Head |
| Avg Consult Time | Time spent per patient consultation | Daily | Doctor |
| Tests Ordered | Count by test type per day | Daily | Lab Head |
| Report Turnaround | Time from test to signed report | Hourly | Admin |
| Diagnosis Distribution | Most common diagnoses this month | Daily | Clinical Head |
| Referral Rate | % of patients referred to other depts | Weekly | Admin |
| Readmission Rate | Patients returning within 7 days | Weekly | Clinical Head |

### 3.3 Financial Metrics
| Metric | Definition | Refresh | Audience |
|--------|-----------|---------|----------|
| Daily Revenue | Total collection today | Real-time | Accountant |
| Monthly Revenue | MTD revenue vs target | Daily | Owner, Accountant |
| Payment Methods | % by cash, UPI, card, credit | Daily | Accountant |
| Pending Payments | Unpaid bills > 30 days | Daily | Accountant |
| Avg Bill Value | Average bill per patient | Daily | Owner |
| Revenue by Dept | % contribution per department | Daily | Admin |
| Refund Rate | % of bills refunded | Weekly | Admin |

### 3.4 Patient Metrics
| Metric | Definition | Refresh | Audience |
|--------|-----------|---------|----------|
| New vs Follow-up | Ratio of new patients to returning | Daily | Admin |
| Peak Hours | Busiest hours of the day | Hourly | Reception |
| Satisfaction Score | Avg rating from feedback | Weekly | Manager |
| Appointment Fill Rate | % of appointment slots filled | Daily | Reception |
| Avg Wait per Dept | Patient-reported wait by department | Daily | Manager |
| Demographics | Age/gender/location distribution | Monthly | Owner |
| Retention Rate | % of patients returning within 6 months | Monthly | Owner |

### 3.5 Operational Metrics
| Metric | Definition | Refresh | Audience |
|--------|-----------|---------|----------|
| Department Utilization | % of staff capacity used | Daily | Admin |
| Staff Attendance | % of scheduled staff present | Daily | HR, Admin |
| Equipment Usage | % uptime of critical equipment | Real-time | Tech |
| Peak Resource Usage | Max concurrent patients per hour | Hourly | Admin |
| Communication Cost | Cost per channel (SMS, WhatsApp) | Weekly | Accountant |

---

## 4. DATA PIPELINE

```
┌─────────────┐    ┌──────────────┐    ┌─────────────┐    ┌─────────────┐
│ Raw Events   │───▶│ ETL Pipeline │───▶│ Aggregated   │───▶│ Dashboards  │
│ (Queue,      │    │              │    │ Metrics      │    │ & Reports   │
│  Billing,    │    │ • Clean      │    │ (Pre-computed│    │             │
│  Visits)     │    │ • Transform  │    │  for speed)  │    │ • Real-time │
│              │    │ • Aggregate  │    │              │    │ • Daily     │
│              │    │ • Store      │    │              │    │ • Monthly   │
└─────────────┘    └──────────────┘    └──────────────┘    └─────────────┘
```

### Aggregation Strategy

| Granularity | Retention | Update | Use Case |
|------------|-----------|--------|----------|
| Raw events | 7 days | Real-time | Live queue board |
| 5-min buckets | 30 days | Every 5 min | Hourly trends |
| Hourly | 90 days | Every hour | Daily reports |
| Daily | 365 days | Every night | Monthly reports |
| Monthly | 10 years | Every month | Year-over-year comparison |

---

## 5. DATABASE SCHEMA

```sql
-- Aggregated metrics store
CREATE TABLE analytics_metrics (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    metric_name VARCHAR(100) NOT NULL,        -- queue.avg_wait_time
    granularity VARCHAR(20) NOT NULL,          -- raw, 5min, hourly, daily, monthly
    time_bucket TIMESTAMP NOT NULL,            -- Start of the time bucket
    value DECIMAL(15, 4) NOT NULL,
    dimension JSONB,                           -- {department_id, doctor_id, ...}
    sample_size INTEGER,                       -- Number of data points
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(hospital_id, metric_name, granularity, time_bucket, dimension)
);

-- Pre-computed KPI snapshots
CREATE TABLE analytics_kpis (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    kpi_name VARCHAR(100) NOT NULL,            -- revenue.monthly, queue.avg_wait
    period VARCHAR(20) NOT NULL,               -- today, this_week, this_month, this_year
    value DECIMAL(15, 4) NOT NULL,
    previous_value DECIMAL(15, 4),             -- Previous period for comparison
    change_percent DECIMAL(8, 2),              -- (value - previous) / previous * 100
    trend VARCHAR(10),                         -- up, down, stable
    dimension JSONB,
    computed_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(hospital_id, kpi_name, period, dimension)
);

-- Report definitions (custom reports)
CREATE TABLE analytics_reports (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    name VARCHAR(200) NOT NULL,
    description TEXT,
    config JSONB NOT NULL,                     -- Report configuration
    schedule VARCHAR(50),                      -- daily, weekly, monthly, manual
    recipients JSONB,                          -- Email/WhatsApp recipients
    last_sent_at TIMESTAMP,
    created_by UUID REFERENCES staff_users(id),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_analytics_metrics ON analytics_metrics(hospital_id, metric_name, granularity, time_bucket);
CREATE INDEX idx_analytics_kpis ON analytics_kpis(hospital_id, kpi_name, period);
CREATE INDEX idx_analytics_reports ON analytics_reports(hospital_id, schedule);
```

---

## 6. METRICS COMPUTATION ENGINE

```python
class MetricsEngine:
    """
    Computes and stores analytics metrics.
    
    Two computation modes:
    1. Real-time: Simple counts/avgs from Redis (queue wait time, patients waiting)
    2. Batch: Complex aggregations computed by scheduled jobs (daily revenue, monthly trends)
    """
    
    def __init__(self):
        self.redis = RedisPool()
    
    # === Real-time Metrics ===
    
    async def get_realtime_queue_metrics(self, hospital_id: UUID) -> dict:
        """Get current queue state for the live board."""
        pipe = self.redis.pipeline()
        
        # Get current wait times by department
        departments = await Department.filter(hospital_id=hospital_id).all()
        
        metrics = {}
        for dept in departments:
            # Patients waiting
            waiting = await QueueEntry.filter(
                department_id=dept.id,
                status="waiting"
            ).count()
            
            # Average wait time (last 10 completed)
            last_completed = await QueueEntry.filter(
                department_id=dept.id,
                status="completed"
            ).order_by("-completed_at").limit(10).all()
            
            avg_wait = 0
            if last_completed:
                waits = [(e.called_at - e.entered_at).total_seconds() for e in last_completed if e.called_at]
                avg_wait = sum(waits) / len(waits) if waits else 0
            
            # Staff on duty
            staff_count = await StaffUser.filter(
                department_id=dept.id,
                active=True,
                is_clocked_in=True
            ).count()
            
            metrics[dept.name] = {
                "waiting": waiting,
                "avg_wait_seconds": round(avg_wait),
                "avg_wait_minutes": round(avg_wait / 60, 1),
                "staff_on_duty": staff_count,
                "utilization": round((waiting / max(staff_count, 1)) * 100, 1) if staff_count else 0
            }
        
        return metrics
    
    async def get_daily_metrics(self, hospital_id: UUID, date: date = None) -> dict:
        """Get daily summary metrics."""
        date = date or date.today()
        
        visits_today = await Visit.filter(
            hospital_id=hospital_id,
            created_at__gte=date,
            created_at__lt=date + timedelta(days=1)
        ).count()
        
        revenue_today = await Billing.filter(
            hospital_id=hospital_id,
            paid_at__gte=date,
            paid_at__lt=date + timedelta(days=1)
        ).annotate(
            total=Sum("amount_paid")
        ).values("total")
        
        return {
            "date": date.isoformat(),
            "total_visits": visits_today,
            "total_revenue": float(revenue_today[0]["total"]) if revenue_today else 0.0,
            "new_patients": await self._count_new_patients(hospital_id, date),
            "follow_ups": await self._count_followups(hospital_id, date),
            "no_shows": await self._count_noshows(hospital_id, date),
            "avg_wait_minutes": await self._get_avg_wait_today(hospital_id, date)
        }
    
    async def record_event(self, event_type: str, data: dict):
        """Record a raw analytics event (called by other engines)."""
        # Store in Redis stream for batch processing
        event = {
            "type": event_type,
            "data": json.dumps(data),
            "timestamp": datetime.now().isoformat()
        }
        await self.redis.xadd("analytics:events", event, maxlen=10000)
    
    # === Batch Computation ===
    
    async def compute_daily_metrics(self, hospital_id: UUID, for_date: date = None):
        """Batch compute and store daily metrics (run via cron at midnight)."""
        date = for_date or (date.today() - timedelta(days=1))
        
        # Queue metrics
        avg_wait = await self._compute_avg_wait(hospital_id, date)
        max_wait = await self._compute_max_wait(hospital_id, date)
        throughput = await self._compute_throughput(hospital_id, date)
        no_show_rate = await self._compute_no_show_rate(hospital_id, date)
        
        # Store each metric
        await self._store_metric(hospital_id, "queue.avg_wait", "daily", date, avg_wait)
        await self._store_metric(hospital_id, "queue.max_wait", "daily", date, max_wait)
        await self._store_metric(hospital_id, "queue.throughput", "daily", date, throughput)
        await self._store_metric(hospital_id, "queue.no_show_rate", "daily", date, no_show_rate)
        
        # Revenue metrics
        daily_revenue = await self._compute_daily_revenue(hospital_id, date)
        await self._store_metric(hospital_id, "revenue.daily", "daily", date, daily_revenue)
        
        # Update KPI snapshots
        await self._update_kpis(hospital_id, date)
    
    async def _store_metric(self, hospital_id, metric_name, granularity, time_bucket, value, dimension=None):
        await AnalyticsMetric.create(
            hospital_id=hospital_id,
            metric_name=metric_name,
            granularity=granularity,
            time_bucket=time_bucket,
            value=value,
            dimension=dimension or {}
        )
    
    async def _update_kpis(self, hospital_id: UUID, for_date: date):
        """Update pre-computed KPI values with period-over-period comparison."""
        today = for_date
        
        # This month vs last month
        month_start = today.replace(day=1)
        last_month_start = (month_start - timedelta(days=1)).replace(day=1)
        last_month_end = month_start - timedelta(days=1)
        
        monthly_revenue = await self._sum_metric(hospital_id, "revenue.daily", "daily", month_start, today)
        last_month_revenue = await self._sum_metric(hospital_id, "revenue.daily", "daily", last_month_start, last_month_end)
        
        change = monthly_revenue - last_month_revenue
        change_pct = round((change / last_month_revenue) * 100, 2) if last_month_revenue else 0
        
        await AnalyticsKPI.create(
            hospital_id=hospital_id,
            kpi_name="revenue.monthly",
            period="this_month",
            value=monthly_revenue,
            previous_value=last_month_revenue,
            change_percent=change_pct,
            trend="up" if change > 0 else ("down" if change < 0 else "stable"),
            computed_at=datetime.now()
        )
```

---

## 7. DASHBOARD ENDPOINTS

```python
# FastAPI Analytics Routes

@router.get("/api/v1/analytics/queue/realtime")
async def realtime_queue(hospital_id: UUID = Header(...)):
    """Real-time queue metrics for the live board."""
    engine = MetricsEngine()
    return await engine.get_realtime_queue_metrics(hospital_id)


@router.get("/api/v1/analytics/daily")
async def daily_summary(
    date: date = None,
    hospital_id: UUID = Header(...)
):
    """Daily summary for the home dashboard."""
    engine = MetricsEngine()
    return await engine.get_daily_metrics(hospital_id, date or date.today())


@router.get("/api/v1/analytics/trends")
async def trends(
    metric: str = Query(...),
    granularity: str = Query("daily"),
    from_date: date = Query(...),
    to_date: date = Query(...),
    hospital_id: UUID = Header(...)
):
    """Time-series data for charts."""
    metrics = await AnalyticsMetric.filter(
        hospital_id=hospital_id,
        metric_name=metric,
        granularity=granularity,
        time_bucket__gte=from_date,
        time_bucket__lte=to_date
    ).order_by("time_bucket").all()
    
    return {
        "metric": metric,
        "granularity": granularity,
        "data_points": [
            {"date": m.time_bucket.isoformat(), "value": float(m.value)}
            for m in metrics
        ]
    }


@router.get("/api/v1/analytics/kpis")
async def kpis(
    period: str = Query("this_month"),
    hospital_id: UUID = Header(...)
):
    """Pre-computed KPI values for dashboard cards."""
    kpis = await AnalyticsKPI.filter(
        hospital_id=hospital_id,
        period=period
    ).all()
    
    return {
        "period": period,
        "kpis": [
            {
                "name": k.kpi_name,
                "value": float(k.value),
                "previous": float(k.previous_value) if k.previous_value else None,
                "change_pct": float(k.change_percent) if k.change_percent else 0,
                "trend": k.trend
            }
            for k in kpis
        ]
    }
```

---

## 8. SCHEDULED COMPUTATION JOBS

```yaml
# Cron jobs for analytics computation
jobs:
  realtime_queue:
    schedule: "*/5 * * * *"      # Every 5 minutes
    function: compute_queue_metrics
  
  hourly_metrics:
    schedule: "0 * * * *"         # Every hour
    function: compute_hourly_metrics
  
  daily_metrics:
    schedule: "0 1 * * *"         # 1 AM daily
    function: compute_daily_metrics
  
  weekly_reports:
    schedule: "0 6 * * 1"         # 6 AM Monday
    function: generate_weekly_reports
  
  monthly_aggregation:
    schedule: "0 2 1 * *"         # 2 AM on 1st of month
    function: compute_monthly_metrics
  
  kpi_update:
    schedule: "0 0 * * *"         # Midnight daily
    function: update_all_kpis
```

---

## 9. VISUALIZATION COMPONENTS

The frontend should provide reusable chart components:

```typescript
// React component examples

// 1. Time Series Chart (revenue over time)
<LineChart
  data={trendData}
  xField="date"
  yField="value"
  tooltip={{ format: 'currency' }}
/>

// 2. Comparison Card (KPI with trend)
<KPICard
  title="Monthly Revenue"
  value="₹12,45,000"
  previousValue="₹11,20,000"
  change="+11.2%"
  trend="up"
  icon="💰"
/>

// 3. Department Utilization Heatmap
<Heatmap
  data={departmentData}
  xField="hour"
  yField="department"
  colorField="utilization"
  colorScheme="green-to-red"
/>

// 4. Real-time Queue Gauges
<Gauge
  value={currentWait}
  max={targetWait}
  label="Avg Wait Time"
  unit="min"
  thresholds={[
    { value: 10, color: 'green' },
    { value: 20, color: 'yellow' },
    { value: 30, color: 'red' }
  ]}
/>

// 5. Doctor Productivity Bar Chart
<BarChart
  data={doctorData}
  xField="doctor"
  yField="patients_seen"
  colorField="department"
  horizontal={true}
/>

// 6. Pie Chart for Payment Methods
<PieChart
  data={paymentData}
  angleField="amount"
  colorField="method"
  labelField="percentage"
/>
```

---

## 10. REPORT GENERATION (PDF)

```python
class AnalyticsReport:
    """Generate printable analytics reports (PDF)."""
    
    async def generate_report(
        self,
        hospital_id: UUID,
        report_type: str,    # daily, weekly, monthly, custom
        date_range: tuple    # (from_date, to_date)
    ) -> bytes:
        """Generate a complete analytics report as PDF."""
        from_date, to_date = date_range
        
        # Gather all data
        metrics_engine = MetricsEngine()
        
        data = {
            "hospital": await Hospital.get(hospital_id),
            "date_range": {"from": from_date, "to": to_date},
            "summary": await self._get_summary(hospital_id, from_date, to_date),
            "queue_metrics": await self._get_queue_section(hospital_id, from_date, to_date),
            "financial_metrics": await self._get_financial_section(hospital_id, from_date, to_date),
            "clinical_metrics": await self._get_clinical_section(hospital_id, from_date, to_date),
            "patient_metrics": await self._get_patient_section(hospital_id, from_date, to_date),
            "charts": await self._generate_charts(hospital_id, from_date, to_date)
        }
        
        # Render PDF
        env = Environment(loader=FileSystemLoader("templates/reports/"))
        template = env.get_template("analytics_report.html")
        html = template.render(**data)
        
        pdf_bytes = HTML(string=html).write_pdf()
        return pdf_bytes
```

---

## 11. EXPORT INTEGRATIONS

| Export Type | Format | Use Case |
|-------------|--------|----------|
| Download | PDF | Printable reports for meetings |
| Download | CSV | Data analysis in Excel |
| Download | JSON | API integration |
| Email | PDF | Scheduled delivery to stakeholders |
| WhatsApp | PDF | Quick share with owner |
| Dashboard | Web | Real-time interactive view |
| Webhook | JSON | External BI tools (Power BI, Tableau) |

---

## 12. CONFIGURATION

```yaml
analytics:
  metrics:
    retention_days:
      raw: 7
      "5min": 30
      hourly: 90
      daily: 365
      monthly: 3650
  
  computation:
    batch_size: 1000
    queue_realtime_interval_seconds: 5
    hourly_cron: "0 * * * *"
    daily_cron: "0 1 * * *"
    monthly_cron: "0 2 1 * *"
  
  dashboard:
    realtime_refresh_seconds: 10
    daily_refresh_seconds: 300
    max_chart_points: 365
    default_date_range_days: 30
  
  kpis:
    auto_compute: true
    comparison_periods: ["previous_period", "same_period_last_year", "target"]
  
  reports:
    format: "pdf"
    max_date_range_days: 365
    auto_generate: ["daily", "monthly"]
    email_recipients: []
```

---

## 13. KEY DESIGN DECISIONS

1. **Pre-compute everything** — Metrics are computed in batch jobs, not on dashboard load. Dashboards just read pre-aggregated numbers.
2. **Two-tier storage** — Real-time metrics in Redis (fast), historical metrics in PostgreSQL (durable).
3. **Granularity hierarchy** — Raw → 5min → hourly → daily → monthly. Higher granularity = longer retention.
4. **Event-driven pipeline** — All state changes emit events stored in Redis streams. Batch jobs consume and aggregate.
5. **Period-over-period** — Every KPI automatically stores previous period value and percentage change.
6. **Self-service reports** — Admin can create custom report definitions without code.
7. **Audience-aware dashboards** — Different views for different roles (owner vs receptionist vs doctor).
