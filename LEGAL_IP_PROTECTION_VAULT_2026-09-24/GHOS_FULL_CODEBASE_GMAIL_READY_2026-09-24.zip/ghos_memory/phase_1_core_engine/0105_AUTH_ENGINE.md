---
file_id: "0105"
module_name: "Auth Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["0106_PERMISSION_ENGINE.md", "0800_SECURITY.md", "0801_ENCRYPTION.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "auth", "authentication", "otp", "jwt", "sso"]
---

# 🔐 GHOS — Auth Engine

> **The Auth Engine is the gatekeeper of GHOS. Every user — staff, patient, admin, external system — passes through it. It supports OTP-based login, password auth, QR-based session tokens, and API key authentication for external integrations.**

---

## 1. PURPOSE

The Auth Engine provides:
- **Authentication** — Verify who a user claims to be
- **Session management** — Issue, validate, refresh, and revoke tokens
- **Multi-factor** — OTP (SMS/WhatsApp) + optional password
- **Device tracking** — Track active sessions per user
- **Account security** — Lockout, rate limiting, suspicious activity detection
- **API authentication** — API keys for external integrations

---

## 2. AUTHENTICATION FLOWS

### 2.1 Staff Login (Primary Flow)
```
User enters mobile number
  → System checks if number exists + active
  → Generates 6-digit OTP
  → Sends via WhatsApp (primary) or SMS (fallback)
  → User enters OTP
  → OTP validated (TTL: 5 min, max 3 attempts)
  → JWT issued (24h expiry, refreshable for 7 days)
  → Role-based redirect to dashboard
  → Active session logged
```

### 2.2 Staff Login (Password Fallback)
```
User clicks "Login with password" (admin/owner only)
  → Enters username + password
  → Argon2id hash verification
  → If MFA enabled → send OTP as second factor
  → JWT issued
```

### 2.3 Patient Access (No-Password)
```
Patient clicks link from WhatsApp/SMS
  → URL contains signed token (visit_id + patient_id + timestamp + signature)
  → Token decoded and verified
  → Creates temporary session (expires with visit)
  → Patient sees their status page
  → No password needed, no account creation
```

### 2.4 QR-Based Access
```
Patient at clinic:
  → Show QR code on phone (from WhatsApp link)
  → Receptionist scans with camera
  → QR contains visit reference + signed nonce
  → System validates and shows patient details
  → Registration complete in one scan
```

### 2.5 API Authentication (External Systems)
```
External system (lab machine, billing software, etc.):
  → Pre-registered API key (UUID format)
  → HMAC-SHA256 signature of request body + timestamp
  → Server verifies signature, checks rate limits
  → Granular permissions per API key
```

---

## 3. TOKEN STRUCTURE

```python
class TokenManager:
    """
    Manages JWT and session token lifecycle.
    
    Token types:
    - access_token: Short-lived (24h) for API authorization
    - refresh_token: Long-lived (7 days) for renewing access
    - patient_token: Visit-scoped (1-24h) for patient self-service
    - api_key: Permanent (manual revoke) for external integrations
    - signed_link: One-time use, 15min TTL for QR/login links
    """
    
    ACCESS_TOKEN_TTL = timedelta(hours=24)
    REFRESH_TOKEN_TTL = timedelta(days=7)
    PATIENT_TOKEN_TTL = timedelta(hours=24)  # Same as visit max duration
    SIGNED_LINK_TTL = timedelta(minutes=15)
    OTP_TTL = timedelta(minutes=5)
    
    def __init__(self):
        self.secret_key = settings.AUTH_SECRET_KEY
        self.algorithm = "HS256"
        
        # For patient signed links — separate key from staff JWTs
        self.link_signing_key = settings.LINK_SIGNING_KEY
    
    def create_staff_token(self, user: StaffUser) -> str:
        """Create JWT access token for staff members."""
        payload = {
            "sub": str(user.id),
            "type": "staff",
            "role": user.role,
            "hospital_id": str(user.hospital_id),
            "branch_id": str(user.branch_id) if user.branch_id else None,
            "name": user.name,
            "iat": datetime.now(),
            "exp": datetime.now() + self.ACCESS_TOKEN_TTL,
            "jti": str(uuid4())  # Unique token ID for revocation
        }
        
        # Add department-level permissions
        if hasattr(user, 'department_permissions'):
            payload["dept_perms"] = user.department_permissions
        
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_staff_refresh_token(self, user: StaffUser) -> str:
        """Create longer-lived refresh token."""
        payload = {
            "sub": str(user.id),
            "type": "refresh",
            "iat": datetime.now(),
            "exp": datetime.now() + self.REFRESH_TOKEN_TTL,
            "jti": str(uuid4())
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_patient_token(self, visit: Visit) -> str:
        """Create visit-scoped token for patient self-service."""
        payload = {
            "sub": str(visit.patient_id),
            "type": "patient",
            "visit_id": str(visit.id),
            "hospital_id": str(visit.hospital_id),
            "iat": datetime.now(),
            "exp": datetime.now() + self.PATIENT_TOKEN_TTL,
            "scope": ["view_status", "view_reports"]
        }
        return jwt.encode(payload, self.secret_key, algorithm=self.algorithm)
    
    def create_signed_link(self, patient_id: UUID, visit_id: UUID) -> str:
        """Create one-time signed URL (for WhatsApp/SMS links)."""
        expiry = datetime.now() + self.SIGNED_LINK_TTL
        payload = {
            "pid": str(patient_id),
            "vid": str(visit_id),
            "exp": int(expiry.timestamp())
        }
        # Serialize and sign
        data = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode()
        signature = hmac.new(
            self.link_signing_key.encode(),
            data.encode(),
            hashlib.sha256
        ).hexdigest()[:16]
        
        return f"{data}.{signature}"
    
    def verify_signed_link(self, token: str) -> Optional[dict]:
        """Verify and decode a signed link."""
        try:
            data, signature = token.split(".")
            expected_sig = hmac.new(
                self.link_signing_key.encode(),
                data.encode(),
                hashlib.sha256
            ).hexdigest()[:16]
            
            if not hmac.compare_digest(signature, expected_sig):
                return None
            
            payload = json.loads(base64.urlsafe_b64decode(data + "=="))
            
            if datetime.now().timestamp() > payload["exp"]:
                return None
            
            return payload
        except Exception:
            return None
    
    def verify_token(self, token: str) -> Optional[dict]:
        """Verify and decode any JWT token."""
        try:
            payload = jwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                options={"require": ["sub", "type", "iat", "exp"]}
            )
            
            # Check if token is revoked
            if self.is_token_revoked(payload.get("jti")):
                return None
            
            return payload
        except jwt.ExpiredSignatureError:
            return None
        except jwt.InvalidTokenError:
            return None
    
    def refresh_access_token(self, refresh_token: str) -> Optional[str]:
        """Exchange a refresh token for a new access token."""
        payload = self.verify_token(refresh_token)
        if not payload or payload.get("type") != "refresh":
            return None
        
        # Get user and create new access token
        user = StaffUser.get(payload["sub"])
        if not user or not user.active:
            return None
        
        return self.create_staff_token(user)
    
    async def revoke_token(self, token_jti: str):
        """Revoke a token (add to blocklist)."""
        await redis.setex(f"revoked:{token_jti}", int(self.ACCESS_TOKEN_TTL.total_seconds()), "1")
    
    async def revoke_all_user_tokens(self, user_id: UUID):
        """Revoke all tokens for a user (used on password change / account lock)."""
        await redis.setex(f"revoke_all:{user_id}", int(self.REFRESH_TOKEN_TTL.total_seconds()), str(datetime.now().timestamp()))
    
    async def is_token_revoked(self, token_jti: str) -> bool:
        if not token_jti:
            return False
        return await redis.exists(f"revoked:{token_jti}")
```

---

## 4. OTP SERVICE

```python
class OTPService:
    """
    OTP generation, delivery, and verification.
    
    Features:
    - 6-digit numeric OTP
    - 5-minute TTL
    - Max 3 verification attempts
    - Cooldown: 30s between resends
    - Max 5 OTPs per number per hour
    - Automatic expiry cleanup
    """
    
    OTP_LENGTH = 6
    OTP_TTL_SECONDS = 300
    MAX_ATTEMPTS = 3
    RESEND_COOLDOWN = 30
    MAX_PER_HOUR = 5
    
    def __init__(self):
        self.communication_engine = CommunicationEngine()
    
    async def generate_and_send(
        self,
        mobile: str,
        channel: str = "whatsapp",
        user_name: str = None
    ) -> dict:
        """Generate OTP and send via preferred channel."""
        
        # Rate limit check
        hourly_key = f"otp:hourly:{mobile}"
        hourly_count = await redis.incr(hourly_key)
        if hourly_count == 1:
            await redis.expire(hourly_key, 3600)
        
        if hourly_count > self.MAX_PER_HOUR:
            return {
                "success": False,
                "error": "rate_limited",
                "message": "Maximum OTP requests reached. Try again later."
            }
        
        # Cooldown check
        cooldown_key = f"otp:cooldown:{mobile}"
        if await redis.exists(cooldown_key):
            ttl = await redis.ttl(cooldown_key)
            return {
                "success": False,
                "error": "cooldown",
                "message": f"Please wait {ttl} seconds before requesting again."
            }
        
        # Generate OTP
        otp = ''.join(random.choices(string.digits, k=self.OTP_LENGTH))
        
        # Store OTP hash (never store plaintext OTP)
        otp_hash = hashlib.sha256(f"{mobile}:{otp}:{settings.OTP_PEPPER}".encode()).hexdigest()
        await redis.setex(f"otp:{mobile}", self.OTP_TTL_SECONDS, otp_hash)
        await redis.setex(f"otp:attempts:{mobile}", self.OTP_TTL_SECONDS, 0)
        await redis.setex(cooldown_key, self.RESEND_COOLDOWN, "1")
        
        # Send OTP
        greeting = f"Hello {user_name}, " if user_name else ""
        message = f"{greeting}Your GHOS login OTP is: {otp}. Valid for 5 minutes. Do not share this OTP with anyone."
        
        result = await self.communication_engine.send(
            patient_id=None,
            template_key="otp",
            data={"otp": otp, "name": user_name or ""},
            preferred_channel=channel
        )
        
        # Log OTP generation
        await self._log_otp(mobile, channel)
        
        return {
            "success": result.success,
            "message_id": result.get("message_id"),
            "ttl_seconds": self.OTP_TTL_SECONDS
        }
    
    async def verify(self, mobile: str, otp: str) -> dict:
        """Verify an OTP."""
        # Check attempts
        attempts_key = f"otp:attempts:{mobile}"
        attempts = await redis.get(attempts_key)
        attempts = int(attempts) if attempts else 0
        
        if attempts >= self.MAX_ATTEMPTS:
            await redis.delete(f"otp:{mobile}")
            return {
                "success": False,
                "error": "max_attempts",
                "message": "Maximum OTP attempts exceeded. Request a new OTP."
            }
        
        # Get stored hash
        otp_key = f"otp:{mobile}"
        stored_hash = await redis.get(otp_key)
        
        if not stored_hash:
            return {
                "success": False,
                "error": "expired",
                "message": "OTP expired or not requested. Please request a new OTP."
            }
        
        # Increment attempts
        await redis.incr(attempts_key)
        
        # Verify
        computed_hash = hashlib.sha256(f"{mobile}:{otp}:{settings.OTP_PEPPER}".encode()).hexdigest()
        
        if computed_hash == stored_hash:
            # Success — clean up
            await redis.delete(otp_key)
            await redis.delete(attempts_key)
            return {
                "success": True,
                "message": "OTP verified successfully."
            }
        
        remaining = self.MAX_ATTEMPTS - (attempts + 1)
        return {
            "success": False,
            "error": "invalid",
            "message": f"Invalid OTP. {remaining} attempts remaining."
        }
    
    async def _log_otp(self, mobile: str, channel: str):
        """Log OTP generation for audit."""
        await AuditLog.create(
            action="otp_generated",
            target=mobile,
            metadata={"channel": channel},
            created_at=datetime.now()
        )
```

---

## 5. PASSWORD AUTHENTICATION

```python
class PasswordAuth:
    """
    Password-based authentication for admin/owner accounts.
    
    Security standards:
    - Argon2id hashing (memory-hard, resists GPU attacks)
    - Min 8 characters, must include uppercase + number
    - Password history: last 5 passwords remembered
    - Account lockout: 5 failed attempts → 15 min lockout
    - Force password change: every 90 days
    - Breached password check (HaveIBeenPwned API optional)
    """
    
    def __init__(self):
        self.argon2 = PasswordHasher(
            time_cost=3,         # 3 iterations
            memory_cost=65536,    # 64 MB
            parallelism=4,
            hash_len=32,
            salt_len=16
        )
    
    async def hash_password(self, password: str) -> str:
        """Hash password using Argon2id."""
        return self.argon2.hash(password)
    
    async def verify_password(self, password: str, hash: str) -> bool:
        """Verify password against Argon2id hash."""
        try:
            return self.argon2.verify(hash, password)
        except VerifyMismatchError:
            return False
    
    async def check_password_strength(self, password: str) -> dict:
        """Check password strength and return feedback."""
        errors = []
        if len(password) < 8:
            errors.append("At least 8 characters required")
        if not any(c.isupper() for c in password):
            errors.append("At least one uppercase letter required")
        if not any(c.isdigit() for c in password):
            errors.append("At least one number required")
        if password.lower() in COMMON_PASSWORDS:
            errors.append("This password is too common")
        
        score = max(0, 100 - (len(errors) * 25))
        
        return {
            "score": score,
            "is_strong": score >= 75,
            "errors": errors
        }
    
    async def change_password(
        self,
        user: StaffUser,
        old_password: str,
        new_password: str
    ) -> dict:
        """Change user password with history check."""
        # Verify old password
        if not await self.verify_password(old_password, user.password_hash):
            return {"success": False, "error": "Current password is incorrect"}
        
        # Check password strength
        strength = await self.check_password_strength(new_password)
        if not strength["is_strong"]:
            return {"success": False, "error": " | ".join(strength["errors"])}
        
        # Check password history (last 5)
        history = await PasswordHistory.filter(user_id=user.id).order_by("-created_at").limit(5)
        for entry in history:
            if await self.verify_password(new_password, entry.password_hash):
                return {"success": False, "error": "Cannot reuse a recent password"}
        
        # Hash and save
        new_hash = await self.hash_password(new_password)
        
        # Update user
        old_hash = user.password_hash
        user.password_hash = new_hash
        user.password_changed_at = datetime.now()
        await user.save()
        
        # Add to history
        await PasswordHistory.create(
            user_id=user.id,
            password_hash=old_hash,
            created_at=datetime.now()
        )
        
        # Revoke all existing tokens
        await TokenManager().revoke_all_user_tokens(user.id)
        
        # Log audit
        await AuditLog.create(
            action="password_changed",
            user_id=user.id,
            target=str(user.id),
            metadata={"reason": "user_change"},
            created_at=datetime.now()
        )
        
        return {"success": True, "message": "Password changed successfully"}
```

---

## 6. MIDDLEWARE & GUARDS

```python
# === FastAPI Middleware ===

@app.middleware("http")
async def auth_middleware(request: Request, call_next):
    """Global auth middleware — extracts and validates tokens for every request."""
    
    # Public paths (no auth required)
    public_paths = [
        "/health", "/docs", "/openapi.json",
        "/webhooks/", "/api/v1/auth/",
        "/api/v1/patient/status"  # Patient status pages use signed links
    ]
    
    if any(request.url.path.startswith(p) for p in public_paths):
        return await call_next(request)
    
    # Extract token
    auth_header = request.headers.get("Authorization", "")
    token = auth_header.replace("Bearer ", "") if auth_header.startswith("Bearer ") else ""
    
    # Also check cookies (for web/PWA sessions)
    if not token:
        token = request.cookies.get("access_token", "")
    
    if not token:
        return JSONResponse(status_code=401, content={"detail": "Authentication required"})
    
    # Verify token
    token_data = TokenManager().verify_token(token)
    if not token_data:
        return JSONResponse(status_code=401, content={"detail": "Invalid or expired token"})
    
    # Attach user info to request state
    request.state.user = token_data
    request.state.user_id = UUID(token_data["sub"])
    
    return await call_next(request)


# === Decorator Guards ===

def require_auth(roles: List[str] = None):
    """Decorator to require authentication with optional role check."""
    async def decorator(request: Request, handler):
        user = getattr(request.state, "user", None)
        if not user:
            raise HTTPException(status_code=401, detail="Not authenticated")
        
        if roles and user.get("role") not in roles:
            raise HTTPException(status_code=403, detail="Insufficient permissions")
        
        return await handler(request)
    return decorator


def optional_auth(handler):
    """Decorator that extracts user info if available, but doesn't require it."""
    async def decorator(request: Request):
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        if token:
            request.state.user = TokenManager().verify_token(token)
        else:
            request.state.user = None
        return await handler(request)
    return decorator


# === API Key Authentication (for external systems) ===

async def verify_api_key(request: Request) -> Optional[APIKey]:
    """Verify API key for external system access."""
    api_key = request.headers.get("X-API-Key", "")
    if not api_key:
        return None
    
    key_record = await APIKey.get_or_none(key_hash=hashlib.sha256(api_key.encode()).hexdigest())
    if not key_record or not key_record.active:
        return None
    
    # Rate limit check
    rate_key = f"apikey:ratelimit:{key_record.id}"
    count = await redis.incr(rate_key)
    if count == 1:
        await redis.expire(rate_key, 60)
    
    if count > key_record.rate_limit_per_minute:
        raise HTTPException(status_code=429, detail="Rate limit exceeded")
    
    # Log usage
    await APIKeyUsage.create(
        api_key_id=key_record.id,
        endpoint=request.url.path,
        ip_address=request.client.host,
        created_at=datetime.now()
    )
    
    return key_record
```

---

## 7. DATABASE SCHEMA

```sql
-- Staff users
CREATE TABLE staff_users (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    branch_id UUID REFERENCES branches(id),
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(20) UNIQUE NOT NULL,
    email VARCHAR(200),
    role VARCHAR(50) NOT NULL,           -- admin, doctor, receptionist, etc.
    department_id UUID REFERENCES departments(id),
    password_hash VARCHAR(256),          -- Argon2id hash (nullable for OTP-only users)
    active BOOLEAN DEFAULT TRUE,
    is_locked BOOLEAN DEFAULT FALSE,
    locked_until TIMESTAMP,
    failed_login_attempts INTEGER DEFAULT 0,
    last_login_at TIMESTAMP,
    last_login_ip VARCHAR(45),
    password_changed_at TIMESTAMP,
    mfa_enabled BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Patients (for patient access sessions)
CREATE TABLE patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    name VARCHAR(100) NOT NULL,
    mobile VARCHAR(20) NOT NULL,
    email VARCHAR(200),
    language VARCHAR(10) DEFAULT 'hi',    -- hi, en
    fcm_token VARCHAR(500),               -- Push notification token
    is_online BOOLEAN DEFAULT FALSE,
    last_active_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

-- Active sessions
CREATE TABLE sessions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL,                 -- staff_user.id or patient.id
    user_type VARCHAR(20) NOT NULL,        -- staff, patient
    token_jti VARCHAR(100) UNIQUE NOT NULL,
    refresh_token_jti VARCHAR(100),
    device_info TEXT,                      -- User agent, platform
    ip_address VARCHAR(45),
    expires_at TIMESTAMP NOT NULL,
    last_activity_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Password history
CREATE TABLE password_history (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id UUID NOT NULL REFERENCES staff_users(id),
    password_hash VARCHAR(256) NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

-- API keys for external integrations
CREATE TABLE api_keys (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL REFERENCES hospitals(id),
    name VARCHAR(100) NOT NULL,             -- "Lab Machine 1", "Billing API"
    key_hash VARCHAR(64) NOT NULL UNIQUE,   -- SHA-256 of actual key
    permissions JSONB,                      -- ["queue.read", "patient.create"]
    rate_limit_per_minute INTEGER DEFAULT 60,
    active BOOLEAN DEFAULT TRUE,
    created_by UUID REFERENCES staff_users(id),
    expires_at TIMESTAMP,
    last_used_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- API key usage log
CREATE TABLE api_key_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    api_key_id UUID NOT NULL REFERENCES api_keys(id),
    endpoint VARCHAR(200),
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- OTP audit log
CREATE TABLE otp_logs (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    mobile VARCHAR(20) NOT NULL,
    channel VARCHAR(20),
    status VARCHAR(20),                    -- sent, verified, expired, failed
    ip_address VARCHAR(45),
    created_at TIMESTAMP DEFAULT NOW()
);

-- Indexes
CREATE INDEX idx_staff_mobile ON staff_users(mobile);
CREATE INDEX idx_staff_hospital ON staff_users(hospital_id, role);
CREATE INDEX idx_patient_mobile ON patients(mobile);
CREATE INDEX idx_sessions_user ON sessions(user_id, user_type);
CREATE INDEX idx_sessions_token ON sessions(token_jti);
CREATE INDEX idx_sessions_active ON sessions(expires_at) WHERE expires_at > NOW();
CREATE INDEX idx_apikeys_hospital ON api_keys(hospital_id, active);
CREATE INDEX idx_otp_logs_mobile ON otp_logs(mobile, created_at);
```

---

## 8. ACCOUNT LOCKOUT & PROTECTION

```python
class AccountProtection:
    """
    Protects accounts from brute force, credential stuffing, and abuse.
    
    Protection layers:
    1. Rate limiting — Max 5 OTP requests/hour per number
    2. IP blacklisting — Temporarily block IPs with >20 failed attempts
    3. Account lockout — Lock account after 5 failed password attempts
    4. Device fingerprinting — Detect unusual device/location combinations
    5. Concurrent session limit — Max 5 active sessions per staff user
    """
    
    FAILED_ATTEMPT_THRESHOLD = 5
    LOCKOUT_DURATION = timedelta(minutes=15)
    IP_BLACKLIST_THRESHOLD = 20
    IP_BLACKLIST_DURATION = timedelta(hours=1)
    MAX_CONCURRENT_SESSIONS = 5
    
    async def record_failed_attempt(self, user_id: UUID, ip_address: str):
        """Record a failed login attempt."""
        user = await StaffUser.get(user_id)
        user.failed_login_attempts += 1
        
        if user.failed_login_attempts >= self.FAILED_ATTEMPT_THRESHOLD:
            user.is_locked = True
            user.locked_until = datetime.now() + self.LOCKOUT_DURATION
        
        await user.save()
        
        # IP tracking
        ip_key = f"failed_ip:{ip_address}"
        count = await redis.incr(ip_key)
        if count == 1:
            await redis.expire(ip_key, 3600)
        
        if count >= self.IP_BLACKLIST_THRESHOLD:
            await redis.setex(f"blacklisted_ip:{ip_address}", int(self.IP_BLACKLIST_DURATION.total_seconds()), "1")
    
    async def record_successful_login(self, user: StaffUser, ip_address: str, device_info: str):
        """Record a successful login."""
        user.failed_login_attempts = 0
        user.is_locked = False
        user.locked_until = None
        user.last_login_at = datetime.now()
        user.last_login_ip = ip_address
        await user.save()
        
        # Clean up old sessions if over limit
        active_sessions = await Session.filter(
            user_id=user.id,
            user_type="staff",
            expires_at__gt=datetime.now()
        ).count()
        
        if active_sessions >= self.MAX_CONCURRENT_SESSIONS:
            # Revoke oldest session
            oldest = await Session.filter(
                user_id=user.id,
                user_type="staff"
            ).order_by("created_at").first()
            if oldest:
                await TokenManager().revoke_token(oldest.token_jti)
                await oldest.delete()
        
        # Clear IP rate limits
        await redis.delete(f"failed_ip:{ip_address}")
    
    async def is_ip_blacklisted(self, ip_address: str) -> bool:
        return await redis.exists(f"blacklisted_ip:{ip_address}")
    
    async def is_account_locked(self, user_id: UUID) -> dict:
        user = await StaffUser.get(user_id)
        if not user.is_locked or not user.locked_until:
            return {"locked": False}
        
        if datetime.now() > user.locked_until:
            user.is_locked = False
            user.locked_until = None
            user.failed_login_attempts = 0
            await user.save()
            return {"locked": False}
        
        remaining = (user.locked_until - datetime.now()).seconds
        return {"locked": True, "remaining_seconds": remaining}
```

---

## 9. SESSION MANAGEMENT

```python
class SessionManager:
    """
    Manages user sessions across devices and browsers.
    
    Capabilities:
    - List all active sessions for a user
    - Terminate specific session (logout from one device)
    - Terminate all sessions (logout from all devices)
    - Detect session hijacking (IP/device change)
    - Session timeout (inactivity > 30 min → auto-logout)
    """
    
    INACTIVITY_TIMEOUT = timedelta(minutes=30)
    
    async def create_session(
        self,
        user_id: UUID,
        user_type: str,
        token_jti: str,
        refresh_jti: str,
        device_info: str,
        ip_address: str
    ):
        await Session.create(
            user_id=user_id,
            user_type=user_type,
            token_jti=token_jti,
            refresh_token_jti=refresh_jti,
            device_info=device_info,
            ip_address=ip_address,
            expires_at=datetime.now() + TokenManager.ACCESS_TOKEN_TTL,
            last_activity_at=datetime.now()
        )
    
    async def update_activity(self, token_jti: str):
        """Update last activity timestamp for a session."""
        await Session.filter(token_jti=token_jti).update(
            last_activity_at=datetime.now()
        )
    
    async def list_sessions(self, user_id: UUID) -> List[dict]:
        """List all active sessions for a user."""
        sessions = await Session.filter(
            user_id=user_id,
            expires_at__gt=datetime.now()
        ).order_by("-last_activity_at")
        
        return [
            {
                "id": str(s.id),
                "device": s.device_info,
                "ip": s.ip_address,
                "last_active": s.last_activity_at,
                "created": s.created_at,
                "is_current": False  # Set by caller
            }
            for s in sessions
        ]
    
    async def terminate_session(self, session_id: UUID):
        """Terminate a specific session."""
        session = await Session.get(session_id)
        if session:
            await TokenManager().revoke_token(session.token_jti)
            await session.delete()
    
    async def terminate_all_sessions(self, user_id: UUID, except_jti: str = None):
        """Terminate all sessions for a user (except current one)."""
        sessions = await Session.filter(
            user_id=user_id,
            expires_at__gt=datetime.now()
        )
        for session in sessions:
            if except_jti and session.token_jti == except_jti:
                continue
            await TokenManager().revoke_token(session.token_jti)
            await session.delete()
    
    async def check_inactivity(self, token_jti: str) -> bool:
        """Check if session has been inactive too long."""
        session = await Session.get_or_none(token_jti=token_jti)
        if not session:
            return True
        if session.last_activity_at and (datetime.now() - session.last_activity_at) > self.INACTIVITY_TIMEOUT:
            await self.terminate_session(session.id)
            return True
        return False
```

---

## 10. AUDIT EVENTS

All authentication events are logged for audit:

| Event | Description |
|-------|-------------|
| `login.success` | Successful login with OTP or password |
| `login.failed` | Failed login attempt (reason recorded) |
| `login.otp_sent` | OTP sent via SMS/WhatsApp |
| `login.otp_verified` | OTP verified successfully |
| `login.otp_failed` | OTP verification failed |
| `logout` | User logged out |
| `token.refresh` | Access token refreshed |
| `token.revoke` | Token manually revoked |
| `password.change` | Password changed |
| `password.reset` | Admin-initiated password reset |
| `account.lock` | Account locked due to failed attempts |
| `account.unlock` | Account manually unlocked by admin |
| `apikey.create` | New API key created |
| `apikey.revoke` | API key revoked |

---

## 11. CONFIGURATION

```yaml
# config/auth.yaml
auth:
  # JWT settings
  jwt:
    secret_key: "${AUTH_SECRET_KEY}"     # 256-bit random key
    algorithm: "HS256"
    access_token_ttl_hours: 24
    refresh_token_ttl_days: 7
    link_signing_key: "${LINK_SIGNING_KEY}"
  
  # OTP settings
  otp:
    length: 6
    ttl_seconds: 300
    max_attempts: 3
    resend_cooldown_seconds: 30
    max_per_hour: 5
  
  # Password policy
  password:
    min_length: 8
    require_uppercase: true
    require_number: true
    history_count: 5
    force_change_days: 90
    hasher: "argon2id"
    argon_time_cost: 3
    argon_memory_cost: 65536
  
  # Account protection
  protection:
    max_failed_attempts: 5
    lockout_minutes: 15
    ip_blacklist_threshold: 20
    ip_blacklist_hours: 1
    max_concurrent_sessions: 5
    inactivity_timeout_minutes: 30
  
  # API keys
  api_keys:
    key_length: 32           # Characters
    default_rate_limit: 60   # Per minute
    auto_expire_days: 365
  
  # Login methods by role
  login_methods:
    admin: ["otp", "password"]
    owner: ["otp", "password"]
    doctor: ["otp"]
    receptionist: ["otp"]
    nurse: ["otp"]
    lab_technician: ["otp"]
    pharmacist: ["otp"]
    accountant: ["otp"]
    patient: ["signed_link"]
```

---

## 12. KEY DESIGN DECISIONS

1. **OTP over password for most staff** — Eliminates password fatigue, phishing risk, and support tickets for "forgot password"
2. **Argon2id for passwords** — Memory-hard hashing resists GPU/ASIC attacks. PBKDF2 and bcrypt are intentionally not used.
3. **OTP hashed with pepper** — Plaintext OTP never stored, not even temporarily. SHA-256 with server-side pepper prevents DB leak from exposing OTPs.
4. **Signed links for patients** — Zero-friction access. No account creation, no password, no OTP. The link itself is the credential.
5. **Stateless JWTs with revocation** — JWTs are stateless for performance, but JTI (JWT ID) allows selective revocation via Redis blocklist.
6. **HMAC verification for signed links** — Uses separate signing key from JWT secret. Even if link signing key is compromised, JWTs remain secure.
7. **Granular rate limiting** — Different limits for OTP, password attempts, IP address, and API keys prevent abuse without impacting legitimate users.
