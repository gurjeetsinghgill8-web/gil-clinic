---
file_id: "0101"
module_name: "Workflow Engine"
version: "1.0"
status: "Approved"
phase: "Phase 1 — Core Engine"
dependencies: ["0100_QUEUE_ENGINE.md"]
related_files: ["0102_TOKEN_ENGINE.md", "0601_PATIENT_TIMELINE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "workflow-engine", "patient-journey", "orchestrator"]
---

# 🔄 GHOS — Workflow Engine

---

## 1. PURPOSE

While the Queue Engine manages **who is next**, the Workflow Engine manages **where the patient goes next**. It is the orchestrator that defines the patient journey.

---

## 2. CORE CONCEPT

Every visit has a **workflow definition** — a directed graph of steps the patient must go through:

```
Example: Cardiac Checkup Visit

[Reception] ──→ [Doctor] ──→ [ECG]
                                  │
                                  ├──→ [Doctor (review)] ──→ [Pharmacy] ──→ [Billing] ──→ ✅ Done
                                  │
                                  └──→ [Echo] ──→ [Doctor (review)] ──→ [Pharmacy]
```

---

## 3. WORKFLOW DEFINITION

```yaml
workflow_id: "cardiac_checkup_v1"
name: "Cardiac Checkup"
departments:
  - id: "reception"
    order: 1
    required: true
    auto_proceed: true  # Auto-move to next after completion

  - id: "doctor_consult"
    order: 2
    required: true
    auto_proceed: false  # Doctor decides next step
    routing_rules:
      - to: "ecg"
        condition: "first_visit || symptoms.chest_pain"
        label: "Send to ECG"
        icon: "heart"
      - to: "pharmacy"
        condition: "prescription.medicines.length > 0"
        label: "Send to Pharmacy"
        icon: "pill"
      - to: "billing"
        condition: "true"
        label: "Send to Billing"
        icon: "receipt"

  - id: "ecg"
    order: 3
    required: false
    auto_proceed: false
    routing_rules:
      - to: "doctor_consult"  # Return to doctor for review
        label: "Send to Doctor (Review)"
        icon: "stethoscope"
      - to: "echo"
        condition: "ecg_result.abnormal"
        label: "Send to Echo (Further investigation)"
      - to: "pharmacy"
        label: "Send to Pharmacy"

  - id: "echo"
    order: 4
    required: false
    auto_proceed: false
    routing_rules:
      - to: "doctor_consult"
        label: "Send to Doctor (Review)"

  - id: "pharmacy"
    order: 5
    required: false
    auto_proceed: true
    routing_rules:
      - to: "billing"
        label: "Send to Billing"

  - id: "billing"
    order: 6
    required: true
    auto_proceed: false
    is_terminal: true  # End of visit
```

---

## 4. WORKFLOW EXECUTION

```python
class WorkflowEngine:
    """
    Manages the patient's journey through the clinic.
    Determines what happens next after each department visit.
    """

    async def get_next_steps(
        self,
        visit_id: UUID,
        current_department_id: UUID
    ) -> List[WorkflowStep]:
        """
        Get available next steps after completing current department.
        Returns a list of possible next departments with conditions.
        """
        visit = await Visit.get(visit_id)
        workflow = await self.get_workflow(visit.workflow_id)

        current_step = workflow.get_step(current_department_id)
        if not current_step or current_step.auto_proceed:
            # Auto-proceed to next required step
            next_step = workflow.get_next_required(current_step.order)
            return [WorkflowStep(
                department_id=next_step.id,
                label=next_step.name,
                auto=True
            )]

        # Return routing rules as available actions
        available = []
        for rule in current_step.routing_rules:
            if rule.condition:
                # Evaluate condition against visit context
                if await self.evaluate_condition(rule.condition, visit):
                    available.append(WorkflowStep(
                        department_id=rule.to,
                        label=rule.label,
                        icon=rule.icon
                    ))
            else:
                available.append(WorkflowStep(
                    department_id=rule.to,
                    label=rule.label,
                    icon=rule.icon
                ))

        return available

    async def execute_step(
        self,
        visit_id: UUID,
        from_department: UUID,
        to_department: UUID
    ):
        """Execute a workflow step — route patient to next department."""
        # 1. Record the transition
        await self.record_transition(
            visit_id, from_department, to_department
        )

        # 2. Update patient timeline
        await add_timeline_event(
            visit_id=visit_id,
            event_type="department_change",
            data={
                "from": from_department,
                "to": to_department
            }
        )

        # 3. Enqueue patient in next department
        await enqueue(
            visit_id=visit_id,
            department_id=to_department,
            source_department_id=from_department
        )

        # 4. Update visit current department
        visit = await Visit.get(visit_id)
        visit.current_department_id = to_department
        await visit.save()

        # 5. Send notification to patient
        await send_communication(
            patient_id=visit.patient_id,
            channel="whatsapp",
            template="routed_to_department",
            data={
                "department_name": department_name,
                "token": new_token,
                "wait_time": estimated_wait
            }
        )
```

---

## 5. CONDITION EVALUATOR

```python
class ConditionEvaluator:
    """
    Evaluates workflow routing conditions against visit context.
    Supports simple rule-based conditions.
    """

    async def evaluate(self, condition: str, visit: Visit) -> bool:
        """
        Evaluate a condition string against visit data.
        Example conditions:
        - "first_visit"
        - "symptoms.chest_pain"
        - "prescription.medicines.length > 0"
        - "ecg_result.abnormal"
        - "age > 60"
        """
        # Parse condition
        # Simple key lookup or comparison
        if "." in condition:
            # Nested key lookup
            parts = condition.split(".")
            value = visit.context
            for part in parts:
                if "(" in part:
                    # Function call (e.g., length > 0)
                    func = part.split("(")[0]
                    if func == "length":
                        return len(value) > 0
                value = value.get(part)
            return bool(value)

        # Direct key lookup
        return bool(visit.context.get(condition, False))
```

---

## 6. VISIT STATE MACHINE

```
                    ┌─────────────┐
                    │  REGISTERED │
                    └──────┬──────┘
                           │
                     enqueue(reception)
                           │
                           ▼
                    ┌─────────────┐
              ┌────│ IN_PROGRESS │────┐
              │    └──────┬──────┘    │
              │           │           │
         department    workflow    all done?
         completed     routed      check
              │           │           │
              ▼           ▼           ▼
        ┌─────────┐ ┌─────────┐ ┌─────────┐
        │ WAITING │ │NEXT DEPT│ │COMPLETED│
        │ NEXT    │ │  QUEUED │ │   ✅    │
        └─────────┘ └─────────┘ └─────────┘
```

---

## 7. PATIENT TIMELINE (Universal)

Every workflow step generates a timeline event visible to patient, doctor, and staff:

```json
{
  "visit_id": "uuid",
  "events": [
    {
      "timestamp": "2026-07-09T09:00:00Z",
      "type": "registration",
      "department": "Reception",
      "status"
