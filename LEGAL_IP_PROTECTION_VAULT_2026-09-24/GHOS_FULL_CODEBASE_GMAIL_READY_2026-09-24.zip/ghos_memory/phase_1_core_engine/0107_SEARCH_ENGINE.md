---
file_id: "0107"
module_name: "Search Engine"
version: "1.0"
status: "Draft"
phase: "Phase 1 — Core Engine"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: []
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "search", "patient-search", "fulltext", "trigram", "meilisearch"]
---

# 🔍 GHOS — Search Engine

> **The Search Engine provides fast, fuzzy search across patients, visits, prescriptions, and reports. It uses PostgreSQL full-text search and trigram similarity for most queries, with Meilisearch as an optional dedicated search index for high-volume deployments.**

---

## 1. PURPOSE

The Search Engine answers: **"Find all records matching this query across the hospital."**

It handles:
- **Patient lookup** — Find patients by name, mobile, ID, or any combination
- **Visit history** — Search past visits by patient, date range, or department
- **Clinical records** — Full-text search across reports, prescriptions, and notes
- **Quick lookup** — Instant mobile number search for reception
- **Autocomplete** — Typeahead suggestions for patient names
- **Fuzzy matching** — Handle typos, partial names, and transliterations

---

## 2. SEARCH TIERS

GHOS uses a three-tier search strategy:

```
Tier 1: Redis Cache ( < 5ms )
  - Mobile number exact match
  - Recent patient lookups (last 1000)
  - Active patient IDs

Tier 2: PostgreSQL ( 5-50ms )
  - Patient name by trigram similarity
  - Visit history by date range
  - Report metadata searches
  - Phone number partial match

Tier 3: Meilisearch (Optional, 10-30ms )
  - Full-text search across all documents
  - Prescription content search
  - Report interpretation search
  - Cross-hospital searches (SaaS)
```

---

## 3. TIER 1: REDIS CACHE

```python
class QuickLookupCache:
    """
    Ultra-fast patient lookup cache.
    
    Cached data:
    - patient:{mobile} → patient_id, name, active_visit_id
    - recent_searches:{hospital_id} → last 1000 search queries
    - active_patients:{department_id} → currently waiting patients
    """
    
    CACHE_TTL = 3600  # 1 hour
    MAX_RECENT = 1000
    
    def __init__(self):
        self.redis = RedisPool()
    
    async def lookup_by_mobile(self, mobile: str) -> Optional[dict]:
        """Instant lookup by mobile number. Returns cached patient summary."""
        key = f"patient_mobile:{mobile}"
        data = await self.redis.get(key)
        if data:
            return json.loads(data)
        
        # Cache miss — fetch from DB and cache
        patient = await Patient.filter(mobile=mobile).first()
        if not patient:
            return None
        
        result = {
            "id": str(patient.id),
            "name": patient.name,
            "mobile": patient.mobile,
            "active_visit": str(patient.active_visit_id) if patient.active_visit_id else None
        }
        await self.redis.setex(key, self.CACHE_TTL, json.dumps(result))
        return result
    
    async def cache_patient(self, patient: Patient):
        """Cache/update a patient record after registration or update."""
        key = f"patient_mobile:{patient.mobile}"
        data = {
            "id": str(patient.id),
            "name": patient.name,
            "mobile": patient.mobile,
            "active_visit": str(patient.active_visit_id) if patient.active_visit_id else None
        }
        await self.redis.setex(key, self.CACHE_TTL, json.dumps(data))
        
        # Also cache by ID for fast lookups
        id_key = f"patient_id:{patient.id}"
        await self.redis.setex(id_key, self.CACHE_TTL, json.dumps(data))
    
    async def add_recent_search(self, hospital_id: UUID, query: str):
        """Add query to recent searches list (ring buffer)."""
        key = f"recent_searches:{hospital_id}"
        await self.redis.lpush(key, query)
        await self.redis.ltrim(key, 0, self.MAX_RECENT - 1)
        await self.redis.expire(key, 86400)  # 24h TTL
    
    async def get_recent_searches(self, hospital_id: UUID, limit: int = 10) -> List[str]:
        """Get recent search queries for autocomplete suggestions."""
        key = f"recent_searches:{hospital_id}"
        return await self.redis.lrange(key, 0, limit - 1)
```

---

## 4. TIER 2: POSTGRESQL SEARCH

### 4.1 Patient Search (Trigram)

PostgreSQL's `pg_trgm` extension provides fuzzy string matching. The similarity threshold is set to 0.3 for lenient matching.

```python
class PatientSearch:
    """
    Patient search with fuzzy name matching and mobile partial match.
    
    Search strategies:
    1. Exact mobile match (fastest)
    2. Partial mobile match (contains)
    3. Trigram name similarity (fuzzy)
    4. Combined name + mobile
    """
    
    SIMILARITY_THRESHOLD = 0.3
    
    async def search(
        self,
        query: str,
        hospital_id: UUID,
        limit: int = 20,
        include_inactive: bool = False
    ) -> List[PatientResult]:
        """Search patients by name or mobile."""
        # 1. Try exact mobile match first
        digits = re.sub(r'[^\d]', '', query)
        if len(digits) >= 10:
            patients = await self._exact_mobile_search(digits, hospital_id, limit)
            if patients:
                return patients
        
        # 2. Try partial mobile match
        if len(digits) >= 4:
            patients = await self._partial_mobile_search(digits, hospital_id, limit)
            if patients:
                return patients
        
        # 3. Trigram fuzzy name search
        return await self._fuzzy_name_search(query, hospital_id, limit, include_inactive)
    
    async def _exact_mobile_search(self, mobile: str, hospital_id, limit) -> List[PatientResult]:
        """Search by exact mobile number (with or without country code)."""
        patients = await Patient.filter(
            hospital_id=hospital_id,
            mobile__endswith=mobile  # Handles +91 prefix variations
        ).limit(limit).all()
        return [self._to_result(p) for p in patients]
    
    async def _partial_mobile_search(self, digits: str, hospital_id, limit) -> List[PatientResult]:
        """Search by partial mobile number (last 4+ digits)."""
        patients = await Patient.raw(
            """
            SELECT * FROM patients
            WHERE hospital_id = $1
            AND REPLACE(mobile, '+', '') LIKE $2
            ORDER BY
                CASE WHEN mobile LIKE $3 THEN 0 ELSE 1 END,
                created_at DESC
            LIMIT $4
            """,
            hospital_id, f"%{digits}%", f"%{digits}"
        )
        return [self._to_result(p) for p in patients]
    
    async def _fuzzy_name_search(
        self, query: str, hospital_id, limit, include_inactive
    ) -> List[PatientResult]:
        """Fuzzy name search using PostgreSQL trigram similarity."""
        # Normalize query
        query = query.strip().lower()
        
        # Build search condition
        conditions = ["hospital_id = $1"]
        params = [hospital_id]
        
        # Trigram similarity for fuzzy matching
        conditions.append(f"similarity(LOWER(name), $2) > {self.SIMILARITY_THRESHOLD}")
        params.append(query)
        
        if not include_inactive:
            conditions.append("active = true")
        
        where_clause = " AND ".join(conditions)
        
        patients = await Patient.raw(
            f"""
            SELECT *,
                   similarity(LOWER(name), $2) AS relevance
            FROM patients
            WHERE {where_clause}
            ORDER BY relevance DESC,
                     CASE WHEN LOWER(name) LIKE $3 THEN 0 ELSE 1 END,
                     last_visit_at DESC NULLS LAST
            LIMIT $4
            """,
            *params,
            f"{query}%",
            limit
        )
        return [self._to_result(p) for p in patients]
    
    async def autocomplete(
        self, query: str, hospital_id: UUID, limit: int = 8
    ) -> List[dict]:
        """Typeahead autocomplete — returns lightweight results for dropdown."""
        patients = await Patient.raw(
            """
            SELECT id, name, mobile
            FROM patients
            WHERE hospital_id = $1
              AND (
                LOWER(name) LIKE $2
                OR mobile LIKE $3
              )
            ORDER BY
              CASE WHEN LOWER(name) LIKE $2 THEN 0 ELSE 1 END,
              last_visit_at DESC NULLS LAST
            LIMIT $4
            """,
            hospital_id,
            f"{query.lower()}%",
            f"%{query}%",
            limit
        )
        return [
            {"id": str(p.id), "name": p.name, "mobile": p.mobile, "label": f"{p.name} ({p.mobile[-4:]})"}
            for p in patients
        ]
    
    def _to_result(self, patient) -> PatientResult:
        return PatientResult(
            id=str(patient.id),
            name=patient.name,
            mobile=patient.mobile,
            last_visit=patient.last_visit_at.isoformat() if patient.last_visit_at else None,
            active=patient.active,
            department=patient.current_department
        )
```

### 4.2 Visit History Search

```python
class VisitSearch:
    """Search visit history by date range, department, doctor, or status."""
    
    async def search(
        self,
        patient_id: UUID = None,
        hospital_id: UUID = None,
        date_from: date = None,
        date_to: date = None,
        department_id: UUID = None,
        doctor_id: UUID = None,
        status: str = None,
        limit: int = 50,
        offset: int = 0
    ) -> SearchResult:
        """Search visit records with filters."""
        query = Visit.filter()
        
        if patient_id:
            query = query.filter(patient_id=patient_id)
        if hospital_id:
            query = query.filter(hospital_id=hospital_id)
        if date_from:
            query = query.filter(created_at__gte=date_from)
        if date_to:
            query = query.filter(created_at__lte=date_to + timedelta(days=1))
        if department_id:
            query = query.filter(department_id=department_id)
        if doctor_id:
            query = query.filter(doctor_id=doctor_id)
        if status:
            query = query.filter(status=status)
        
        total = await query.count()
        visits = await query.order_by("-created_at").offset(offset).limit(limit).all()
        
        return SearchResult(
            total=total,
            limit=limit,
            offset=offset,
            results=[self._visit_to_dict(v) for v in visits]
        )
    
    async def recent_visits(
        self, patient_id: UUID, limit: int = 5
    ) -> List[dict]:
        """Get recent visits for a patient (timeline view)."""
        visits = await Visit.filter(
            patient_id=patient_id
        ).order_by("-created_at").limit(limit).prefetch_related(
            "department", "doctor"
        ).all()
        
        return [
            {
                "id": str(v.id),
                "date": v.created_at.isoformat(),
                "department": v.department.name if v.department else None,
                "doctor": v.doctor.name if v.doctor else None,
                "status": v.status,
                "diagnosis": v.diagnosis[:100] if v.diagnosis else None
            }
            for v in visits
        ]
```

### 4.3 Clinical Record Search

```python
class ClinicalSearch:
    """
    Full-text search across clinical records.
    
    Uses PostgreSQL tsvector/tsquery for:
    - Report interpretations (ECG, Echo, Lab)
    - Prescription notes
    - Doctor's clinical notes
    - Diagnosis descriptions
    """
    
    async def search(
        self,
        query: str,
        hospital_id: UUID,
        patient_id: UUID = None,
        document_type: str = None,  # report, prescription, note
        limit: int = 20
    ) -> List[SearchHit]:
        """
        Full-text search across all clinical documents.
        
        Uses PostgreSQL text search with:
        - english and simple configurations
        - Ranking by ts_rank
        - Highlighting with ts_headline
        """
        results = []
        
        # Search reports
        if not document_type or document_type == "report":
            report_results = await self._search_reports(query, hospital_id, patient_id, limit)
            results.extend(report_results)
        
        # Search prescriptions
        if not document_type or document_type == "prescription":
            rx_results = await self._search_prescriptions(query, hospital_id, patient_id, limit)
            results.extend(rx_results)
        
        # Sort by relevance and return top results
        results.sort(key=lambda r: r.relevance, reverse=True)
        return results[:limit]
    
    async def _search_reports(self, query, hospital_id, patient_id, limit):
        return await Report.raw(
            """
            SELECT r.id, r.type, r.interpretation,
                   p.name AS patient_name,
                   ts_rank(
                       to_tsvector('english', COALESCE(r.interpretation, '')),
                       plainto_tsquery('english', $1)
                   ) AS relevance,
                   ts_headline('english', r.interpretation, plainto_tsquery('english', $1),
                               'MaxWords=30, MinWords=15, StartSel=**>, StopSel=<**') AS highlight
            FROM reports r
            JOIN patients p ON p.id = r.patient_id
            WHERE r.hospital_id = $2
              AND ($3::uuid IS NULL OR r.patient_id = $3)
              AND to_tsvector('english', COALESCE(r.interpretation, '')) @@ plainto_tsquery('english', $1)
            ORDER BY relevance DESC
            LIMIT $4
            """,
            query, hospital_id, patient_id, limit
        )
    
    async def _search_prescriptions(self, query, hospital_id, patient_id, limit):
        # Similar to _search_reports but for prescriptions table
        ...
```

---

## 5. TIER 3: MEILISEARCH (Optional)

For high-volume deployments or cross-document search, Meilisearch provides sub-50ms full-text search across millions of documents.

```python
class MeilisearchIndex:
    """Optional dedicated search index using Meilisearch."""
    
    def __init__(self):
        self.client = MeilisearchClient(settings.MEILISEARCH_URL, settings.MEILISEARCH_API_KEY)
        self.indexes = {
            "patients": {
                "primary_key": "id",
                "searchable": ["name", "mobile", "email"],
                "filterable": ["hospital_id", "active"],
                "sortable": ["last_visit_at", "created_at"]
            },
            "visits": {
                "primary_key": "id",
                "searchable": ["diagnosis", "notes"],
                "filterable": ["hospital_id", "patient_id", "department_id", "status"],
                "sortable": ["created_at"]
            },
            "reports": {
                "primary_key": "id",
                "searchable": ["interpretation", "summary"],
                "filterable": ["hospital_id", "patient_id", "type"],
                "sortable": ["created_at"]
            }
        }
    
    async def sync_patient(self, patient: Patient):
        """Index or update a patient record."""
        index = self.client.index("patients")
        await index.add_documents([{
            "id": str(patient.id),
            "name": patient.name,
            "mobile": patient.mobile,
            "email": patient.email or "",
            "hospital_id": str(patient.hospital_id),
            "active": patient.active,
            "last_visit_at": int(patient.last_visit_at.timestamp()) if patient.last_visit_at else 0,
            "created_at": int(patient.created_at.timestamp())
        }])
    
    async def search_patients(self, query: str, hospital_id: UUID, limit: int = 20):
        """Search patients using Meilisearch."""
        index = self.client.index("patients")
        results = await index.search(query, {
            "filter": f"hospital_id = {hospital_id}",
            "limit": limit,
            "sort": ["last_visit_at:desc"]
        })
        return results.hits
    
    async def fulltext_search(self, query: str, hospital_id: UUID, limit: int = 20):
        """Search across all indexes (patients, visits, reports)."""
        results = {"patients": [], "visits": [], "reports": []}
        
        for index_name, config in self.indexes.items():
            index = self.client.index(index_name)
            try:
                hits = await index.search(query, {
                    "filter": f"hospital_id = {hospital_id}",
                    "limit": limit // 3
                })
                results[index_name] = hits.hits
            except Exception as e:
                logger.error(f"Meilisearch {index_name} error: {e}")
        
        return results
```

---

## 6. SEARCH API

```python
# FastAPI Search Routes

@router.get("/api/v1/search/patients")
async def search_patients(
    q: str = Query(..., min_length=2),
    hospital_id: UUID = Header(...),
    limit: int = Query(20, le=100),
    include_inactive: bool = False
):
    """Search patients by name or mobile number."""
    engine = PatientSearch()
    results = await engine.search(q, hospital_id, limit, include_inactive)
    return {"query": q, "total": len(results), "results": [r.dict() for r in results]}


@router.get("/api/v1/search/autocomplete")
async def autocomplete(
    q: str = Query(..., min_length=1),
    hospital_id: UUID = Header(...)
):
    """Typeahead autocomplete for patient names."""
    engine = PatientSearch()
    results = await engine.autocomplete(q, hospital_id)
    return {"suggestions": results}


@router.get("/api/v1/search/visits")
async def search_visits(
    patient_id: UUID = None,
    hospital_id: UUID = Header(...),
    date_from: date = None,
    date_to: date = None,
    department_id: UUID = None,
    doctor_id: UUID = None,
    status: str = None,
    limit: int = 50,
    offset: int = 0
):
    """Search visit history with filters."""
    engine = VisitSearch()
    return await engine.search(
        patient_id=patient_id,
        hospital_id=hospital_id,
        date_from=date_from,
        date_to=date_to,
        department_id=department_id,
        doctor_id=doctor_id,
        status=status,
        limit=limit,
        offset=offset
    )


@router.get("/api/v1/search/clinical")
async def search_clinical_records(
    q: str = Query(..., min_length=3),
    hospital_id: UUID = Header(...),
    patient_id: UUID = None,
    document_type: str = None
):
    """Full-text search across clinical documents."""
    engine = ClinicalSearch()
    results = await engine.search(q, hospital_id, patient_id, document_type)
    return {"query": q, "total": len(results), "results": [r.dict() for r in results]}
```

---

## 7. DATABASE SCHEMA & INDEXES

```sql
-- Enable extensions
CREATE EXTENSION IF NOT EXISTS pg_trgm;
CREATE EXTENSION IF NOT EXISTS unaccent;

-- Trigram indexes for fuzzy search
CREATE INDEX idx_patients_name_trgm ON patients
    USING GIN (LOWER(name) gin_trgm_ops);

CREATE INDEX idx_patients_mobile_trgm ON patients
    USING GIN (mobile gin_trgm_ops);

-- Full-text search indexes
CREATE INDEX idx_reports_fts ON reports
    USING GIN (to_tsvector('english', COALESCE(interpretation, '')));

CREATE INDEX idx_prescriptions_fts ON prescriptions
    USING GIN (to_tsvector('english', COALESCE(notes, '')));

-- Standard B-tree indexes for filtered search
CREATE INDEX idx_patients_hospital_active ON patients(hospital_id, active);
CREATE INDEX idx_patients_last_visit ON patients(last_visit_at DESC);
CREATE INDEX idx_visits_patient_date ON visits(patient_id, created_at DESC);
CREATE INDEX idx_visits_hospital_date ON visits(hospital_id, created_at DESC);
CREATE INDEX idx_visits_department ON visits(hospital_id, department_id, status);

-- Unaccent dictionary for diacritic-insensitive search
CREATE TEXT SEARCH CONFIGURATION simple_unaccent (COPY = simple);
ALTER TEXT SEARCH CONFIGURATION simple_unaccent
    ALTER MAPPING FOR hword, hword_part, word
    WITH unaccent, simple;
```

---

## 8. SEARCH RESULT FORMAT

```json
{
  "query": "raj",
  "total": 3,
  "limit": 20,
  "offset": 0,
  "results": [
    {
      "id": "550e8400-e29b-41d4-a716-446655440000",
      "name": "Rajesh Kumar",
      "mobile": "+919876543210",
      "last_visit": "2026-07-08T10:30:00",
      "active": true,
      "department": "Cardiology",
      "relevance": 0.85,
      "highlight": "**Raj**esh Kumar"
    },
    {
      "id": "550e8400-e29b-41d4-a716-446655440001",
      "name": "Rajendra Singh",
      "mobile": "+919876543211",
      "last_visit": "2026-07-05T14:20:00",
      "active": false,
      "department": null,
      "relevance": 0.72,
      "highlight": "**Raj**endra Singh"
    }
  ],
  "facets": {
    "active": {"true": 1, "false": 2},
    "department": {"Cardiology": 1, "Orthopedics": 1, "General": 1}
  }
}
```

---

## 9. PERFORMANCE OPTIMIZATIONS

| Technique | Benefit |
|-----------|---------|
| Trigram GIN index | 10-50x faster fuzzy name matching |
| Redis cache for mobile | < 5ms for reception's most common query |
| Partial match first | Mobile search returns instantly if last 4+ digits match |
| Query normalization | Strip diacritics, lowercase, remove extra spaces |
| Result limiting | Never return more than 100 results per query |
| Pagination | Cursor-based for large result sets |
| Relevance scoring | Trigram similarity + recency + exact prefix match |
| Materialized view | Pre-computed search index for very large hospitals (>100k patients) |

### Materialized View for Large Deployments

```sql
CREATE MATERIALIZED VIEW patient_search_view AS
SELECT
    p.id,
    p.name,
    p.mobile,
    p.email,
    p.hospital_id,
    p.active,
    p.last_visit_at,
    p.created_at,
    to_tsvector('simple_unaccent', COALESCE(p.name, '')) ||
    to_tsvector('simple', COALESCE(p.mobile, '')) AS search_vector
FROM patients p;

CREATE INDEX idx_patient_search_fts ON patient_search_view
    USING GIN (search_vector);

REFRESH MATERIALIZED VIEW CONCURRENTLY patient_search_view;
```

---

## 10. ERROR HANDLING

| Error | Cause | Fallback |
|-------|-------|----------|
| Meilisearch unavailable | Service down | Fall back to PostgreSQL search |
| Trigram index missing | Extension not created | Use LIKE '%query%' (slower) |
| Search timeout | Complex query, large dataset | Reduce limit, simplify query |
| Empty results | No matches | Suggest "Did you mean...?" using trigram |
| Too many results | Query too short (< 2 chars) | Require min 2 characters |

---

## 11. CONFIGURATION

```yaml
search:
  postgresql:
    trigram_threshold: 0.3
    max_results: 100
    min_query_length: 2
    autocomplete_min_length: 1
  
  redis_cache:
    patient_ttl_seconds: 3600
    recent_searches_ttl: 86400
    max_recent_searches: 1000
  
  meilisearch:
    enabled: false
    url: "http://localhost:7700"
    api_key: "${MEILISEARCH_KEY}"
    sync_interval_seconds: 60
  
  features:
    autocomplete: true
    fuzzy_search: true
    fulltext_search: true
    phonenumber_search: true
```

---

## 12. KEY DESIGN DECISIONS

1. **PostgreSQL-first** — No external dependency required for basic search. Meilisearch is purely optional.
2. **Trigram over full-text for names** — Indian names vary wildly in spelling. Trigram similarity handles transliteration variations (Raj/Rajesh/Raju/Rajendra).
3. **Cache by mobile** — The most common search at reception is "find patient by mobile number." Redis makes this instant.
4. **Progressive enhancement** — Redis → PostgreSQL → Meilisearch. Each tier adds capability without breaking the previous.
5. **Fuzzy by default** — No exact-match-only searches. Even mobile search uses `contains` to handle prefix/variations.
6. **Search is read-only** — No search operation ever modifies data. Safe to use anywhere.
7. **Highlight results** — Show why a result matched using `ts_headline` or Meilisearch's built-in highlighting.

