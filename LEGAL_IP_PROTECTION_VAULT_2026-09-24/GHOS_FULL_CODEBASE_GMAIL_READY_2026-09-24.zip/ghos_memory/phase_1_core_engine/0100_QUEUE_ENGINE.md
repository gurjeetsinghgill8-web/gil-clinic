---
file_id: "0100"
module_name: "Queue Engine"
version: "1.0"
status: "Approved"
phase: "Phase 1 — Core Engine"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["0101_WORKFLOW_ENGINE.md", "0102_TOKEN_ENGINE.md"]
last_updated: "2026-07-09"
priority: "Critical"
ai_tags: ["ghos", "queue-engine", "core", "algorithm", "heart"]
---

# ⚙️ GHOS — Queue Engine

> **This is the single most important component in GHOS. Everything else connects to it.**

---

## 1. PURPOSE

The Queue Engine manages the lifecycle of every patient's visit through every department. It answers three questions:
1. **Who is next?** — Dequeue logic
2. **How long?** — Wait time prediction
3. **Where next?** — Multi-department routing

---

## 2. QUEUE DATA STRUCTURE

Each department maintains an independent queue:

```
Department Queue (Redis Sorted Set):
  Key: queue:{hospital_id}:{department_id}:{date}
  Score: priority_score (lower = earlier)
  Value: queue_entry_id (UUID)

Queue Entry (PostgreSQL):
  id: UUID
  visit_id: UUID → visits.id
  department_id: UUID → departments.id
  token_number: integer
  status: enum(waiting, called, in_progress, completed, skipped)
  priority: integer (0=normal, 1=senior, 2=emergency, 3=VIP)
  entered_at: timestamp
  called_at: timestamp (nullable)
  completed_at: timestamp (nullable)
  estimated_wait_seconds: integer
```

---

## 3. CORE ALGORITHMS

### 3.1 Enqueue (Adding a Patient)

```python
async def enqueue(
    visit_id: UUID,
    department_id: UUID,
    priority: int = 0,
    source_department_id: Optional[UUID] = None
) -> QueueEntry:
    """
    Add a patient to a department queue.
    Returns the queue entry with token number and estimated wait.
    """
    # 1. Generate token number (sequential per department per day)
    token = await generate_token(department_id)

    # 2. Calculate initial priority score
    #    Priority score = (priority * 1000) + token_number
    #    Lower score = earlier in queue
    priority_score = (priority * 1000) + token

    # 3. Create queue entry in PostgreSQL
    entry = await QueueEntry.create(
        visit_id=visit_id,
        department_id=department_id,
        token_number=token,
        status="waiting",
        priority=priority,
        priority_score=priority_score,
        entered_at=datetime.utcnow()
    )

    # 4. Add to Redis sorted set
    await redis.zadd(
        f"queue:{department_id}:{today()}",
        {str(entry.id): priority_score}
    )

    # 5. Calculate estimated wait time
    wait_time = await calculate_wait_time(department_id, priority_score)

    # 6. Publish WebSocket event
    await publish_event("queue.entry_added", {
        "department_id": department_id,
        "entry_id": entry.id,
        "token": token,
        "wait_time": wait_time
    })

    # 7. If patient was in another department, mark previous as completed
    if source_department_id:
        await complete_queue_entry(visit_id, source_department_id)

    return entry
```

### 3.2 Dequeue (Calling Next Patient)

```python
async def dequeue(department_id: UUID) -> Optional[QueueEntry]:
    """
    Get the next patient from the department queue.
    Returns the highest-priority (lowest score) waiting patient.
    """
    # 1. Get minimum score entry from Redis
    entries = await redis.zpopmin(
        f"queue:{department_id}:{today()}",
        1  # Get 1 entry with lowest score
    )

    if not entries:
        return None

    entry_id = entries[0][0]  # (member, score) tuple

    # 2. Fetch full entry from PostgreSQL
    entry = await QueueEntry.get(entry_id)

    # 3. Validate entry is still valid
    if entry.status != "waiting":
        # Someone else already called this patient, get next
        return await dequeue(department_id)

    # 4. Update status to "called"
    entry.status = "called"
    entry.called_at = datetime.utcnow()
    await entry.save()

    # 5. Publish WebSocket event
    await publish_event("queue.patient_called", {
        "department_id": department_id,
        "entry_id": entry.id,
        "token": entry.token_number,
        "visit_id": entry.visit_id
    })

    return entry
```

### 3.3 Wait Time Calculation

```python
async def calculate_wait_time(
    department_id: UUID,
    new_entry_score: Optional[int] = None
) -> int:
    """
    Calculate estimated wait time in seconds for a department.
    Formula: (ahead_count * avg_service_time) - elapsed_time_of_current
    """
    # 1. Get all waiting entries ahead of this one
    if new_entry_score:
        ahead_count = await redis.zcount(
            f"queue:{department_id}:{today()}",
            0,  # min score
            new_entry_score - 1  # max score (entries with lower score)
        )
    else:
        ahead_count = await redis.zcard(
            f"queue:{department_id}:{today()}"
        )

    # 2. Get average service time for this department (configurable)
    avg_time = await get_avg_service_time(department_id)  # seconds

    # 3. Get elapsed time of current patient
    current = await get_current_patient(department_id)
    elapsed = 0
    if current:
        elapsed = (datetime.utcnow() - current.called_at).seconds

    # 4. Adjust if current is taking longer than average
    delay_penalty = max(0, elapsed - avg_time)

    # 5. Calculate
    wait = (ahead_count * avg_time) + delay_penalty

    # 6. Store for real-time display
    await redis.setex(
        f"waittime:{department_id}", 60,  # cache for 60 seconds
        wait
    )

    return wait
```

---

## 4. PRIORITY SYSTEM

| Priority Level | Value | Score Addition | Who Can Set |
|---------------|-------|----------------|-------------|
| Normal | 0 | 0 | Auto (default) |
| Senior Citizen (60+) | 1 | +1000 | Reception |
| Emergency | 2 | +2000 | Doctor/Reception |
| VIP | 3 | +3000 | Admin |
| Staff Family | 0 | -100 (preferred) | Admin |

Priority-based reordering happens dynamically. If a VIP arrives, they get inserted ahead of normal patients.

---

## 5. DELAY DETECTION

```python
async def check_delays(department_id: UUID):
    """
    Check if a department is running behind schedule.
    Triggers alerts if delay exceeds thresholds.
    """
    current = await get_current_patient(department_id)
    if not current:
        return

    avg_time = await get_avg_service_time(department_id)
    elapsed = (datetime.utcnow() - current.called_at).seconds
    waiting_count = await redis.zcard(f"queue:{department_id}:{today()}")

    delay = elapsed - avg_time

    if delay > 300:  # 5 minutes delayed
        await publish_event("queue.delay_alert", {
            "department_id": department_id,
            "delay_minutes": delay // 60,
            "waiting_count": waiting_count,
            "severity": "warning" if delay < 600 else "critical"
        })

        # Notify admin/manager
        await notify_admins(
            f"⚠️ {department_name} is {delay//60} min behind schedule. "
            f"{waiting_count} patients waiting."
        )
```

---

## 6. QUEUE STATUS FLOW

```
                ┌──────────┐
                │ WAITING  │
                └────┬─────┘
                     │
              dequeue() called
                     │
                     ▼
                ┌──────────┐
       ┌───────│  CALLED  │────────┐
       │       └────┬─────┘        │
       │            │              │
   skip()      start_test()    no_show()
       │            │              │
       ▼            ▼              ▼
  ┌────────┐  ┌───────────┐  ┌──────────┐
  │SKIPPED │  │IN_PROGRESS│  │NO_SHOW   │
  └────────┘  └─────┬─────┘  └──────────┘
                    │
              complete_test()
                    │
                    ▼
              ┌───────────┐
              │ COMPLETED │───→ Route to next dept or finish
              └───────────┘
```

---

## 7. REDIS KEYS SCHEMA

