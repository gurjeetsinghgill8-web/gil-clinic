---
file_id: "1000"
module_name: "Multi-Hospital Architecture"
version: "1.0"
status: "Draft"
phase: "Phase 10 — SaaS"
dependencies: ["0004_SYSTEM_ARCHITECTURE.md"]
related_files: ["1001_MULTI_BRANCH.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "saas", "multi-tenant", "hospital", "schema-per-tenant"]
---

# GHOS — Multi-Hospital Architecture

> **One codebase, many hospitals. Data is sacred — tenants are isolated at the schema level. Each hospital's data exists in its own PostgreSQL schema, invisible to every other tenant. Shared services run on shared tables. The boundary between shared and isolated is enforced at every layer.**

---

## 1. TENANCY MODEL

GHOS uses **schema-per-tenant** isolation in a shared PostgreSQL database. Each hospital (tenant) gets its own PostgreSQL schema. All tenant schemas share the same table definitions but store data in physically separate namespaces.

### 1.1 Why Schema-Per-Tenant (Not Database-Per-Tenant or Row-Level)

| Approach | Pros | Cons | Verdict |
|----------|------|------|---------|
| Database-per-tenant | Strongest isolation, separate backups | 100+ databases = connection pool chaos, migration nightmare, expensive | Rejected — operational overhead at hospital scale |
| Schema-per-tenant | Good isolation, single connection pool, easy migrations, cross-tenant analytics possible | Slightly weaker isolation than separate DB | **Selected** — best balance for 100-1000 hospitals |
| Row-level (tenant_id column) | Simplest, no schema management | Accidental cross-tenant leaks, massive tables, hard to QOS | Rejected — insufficient isolation for healthcare PHI |

### 1.2 Connection Pooling with Dynamic search_path

All tenant traffic flows through a single connection pool (PgBouncer/PgCat). The tenant schema is resolved at the application layer using PostgreSQL's `search_path`:

```python
import asyncpg
from typing import Optional

class TenantAwarePool:
    """Connection pool that sets search_path per connection."""

    def __init__(self, dsn: str, pool_size: int = 20):
        self.pool = None
        self.dsn = dsn
        self.pool_size = pool_size

    async def init(self):
        self.pool = await asyncpg.create_pool(
            self.dsn, min_size=5, max_size=self.pool_size
        )

    async def acquire(self, schema_name: str) -> asyncpg.Connection:
        conn = await self.pool.acquire()
        await conn.execute(f"SET search_path TO {schema_name}, public")
        return conn

    async def release(self, conn: asyncpg.Connection):
        await self.pool.release(conn)
```

Every query automatically resolves tables to the correct schema. The `public` schema holds shared tables (tenants, plans, audit_log_shared).

### 1.3 Tenant Resolution Middleware

Every request goes through a middleware that resolves the tenant identity and attaches it to the request context:

```
Request --> DomainParser --> TenantResolver --> SchemaSelector --> TenantAwarePool
```

---

## 2. ARCHITECTURE DIAGRAM

```
                              INTERNET
                                 |
                        +--------v---------+
                        |   Load Balancer   |
                        |  (ALB / Nginx)    |
                        +--------+---------+
                                 |
                        +--------v---------+
                        |   API Gateway     |
                        |  (Traefik/Kong)   |
                        +--------+---------+
                                 |
                        +--------v---------+
                        | Tenant Resolver   |
                        |  Middleware        |
                        |                   |
                        |  Resolves tenant  |
                        |  from:            |
                        |   - subdomain     |
                        |   - custom domain |
                        |   - X-Tenant-ID   |
                        |   - JWT claim     |
                        +--------+---------+
                                 |
                        +--------v---------+
                        | Schema Selector   |
                        |                   |
                        |  Looks up schema  |
                        |  from tenant_id   |
                        |  in shared cache  |
                        |  (Redis)          |
                        +--------+---------+
                                 |
                        +--------v---------+
                        |   Application     |
                        |   Services        |
                        |                   |
                        |  Auth | Queue |   |
                        |  Patient | Billing|
                        |  AI | Analytics   |
                        +--------+---------+
                                 |
                 +---------------+---------------+
                 |               |               |
        +--------v------+  +----v--------+  +---v---------+
        | PostgreSQL     |  | Redis       |  | S3 / MinIO  |
        |                |  |             |  |             |
        | public schema  |  | tenant_id:  |  | tenant_id/  |
        |   - tenants    |  |   key       |  |   prefix    |
        |   - plans      |  +-------------+  +-------------+
        |   - audit_log  |
        |                |
        | tenant_1       |
        |   - patients   |
        |   - queue      |
        |   - visits     |
        |   - invoices   |
        |                |
        | tenant_2       |
        |   - patients   |
        |   - queue      |
        |   - visits     |
        |   - invoices   |
        +----------------+
```

---

## 3. SCHEMA MANAGEMENT

### 3.1 Tenant Creation Flow

When a new hospital signs up, the `SchemaManager.create_tenant()` function orchestrates the full provisioning pipeline:

1. Create hospital record in `public.tenants` table
2. Generate tenant_id (UUID v4)
3. `CREATE SCHEMA IF NOT EXISTS tenant_{tenant_id}`
4. Clone schema from template (run all DDL against the new schema)
5. Record migration version in `public.tenant_migrations`
6. Insert default configuration in `public.tenant_config`
7. Configure S3 prefix: `s3://ghos-data/{tenant_id}/`
8. Seed default roles and permissions (hospital-specific)
9. Warm Redis cache with tenant routing info
10. Return tenant_id + schema_name to caller

```python
class SchemaManager:
    """Manages tenant schema lifecycle."""

    def __init__(self, pool: TenantAwarePool, redis_client):
        self.pool = pool
        self.redis = redis_client

    async def create_tenant(self, hospital_data: dict) -> dict:
        tenant_id = str(uuid.uuid4())
        schema_name = f"tenant_{tenant_id.replace('-', '_')}"
        conn = await self.pool.acquire("public")
        try:
            async with conn.transaction():
                # 1. Create tenant record
                await conn.execute(
                    """INSERT INTO public.tenants (id, schema_name, name, domain,
                       status, config)
                       VALUES ($1, $2, $3, $4, 'active', $5)""",
                    tenant_id, schema_name, hospital_data["name"],
                    hospital_data.get("domain"), json.dumps({})
                )
                # 2. Create schema
                await conn.execute(f"CREATE SCHEMA IF NOT EXISTS {schema_name}")
                # 3. Clone from template
                await self._clone_template_schema(conn, schema_name)
                await self._record_migration(conn, tenant_id, schema_name)
                await self._seed_default_data(conn, schema_name, hospital_data)
        finally:
            await self.pool.release(conn)
        self._warm_tenant_cache(tenant_id, schema_name)
        return {"tenant_id": tenant_id, "schema_name": schema_name}

    async def _clone_template_schema(self, conn, schema_name: str):
        """Execute the full DDL template against the new schema."""
        template_sql = self._load_template_schema()
        modified_sql = template_sql.replace("__SCHEMA__", schema_name)
        await conn.execute(modified_sql)
```

### 3.2 Template Schema

A `_template` schema exists in the database that always reflects the latest DDL. When a new tenant is created, the template is cloned using:

```sql
CREATE SCHEMA IF NOT EXISTS tenant_{id};
CREATE TABLE tenant_{id}.patients (LIKE _template.patients INCLUDING ALL);
CREATE TABLE tenant_{id}.queue (LIKE _template.queue INCLUDING ALL);
-- ... all other tenant-scoped tables
```

Alternatively, use pg_dump / pg_restore for the schema-only clone on first creation.

### 3.3 Alembic Migration Strategy

Every migration must be run against ALL tenant schemas plus the public schema. We use Alembic with a custom migration runner:

```python
# alembic/env.py
from alembic import context

def run_migrations_online():
    """Run migrations for public schema, then every tenant schema."""
    conn = engine.connect()

    # 1. Migrate public schema
    conn.execute("SET search_path TO public")
    context.configure(connection=conn, target_metadata=target_metadata)
    context.run_migrations()

    # 2. Migrate each tenant schema
    tenant_schemas = conn.execute(
        "SELECT schema_name FROM public.tenants WHERE status = 'active'"
    ).fetchall()
    for row in tenant_schemas:
        conn.execute(f"SET search_path TO {row.schema_name}")
        context.configure(connection=conn, target_metadata=target_metadata)
        context.run_migrations()

    conn.close()
```

Migration tracking uses the standard `alembic_version` table per schema. The `public.tenant_migrations` table also records which migration version each tenant is on, enabling per-tenant rollback if needed.

### 3.4 Per-Tenant Rollback

If a migration fails on one tenant, only that tenant is rolled back (not all tenants). The `SchemaManager` maintains a migration log:

```sql
-- In public schema
CREATE TABLE tenant_migrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    migration_version VARCHAR(50) NOT NULL,
    applied_at TIMESTAMPTZ DEFAULT NOW(),
    status VARCHAR(20) NOT NULL CHECK (status IN ('success', 'failed', 'rolled_back')),
    duration_ms INTEGER,
    error_message TEXT
);
```

---

## 4. TENANT RESOLUTION

### 4.1 Resolution Strategies (Priority Order)

| Method | Source | Priority | Example | Use Case |
|--------|--------|----------|---------|----------|
| Subdomain | Host header | 1 | `hospital-a.ghos.in` | Default SaaS access |
| Custom Domain | Host header | 2 | `clinic.example.com` | White-label customers |
| X-Tenant-ID | HTTP header | 3 | `X-Tenant-ID: t_abc123` | API integrations |
| JWT Claim | JWT payload | 4 | `{"tenant_id": "t_abc123"}` | Authenticated sessions |

### 4.2 Domain Resolution Logic

```python
from fastapi import Request, HTTPException
import re

TENANT_DOMAIN_PATTERN = re.compile(r"^([a-z0-9-]+)\.ghos\.in$")

class TenantResolver:
    """Resolve tenant identity from incoming request."""

    def __init__(self, redis_client, db_pool):
        self.redis = redis_client
        self.db_pool = db_pool

    async def resolve(self, request: Request) -> dict:
        """Returns tenant_id, schema_name, and config for the tenant."""
        tenant_id = None

        # Method 1: X-Tenant-ID header (for API keys)
        tenant_id = request.headers.get("X-Tenant-ID")
        if tenant_id:
            return await self._lookup_tenant(tenant_id)

        # Method 2: Subdomain (hospital-a.ghos.in)
        host = request.headers.get("host", "")
        match = TENANT_DOMAIN_PATTERN.match(host)
        if match:
            subdomain = match.group(1)
            tenant_id = await self._resolve_subdomain(subdomain)
            if tenant_id:
                return await self._lookup_tenant(tenant_id)

        # Method 3: Custom domain (CNAME lookup)
        tenant_id = await self._resolve_custom_domain(host)
        if tenant_id:
            return await self._lookup_tenant(tenant_id)

        # Method 4: JWT claim (from Authorization header)
        token = request.headers.get("Authorization", "").replace("Bearer ", "")
        if token:
            tenant_id = await self._extract_from_jwt(token)
            if tenant_id:
                return await self._lookup_tenant(tenant_id)

        raise HTTPException(status_code=401, detail="Tenant not resolved")

    async def _lookup_tenant(self, tenant_id: str) -> dict:
        """Fetch tenant info from cache or DB."""
        cache_key = f"tenant:{tenant_id}"
        cached = await self.redis.get(cache_key)
        if cached:
            return json.loads(cached)
        conn = await self.db_pool.acquire("public")
        try:
            row = await conn.fetchrow(
                "SELECT id, schema_name, config FROM public.tenants WHERE id = $1",
                tenant_id
            )
            if not row:
                raise HTTPException(status_code=404, detail="Tenant not found")
            result = {
                "tenant_id": str(row["id"]),
                "schema_name": row["schema_name"],
                "config": row["config"]
            }
            await self.redis.setex(cache_key, 300, json.dumps(result))
            return result
        finally:
            await self.db_pool.release(conn)
```

### 4.3 Tenant Domain Registration

```sql
CREATE TABLE public.tenant_domains (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    domain VARCHAR(255) NOT NULL UNIQUE,
    domain_type VARCHAR(20) NOT NULL CHECK (domain_type IN ('subdomain', 'custom', 'api')),
    is_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    ssl_provisioned BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, domain)
);
```

Custom domain verification uses DNS TXT record challenge (similar to Let's Encrypt or AWS Certificate Manager):

```python
async def verify_custom_domain(tenant_id: str, domain: str):
    """Verify domain ownership via DNS TXT record."""
    verification_token = secrets.token_hex(16)
    await db.execute(
        "UPDATE public.tenant_domains SET verification_token = $1 WHERE domain = $2",
        verification_token, domain
    )
    # Expected: TXT record at _ghos-verify.{domain} = {verification_token}
    # Admin creates this record in their DNS, then calls verification endpoint
```

---

## 5. DATA ISOLATION

### 5.1 Database Isolation (Defense in Depth)

| Layer | Mechanism | Description |
|-------|-----------|-------------|
| L1 Schema isolation | PostgreSQL schema namespace | Tables physically in separate schemas — `tenant_1.patients` vs `tenant_2.patients` |
| L2 search_path | Controlled per-connection | Application explicitly sets `search_path` — cross-schema queries require explicit schema prefix |
| L3 Row Security Policies | Optional defense-in-depth | `ALTER TABLE tenant_{id}.patients ENABLE ROW LEVEL SECURITY` with policy matching tenant_id |
| L4 Application guard | Tenant filter in ORM | Every query includes `hospital_id = current_tenant.id` even within schema |
| L5 Audit | Cross-schema query detection | Log queries that touch multiple schemas, alert on unexpected cross-schema patterns |

### 5.2 Cross-Tenant Query Prevention

```sql
-- RLS policy on every tenant table (defense in depth)
ALTER TABLE tenant_abc123.patients ENABLE ROW LEVEL SECURITY;
CREATE POLICY tenant_isolation ON tenant_abc123.patients
    USING (true);  -- RLS alone doesn't isolate schemas; schema isolation is L1

-- Proactive detection: log table accesses across schemas
CREATE EXTENSION IF NOT EXISTS pgaudit;
SELECT set_config('pgaudit.log', 'write,function,role', true);
```

The real isolation is L1 (schema namespaces). RLS is a safety net for application bugs.

### 5.3 S3 Prefix Isolation

Each tenant gets a dedicated S3 prefix (virtual folder). IAM policies restrict access to only the tenant's prefix:

```json
{
    "Version": "2012-10-17",
    "Statement": [
        {
            "Effect": "Allow",
            "Action": ["s3:GetObject", "s3:PutObject"],
            "Resource": "arn:aws:s3:::ghos-data/${tenant_id}/*"
        }
    ]
}
```

Presigned URLs are scoped to the tenant prefix. No tenant can list or access another tenant's files.

### 5.4 Redis Key Prefix Isolation

All Redis keys are prefixed with the tenant ID:

```
tenant_id:queue:patient_123          -- queue tokens
tenant_id:session:user_456           -- user sessions
tenant_id:perm:user_789              -- cached permissions
tenant_id:counter:sms_daily          -- usage counters
```

Redis runs in a shared instance. The key prefix convention is enforced at the application level by the `TenantAwareCache` wrapper:

```python
class TenantAwareCache:
    def __init__(self, redis_client, tenant_id: str):
        self.redis = redis_client
        self.prefix = f"{tenant_id}:"

    async def get(self, key: str):
        return await self.redis.get(self.prefix + key)

    async def setex(self, key: str, ttl: int, value):
        await self.redis.setex(self.prefix + key, ttl, value)
```

---

## 6. WHITE-LABEL

### 6.1 Configurable Per-Tenant Settings

Each tenant can customize their instance. Settings are stored as JSONB in the `tenants.config` column:

```json
{
    "branding": {
        "logo_url": "https://cdn.ghos.in/tenant_abc/logo.png",
        "favicon_url": "https://cdn.ghos.in/tenant_abc/favicon.ico",
        "primary_color": "#2563EB",
        "secondary_color": "#1E40AF",
        "accent_color": "#F59E0B",
        "font_family": "Inter, sans-serif",
        "hospital_name": "Apollo Health City",
        "tagline": "Caring for you"
    },
    "email": {
        "sender_name": "Apollo Health City",
        "sender_email": "noreply@apolloclinic.com",
        "logo_in_email": true,
        "custom_templates": {
            "appointment_reminder": "template_apollo_1",
            "prescription": "template_apollo_2"
        }
    },
    "sms": {
        "sender_id": "APOLLO",
        "dlt_template_id": "1207161234567890123"
    },
    "dashboard": {
        "default_theme": "light",
        "show_analytics": true,
        "custom_css_url": null,
        "widget_order": ["queue", "appointments", "revenue", "inventory"]
    },
    "features": {
        "enable_ai_receptionist": false,
        "enable_whatsapp": true,
        "enable_multi_branch": false,
        "max_branches": 1
    }
}
```

### 6.2 Custom Domain Provisioning Flow

1. Hospital admin adds custom domain in settings: `clinic.example.com`
2. System generates verification token and displays DNS setup instructions
3. Admin creates CNAME record: `clinic.example.com -> hospital-a.ghos.in`
4. Admin creates TXT record: `_ghos-verify.clinic.example.com -> {token}`
5. Admin clicks "Verify" in dashboard
6. System checks DNS, marks domain as verified
7. System provisions SSL certificate (Let's Encrypt / ACM)
8. CLB/ALB is updated with the new domain
9. Domain is ready. All branding (logo, colors) is fetched from tenant config

---

## 7. SHARED VS ISOLATED SERVICES

| Service | Strategy | Schema | Details |
|---------|----------|--------|---------|
| **Auth** (admin login) | Shared | public | `public.users` table — GHOS-level admin accounts for cross-tenant management. Hospital staff login uses tenant schema. |
| **Plans** | Shared | public | `public.plans`, `public.subscriptions` — plan definitions and subscription status for all tenants |
| **Analytics** | Hybrid | Both | Per-tenant aggregations in tenant schema. Cross-tenant rollups in `public.analytics_rollups` |
| **Audit Log** | Hybrid | Both | Per-tenant audit in tenant schema. Cross-tenant audit in `public.audit_log_shared` for SIEM ingestion |
| **Billing** | Shared | public | Invoice records, payment transactions in `public.invoices`. Each invoice references tenant_id. |
| **Support Tickets** | Shared | public | `public.support_tickets` — tenant_id scoped |

---

## 8. DATABASE SCHEMAS

### 8.1 Shared Schema (public)

```sql
-- ============================================================
-- TENANTS
-- ============================================================
CREATE TABLE public.tenants (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    schema_name VARCHAR(100) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    slug VARCHAR(100) UNIQUE NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'suspended', 'archived')),
    config JSONB NOT NULL DEFAULT '{}',
    plan_id UUID REFERENCES public.plans(id),
    subscription_id UUID REFERENCES public.subscriptions(id),
    trial_ends_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- ============================================================
-- TENANT DOMAINS
-- ============================================================
CREATE TABLE public.tenant_domains (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id) ON DELETE CASCADE,
    domain VARCHAR(255) NOT NULL UNIQUE,
    domain_type VARCHAR(20) NOT NULL CHECK (domain_type IN ('subdomain', 'custom', 'api')),
    is_verified BOOLEAN DEFAULT FALSE,
    verification_token VARCHAR(100),
    ssl_provisioned BOOLEAN DEFAULT FALSE,
    verified_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, domain)
);

-- ============================================================
-- TENANT MIGRATIONS (version tracking)
-- ============================================================
CREATE TABLE public.tenant_migrations (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES public.tenants(id),
    migration_version VARCHAR(50) NOT NULL,
    migration_name VARCHAR(255),
    applied_by VARCHAR(100),
    applied_at TIMESTAMPTZ DEFAULT NOW(),
    duration_ms INTEGER,
    status VARCHAR(20) NOT NULL CHECK (status IN ('success', 'failed', 'rolled_back')),
    error_message TEXT
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE UNIQUE INDEX idx_tenants_slug ON public.tenants(slug);
CREATE UNIQUE INDEX idx_tenants_domain ON public.tenants(domain) WHERE domain IS NOT NULL;
CREATE INDEX idx_tenant_domains_verified ON public.tenant_domains(domain, is_verified);
CREATE INDEX idx_tenant_migrations_tenant ON public.tenant_migrations(tenant_id, applied_at DESC);
```

### 8.2 Per-Schema Tables (Template)

Every tenant schema contains the same set of tables. Key tables include:

```sql
-- Tenant schema: patients
CREATE TABLE {schema}.patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL,  -- equals the tenant's hospital_id
    name VARCHAR(255) NOT NULL,
    phone VARCHAR(15),
    email VARCHAR(255),
    aadhaar_hash VARCHAR(64),
    date_of_birth DATE,
    gender VARCHAR(10),
    address TEXT,
    blood_group VARCHAR(5),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tenant schema: queue
CREATE TABLE {schema}.queue (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    token_number INTEGER NOT NULL,
    branch_id UUID,
    department_id UUID,
    patient_id UUID REFERENCES {schema}.patients(id),
    status VARCHAR(20) DEFAULT 'waiting',
    priority VARCHAR(10) DEFAULT 'normal',
    called_at TIMESTAMPTZ,
    completed_at TIMESTAMPTZ,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Tenant schema: appointments
CREATE TABLE {schema}.appointments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID REFERENCES {schema}.patients(id),
    doctor_id UUID,
    branch_id UUID,
    department_id UUID,
    appointment_date DATE NOT NULL,
    time_slot VARCHAR(20),
    status VARCHAR(20) DEFAULT 'scheduled',
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## 9. PYTHON IMPLEMENTATION

### 9.1 TenantResolver (Middleware)

```python
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware
import json

class TenantMiddleware(BaseHTTPMiddleware):
    """Resolves tenant context for every request and attaches to request.state."""

    def __init__(self, app, redis_client, db_pool):
        super().__init__(app)
        self.resolver = TenantResolver(redis_client, db_pool)

    async def dispatch(self, request: Request, call_next):
        tenant = await self.resolver.resolve(request)
        request.state.tenant = tenant
        request.state.db = TenantAwarePool(request.state.db_pool)
        request.state.cache = TenantAwareCache(request.state.redis, tenant["tenant_id"])
        response = await call_next(request)
        return response
```

### 9.2 SchemaManager

```python
class SchemaManager:
    """Full lifecycle management for tenant schemas."""

    async def create_tenant(self, hospital_data: dict) -> dict:
        """Provision a new tenant: schema, seed data, S3 prefix, cache warm."""
        ...

    async def deactivate_tenant(self, tenant_id: str):
        """Set tenant to archived, retain data for 90 days."""
        ...

    async def delete_tenant(self, tenant_id: str):
        """DROP SCHEMA after retention period. Irreversible."""
        ...

    async def run_migration(self, tenant_id: str, migration_version: str):
        """Run a specific migration on a single tenant schema."""
        ...

    async def clone_from_template(self, src_tenant_id: str, dst_tenant_id: str):
        """Clone one tenant's schema to another (for enterprise sandbox)."""
        ...

    async def get_migration_status(self, tenant_id: str) -> list:
        """Return all migrations applied to a tenant."""
        ...

    async def verify_schema_integrity(self, tenant_id: str) -> dict:
        """Compare tenant schema DDL against template schema."""
        ...
```

### 9.3 TenantAwareSession (FastAPI Dependency)

```python
from fastapi import Depends, Request

async def get_tenant_db(request: Request):
    """FastAPI dependency — yields a connection scoped to the request's tenant."""
    pool = request.state.db_pool
    tenant = request.state.tenant
    conn = await pool.acquire(tenant["schema_name"])
    try:
        yield conn
    finally:
        await pool.release(conn)

async def get_tenant_cache(request: Request):
    """FastAPI dependency — yields a tenant-prefixed cache client."""
    return request.state.cache
```

---

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Isolation model | Schema-per-tenant | Stronger than row-level, simpler than DB-per-tenant. Good for 100-1000 tenants. |
| Connection pooling | Single pool with search_path | One pool to manage. No per-tenant connection overhead. search_path routing is fast. |
| Tenant resolution | Middleware | Single point of enforcement. Every request resolved once. No forgotten tenant checks. |
| Migration strategy | Alembic per-schema | Standard tooling. Rollback one tenant without affecting others. |
| White-label config | JSONB in tenants table | Flexible. No schema changes for new branding fields. Indexed for query. |
| S3 isolation | Prefix-based + IAM | Standard AWS pattern. Audit-friendly. No per-tenant bucket limits. |
| Cache isolation | Key prefix | Simple. Shared Redis instance. No separate cluster per tenant. |
| Cross-tenant analytics | Public schema rollups | ETL job reads tenant schemas, writes to public.analytics_rollups. No direct cross-tenant query at runtime. |

---

## 11. OPERATIONAL PLAYBOOK

### 11.1 Adding a New Tenant

```bash
# 1. API call to provision
curl -X POST https://api.ghos.in/admin/tenants \
  -H "Authorization: Bearer {super_admin_token}" \
  -d '{"name": "Apollo Health City", "domain": "apollo.ghos.in", "plan": "pro"}'

# 2. System response (auto-provisioned)
{
  "tenant_id": "abc123...",
  "schema_name": "tenant_abc123",
  "domain": "apollo.ghos.in",
  "status": "active",
  "provisioning_time_ms": 2450
}
```

### 11.2 Deleting a Tenant

1. Set `tenants.status = 'archived'` — data preserved for 90-day retention
2. Revoke all access tokens and API keys
3. Remove custom DNS entries from load balancer
4. After 90 days, run `DROP SCHEMA tenant_xxx CASCADE`
5. Clean up S3 prefix, Redis keys

### 11.3 Migrating All Tenants

```bash
# Run Alembic migration across all schemas
alembic upgrade head          # Uses custom env.py that iterates schemas

# Monitor progress in tenant_migrations table
SELECT migration_version, COUNT(*), status FROM public.tenant_migrations
GROUP BY migration_version, status;
```
