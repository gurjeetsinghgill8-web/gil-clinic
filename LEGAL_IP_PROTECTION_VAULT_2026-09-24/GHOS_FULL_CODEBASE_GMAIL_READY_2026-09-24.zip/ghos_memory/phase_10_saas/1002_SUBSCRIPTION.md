---
file_id: "1002"
module_name: "Subscription Module"
version: "1.0"
status: "Draft"
phase: "Phase 10 — SaaS"
dependencies: ["1000_MULTI_HOSPITAL.md"]
related_files: ["1003_BILLING_PLAN.md", "1004_USAGE_LIMIT.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "subscription", "pricing", "plans", "tiers", "saas"]
---

# GHOS — Subscription Module

> **Every hospital starts free. They upgrade as they grow. The subscription system gates features, meters usage, handles billing, and manages the complete subscription lifecycle from trial to cancellation — without ever losing their data.**

---

## 1. SUBSCRIPTION TIERS

### 1.1 Detailed Feature Comparison

| Feature | Free | Pro (Rs 999/mo/branch) | Enterprise (Custom) |
|---------|------|------------------------|---------------------|
| Patient Registration | Unlimited | Unlimited | Unlimited |
| Queue Management | Basic (single queue) | Multi-department queue | All features |
| Patient Tracking | Basic | Advanced (history, charts) | Full clinical analytics |
| Basic Dashboard | Yes | Yes | Yes |
| Advanced Analytics | No | Basic dashboards | Custom dashboards, BI export |
| Multi-Branch | 1 branch | Up to 3 branches | Unlimited branches |
| WhatsApp Notifications | No | 500/mo | Unlimited |
| SMS Notifications | No | 100/mo | Unlimited |
| Email Notifications | Yes (transactional) | Yes (transactional + campaign) | Yes (unlimited) |
| Billing & Invoicing | No (manual) | Yes (GST invoices, POS) | Yes (full accounting suite) |
| AI Receptionist | No | No | Yes (unlimited calls) |
| White-Label | No | No | Yes (custom domain, branding) |
| Staff Accounts | Up to 10 | Up to 50 | Unlimited |
| Inventory Management | Basic (10 items) | Full catalog | Unlimited + warehouse mgmt |
| API Access | No | Rate-limited (1000/day) | Unlimited |
| Data Export | Manual CSV | Automated CSV | API + SFTP + BI tools |
| Storage | 100 MB | 1 GB | 10 GB base (expandable) |
| Support | Community | Email (24hr response) | Priority (1hr), dedicated manager |
| SLA | None | 99.5% uptime | 99.9% uptime |

### 1.2 Add-On Modules

| Add-On | Price | Included In |
|--------|-------|-------------|
| AI Receptionist | Rs 2,000/mo | Enterprise (unlimited) |
| SMS Pack (1000) | Rs 250/mo | Pro (partial) |
| WhatsApp Pack (1000) | Rs 300/mo | Pro (partial) |
| Extra Storage (1 GB) | Rs 100/mo | All tiers |
| Extra Branch (Pro) | Rs 999/mo/branch | Pro only |
| API Rate Boost (10K/day) | Rs 500/mo | Pro + Enterprise |
| SMS Sender ID Registration | Rs 2,500 (one-time) | All tiers |

### 1.3 Pricing Model

- **Free**: Rs 0 (forever, no credit card required)
- **Pro**: Rs 999/mo per branch (first branch included in base price)
- **Enterprise**: Custom pricing (contact sales)

**Yearly Discount**: 2 months free on yearly billing = pay for 10 months.

**Volume Discounts**:
| Branches | Discount |
|----------|----------|
| 1-4 | None (Rs 999/branch) |
| 5-10 | 10% off (Rs 899/branch) |
| 11-20 | 15% off (Rs 849/branch) |
| 21+ | 20% off (Rs 799/branch) |

---

## 2. SUBSCRIPTION LIFECYCLE

### 2.1 State Machine

```
                    +---> Trial (14 days)
                    |         |
                    |         v (convert at any time)
                    |      Active
                    |         |
                    |    +----+----+
                    |    |         |
                    |    v         v
                    | Past Due  Upgrade/Downgrade
                    | (3 day     (immediate or
                    |  grace)     end-of-cycle)
                    |    |
                    |    v (after 3 days)
                    | Suspended
                    |    |
                    |    v (end of billing period)
                    | Cancelled
                    |    |
                    |    v (after 90 days)
                    +-- Data Archived
```

### 2.2 Lifecycle States

| State | Description | Actions Allowed | Data Access |
|-------|-------------|-----------------|-------------|
| **Trial** | 14-day free Pro access | All Pro features | Full |
| **Active** | Paid subscription | As per plan | Full |
| **Past Due** | Payment failed, 3-day grace | All features, warning banner | Full |
| **Suspended** | Payment failed after 3 days | Read-only, no new actions | Read-only |
| **Canceled** | Canceled, end of billing period | Read-only export | Read-only |
| **Expired** | Canceled + 90 days past | Sign-up new plan | Archived (contact support) |
| **Data Archived** | Data moved to cold storage | None | Reactivation possible within 2 years |

### 2.3 Subscription Record

```sql
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    plan_id UUID NOT NULL REFERENCES plans(id),
    status VARCHAR(20) NOT NULL DEFAULT 'trial'
        CHECK (status IN ('trial', 'active', 'past_due', 'suspended', 'canceled', 'expired')),
    branch_count INTEGER NOT NULL DEFAULT 1,
    billing_cycle VARCHAR(10) NOT NULL DEFAULT 'monthly'
        CHECK (billing_cycle IN ('monthly', 'yearly')),
    current_period_start DATE NOT NULL,
    current_period_end DATE NOT NULL,
    trial_start DATE,
    trial_end DATE,
    canceled_at TIMESTAMPTZ,
    canceled_reason VARCHAR(100),
    auto_renew BOOLEAN DEFAULT TRUE,
    grace_end TIMESTAMPTZ,
    payment_gateway VARCHAR(20),
    gateway_subscription_id VARCHAR(255),
    gateway_customer_id VARCHAR(255),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

---

## 3. PRICING ENGINE

### 3.1 Price Calculation

```python
class PricingEngine:
    """Calculates subscription prices with discounts and promotions."""

    BASE_PRICES = {
        "pro_monthly": 999,
        "pro_yearly": 9990,   # 999 * 10 (2 months free)
    }

    VOLUME_DISCOUNTS = [
        (1, 0.0),      # 0% discount
        (5, 0.10),     # 10% discount for 5+ branches
        (11, 0.15),    # 15% discount for 11+ branches
        (21, 0.20),    # 20% discount for 21+ branches
    ]

    ADDON_PRICES = {
        "ai_receptionist": 2000,
        "sms_pack_1000": 250,
        "whatsapp_pack_1000": 300,
        "extra_storage_gb": 100,
        "extra_branch_pro": 999,
    }

    def calculate_price(self, plan_slug: str, branch_count: int,
                        billing_cycle: str, addons: list = None,
                        promo_code: str = None) -> dict:
        base_key = f"{plan_slug}_{billing_cycle}"
        unit_price = self.BASE_PRICES.get(base_key, 0)

        # Base price for first branch
        total = unit_price

        # Additional branches at branch pricing
        extra_branches = max(0, branch_count - 1)
        branch_price = self.ADDON_PRICES.get("extra_branch_pro", unit_price)
        total += extra_branches * branch_price

        # Volume discount
        discount_pct = 0
        for threshold, disc in reversed(self.VOLUME_DISCOUNTS):
            if branch_count >= threshold:
                discount_pct = disc
                break
        discount_amount = total * discount_pct
        total -= discount_amount

        # Add-ons
        addon_total = 0
        if addons:
            for addon in addons:
                addon_total += self.ADDON_PRICES.get(addon["slug"], 0) * addon.get("quantity", 1)
        total += addon_total

        # Promo code
        if promo_code:
            promo = self._validate_promo_code(promo_code)
            if promo:
                if promo["type"] == "percentage":
                    total -= total * (promo["value"] / 100)
                elif promo["type"] == "fixed":
                    total -= promo["value"]

        # GST
        gst = round(total * 0.18, 2)
        grand_total = total + gst

        return {
            "subtotal": round(total, 2),
            "branches": branch_count,
            "volume_discount_percent": discount_pct * 100,
            "volume_discount_amount": round(discount_amount, 2),
            "addon_total": round(addon_total, 2),
            "promo_applied": bool(promo_code),
            "gst_18": gst,
            "grand_total": grand_total,
            "billing_cycle": billing_cycle,
            "monthly_effective": round(grand_total / 12, 2) if billing_cycle == "yearly" else grand_total
        }

    def _validate_promo_code(self, code: str) -> dict:
        """Validate and return promo code details from DB."""
        ...
```

---

## 4. BILLING INTEGRATION

### 4.1 Payment Gateway Support

| Gateway | Mode | Supported Features |
|---------|------|--------------------|
| Razorpay | Primary (India) | Recurring subscriptions, invoices, payment links, UPI, cards, netbanking |
| Stripe | Secondary (International) | Recurring, invoices, payment intents |

### 4.2 Razorpay Integration

```python
import razorpay
from datetime import datetime

class RazorpayBilling:
    """Handle Razorpay subscription lifecycle."""

    def __init__(self, key_id: str, key_secret: str):
        self.client = razorpay.Client(auth=(key_id, key_secret))

    async def create_subscription(self, tenant_id: str, plan_id: str,
                                   branch_count: int, billing_cycle: str) -> dict:
        # Calculate price via PricingEngine
        price = PricingEngine().calculate_price("pro", branch_count, billing_cycle)

        # Create Razorpay subscription
        subscription_data = {
            "plan_id": plan_id,  # Razorpay plan ID
            "total_count": 12 if billing_cycle == "monthly" else 1,
            "quantity": 1,
            "customer_notify": True,
            "notes": {
                "tenant_id": tenant_id,
                "branch_count": str(branch_count)
            }
        }
        subscription = self.client.subscription.create(subscription_data)
        return {
            "gateway_subscription_id": subscription["id"],
            "short_url": subscription["short_url"],
            "status": subscription["status"]
        }

    async def handle_webhook(self, payload: dict, signature: str) -> str:
        """Process Razorpay webhook events."""
        self.client.utility.verify_webhook_signature(
            json.dumps(payload), signature, self.webhook_secret
        )
        event = payload["event"]
        if event == "subscription.charged":
            await self._handle_successful_charge(payload["payload"])
        elif event == "payment.failed":
            await self._handle_failed_payment(payload["payload"])
        elif event == "subscription.cancelled":
            await self._handle_cancellation(payload["payload"])
        return "ok"
```

### 4.3 Invoice Generation

```python
class InvoiceGenerator:
    """Generate GST-compliant invoices for subscription charges."""

    async def generate_invoice(self, subscription_id: UUID, period_start: date,
                                 period_end: date) -> dict:
        sub = await self._get_subscription(subscription_id)
        tenant = await self._get_tenant(sub["tenant_id"])
        price = PricingEngine().calculate_price(
            "pro", sub["branch_count"], sub["billing_cycle"]
        )

        invoice = {
            "invoice_number": await self._next_invoice_number(),
            "tenant_id": sub["tenant_id"],
            "tenant_name": tenant["name"],
            "tenant_gst": tenant.get("gst_number", ""),
            "subscription_id": subscription_id,
            "period_start": period_start.isoformat(),
            "period_end": period_end.isoformat(),
            "line_items": [
                {"description": f"GHOS Pro ({sub['branch_count']} branch{'es' if sub['branch_count'] > 1 else ''})",
                 "quantity": 1, "unit_price": price["subtotal"], "amount": price["subtotal"]}
            ],
            "subtotal": price["subtotal"],
            "gst_percent": 18,
            "gst_amount": price["gst_18"],
            "total": price["grand_total"],
            "currency": "INR",
            "status": "pending",
            "due_date": period_start.isoformat(),
            "created_at": datetime.utcnow().isoformat()
        }

        # Generate PDF
        pdf_bytes = await self._generate_pdf(invoice)
        # Upload to S3
        await self._upload_to_s3(f"invoices/{tenant['id']}/{invoice['invoice_number']}.pdf", pdf_bytes)
        # Save to DB
        invoice_id = await self._save_invoice(invoice)
        # Email to tenant
        await self._email_invoice(tenant["email"], invoice)

        return {"invoice_id": invoice_id, "invoice_number": invoice["invoice_number"]}
```

---

## 5. PLAN CHANGE

### 5.1 Upgrade/Downgrade Rules

| Change Type | Effective | Proration | Data Impact |
|-------------|-----------|-----------|-------------|
| Free -> Pro | Immediate | Full charge for remainder of billing period | All features unlocked immediately |
| Pro -> Enterprise | Immediate | Prorated credit applied, new rate starts | All features unlocked |
| Pro -> Free | End of billing period | No refund for partial period | Features restricted at end of period |
| Add add-on | Immediate | Prorated charge for remainder | Feature enabled immediately |
| Remove add-on | End of billing period | No refund | Feature available until period end |
| Increase branches | Immediate | Prorated charge for additional branches | New branches functional immediately |
| Decrease branches | End of billing period | No refund | Branches deactivated at period end |

### 5.2 Upgrade Flow

```python
class SubscriptionService:
    """Manage subscription changes and feature access."""

    async def upgrade_plan(self, tenant_id: UUID, new_plan_slug: str) -> dict:
        """Upgrade tenant to a higher plan. Takes effect immediately."""
        current_sub = await self._get_active_subscription(tenant_id)
        new_plan = await self._get_plan_by_slug(new_plan_slug)

        if not new_plan:
            raise ValueError("Invalid plan")
        if new_plan["price"] <= current_sub["plan_price"]:
            raise ValueError("New plan must have higher price for upgrade")

        prorated_credit = await self._calculate_prorated_credit(current_sub)
        new_price = new_plan["price"]

        # Charge the difference (prorated)
        charge_amount = max(0, new_price - prorated_credit)

        if charge_amount > 0:
            await self.billing.charge(tenant_id, charge_amount, "upgrade")

        # Update subscription
        await db.execute("""
            UPDATE subscriptions SET
                plan_id = $1,
                updated_at = NOW()
            WHERE tenant_id = $2 AND status = 'active'
        """, new_plan["id"], tenant_id)

        # Invalidate feature flag cache
        await self._invalidate_feature_cache(tenant_id)

        return {
            "old_plan": current_sub["plan_slug"],
            "new_plan": new_plan_slug,
            "prorated_credit": prorated_credit,
            "charged": charge_amount,
            "effective_immediately": True
        }

    async def downgrade_plan(self, tenant_id: UUID, new_plan_slug: str) -> dict:
        """Downgrade to lower plan. Takes effect at end of billing period."""
        current_sub = await self._get_active_subscription(tenant_id)
        new_plan = await self._get_plan_by_slug(new_plan_slug)

        if new_plan["price"] >= current_sub["plan_price"]:
            raise ValueError("New plan must have lower price for downgrade")

        # Schedule downgrade for end of period
        await db.execute("""
            UPDATE subscriptions SET
                scheduled_plan_id = $1,
                scheduled_change_at = current_period_end,
                updated_at = NOW()
            WHERE tenant_id = $2 AND status = 'active'
        """, new_plan["id"], tenant_id)

        return {
            "current_plan": current_sub["plan_slug"],
            "scheduled_plan": new_plan_slug,
            "effective_date": current_sub["current_period_end"].isoformat()
        }
```

---

## 6. TRIAL MANAGEMENT

### 6.1 Trial Rules

- Trial duration: 14 days with full Pro feature access
- Single trial per hospital (cannot restart trial after expiration)
- No credit card required to start trial
- Trial reminder: Day 10 (email + SMS): "Your trial ends in 4 days"
- Trial expiry: Day 14: Automatic downgrade to Free tier if not converted
- During trial conversion: Billing period starts from conversion date (not trial start)

### 6.2 Trial Enforcement

```python
async def enforce_trial(tenant_id: UUID) -> dict:
    sub = await get_subscription(tenant_id)
    if sub["status"] != "trial":
        return {"action": "none"}

    days_remaining = (sub["trial_end"] - date.today()).days

    if days_remaining < 0:
        # Trial expired — downgrade to Free
        await db.execute("""
            UPDATE subscriptions SET
                status = 'expired',
                plan_id = (SELECT id FROM plans WHERE slug = 'free'),
                updated_at = NOW()
            WHERE tenant_id = $1
        """, tenant_id)
        return {"action": "downgraded_to_free"}

    elif days_remaining <= 3:
        # Send reminder
        await send_trial_ending_notification(tenant_id, days_remaining)
        return {"action": "reminder_sent", "days_remaining": days_remaining}

    return {"action": "none", "days_remaining": days_remaining}
```

---

## 7. FEATURE GATING

### 7.1 FeatureFlag Service

```python
class FeatureFlagService:
    """Check if feature is available for current tenant's subscription."""

    FEATURE_PLAN_MAP = {
        "multi_branch":         ["pro", "enterprise"],
        "whatsapp":             ["pro", "enterprise"],
        "sms":                  ["pro", "enterprise"],
        "billing_invoicing":    ["pro", "enterprise"],
        "ai_receptionist":       ["enterprise"],
        "white_label":           ["enterprise"],
        "advanced_analytics":    ["enterprise"],
        "api_access":           ["pro", "enterprise"],
        "inventory_management": ["pro", "enterprise"],
        "data_export":          ["free", "pro", "enterprise"],
    }

    def __init__(self, redis_client):
        self.redis = redis_client
        self.cache_ttl = 60  # 1 minute — short TTL for fast plan changes

    async def check_access(self, tenant_id: UUID, feature: str) -> bool:
        """Check if a feature is available for the tenant."""
        cache_key = f"feature:{tenant_id}:{feature}"
        cached = await self.redis.get(cache_key)
        if cached is not None:
            return cached == "1"

        # Get current plan
        plan = await self._get_tenant_plan(tenant_id)
        allowed_plans = self.FEATURE_PLAN_MAP.get(feature, [])

        # Check add-on overrides
        if feature in await self._get_tenant_addons(tenant_id):
            await self.redis.setex(cache_key, self.cache_ttl, "1")
            return True

        has_access = plan["slug"] in allowed_plans
        await self.redis.setex(cache_key, self.cache_ttl, "1" if has_access else "0")
        return has_access

    async def require_feature(self, tenant_id: UUID, feature: str):
        """Raise HTTPException if feature not available (graceful)."""
        if not await self.check_access(tenant_id, feature):
            raise HTTPException(
                status_code=402,  # Payment Required
                detail={
                    "error": "feature_not_available",
                    "feature": feature,
                    "message": f"{feature.replace('_', ' ').title()} is not available on your plan.",
                    "upgrade_url": f"/settings/billing?upgrade=pro",
                    "graceful": True
                }
            )
```

### 7.2 Graceful Degradation

When a premium feature is blocked, the system shows an upgrade CTA instead of an error:

```python
async def get_ai_receptionist_response(tenant_id: UUID, message: str):
    feature = FeatureFlagService(redis)
    if not await feature.check_access(tenant_id, "ai_receptionist"):
        return {
            "type": "upgrade_required",
            "message": "AI Receptionist is an Enterprise feature.",
            "upgrade_cta": True,
            "fallback": "Please speak with a receptionist or upgrade to Enterprise."
        }
    # Proceed with AI call
    ...
```

---

## 8. DATABASE SCHEMAS

```sql
-- ============================================================
-- SUBSCRIPTION PLANS (plan definitions)
-- ============================================================
CREATE TABLE subscription_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(50) UNIQUE NOT NULL,         -- 'free', 'pro', 'enterprise'
    name VARCHAR(100) NOT NULL,
    description TEXT,
    price_monthly DECIMAL(10, 2) NOT NULL DEFAULT 0,
    price_yearly DECIMAL(10, 2) NOT NULL DEFAULT 0,
    branch_limit INTEGER DEFAULT 1,
    features JSONB NOT NULL DEFAULT '{}',      -- Feature flags
    limits JSONB NOT NULL DEFAULT '{}',        -- Usage limits
    sort_order INTEGER DEFAULT 0,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- SUBSCRIPTIONS (per-tenant subscription)
-- ============================================================
CREATE TABLE subscriptions (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    plan_id UUID NOT NULL REFERENCES subscription_plans(id),
    status VARCHAR(20) NOT NULL DEFAULT 'trial',
    branch_count INTEGER NOT NULL DEFAULT 1,
    billing_cycle VARCHAR(10) NOT NULL DEFAULT 'monthly',
    current_period_start DATE NOT NULL,
    current_period_end DATE NOT NULL,
    trial_start DATE,
    trial_end DATE,
    scheduled_plan_id UUID REFERENCES subscription_plans(id),
    scheduled_change_at DATE,
    canceled_at TIMESTAMPTZ,
    canceled_reason VARCHAR(100),
    auto_renew BOOLEAN DEFAULT TRUE,
    grace_end TIMESTAMPTZ,
    payment_gateway VARCHAR(20),
    gateway_subscription_id VARCHAR(255),
    gateway_customer_id VARCHAR(255),
    metadata JSONB DEFAULT '{}',
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- ADD-ONS (per-tenant add-on subscriptions)
-- ============================================================
CREATE TABLE addons (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    subscription_id UUID NOT NULL REFERENCES subscriptions(id),
    addon_slug VARCHAR(50) NOT NULL,
    quantity INTEGER NOT NULL DEFAULT 1,
    unit_price DECIMAL(10, 2) NOT NULL,
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'scheduled_removal', 'removed')),
    added_at TIMESTAMPTZ DEFAULT NOW(),
    removed_at TIMESTAMPTZ,
    UNIQUE(tenant_id, addon_slug, status)
);

-- ============================================================
-- INVOICES
-- ============================================================
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    subscription_id UUID REFERENCES subscriptions(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'paid', 'failed', 'refunded', 'cancelled')),
    period_start DATE,
    period_end DATE,
    line_items JSONB NOT NULL DEFAULT '[]',
    subtotal DECIMAL(12, 2) NOT NULL,
    gst_percent DECIMAL(5, 2) DEFAULT 18.00,
    gst_amount DECIMAL(12, 2) DEFAULT 0,
    discount_amount DECIMAL(12, 2) DEFAULT 0,
    total DECIMAL(12, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    gateway_payment_id VARCHAR(255),
    paid_at TIMESTAMPTZ,
    pdf_url VARCHAR(500),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- FEATURE FLAGS (runtime gating cache table)
-- ============================================================
CREATE TABLE feature_flags (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    feature_key VARCHAR(100) NOT NULL,
    is_enabled BOOLEAN NOT NULL DEFAULT FALSE,
    reason VARCHAR(255),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, feature_key)
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_subscriptions_tenant ON subscriptions(tenant_id);
CREATE INDEX idx_subscriptions_status ON subscriptions(status);
CREATE INDEX idx_subscriptions_gateway ON subscriptions(gateway_subscription_id);
CREATE INDEX idx_addons_subscription ON addons(subscription_id);
CREATE INDEX idx_invoices_tenant ON invoices(tenant_id);
CREATE INDEX idx_invoices_status ON invoices(status);
CREATE INDEX idx_feature_flags_tenant ON feature_flags(tenant_id);
```

---

## 9. PYTHON IMPLEMENTATION

### 9.1 SubscriptionService

```python
class SubscriptionService:
    """Core subscription management service."""

    def __init__(self, db_pool, redis_client, billing_service):
        self.db = db_pool
        self.redis = redis_client
        self.billing = billing_service
        self.feature_flags = FeatureFlagService(redis_client)

    async def check_access(self, tenant_id: UUID, feature: str) -> bool:
        return await self.feature_flags.check_access(tenant_id, feature)

    async def get_subscription(self, tenant_id: UUID) -> dict:
        """Get current subscription with plan details."""
        ...

    async def upgrade(self, tenant_id: UUID, new_plan_slug: str) -> dict:
        """Upgrade plan immediately."""
        ...

    async def downgrade(self, tenant_id: UUID, new_plan_slug: str) -> dict:
        """Schedule downgrade for end of billing period."""
        ...

    async def cancel(self, tenant_id: UUID, reason: str = None) -> dict:
        """Cancel subscription at end of billing period."""
        ...

    async def reactivate(self, tenant_id: UUID) -> dict:
        """Reactivate a canceled subscription within 90 days."""
        ...

    async def add_addon(self, tenant_id: UUID, addon_slug: str, quantity: int = 1) -> dict:
        """Add an add-on module."""
        ...

    async def remove_addon(self, tenant_id: UUID, addon_slug: str) -> dict:
        """Schedule add-on removal."""
        ...

    async def get_feature_summary(self, tenant_id: UUID) -> dict:
        """Return all feature access flags for UI rendering."""
        features = {}
        for feature in self.feature_flags.FEATURE_PLAN_MAP:
            features[feature] = await self.feature_flags.check_access(tenant_id, feature)
        return features

    def _calculate_prorated_credit(self, current_sub: dict) -> Decimal:
        """Calculate prorated credit for unused portion of current billing period."""
        days_in_period = (current_sub["current_period_end"] - current_sub["current_period_start"]).days
        days_used = (date.today() - current_sub["current_period_start"]).days
        daily_rate = current_sub["plan_price"] / days_in_period
        unused_days = max(0, days_in_period - days_used)
        return round(daily_rate * unused_days, 2)
```

### 9.2 BillingService

```python
class BillingService:
    """Handle payment processing, webhooks, and invoices."""

    def __init__(self, db_pool):
        self.db = db_pool
        self.invoice_gen = InvoiceGenerator()
        self.gateway = RazorpayBilling(
            settings.RAZORPAY_KEY_ID,
            settings.RAZORPAY_KEY_SECRET
        )

    async def create_invoice(self, subscription_id: UUID) -> dict:
        """Generate invoice for subscription period."""
        ...

    async def process_payment(self, invoice_id: UUID, payment_method: str) -> dict:
        """Process payment for an invoice."""
        ...

    async def handle_webhook(self, gateway: str, payload: dict, signature: str):
        """Route webhook to correct gateway handler."""
        if gateway == "razorpay":
            return await self._handle_razorpay_webhook(payload, signature)
        elif gateway == "stripe":
            return await self._handle_stripe_webhook(payload, signature)
        raise ValueError(f"Unknown gateway: {gateway}")

    async def refund(self, invoice_id: UUID, amount: Decimal = None, reason: str = None) -> dict:
        """Process a refund for an invoice."""
        ...
```

---

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Pricing model | Per-branch for Pro | Scales with hospital growth. Mirrors physical clinic expansion. |
| Yearly discount | 2 months free | Standard SaaS practice. Strong incentive for annual commitment. |
| Trial duration | 14 days | Long enough to evaluate, short enough to create urgency. |
| Trial enforcement | No credit card | Removes friction. Data lock-in is the real conversion driver. |
| Feature gating | Redis cache (60s TTL) | Fast checks, plan changes reflect within a minute. |
| Plan changes | Upgrade immediate, downgrade end-of-cycle | Prorated charges for upgrades. No loss of access mid-cycle for downgrades. |
| Free tier | Forever (limited features) | Always-on conversion funnel. Zero-risk onboarding. |
| Data on cancel | 90-day retention with reactivation option | Regulatory requirement (medical records). Also a conversion opportunity. |

---

## 11. SCHEDULED JOBS

| Job | Frequency | Description |
|-----|-----------|-------------|
| Trial expiry check | Daily at 00:00 IST | Downgrade expired trials to Free, send reminders |
| Subscription renewal | Daily at 02:00 IST | Process upcoming renewals for next 3 days |
| Invoice generation | Daily at 04:00 IST | Generate invoices for subscriptions starting today |
| Dunning process | Daily at 06:00 IST | Handle failed payments: email -> SMS -> suspend |
| Plan change execution | Daily at 00:00 IST | Execute scheduled downgrades and add-on removals |
| Data archive cleanup | Weekly (Sunday 03:00 IST) | Archive data for subscriptions expired > 90 days |
| Usage reset | Daily at 00:00 IST | Reset daily usage counters for all tenants |
