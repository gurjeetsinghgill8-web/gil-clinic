---
file_id: "1003"
module_name: "Billing Plan Management"
version: "1.0"
status: "Draft"
phase: "Phase 10 — SaaS"
dependencies: ["1002_SUBSCRIPTION.md"]
related_files: ["1004_USAGE_LIMIT.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "billing", "plan", "saas", "razorpay", "stripe", "invoice"]
---

# GHOS — Billing Plan Management

> **Plans define what customers can do. Billing ensures the business runs. Usage metering keeps everything honest. This module covers plan configuration, usage tracking, invoice generation, payment processing, refunds, and dunning — the complete financial lifecycle of a GHOS tenant.**

---

## 1. PLAN CONFIGURATION

### 1.1 Admin Plan CRUD

The GHOS admin panel provides full CRUD for subscription plans. Each plan is defined as:

```sql
CREATE TABLE billing_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    tagline VARCHAR(200),
    price_monthly DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    price_yearly DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    billing_cycle_options VARCHAR(10)[] DEFAULT '{monthly,yearly}',
    features JSONB NOT NULL DEFAULT '{}',
    limits JSONB NOT NULL DEFAULT '{}',
    trial_days INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    highlight BOOLEAN DEFAULT FALSE,
    created_by UUID REFERENCES staff_users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 1.2 Plan Configuration UI

The admin can configure:
- **Basic Info**: Name, description, tagline, sort order, visibility
- **Pricing**: Monthly price, yearly price, currency (INR default)
- **Feature Flags**: Toggle each feature on/off per plan
- **Usage Limits**: Set soft and hard limits per metered resource
- **Trial**: Trial duration in days (0 = no trial)
- **Display Options**: Badge (Most Popular / Best Value), highlight color
- **Plan Hierarchy**: Sort order determines upgrade/downgrade path

### 1.3 Feature JSON Schema

```json
{
    "features": {
        "patient_registration": {"type": "boolean", "value": true},
        "queue_management": {"type": "boolean", "value": true},
        "patient_tracking": {"type": "boolean", "value": true},
        "basic_dashboard": {"type": "boolean", "value": true},
        "advanced_analytics": {"type": "boolean", "value": false},
        "multi_branch": {"type": "boolean", "value": false},
        "whatsapp_notifications": {"type": "boolean", "value": true},
        "sms_notifications": {"type": "boolean", "value": false},
        "billing_invoicing": {"type": "boolean", "value": false},
        "ai_receptionist": {"type": "boolean", "value": false},
        "white_label": {"type": "boolean", "value": false},
        "api_access": {"type": "boolean", "value": false}
    },
    "limits": {
        "branches": {"soft": 1, "hard": 1, "unit": "count"},
        "staff_accounts": {"soft": 8, "hard": 10, "unit": "count"},
        "whatsapp_per_day": {"soft": 400, "hard": 500, "unit": "messages"},
        "sms_per_day": {"soft": 0, "hard": 0, "unit": "messages"},
        "ai_calls_per_month": {"soft": 0, "hard": 0, "unit": "calls"},
        "storage_mb": {"soft": 80, "hard": 100, "unit": "mb"}
    }
}
```

---

## 2. USAGE METERING

### 2.1 Metered Resources

| Resource | Metering Unit | Reset Period | Tracking Method |
|----------|--------------|--------------|-----------------|
| WhatsApp messages | Per message | Daily | Redis counter + DB persistence |
| SMS sent | Per SMS | Daily | Redis counter + DB persistence |
| AI calls | Per API call | Monthly | Redis counter + DB persistence |
| Active branches | Concurrent count | Cumulative | DB snapshot daily |
| Storage used | MB | Cumulative | Daily aggregation job |
| Staff accounts | Count | Cumulative | DB snapshot daily |
| API calls | Per request | Daily | Redis counter |

### 2.2 Near-Real-Time Counter (Redis + DB)

```python
class UsageTracker:
    """Track usage with near-real-time Redis counters + DB persistence."""

    def __init__(self, redis_client, db_pool):
        self.redis = redis_client
        self.db = db_pool

    async def increment(self, tenant_id, resource, amount=1, ttl=86400) -> int:
        """Increment usage counter. Returns current count."""
        daily_key = f"usage:{tenant_id}:{resource}:daily:{date.today().isoformat()}"
        count = await self.redis.incrby(daily_key, amount)
        if count == amount:
            await self.redis.expire(daily_key, ttl)
        return count

    async def increment_monthly(self, tenant_id, resource, amount=1) -> int:
        """Increment monthly counter (resets on billing anniversary)."""
        reset_date = await self._get_monthly_reset_date(tenant_id)
        monthly_key = f"usage:{tenant_id}:{resource}:monthly:{reset_date}"
        count = await self.redis.incrby(monthly_key, amount)
        return count

    async def get_usage(self, tenant_id, resource, period="daily") -> int:
        """Get current usage for a resource."""
        if period == "daily":
            key = f"usage:{tenant_id}:{resource}:daily:{date.today().isoformat()}"
        elif period == "monthly":
            reset_date = await self._get_monthly_reset_date(tenant_id)
            key = f"usage:{tenant_id}:{resource}:monthly:{reset_date}"
        else:
            return await self._get_cumulative_usage(tenant_id, resource)
        return int(await self.redis.get(key) or 0)

    async def check_limit(self, tenant_id, resource) -> dict:
        """Check if usage is within limits."""
        plan = await self._get_tenant_plan(tenant_id)
        limits = plan["limits"].get(resource, {})
        soft_limit = limits.get("soft", 0)
        hard_limit = limits.get("hard", 0)
        current = await self.get_usage(tenant_id, resource)
        return {
            "resource": resource,
            "current": current,
            "soft_limit": soft_limit,
            "hard_limit": hard_limit,
            "usage_percent": round((current / hard_limit) * 100, 1) if hard_limit > 0 else 0,
            "is_soft_exceeded": current >= soft_limit if soft_limit > 0 else False,
            "is_hard_exceeded": current >= hard_limit if hard_limit > 0 else False,
            "remaining": max(0, hard_limit - current) if hard_limit > 0 else None
        }

    async def persist_daily_usage(self):
        """Scheduled job: persist Redis counters to DB (runs hourly)."""
        keys = await self.redis.keys("usage:*:daily:*")
        for key in keys:
            parts = key.split(":")
            tenant_id, resource, date_str = parts[1], parts[2], parts[4]
            count = int(await self.redis.get(key))
            await self.db.execute("""
                INSERT INTO daily_usage (tenant_id, resource, usage_date, count)
                VALUES ($1, $2, $3, $4)
                ON CONFLICT (tenant_id, resource, usage_date)
                DO UPDATE SET count = EXCLUDED.count, updated_at = NOW()
            """, tenant_id, resource, date_str, count)
```

---

## 3. INVOICE SYSTEM

### 3.1 Invoice Lifecycle

```
Billing Period Start
       |
       v
Auto-generate invoice (due immediately)
       |
       v
Send invoice via email (PDF attached)
       |
       v
+-- Payment received -> Mark as paid -> Generate receipt
|
+-- Payment failed -> Mark as unpaid, move to dunning
        |
        v
    Retry 1 (day 1)
    Retry 2 (day 2)
    Retry 3 (day 4)
        |
    +-- All failed -> Suspend subscription
```

### 3.2 Invoice Record

```sql
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    subscription_id UUID REFERENCES subscriptions(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('draft', 'pending', 'paid', 'failed', 'refunded', 'cancelled')),
    type VARCHAR(20) NOT NULL DEFAULT 'subscription'
        CHECK (type IN ('subscription', 'addon', 'credit_note', 'one_time')),
    period_start DATE,
    period_end DATE,
    line_items JSONB NOT NULL DEFAULT '[]',
    subtotal DECIMAL(12, 2) NOT NULL,
    discount_type VARCHAR(20),
    discount_percent DECIMAL(5, 2),
    discount_amount DECIMAL(12, 2) DEFAULT 0,
    gst_percent DECIMAL(5, 2) DEFAULT 18.00,
    gst_amount DECIMAL(12, 2) DEFAULT 0,
    total DECIMAL(12, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    gateway VARCHAR(20),
    gateway_payment_id VARCHAR(255),
    gateway_invoice_id VARCHAR(255),
    paid_at TIMESTAMPTZ,
    pdf_url VARCHAR(500),
    notes TEXT,
    billing_address JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE credit_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    credit_note_number VARCHAR(30) UNIQUE NOT NULL,
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    reason VARCHAR(100) NOT NULL CHECK (reason IN ('refund', 'credit', 'adjustment', 'cancellation')),
    amount DECIMAL(12, 2) NOT NULL,
    tax_amount DECIMAL(12, 2) DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'issued',
    issued_by UUID,
    applied_to_invoice_id UUID REFERENCES invoices(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.3 Invoice Number Format

```
GHOS-INV-{YYYYMM}-{Sequential: 00001}
Example: GHOS-INV-202607-00042
```

### 3.4 PDF Invoice (WeasyPrint)

```python
class InvoicePDFGenerator:
    """Generate GST-compliant invoice PDF using WeasyPrint."""

    TEMPLATE = """
    <html>
    <body>
        <div class="header">
            <h1>GHOS - Invoice</h1>
            <p><strong>Invoice #:</strong> {{ invoice_number }}</p>
            <p><strong>Date:</strong> {{ created_at }}</p>
        </div>
        <div class="bill-to">
            <h3>Bill To:</h3>
            <p>{{ tenant_name }}</p>
            <p>{{ tenant_address }}</p>
            <p>GST: {{ tenant_gst }}</p>
        </div>
        <table class="items">
            <thead>
                <tr>
                    <th>Description</th><th>Qty</th><th>Unit Price</th><th>Amount</th>
                </tr>
            </thead>
            <tbody>
                {% for item in line_items %}
                <tr>
                    <td>{{ item.description }}</td>
                    <td>{{ item.quantity }}</td>
                    <td>Rs {{ "%.2f"|format(item.unit_price) }}</td>
                    <td>Rs {{ "%.2f"|format(item.amount) }}</td>
                </tr>
                {% endfor %}
            </tbody>
        </table>
        <div class="totals">
            <p>Subtotal: Rs {{ "%.2f"|format(subtotal) }}</p>
            <p>GST (18%%): Rs {{ "%.2f"|format(gst_amount) }}</p>
            <p><strong>Total: Rs {{ "%.2f"|format(total) }}</strong></p>
        </div>
    </body>
    </html>
    """

    def generate(self, invoice_data: dict) -> bytes:
        template = Template(self.TEMPLATE)
        html = template.render(**invoice_data)
        pdf = HTML(string=html).write_pdf()
        return pdf
```

---

## 4. PAYMENT GATEWAY

### 4.1 Razorpay Webhook Handling

```python
class RazorpayWebhookHandler:
    """Handle all Razorpay webhook events."""

    WEBHOOK_EVENTS = {
        "payment.captured": "_handle_payment_captured",
        "payment.failed": "_handle_payment_failed",
        "subscription.charged": "_handle_subscription_charged",
        "subscription.cancelled": "_handle_subscription_cancelled",
    }

    def __init__(self, db_pool, redis_client):
        self.db = db_pool
        self.redis = redis_client

    async def handle(self, payload: dict, signature: str) -> str:
        self._verify_signature(payload, signature)
        event = payload["event"]
        handler_name = self.WEBHOOK_EVENTS.get(event)
        if not handler_name:
            return "ignored"
        handler = getattr(self, handler_name)
        await handler(payload["payload"])
        return "ok"

    async def _handle_subscription_charged(self, payload: dict):
        """Subscription payment successful."""
        subscription = payload["subscription"]["entity"]
        payment = payload["payment"]["entity"]
        tenant_id = subscription["notes"]["tenant_id"]

        await self.db.execute("""
            UPDATE invoices SET
                status = 'paid',
                gateway_payment_id = $1,
                paid_at = NOW()
            WHERE tenant_id = $2 AND status = 'pending'
            ORDER BY created_at DESC LIMIT 1
        """, payment["id"], tenant_id)

        await self.redis.delete(f"feature:{tenant_id}:*")

    async def _handle_payment_failed(self, payload: dict):
        """Payment failed. Trigger dunning."""
        payment = payload["payment"]["entity"]
        invoice_id = payment.get("notes", {}).get("invoice_id")
        if invoice_id:
            await self.db.execute("""
                UPDATE invoices SET status = 'failed', updated_at = NOW()
                WHERE id = $1
            """, invoice_id)
        await self.dunning.handle_failed_payment(invoice_id, payment.get("error_code"), payment.get("error_description"))

    def _verify_signature(self, payload: dict, signature: str):
        """Verify Razorpay webhook signature."""
        expected = hmac.new(
            settings.RAZORPAY_WEBHOOK_SECRET.encode(),
            json.dumps(payload).encode(),
            hashlib.sha256
        ).hexdigest()
        if not hmac.compare_digest(expected, signature):
            raise HTTPException(status_code=400, detail="Invalid webhook signature")
```

### 4.2 Payment Retry Logic

```python
class PaymentRetryManager:
    """Retry failed payments with escalating urgency."""

    MAX_RETRIES = 3
    RETRY_DELAYS = [24 * 3600, 48 * 3600, 96 * 3600]

    async def retry_payment(self, invoice_id: UUID) -> dict:
        invoice = await self._get_invoice(invoice_id)
        if invoice["retry_count"] >= self.MAX_RETRIES:
            await self._escalate_to_dunning(invoice)
            return {"status": "max_retries_reached", "action": "dunning"}
        delay = self.RETRY_DELAYS[invoice["retry_count"]]
        schedule_time = datetime.utcnow() + timedelta(seconds=delay)
        await self._schedule_retry(invoice_id, schedule_time)
        return {"status": "retry_scheduled", "retry_attempt": invoice["retry_count"] + 1}

    async def _escalate_to_dunning(self, invoice: dict):
        """All retries exhausted -- escalate to dunning."""
        await db.execute("""
            UPDATE subscriptions SET
                status = 'past_due',
                grace_end = NOW() + INTERVAL '3 days',
                updated_at = NOW()
            WHERE tenant_id = $1
        """, invoice["tenant_id"])
        await send_dunning_email(invoice["tenant_id"], invoice)
```

---

## 5. REFUND FLOW

### 5.1 Refund Policy

| Condition | Refund Policy | Approval |
|-----------|--------------|----------|
| First month dissatisfaction | Full refund within 7 days of payment | Auto-approved |
| Partial month cancellation | Pro-rated refund for unused days | Auto-approved |
| Refund < Rs 5,000 | Full refund to original payment method | Auto-approved |
| Refund >= Rs 5,000 | Requires admin approval | Manual approval needed |
| Payment gateway fees | Deducted from refund (2% + GST) | Always |

### 5.2 Refund Processing

```python
class RefundProcessor:
    """Process subscription refunds with pro-rata calculation."""

    async def calculate_prorated_refund(self, invoice_id: UUID) -> dict:
        invoice = await self._get_invoice(invoice_id)
        days_in_period = (invoice["period_end"] - invoice["period_start"]).days
        days_used = (date.today() - invoice["period_start"]).days
        daily_rate = invoice["total"] / days_in_period
        refund_amount = daily_rate * max(0, days_in_period - days_used)
        gateway_fee = round(refund_amount * Decimal("0.02"), 2)
        net_refund = refund_amount - gateway_fee
        return {
            "invoice_total": invoice["total"],
            "gross_refund": round(refund_amount, 2),
            "gateway_fee": gateway_fee,
            "net_refund": round(net_refund, 2),
            "needs_approval": net_refund > Decimal("5000")
        }

    async def process_refund(self, invoice_id: UUID, amount: Decimal, reason: str, approved_by: UUID = None) -> dict:
        invoice = await self._get_invoice(invoice_id)
        if amount > Decimal("5000") and not approved_by:
            return {"status": "needs_approval", "message": "Refund > Rs 5,000 requires admin approval"}
        refund = razorpay_client.payment.refund(invoice["gateway_payment_id"], {
            "amount": int(amount * 100),
            "notes": {"reason": reason, "invoice_id": str(invoice_id)}
        })
        credit_note_id = await self._create_credit_note(invoice_id, amount, "refund")
        await self.db.execute("UPDATE invoices SET status = 'refunded', updated_at = NOW() WHERE id = $1", invoice_id)
        return {"status": "refunded", "refund_id": refund["id"], "credit_note_id": credit_note_id, "amount": amount}
```

---

## 6. DUNNING MANAGEMENT

### 6.1 Dunning Timeline

```
Day 0:  Payment failed
Day 1:  Email: "Payment failed -- update your payment method"
Day 3:  SMS: "Your GHOS subscription payment failed"
Day 5:  Email + SMS: "Final notice -- account suspension in 2 days"
Day 7:  Subscription suspended (read-only mode)
Day 90: Data archived (cold storage)
```

### 6.2 Dunning Processor

```python
class DunningManager:
    """Manage the dunning process for failed payments."""

    async def handle_failed_payment(self, invoice_id: UUID, error_code: str, error_description: str):
        invoice = await self._get_invoice(invoice_id)
        await self.db.execute("""
            UPDATE subscriptions SET status = 'past_due',
                grace_end = NOW() + INTERVAL '3 days', updated_at = NOW()
            WHERE id = $1
        """, invoice["subscription_id"])
        await self._schedule_emails(invoice["tenant_id"], invoice_id)
        await self._log_dunning_event(invoice_id, "payment_failed", {"error_code": error_code})

    async def suspend_subscription(self, tenant_id: UUID):
        """Suspend subscription after grace period."""
        await self.db.execute("""
            UPDATE subscriptions SET status = 'suspended', updated_at = NOW()
            WHERE tenant_id = $1 AND status = 'past_due'
        """, tenant_id)
        await self._notify_suspension(tenant_id)
        await self.redis.delete(f"feature:{tenant_id}:*")
```

---

## 7. COMPLETE DATABASE SCHEMA

```sql
-- BILLING PLANS
CREATE TABLE billing_plans (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    slug VARCHAR(50) UNIQUE NOT NULL,
    name VARCHAR(100) NOT NULL,
    description TEXT,
    tagline VARCHAR(200),
    price_monthly DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    price_yearly DECIMAL(10, 2) NOT NULL DEFAULT 0.00,
    billing_cycle_options VARCHAR(10)[] DEFAULT '{monthly,yearly}',
    features JSONB NOT NULL DEFAULT '{}',
    limits JSONB NOT NULL DEFAULT '{}',
    trial_days INTEGER DEFAULT 0,
    sort_order INTEGER DEFAULT 0,
    is_public BOOLEAN DEFAULT TRUE,
    is_active BOOLEAN DEFAULT TRUE,
    highlight BOOLEAN DEFAULT FALSE,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- USAGE METERS
CREATE TABLE usage_meters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    period_type VARCHAR(10) NOT NULL CHECK (period_type IN ('daily', 'monthly', 'cumulative')),
    period_start DATE NOT NULL,
    period_end DATE,
    current_count BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, resource, period_type, period_start)
);

-- DAILY USAGE
CREATE TABLE daily_usage (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    usage_date DATE NOT NULL,
    count BIGINT NOT NULL DEFAULT 0,
    peak_count BIGINT NOT NULL DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, resource, usage_date)
);

-- INVOICES
CREATE TABLE invoices (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_number VARCHAR(30) UNIQUE NOT NULL,
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    subscription_id UUID REFERENCES subscriptions(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending',
    type VARCHAR(20) NOT NULL DEFAULT 'subscription',
    period_start DATE,
    period_end DATE,
    line_items JSONB NOT NULL DEFAULT '[]',
    subtotal DECIMAL(12, 2) NOT NULL,
    discount_type VARCHAR(20),
    discount_percent DECIMAL(5, 2),
    discount_amount DECIMAL(12, 2) DEFAULT 0,
    gst_percent DECIMAL(5, 2) DEFAULT 18.00,
    gst_amount DECIMAL(12, 2) DEFAULT 0,
    total DECIMAL(12, 2) NOT NULL,
    currency VARCHAR(3) DEFAULT 'INR',
    gateway VARCHAR(20),
    gateway_payment_id VARCHAR(255),
    gateway_invoice_id VARCHAR(255),
    paid_at TIMESTAMPTZ,
    pdf_url VARCHAR(500),
    notes TEXT,
    billing_address JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- CREDIT NOTES
CREATE TABLE credit_notes (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    credit_note_number VARCHAR(30) UNIQUE NOT NULL,
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    reason VARCHAR(100) NOT NULL CHECK (reason IN ('refund', 'credit', 'adjustment', 'cancellation')),
    amount DECIMAL(12, 2) NOT NULL,
    tax_amount DECIMAL(12, 2) DEFAULT 0,
    status VARCHAR(20) NOT NULL DEFAULT 'issued',
    issued_by UUID,
    applied_to_invoice_id UUID REFERENCES invoices(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- DUNNING LOG
CREATE TABLE dunning_log (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    invoice_id UUID NOT NULL REFERENCES invoices(id),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    event_type VARCHAR(30) NOT NULL,
    channel VARCHAR(20),
    error_code VARCHAR(100),
    error_description TEXT,
    metadata JSONB,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- INDEXES
CREATE INDEX idx_billing_plans_slug ON billing_plans(slug);
CREATE INDEX idx_usage_meters_tenant ON usage_meters(tenant_id, resource);
CREATE INDEX idx_daily_usage_tenant ON daily_usage(tenant_id, usage_date);
CREATE INDEX idx_invoices_tenant ON invoices(tenant_id, status);
CREATE INDEX idx_invoices_gateway ON invoices(gateway_payment_id);
CREATE INDEX idx_credit_notes_invoice ON credit_notes(invoice_id);
CREATE INDEX idx_dunning_tenant ON dunning_log(tenant_id);
```

---

## 8. PYTHON IMPLEMENTATION

### 8.1 UsageTracker

```python
class UsageTracker:
    """Track, query, and limit usage for metered resources."""
    async def increment(self, tenant_id, resource, amount=1, ttl=86400): ...
    async def get_usage(self, tenant_id, resource, period="daily") -> int: ...
    async def check_limit(self, tenant_id, resource) -> dict: ...
    async def get_all_usage_summary(self, tenant_id) -> list:
        """Return usage for all metered resources with limits."""
        plans = await self._get_tenant_plan(tenant_id)
        summary = []
        for resource, limits in plans["limits"].items():
            status = await self.check_limit(tenant_id, resource)
            summary.append(status)
        return summary
    async def persist_daily_usage(self): ...
```

### 8.2 InvoiceGenerator

```python
class InvoiceGenerator:
    """Generate, deliver, and manage invoices."""
    async def generate_invoice(self, subscription_id, period_start, period_end): ...
    async def generate_credit_note(self, invoice_id, amount, reason): ...
    async def deliver_invoice(self, invoice_id):
        """Email invoice PDF to tenant billing contact."""
        invoice = await self._get_invoice(invoice_id)
        tenant = await self._get_tenant(invoice["tenant_id"])
        pdf = await self._generate_pdf(invoice)
        s3_url = await self._upload_pdf(pdf, invoice["invoice_number"])
        await send_email(
            to=tenant["billing_email"],
            subject=f"Invoice {invoice['invoice_number']} from GHOS",
            body=f"Your invoice for Rs {invoice['total']} is attached.",
            attachments=[{"filename": f"invoice_{invoice['invoice_number']}.pdf", "content": pdf}]
        )
```

### 8.3 PaymentWebhookHandler

```python
class PaymentWebhookHandler:
    """Unified webhook handler for multiple payment gateways."""
    GATEWAYS = {"razorpay": RazorpayWebhookHandler, "stripe": StripeWebhookHandler}
    async def process(self, gateway: str, payload: dict, signature: str):
        handler_class = self.GATEWAYS.get(gateway)
        if not handler_class:
            raise ValueError(f"Unknown gateway: {gateway}")
        handler = handler_class(self.db, self.redis)
        return await handler.handle(payload, signature)
```

---

## 9. SCHEDULED JOBS

| Job | Frequency | Description |
|-----|-----------|-------------|
| Invoice auto-generation | Daily 02:00 IST | Generate invoices for subscriptions starting today |
| Daily usage persist | Hourly | Flush Redis counters to daily_usage table |
| Payment retry | Every 6 hours | Retry failed payments within retry limit |
| Dunning email delivery | Daily 08:00 IST | Send scheduled dunning emails |
| Subscription suspension | Daily 00:00 IST | Suspend subscriptions past grace period |
| Data archive | Weekly (Sunday 03:00 IST) | Archive data for suspended > 90 days |
| Usage report (80% alert) | Daily 06:00 IST | Email usage summary to admins near limits |
