---
file_id: "1001"
module_name: "Multi-Branch Module"
version: "1.0"
status: "Draft"
phase: "Phase 10 — SaaS"
dependencies: ["1000_MULTI_HOSPITAL.md"]
related_files: ["0005_QUEUE_ENGINE.md", "0008_INVENTORY.md", "0010_STAFF_SHIFT.md"]
last_updated: "2026-07-09"
priority: "High"
ai_tags: ["ghos", "multi-branch", "branches", "locations", "routing"]
---

# GHOS — Multi-Branch Module

> **One hospital, many locations. Patients move freely across branches. Queue is local, medical history is global. Staff float between branches. Inventory transfers across locations. Analytics roll up to headquarters.**

---

## 1. BRANCH MODEL

### 1.1 Branch Entity

A branch is a physical location where healthcare services are delivered. Each branch has its own identity, operational hours, departments, and staff.

```sql
CREATE TABLE branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,        -- 'MAIN', 'BR-01', 'DLF-PH-II'
    name VARCHAR(255) NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'clinic'
        CHECK (type IN ('clinic', 'hospital', 'pharmacy', 'lab', 'diagnostic_center')),
    status VARCHAR(20) NOT NULL DEFAULT 'active'
        CHECK (status IN ('active', 'inactive', 'closed', 'renovation')),
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    country VARCHAR(100) DEFAULT 'India',
    latitude DECIMAL(10, 7),
    longitude DECIMAL(10, 7),
    phone VARCHAR(20),
    email VARCHAR(255),
    timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
    region_id UUID REFERENCES regions(id),        -- For grouping branches
    is_head_office BOOLEAN DEFAULT FALSE,
    config JSONB DEFAULT '{}',                     -- Branch-specific settings
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 1.2 Branch Hierarchy

```
HOSPITAL LEVEL
  |-- Region: North India
  |     |-- Branch: DLF Phase 2 (Flagship)
  |     |     |-- Department: Cardiology
  |     |     |-- Department: Orthopedics
  |     |     |-- Department: Lab
  |     |-- Branch: Cyber City (Satellite)
  |           |-- Department: General Medicine
  |           |-- Department: Pharmacy
  |
  |-- Region: South India
        |-- Branch: HITEC City
        |     |-- Department: Cardiology
        |     |-- Department: Neurology
        |-- Branch: Gachibowli
              |-- Department: General Medicine
```

### 1.3 Branch Hours & Departments

```sql
CREATE TABLE branch_hours (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
    is_closed BOOLEAN DEFAULT FALSE,
    open_time TIME,
    close_time TIME,
    break_start TIME,
    break_end TIME,
    slot_duration_minutes INTEGER DEFAULT 15,
    UNIQUE(branch_id, day_of_week)
);

CREATE TABLE branch_departments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    department_id UUID NOT NULL REFERENCES departments(id),
    is_active BOOLEAN DEFAULT TRUE,
    head_doctor_id UUID REFERENCES staff_users(id),
    room_count INTEGER DEFAULT 1,
    max_patients_per_day INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, department_id)
);
```

---

## 2. DATA SHARING RULES

### 2.1 Table Sharing Matrix

| Table | Sharing Model | Rationale |
|-------|---------------|-----------|
| **patients** | Global (shared across all branches) | One patient, one record, visit any branch |
| **staff_users** | Global (shared) | Staff can float across branches |
| **inventory_items** | Global (shared) | Central catalog; branch-level stock is separate |
| **medicine_master** | Global (shared) | One medicine catalog for all branches |
| **departments** | Global (shared) | Department master list |
| **queue** | Branch-specific | Each branch has its own queue |
| **appointments** | Branch-specific | Appointment tied to branch + department |
| **visit_records** | Global (shared) | Visit log has branch_id; data accessible across branches |
| **daily_sales** | Branch-specific | Per-branch financial close |
| **inventory_stock** | Branch-specific | Stock levels per branch |
| **expenses** | Branch-specific | Per-branch P&L |
| **shift_schedules** | Branch-specific | Staff shifts per branch |

### 2.2 Configurable Sharing

Some data sharing can be configured per hospital:

```json
{
    "patient_sharing": "global",          // 'global' | 'branch_only' | 'opt_in'
    "medical_history_sharing": "global",  // 'global' | 'consent_required'
    "staff_cross_branch": true,           // true | false
    "inventory_central": true,            // true = central warehouse, false = per-branch purchasing
    "appointment_cross_branch": true,     // Can book at any branch from any branch
    "queue_cross_view": true              // Receptionist can see queues at other branches
}
```

---

## 3. PATIENT CROSS-BRANCH FLOW

### 3.1 Flow Diagram

```
Patient registered at Branch A (Main)
         |
         | Patient visits Branch B (Satellite) on a different day
         v
Receptionist at Branch B searches patient by phone/Aadhaar
         |
         +-- Found: Patient exists in Branch A
         |       |
         |       v
         |   Confirm identity (SMS OTP to registered phone)
         |       |
         |       v
         |   Create new queue entry at Branch B
         |   Link to existing patient record (single global record)
         |   Branch B visit notes are separate from Branch A notes
         |
         +-- Not Found:
                 |
                 v
             Register as new patient (now accessible at all branches)
```

### 3.2 Data Model for Cross-Branch Visits

```sql
-- Single patient record, accessible globally
CREATE TABLE patients (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL,
    -- ... (all patient demographic fields)
    registered_at_branch_id UUID REFERENCES branches(id),
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Each visit is branch-scoped but linked to the global patient
CREATE TABLE visits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    patient_id UUID NOT NULL REFERENCES patients(id),
    branch_id UUID NOT NULL REFERENCES branches(id),
    department_id UUID REFERENCES departments(id),
    visit_type VARCHAR(30) NOT NULL DEFAULT 'outpatient',
    visit_date DATE NOT NULL,
    registered_by UUID REFERENCES staff_users(id),
    chief_complaint TEXT,
    notes TEXT,                   -- Branch-specific visit notes
    diagnosis TEXT,
    is_completed BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
```

### 3.3 Medical History Aggregation

When a doctor views a patient's medical history, all visits across all branches are aggregated:

```sql
SELECT v.*, b.name as branch_name, d.name as department_name
FROM visits v
JOIN branches b ON b.id = v.branch_id
JOIN departments d ON d.id = v.department_id
WHERE v.patient_id = $1
ORDER BY v.created_at DESC;
```

A "consent required" sharing mode shows only the current branch's visits unless the patient explicitly consents to cross-branch history sharing.

---

## 4. BRANCH ROUTING

### 4.1 Routing Strategies

| Strategy | Description | Use Case |
|----------|-------------|----------|
| **Nearest branch** | Auto-assign by patient pincode -> geocoded nearest branch | Walk-in patient asks "which branch?" |
| **Load-balanced** | Round-robin across open branches with spare capacity | Telemedicine / appointment booking |
| **Department-based** | Route by required specialty | Cardiology only available at Branch A |
| **Manual override** | Patient or receptionist picks any branch | Patient preference |
| **Emergency** | Route to nearest open branch with emergency capacity | Emergency cases |

### 4.2 Nearest Branch by Pincode

```python
class BranchRouter:
    """Route patients to the right branch."""

    async def find_nearest_branch(self, pincode: str, department_id: UUID = None
                                  ) -> dict:
        """Find the nearest active branch with the required department."""
        branches = await self._get_geocoded_branches(pincode, department_id)
        if not branches:
            raise NoBranchAvailable("No branch near this pincode")

        # Geocode patient pincode -> lat/lng
        patient_geo = await self._geocode_pincode(pincode)

        # Calculate distance for each branch
        for branch in branches:
            branch["distance_km"] = self._haversine(
                patient_geo["lat"], patient_geo["lng"],
                branch["latitude"], branch["longitude"]
            )

        # Sort by distance and filter by max range (25 km default)
        within_range = [b for b in branches if b["distance_km"] <= 25]
        within_range.sort(key=lambda b: b["distance_km"])

        if not within_range:
            raise NoBranchAvailable("No branch within 25 km")

        return within_range[0]

    async def get_load_balanced_branch(self, department_id: UUID) -> dict:
        """Select the least-loaded branch for appointment booking."""
        branches = await self._get_active_branches(department_id)
        # Get current queue depth per branch
        for branch in branches:
            branch["queue_depth"] = await self._get_queue_depth(
                branch["id"], department_id
            )
        # Sort by queue depth (ascending)
        branches.sort(key=lambda b: b["queue_depth"])
        return branches[0]
```

### 4.3 API: Suggest Branch

```http
GET /api/v1/branches/suggest?pincode=122002&department=cardiology

Response:
{
  "branches": [
    {
      "id": "...",
      "name": "DLF Phase 2 Clinic",
      "distance_km": 3.2,
      "queue_depth": 12,
      "estimated_wait_minutes": 15,
      "is_open": true,
      "hours": {"open": "08:00", "close": "20:00"}
    },
    {
      "id": "...",
      "name": "Cyber City Clinic",
      "distance_km": 5.8,
      "queue_depth": 8,
      "estimated_wait_minutes": 10,
      "is_open": true,
      "hours": {"open": "09:00", "close": "19:00"}
    }
  ],
  "recommended_branch": "DLF Phase 2 Clinic"
}
```

---

## 5. BRANCH DASHBOARD

### 5.1 Per-Branch KPIs

| KPI | Refresh | Source | Calculation |
|-----|---------|--------|-------------|
| Queue Depth | Real-time | Redis | Current count of waiting tokens |
| Avg Wait Time | Real-time | Redis | Rolling average of last 50 tokens |
| Token Count (today) | Real-time | DB | COUNT of tokens created today |
| Daily Revenue | Every 5 min | DB | SUM of bills created today |
| Appointments Booked | Every 5 min | DB | COUNT of appointments for today |
| No-Show Rate | End of day | DB | (no_shows / total_appointments) * 100 |
| Avg Visit Duration | Hourly | DB | AVG(completed_at - called_at) |
| Active Staff | Real-time | Redis | Staff currently clocked in |
| Bed Occupancy | Real-time | DB | (occupied / total) * 100 |

### 5.2 Branch Comparison Report

```sql
-- Compare KPIs across branches for a date range
SELECT
    b.name AS branch_name,
    COUNT(DISTINCT v.id) AS total_visits,
    COUNT(DISTINCT q.id) AS total_queue,
    AVG(q.wait_time_seconds) AS avg_wait_seconds,
    SUM(i.grand_total) AS total_revenue,
    COUNT(DISTINCT s.id) AS total_staff
FROM branches b
LEFT JOIN visits v ON v.branch_id = b.id
    AND v.visit_date BETWEEN $1 AND $2
LEFT JOIN queue q ON q.branch_id = b.id
    AND q.created_at BETWEEN $1 AND $2
LEFT JOIN invoices i ON i.branch_id = b.id
    AND i.created_at BETWEEN $1 AND $2
LEFT JOIN staff_assignments s ON s.branch_id = b.id
WHERE b.hospital_id = $3 AND b.status = 'active'
GROUP BY b.id, b.name
ORDER BY b.name;
```

### 5.3 Branch-Specific Settings

Each branch can override certain hospital-level defaults:

```json
{
    "queue": {
        "max_tokens_per_day": 200,
        "enable_prioritization": true,
        "priority_rules": ["senior_citizen", "emergency", "vip"]
    },
    "appointments": {
        "enable_online_booking": true,
        "slot_interval_minutes": 15,
        "max_future_days": 30,
        "allow_same_day": true
    },
    "billing": {
        "default_payment_mode": "cash",
        "enable_credit": false,
        "discount_limit_percent": 10
    },
    "notifications": {
        "sms_on_registration": true,
        "whatsapp_on_completion": false
    }
}
```

---

## 6. INVENTORY SHARING

### 6.1 Central Warehouse Model

1. **Central Warehouse**: One master inventory location (can be the head office branch or a dedicated warehouse)
2. **Branch Stock**: Each branch maintains its own stock of inventory items
3. **Transfer Workflow**: Central -> Branch or Branch -> Branch

### 6.2 Transfer Flow

```
Branch A requests: 10 packs of Paracetamol 500mg from Central
         |
         v
Central manager approves transfer
         |
         v
System deducts 10 from Central stock
System adds 10 to Branch A stock (in_transit status)
         |
         v
Branch A receives: stock moves in_transit -> available
         |
         v
Audit log: transfer recorded with timestamp, quantities, approval
```

```sql
CREATE TABLE stock_transfers (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transfer_number VARCHAR(30) UNIQUE NOT NULL,
    from_branch_id UUID NOT NULL REFERENCES branches(id),
    to_branch_id UUID NOT NULL REFERENCES branches(id),
    status VARCHAR(20) NOT NULL DEFAULT 'pending'
        CHECK (status IN ('pending', 'approved', 'in_transit', 'completed', 'cancelled')),
    requested_by UUID REFERENCES staff_users(id),
    approved_by UUID REFERENCES staff_users(id),
    received_by UUID REFERENCES staff_users(id),
    notes TEXT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    completed_at TIMESTAMPTZ
);

CREATE TABLE stock_transfer_items (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    transfer_id UUID NOT NULL REFERENCES stock_transfers(id) ON DELETE CASCADE,
    item_id UUID NOT NULL REFERENCES inventory_items(id),
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price DECIMAL(10, 2),
    batch_number VARCHAR(50),
    expiry_date DATE
);
```

### 6.3 Inter-Branch Transfer Rules

- Transfers between branches require approval from both branch managers
- Emergency transfers (within same city) auto-approved with notification
- Transfer limits: max 20% of transferring branch's stock per item
- Audit trail: every transfer is logged with full chain of custody

---

## 7. STAFF MANAGEMENT ACROSS BRANCHES

### 7.1 Staff-Branch Assignment

```sql
CREATE TABLE staff_branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id UUID NOT NULL REFERENCES staff_users(id),
    branch_id UUID NOT NULL REFERENCES branches(id),
    assignment_type VARCHAR(20) NOT NULL DEFAULT 'primary'
        CHECK (assignment_type IN ('primary', 'secondary', 'float', 'temporary')),
    is_active BOOLEAN DEFAULT TRUE,
    valid_from DATE NOT NULL,
    valid_until DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(staff_id, branch_id, assignment_type)
);
```

### 7.2 Staff Assignment Types

| Type | Meaning | Privileges |
|------|---------|------------|
| **Primary** | Home branch | Full access to branch operations |
| **Secondary** | Can work at this branch | Limited to specific departments |
| **Float** | Cross-branch coverage | Access defined by float schedule |
| **Temporary** | Locum / replacement | Time-bound access, auto-expires |

### 7.3 Shift Scheduling Per Branch

```sql
CREATE TABLE shift_schedules (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id UUID NOT NULL REFERENCES branches(id),
    staff_id UUID NOT NULL REFERENCES staff_users(id),
    shift_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    department_id UUID REFERENCES departments(id),
    role VARCHAR(30),
    is_approved BOOLEAN DEFAULT FALSE,
    check_in TIMESTAMPTZ,
    check_out TIMESTAMPTZ,
    notes TEXT,
    UNIQUE(staff_id, shift_date)
);
```

### 7.4 Float Staff Rules

- Float staff can be assigned to any branch within the same city
- Float assignments cannot exceed 50% of working days in a month
- Float staff get location-based shift differential (extra pay for distant branches)
- System prevents double-booking: a float staff cannot have overlapping shifts at two branches

---

## 8. DATABASE SCHEMAS

```sql
-- ============================================================
-- BRANCHES
-- ============================================================
CREATE TABLE branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    hospital_id UUID NOT NULL,
    code VARCHAR(20) UNIQUE NOT NULL,
    name VARCHAR(255) NOT NULL,
    type VARCHAR(30) NOT NULL DEFAULT 'clinic',
    status VARCHAR(20) NOT NULL DEFAULT 'active',
    address_line1 VARCHAR(255),
    address_line2 VARCHAR(255),
    city VARCHAR(100),
    state VARCHAR(100),
    pincode VARCHAR(10),
    country VARCHAR(100) DEFAULT 'India',
    latitude DECIMAL(10, 7),
    longitude DECIMAL(10, 7),
    phone VARCHAR(20),
    email VARCHAR(255),
    timezone VARCHAR(50) DEFAULT 'Asia/Kolkata',
    region_id UUID,
    is_head_office BOOLEAN DEFAULT FALSE,
    config JSONB DEFAULT '{}',
    sort_order INTEGER DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- BRANCH HOURS
-- ============================================================
CREATE TABLE branch_hours (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    day_of_week INTEGER NOT NULL CHECK (day_of_week BETWEEN 0 AND 6),
    is_closed BOOLEAN DEFAULT FALSE,
    open_time TIME,
    close_time TIME,
    break_start TIME,
    break_end TIME,
    slot_duration_minutes INTEGER DEFAULT 15,
    UNIQUE(branch_id, day_of_week)
);

-- ============================================================
-- BRANCH DEPARTMENTS
-- ============================================================
CREATE TABLE branch_departments (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    branch_id UUID NOT NULL REFERENCES branches(id) ON DELETE CASCADE,
    department_id UUID NOT NULL REFERENCES departments(id),
    is_active BOOLEAN DEFAULT TRUE,
    head_doctor_id UUID,
    room_count INTEGER DEFAULT 1,
    max_patients_per_day INTEGER,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(branch_id, department_id)
);

-- ============================================================
-- STAFF-BRANCH ASSIGNMENT
-- ============================================================
CREATE TABLE staff_branches (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    staff_id UUID NOT NULL,
    branch_id UUID NOT NULL REFERENCES branches(id),
    assignment_type VARCHAR(20) NOT NULL DEFAULT 'primary',
    is_active BOOLEAN DEFAULT TRUE,
    valid_from DATE NOT NULL,
    valid_until DATE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(staff_id, branch_id, assignment_type)
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_branches_hospital ON branches(hospital_id);
CREATE INDEX idx_branches_pincode ON branches(pincode);
CREATE INDEX idx_branches_region ON branches(region_id);
CREATE INDEX idx_branches_coords ON branches(latitude, longitude);
CREATE INDEX idx_branch_hours_branch ON branch_hours(branch_id, day_of_week);
CREATE INDEX idx_branch_dept_branch ON branch_departments(branch_id);
CREATE INDEX idx_staff_branches_staff ON staff_branches(staff_id);
CREATE INDEX idx_staff_branches_branch ON staff_branches(branch_id);
```

---

## 9. PYTHON IMPLEMENTATION

### 9.1 BranchManager

```python
class BranchManager:
    """Core service for multi-branch operations."""

    def __init__(self, db_pool, redis_client, geo_service=None):
        self.db = db_pool
        self.redis = redis_client
        self.geo = geo_service

    async def get_branch(self, branch_id: UUID) -> dict:
        """Fetch branch details with computed fields (is_open, queue_depth)."""
        branch = await self._fetch_branch(branch_id)
        branch["is_open"] = await self._is_branch_open(branch_id)
        branch["current_queue_depth"] = await self._get_queue_depth(branch_id)
        branch["estimated_wait"] = await self._estimate_wait(branch_id)
        return branch

    async def find_nearest(self, pincode: str, department: str = None) -> list:
        """Find nearest branches sorted by distance."""
        ...

    async def transfer_patient_to_branch(self, patient_id: UUID,
                                          from_branch_id: UUID, to_branch_id: UUID) -> dict:
        """Transfer a patient's ongoing visit to another branch."""
        patient = await self._get_patient(patient_id)
        if not patient:
            raise ValueError("Patient not found")
        # Check patient exists at source branch
        # Verify destination branch has capacity
        # Create queue entry at destination
        # Mark source queue entry as transferred
        # Notify staff at both branches
        return {"status": "transferred", "new_queue_id": queue_id}

    async def get_branch_analytics(self, branch_id: UUID, period: str = "today") -> dict:
        """Get aggregated KPIs for a single branch."""
        ...

    async def compare_branches(self, hospital_id: UUID) -> dict:
        """Compare all branches side by side for management dashboard."""
        ...

    async def open_branch_daily(self, branch_id: UUID, opened_by: UUID) -> dict:
        """Start-of-day operations: initialize counters, check inventory."""
        ...

    async def close_branch_daily(self, branch_id: UUID, closed_by: UUID) -> dict:
        """End-of-day: cash settlement, queue flush, day summary."""
        ...

    async def _is_branch_open(self, branch_id: UUID) -> bool:
        """Check if branch is currently open based on hours and holidays."""
        now = datetime.now()
        dow = now.weekday()
        current_time = now.time()
        hours = await self._get_branch_hours(branch_id, dow)
        if not hours or hours["is_closed"]:
            return False
        return hours["open_time"] <= current_time <= hours["close_time"]
```

### 9.2 BranchAnalyticsService

```python
class BranchAnalyticsService:
    """Aggregated analytics for branch-level and hospital-level reporting."""

    async def get_daily_report(self, branch_id: UUID, date: str) -> dict:
        """Full daily ops report for a branch."""
        return {
            "date": date,
            "branch_id": str(branch_id),
            "summary": {
                "total_patients": await self._count_patients(branch_id, date),
                "new_registrations": await self._count_new_registrations(branch_id, date),
                "appointments_scheduled": await self._count_appointments(branch_id, date),
                "appointments_completed": await self._count_completed(branch_id, date),
                "no_shows": await self._count_no_shows(branch_id, date),
                "walkins": await self._count_walkins(branch_id, date),
            },
            "queue": {
                "max_depth": await self._max_queue_depth(branch_id, date),
                "avg_wait_minutes": await self._avg_wait_time(branch_id, date),
                "max_wait_minutes": await self._max_wait_time(branch_id, date),
                "transferred_out": await self._count_transferred(branch_id, date),
            },
            "revenue": {
                "total": await self._total_revenue(branch_id, date),
                "cash": await self._revenue_by_mode(branch_id, date, "cash"),
                "card": await self._revenue_by_mode(branch_id, date, "card"),
                "upi": await self._revenue_by_mode(branch_id, date, "upi"),
                "pending": await self._pending_payments(branch_id, date),
            },
            "staff": {
                "clocked_in": await self._active_staff_count(branch_id),
                "total_assigned": await self._assigned_staff_count(branch_id),
            }
        }

    async def get_hospital_comparison(self, hospital_id: UUID, date: str) -> list:
        """Compare all branches of a hospital."""
        branches = await self._get_active_branches(hospital_id)
        reports = []
        for branch in branches:
            reports.append(await self.get_daily_report(branch["id"], date))
        return reports
```

---

## 10. KEY DESIGN DECISIONS

| Decision | Choice | Rationale |
|----------|--------|-----------|
| Patient data model | Single global record with branch-scoped visits | One patient, one record. No merging headaches. Visit notes naturally scoped. |
| Queue isolation | Per-branch | Each branch has its own queue. No cross-branch queue interference. |
| Inventory model | Central catalog + branch-level stock | Efficient procurement. Per-branch accountability. |
| Staff assignment | Primary + secondary + float | Flexible staffing without full cross-branch access. |
| Branch routing | Nearest + load-balanced + manual | Multiple strategies for different use cases. |
| Analytics | Real-time per-branch + daily rollup | Branch managers need live data. HQ needs daily comparison. |
| Geocoding | Pincode-based lat/lng lookup | Works reliably in India. No need for full address geocoding. |

---

## 11. BRANCH OPEN/CLOSE PROCEDURE

### 11.1 Open Branch

1. Staff clocks in at branch (geofence check: must be within 50m of branch GPS coordinates)
2. System initializes daily counters: queue tokens reset to 0
3. Inventory check: low-stock items flagged
4. Morning shift staff list confirmed
5. Branch status set to `open` in Redis
6. Wait time display boards initialized

### 11.2 Close Branch

1. Final queue tokens processed (remaining transferred or marked as no-show)
2. Cash settlement: total cash collected verified against POS records
3. Daily revenue sheet generated
4. Branch status set to `closed` in Redis
5. End-of-day reports emailed to branch manager and hospital admin
6. All counters reset for next day
