---
file_id: "1004"
module_name: "Usage Limits"
version: "1.0"
status: "Draft"
phase: "Phase 10 — SaaS"
dependencies: ["1002_SUBSCRIPTION.md"]
related_files: ["1003_BILLING_PLAN.md"]
last_updated: "2026-07-09"
priority: "Medium"
ai_tags: ["ghos", "usage", "limits", "throttling", "rate-limit", "metering"]
---

# GHOS — Usage Limits

> **Every resource is finite. Limits protect system stability, ensure fair usage, and create upgrade motivation. Soft limits warn at 80%. Hard limits block at 100%. No data is ever lost — only new actions are prevented. Bursts are tolerated. Enterprise customers can override.**

---

## 1. LIMIT DEFINITION

### 1.1 Limits Table

Limits are stored per plan with soft and hard thresholds, configurable reset periods, and optional per-tenant overrides.

```sql
CREATE TABLE usage_limits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID NOT NULL REFERENCES billing_plans(id),
    resource VARCHAR(50) NOT NULL,                  -- 'branches', 'whatsapp_per_day', 'storage_mb'
    soft_limit INTEGER NOT NULL,                    -- 80% warning threshold
    hard_limit INTEGER NOT NULL,                    -- 100% absolute maximum
    unit VARCHAR(30) NOT NULL,                      -- 'count', 'messages', 'mb', 'calls'
    reset_period VARCHAR(20) NOT NULL               -- 'daily', 'monthly', 'cumulative'
        CHECK (reset_period IN ('daily', 'monthly', 'billing_cycle', 'cumulative')),
    is_metered BOOLEAN DEFAULT TRUE,                -- Track usage? Some limits are just caps
    overridable BOOLEAN DEFAULT TRUE,               -- Can tenant override be set?
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(plan_id, resource)
);
```

### 1.2 Per-Plan Limit Matrix

| Resource | Free | Pro | Enterprise | Unit | Reset |
|----------|------|-----|------------|------|-------|
| Branches | 1 (S:1, H:1) | 3 (S:2, H:3) | Unlimited (S:-, H:-) | count | Cumulative |
| Staff Accounts | 10 (S:8, H:10) | 50 (S:40, H:50) | Unlimited | count | Cumulative |
| WhatsApp/day | 0 (S:0, H:0) | 500 (S:400, H:500) | Unlimited | messages | Daily |
| SMS/day | 0 (S:0, H:0) | 100 (S:80, H:100) | Unlimited | messages | Daily |
| AI Calls/month | 0 (S:0, H:0) | 0 (S:0, H:0) | 1000 (S:800, H:1000) | calls | Monthly |
| Storage | 100MB (S:80, H:100) | 1GB (S:800MB, H:1GB) | 10GB (S:8GB, H:10GB) | mb | Cumulative |
| API Calls/day | 0 | 1000 (S:800, H:1000) | 10000 (S:8000, H:10000) | requests | Daily |
| Active Patients | Unlimited | Unlimited | Unlimited | count | N/A |
| Email Notifications/day | 100 | 500 | Unlimited | emails | Daily |

S = Soft limit (80%), H = Hard limit (100%)

### 1.3 Per-Tenant Override

Enterprise tenants can have custom limits. Overrides are stored in a separate table:

```sql
CREATE TABLE tenant_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    soft_limit INTEGER,                              -- NULL = use plan default
    hard_limit INTEGER,                              -- NULL = use plan default
    reason VARCHAR(255),                             -- 'enterprise_custom', 'promotional', 'temporary_boost'
    valid_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_until TIMESTAMPTZ,                         -- NULL = permanent
    created_by UUID REFERENCES staff_users(id),
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, resource, valid_from)
);
```

---

## 2. ENFORCEMENT ARCHITECTURE

### 2.1 Enforcement Flow

```
Action Request (e.g., send WhatsApp)
       |
       v
LimitEnforcer.check_limit(tenant_id, "whatsapp_per_day")
       |
       +----> Redis Counter Check (microseconds)
       |         |
       |         v
       |     Current usage vs hard limit
       |         |
       |    +----+----+
       |    |         |
       |    v         v
       |  Under     At/Over
       |  Limit    Hard Limit
       |    |         |
       |    |    +----+----+
       |    |    |         |
       |    v    v         v
       |  Allow  Block    Check Burst
       |    |    with      Allowance
       |    |    403 +        |
       |    |    Upgrade     (sliding
       |    |    CTA         window)
       |    |                 |
       |    +-------+---------+
       |            |
       |            v
       |         Allow or Block
       |
       v
  Increment Counter (Redis INCR)
       |
       v
  If usage >= soft_limit (80%):
     Fire alert (async, non-blocking)
       |
       v
  Action Executed
```

### 2.2 Enforcement Patterns

| Pattern | Description | Used For |
|---------|-------------|----------|
| **Pre-action check** | Check limit before allowing action | WhatsApp, SMS, AI calls, API calls |
| **Post-action check** | Check limit after action, retroactively block if exceeded | Storage (can't undo upload) |
| **State check** | Check current state against limit | Branches count, staff count |
| **Deferred check** | Periodic batch check | Storage audit, daily rollup |

---

## 3. SOFT LIMIT (80%)

### 3.1 Behavior at 80%

When usage crosses the soft limit threshold:
1. User sees a **warning toast** (non-blocking, dismissible) on the relevant screen
2. Admin dashboard shows a **yellow alert badge** on the usage card
3. **Email notification** sent to hospital admin (once per day, not on every increment)
4. **SMS alert** for critical resources (SMS balance, WhatsApp balance) — once per threshold crossing
5. Dashboard banner: "You've used 80% of your WhatsApp quota. Upgrade to Pro for unlimited."

### 3.2 Soft Limit Alert Service

```python
class SoftLimitAlerter:
    """Send notifications when usage crosses the soft limit threshold."""

    def __init__(self, redis_client, notification_service):
        self.redis = redis_client
        self.notifications = notification_service

    async def check_and_alert(self, tenant_id: UUID, resource: str,
                               current: int, soft_limit: int, hard_limit: int):
        """Alert if crossed soft limit, but only once per threshold."""
        if hard_limit == 0:
            return  # Feature not enabled for this plan

        percent = (current / hard_limit) * 100
        alert_key = f"alert:{tenant_id}:{resource}:soft_limit"

        if percent >= 80 and not await self.redis.get(alert_key):
            await self.redis.setex(alert_key, 86400, "1")  # Once per day
            await self._send_soft_limit_alert(tenant_id, resource, percent, current, hard_limit)

        # Alert at 90% too
        alert_key_90 = f"alert:{tenant_id}:{resource}:90pct"
        if percent >= 90 and not await self.redis.get(alert_key_90):
            await self.redis.setex(alert_key_90, 43200, "1")  # Once per 12h
            await self._send_critical_alert(tenant_id, resource, percent, current, hard_limit)

    async def _send_soft_limit_alert(self, tenant_id, resource, percent, current, limit):
        """Send email and in-app notification."""
        resource_name = resource.replace("_", " ").title()
        tenant = await self._get_tenant(tenant_id)

        # In-app notification
        await self.notifications.send_in_app(tenant_id, {
            "title": f"{resource_name} Usage Warning",
            "message": f"You have used {int(percent)}% of your {resource_name} limit "
                       f"({current}/{limit}). Upgrade to avoid interruption.",
            "type": "usage_warning",
            "action_url": "/settings/billing"
        })

        # Email
        await self.notifications.send_email(
            to=tenant["admin_email"],
            subject=f"{resource_name} limit at {int(percent)}% — GHOS",
            template="usage_soft_limit.html",
            data={"resource": resource_name, "percent": int(percent),
                  "current": current, "limit": limit}
        )
```

---

## 4. HARD LIMIT (100%)

### 4.1 Behavior at 100%

When usage reaches or exceeds the hard limit:
1. **Action is blocked** with a friendly error message
2. Error includes **upgrade CTA button/link**
3. Admin dashboard shows **red alert badge** on the usage card
4. **No data is deleted or lost** — existing data remains accessible
5. Queued actions (e.g., scheduled WhatsApp messages) are **deferred** not dropped

### 4.2 Hard Limit Block

```python
class HardLimitBlocked(Exception):
    """Raised when a hard limit is exceeded."""
    def __init__(self, resource: str, current: int, limit: int, tenant_id: UUID):
        self.resource = resource
        self.current = current
        self.limit = limit
        self.tenant_id = tenant_id
        resource_name = resource.replace("_", " ").title()
        super().__init__(
            f"{resource_name} limit reached ({current}/{limit}). "
            f"Upgrade your plan to continue using this feature."
        )

    def to_response(self) -> dict:
        return {
            "error": "limit_exceeded",
            "resource": self.resource,
            "current": self.current,
            "limit": self.limit,
            "message": str(self),
            "upgrade_url": "/settings/billing",
            "upgrade_required": True
        }
```

### 4.3 Admin Override (Enterprise)

Enterprise tenants can request a temporary override:

```python
async def admin_override_limit(tenant_id: UUID, resource: str,
                                 new_limit: int, reason: str, duration_hours: int):
    """Admin can temporarily raise a limit for enterprise tenants."""
    tenant = await get_tenant(tenant_id)
    if tenant["plan_slug"] != "enterprise":
        raise PermissionError("Override only available for Enterprise plans")

    override = await db.execute("""
        INSERT INTO tenant_overrides
            (tenant_id, resource, hard_limit, reason, valid_from, valid_until)
        VALUES ($1, $2, $3, $4, NOW(), NOW() + make_interval(hours => $5))
        RETURNING id
    """, tenant_id, resource, new_limit, reason, duration_hours)

    # Invalidate cached limits
    await redis.delete(f"limits:{tenant_id}:{resource}")

    return {"override_id": str(override["id"]), "new_limit": new_limit,
            "expires_at": (datetime.utcnow() + timedelta(hours=duration_hours)).isoformat()}
```

### 4.4 Graceful Degradation per Resource

| Resource | Hard Limit Behavior | Degradation Path |
|----------|--------------------|-------------------|
| WhatsApp/day | Block sending new WhatsApp messages | Show "Send via SMS" fallback, or schedule for next day |
| SMS/day | Block sending new SMS | Suggest WhatsApp or email as alternative |
| AI calls | Block new AI calls | Fallback to manual receptionist, or show "AI busy" message |
| Storage | Block uploads (no new files) | Show storage cleanup tool, suggest upgrade |
| Branches | Block creating new branches | Deactivate option grayed out with upgrade prompt |
| Staff | Block adding new staff | Show staff count management, suggest upgrade |
| API calls | Return 429 Too Many Requests | Retry-After header included, upgrade prompt |

---

## 5. LIMIT RESET

### 5.1 Reset Rules

| Reset Period | Mechanism | Triggers |
|-------------|-----------|----------|
| **Daily** | Redis TTL + scheduled job | Midnight IST (00:00) — Redis keys expire, daily_usage counts reset |
| **Monthly** | Billing anniversary | Subscription.current_period_start — monthly counters reset |
| **Billing cycle** | Billing period | Same as monthly — resets on subscription renewal date |
| **Cumulative** | Never resets | Grows until plan upgrade (storage, branches, staff) |

### 5.2 Daily Limit Reset (Midnight IST)

```python
async def reset_daily_limits():
    """Reset daily usage counters at midnight IST (runs at 00:01 IST)."""
    # 1. Persist yesterday's final counts to DB
    await usage_tracker.persist_daily_usage()

    # 2. Clear daily Redis counters
    keys = await redis.keys("usage:*:daily:*")
    yesterday = (date.today() - timedelta(days=1)).isoformat()
    todays_keys = [k for k in keys if yesterday not in k]
    # Delete only yesterday's keys (today's keys are already current day)
    yesterday_keys = [k for k in keys if yesterday in k]
    if yesterday_keys:
        await redis.delete(*yesterday_keys)

    # 3. Log reset event
    await log_audit("usage_limits", "daily_reset", {"keys_cleared": len(yesterday_keys)})
```

### 5.3 Monthly Limit Reset

```python
async def reset_monthly_limits():
    """Reset monthly usage for tenants whose billing period starts today."""
    today = date.today()
    tenants = await db.fetch("""
        SELECT tenant_id FROM subscriptions
        WHERE current_period_start = $1 AND status = 'active'
    """, today)

    for row in tenants:
        keys = await redis.keys(f"usage:{row['tenant_id']}:*:monthly:*")
        if keys:
            await redis.delete(*keys)
        logger.info(f"Reset monthly counters for tenant {row['tenant_id']}")
```

---

## 6. BURST ALLOWANCE

### 6.1 Burst Policy

Short bursts above the hard limit are allowed to handle traffic spikes:

| Parameter | Value | Description |
|-----------|-------|-------------|
| Burst percentage | 10% | Allowed overage above hard limit |
| Burst window | 5 minutes | Sliding window for burst measurement |
| Burst max per day | 3 bursts | Maximum number of burst events per day |
| Throttle after burst | 10 minutes | Cooling period after burst exhausted |

### 6.2 Sliding Window Burst Tracker

```python
class BurstAllowance:
    """Track burst usage with sliding window counter."""

    BURST_PERCENT = 0.10       # 10% above hard limit
    BURST_WINDOW_SECONDS = 300  # 5 minutes
    MAX_BURSTS_PER_DAY = 3
    COOLDOWN_SECONDS = 600      # 10 minutes

    def __init__(self, redis_client):
        self.redis = redis_client

    async def check_burst_available(self, tenant_id: UUID, resource: str,
                                      hard_limit: int, current: int) -> dict:
        """Check if burst allowance is available and applicable."""
        if current < hard_limit:
            return {"burst_needed": False, "allowed": True}

        burst_limit = int(hard_limit * (1 + self.BURST_PERCENT))

        if current >= burst_limit:
            return {"burst_needed": True, "allowed": False,
                    "reason": "Burst limit also exceeded"}

        # Check burst count for today
        burst_count_key = f"burst:{tenant_id}:{resource}:count:{date.today().isoformat()}"
        burst_count = int(await self.redis.get(burst_count_key) or 0)

        if burst_count >= self.MAX_BURSTS_PER_DAY:
            return {"burst_needed": True, "allowed": False,
                    "reason": "Daily burst limit reached"}

        # Check cooldown
        cooldown_key = f"burst:{tenant_id}:{resource}:cooldown"
        cooldown_ttl = await self.redis.ttl(cooldown_key)
        if cooldown_ttl > 0:
            return {"burst_needed": True, "allowed": False,
                    "reason": f"Cooldown active for {cooldown_ttl}s"}

        return {"burst_needed": True, "allowed": True, "burst_limit": burst_limit}

    async def consume_burst(self, tenant_id: UUID, resource: str):
        """Record burst usage and start cooldown."""
        today = date.today().isoformat()
        burst_count_key = f"burst:{tenant_id}:{resource}:count:{today}"
        cooldown_key = f"burst:{tenant_id}:{resource}:cooldown"

        await self.redis.incr(burst_count_key)
        await self.redis.expire(burst_count_key, 86400)  # Expire at end of day
        await self.redis.setex(cooldown_key, self.COOLDOWN_SECONDS, "1")
```

---

## 7. USAGE ANALYTICS

### 7.1 Limit Consumption Dashboard

Gauge charts showing usage vs limits:

```
WHATSAPP (Daily)
[========80%============]  400 / 500
Soft limit: 400 | Hard limit: 500 | Reset: Midnight IST

STORAGE (Cumulative)
[==45%==================]  450MB / 1GB
Soft limit: 800MB | Hard limit: 1GB | Reset: Never (upgrade to expand)

AI CALLS (Monthly)
[===50%=================]  500 / 1000
Soft limit: 800 | Hard limit: 1000 | Reset: July 15, 2026
```

### 7.2 Forecasting

```python
class UsageForecaster:
    """Predict when usage will hit limits based on trends."""

    async def forecast(self, tenant_id: UUID, resource: str,
                        days_history: int = 30) -> dict:
        """Forecast when the tenant will hit their hard limit."""
        limit = await self._get_hard_limit(tenant_id, resource)
        if limit is None or limit <= 0:
            return {"forecast_days": None, "trend": "stable"}

        usage_data = await self._get_usage_history(tenant_id, resource, days_history)
        if not usage_data:
            return {"forecast_days": None, "trend": "insufficient_data"}

        # Calculate daily average over the period
        daily_avg = sum(usage_data) / len(usage_data)
        if daily_avg == 0:
            return {"forecast_days": None, "trend": "no_usage"}

        current = await usage_tracker.get_usage(tenant_id, resource)
        remaining = max(0, limit - current)
        forecast_days = int(remaining / daily_avg) if daily_avg > 0 else None

        # Trend direction
        recent_avg = sum(usage_data[-7:]) / min(7, len(usage_data))
        trend = "increasing" if recent_avg > daily_avg else (
            "decreasing" if recent_avg < daily_avg else "stable"
        )

        return {
            "resource": resource,
            "current": current,
            "limit": limit,
            "usage_percent": round((current / limit) * 100, 1),
            "daily_avg": round(daily_avg, 1),
            "forecast_days": forecast_days,
            "forecast_date": (date.today() + timedelta(days=forecast_days)).isoformat()
                if forecast_days else None,
            "trend": trend,
            "recommendation": self._get_recommendation(resource, forecast_days, trend)
        }

    def _get_recommendation(self, resource: str, forecast_days: int,
                              trend: str) -> str:
        """Generate an upgrade recommendation."""
        if forecast_days is None:
            return "No upgrade needed."
        if forecast_days <= 7:
            return f"You'll hit your {resource.replace('_', ' ')} limit in {forecast_days} days. "
                   f"Upgrade to Pro for higher limits."
        elif forecast_days <= 30:
            return f"Trending to hit {resource.replace('_', ' ')} limit in ~{forecast_days} days. "
                   f"Consider upgrading."
        return "Usage is within comfortable range."
```

### 7.3 Aggregated Usage Report (Admin)

```python
class UsageAggregator:
    """Generate daily usage reports and forecasting for all tenants."""

    async def daily_rollup(self):
        """Generate daily usage rollup for all active tenants."""
        tenants = await db.fetch("SELECT id, plan_id FROM tenants WHERE status = 'active'")
        for tenant in tenants:
            for resource in ["whatsapp_per_day", "sms_per_day", "ai_calls_per_month",
                             "storage_mb", "api_calls_per_day"]:
                status = await usage_tracker.check_limit(tenant["id"], resource)
                if status["usage_percent"] >= 80:
                    await self._send_daily_report(tenant["id"], [status])

    async def get_tenant_usage_summary(self, tenant_id: UUID) -> dict:
        """Full usage summary for a tenant."""
        resources = ["branches", "staff_accounts", "whatsapp_per_day", "sms_per_day",
                     "ai_calls_per_month", "storage_mb", "api_calls_per_day"]
        summary = {}
        for resource in resources:
            status = await usage_tracker.check_limit(tenant_id, resource)
            forecast = await UsageForecaster().forecast(tenant_id, resource)
            summary[resource] = {**status, "forecast": forecast}
        return summary
```

---

## 8. COMPLETE DATABASE SCHEMA

```sql
-- ============================================================
-- USAGE LIMITS (plan-level definitions)
-- ============================================================
CREATE TABLE usage_limits (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    plan_id UUID NOT NULL REFERENCES billing_plans(id),
    resource VARCHAR(50) NOT NULL,
    soft_limit INTEGER NOT NULL,
    hard_limit INTEGER NOT NULL,
    unit VARCHAR(30) NOT NULL,
    reset_period VARCHAR(20) NOT NULL CHECK (reset_period IN ('daily', 'monthly', 'billing_cycle', 'cumulative')),
    is_metered BOOLEAN DEFAULT TRUE,
    overridable BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(plan_id, resource)
);

-- ============================================================
-- TENANT OVERRIDES (per-tenant custom limits)
-- ============================================================
CREATE TABLE tenant_overrides (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    soft_limit INTEGER,
    hard_limit INTEGER,
    reason VARCHAR(255),
    valid_from TIMESTAMPTZ NOT NULL DEFAULT NOW(),
    valid_until TIMESTAMPTZ,
    created_by UUID,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, resource, valid_from)
);

-- ============================================================
-- USAGE COUNTERS (persisted from Redis)
-- ============================================================
CREATE TABLE usage_counters (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    period_type VARCHAR(20) NOT NULL CHECK (period_type IN ('daily', 'monthly', 'cumulative')),
    period_key VARCHAR(30) NOT NULL,             -- '2026-07-09' for daily, '2026-07' for monthly
    counter BIGINT NOT NULL DEFAULT 0,
    updated_at TIMESTAMPTZ DEFAULT NOW(),
    UNIQUE(tenant_id, resource, period_type, period_key)
);

-- ============================================================
-- USAGE ALERTS (log of sent alerts)
-- ============================================================
CREATE TABLE usage_alerts (
    id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    tenant_id UUID NOT NULL REFERENCES tenants(id),
    resource VARCHAR(50) NOT NULL,
    alert_type VARCHAR(20) NOT NULL CHECK (alert_type IN ('soft_80', 'soft_90', 'hard_100', 'burst', 'forecast')),
    threshold_value INTEGER NOT NULL,
    current_value INTEGER NOT NULL,
    channel VARCHAR(20) NOT NULL,                 -- 'email', 'sms', 'in_app'
    sent_at TIMESTAMPTZ DEFAULT NOW()
);

-- ============================================================
-- INDEXES
-- ============================================================
CREATE INDEX idx_usage_limits_plan ON usage_limits(plan_id, resource);
CREATE INDEX idx_tenant_overrides_tenant ON tenant_overrides(tenant_id, resource);
CREATE INDEX idx_usage_counters_lookup ON usage_counters(tenant_id, resource, period_type, period_key);
CREATE INDEX idx_usage_alerts_tenant ON usage_alerts(tenant_id, created_at DESC);
```

---

## 9. PYTHON IMPLEMENTATION

### 9.1 LimitEnforcer

```python
class LimitEnforcer:
    """Core enforcement engine for usage limits."""

    def __init__(self, redis_client, db_pool, notification_service):
        self.redis = redis_client
        self.db = db_pool
        self.tracker = UsageTracker(redis_client, db_pool)
        self.alerter = SoftLimitAlerter(redis_client, notification_service)
        self.burst = BurstAllowance(redis_client)

    async def check_limit(self, tenant_id: UUID, resource: str,
                           increment: int = 0) -> dict:
        """Check if action is within limits. Optionally increment counter."""
        plan = await self._get_tenant_plan(tenant_id)

        # Get effective limit (check override first)
        limit = await self._get_effective_limit(tenant_id, resource, plan)
        if limit["hard_limit"] == 0:
            return {"allowed": False, "reason": "Feature not available on your plan",
                    "upgrade_required": True}

        current = await self.tracker.get_usage(tenant_id, resource,
                                                  period=limit["reset_period"])

        # Check hard limit
        if current + increment > limit["hard_limit"]:
            # Check burst allowance
            burst = await self.burst.check_burst_available(
                tenant_id, resource, limit["hard_limit"], current + increment
            )
            if not burst["allowed"]:
                return {"allowed": False, "reason": burst.get("reason", "Hard limit exceeded"),
                        "current": current, "limit": limit["hard_limit"],
                        "burst_exhausted": burst.get("burst_needed", False)}
            # Allow with burst
            await self.burst.consume_burst(tenant_id, resource)
            if increment:
                await self.tracker.increment(tenant_id, resource, increment)
            return {"allowed": True, "burst": True, "current": current + increment}

        # Increment if requested (pre-action increment)
        if increment:
            new_count = await self.tracker.increment(tenant_id, resource, increment)
        else:
            new_count = current

        # Check soft limit (async, non-blocking)
        if new_count >= limit["soft_limit"]:
            asyncio.ensure_future(self.alerter.check_and_alert(
                tenant_id, resource, new_count, limit["soft_limit"], limit["hard_limit"]
            ))

        return {"allowed": True, "current": new_count, "limit": limit["hard_limit"],
                "usage_percent": round((new_count / limit["hard_limit"]) * 100, 1)
                    if limit["hard_limit"] > 0 else 0}

    async def enforce(self, tenant_id: UUID, resource: str,
                       increment: int = 1):
        """Check limit and raise if blocked. Safe for FastAPI endpoints."""
        result = await self.check_limit(tenant_id, resource, increment)
        if not result["allowed"]:
            raise HTTPException(
                status_code=429 if resource == "api_calls_per_day" else 402,
                detail=result
            )
        return result

    async def get_usage_percentage(self, tenant_id: UUID, resource: str) -> float:
        """Get usage as a percentage of hard limit (0-100+)."""
        plan = await self._get_tenant_plan(tenant_id)
        limit = await self._get_effective_limit(tenant_id, resource, plan)
        if limit["hard_limit"] <= 0:
            return 0.0
        current = await self.tracker.get_usage(tenant_id, resource,
                                                  period=limit["reset_period"])
        return round((current / limit["hard_limit"]) * 100, 1)

    async def _get_effective_limit(self, tenant_id, resource, plan) -> dict:
        """Get limit with tenant override support. Cached in Redis."""
        cache_key = f"limits:{tenant_id}:{resource}"
        cached = await self.redis.get(cache_key)
        if cached:
            return json.loads(cached)

        # Get plan default limit
        plan_limit = await db.fetchrow(
            "SELECT soft_limit, hard_limit, reset_period FROM usage_limits WHERE plan_id = $1 AND resource = $2",
            plan["id"], resource
        )
        if not plan_limit:
            return {"soft_limit": 0, "hard_limit": 0, "reset_period": "cumulative"}

        soft, hard = plan_limit["soft_limit"], plan_limit["hard_limit"]
        reset = plan_limit["reset_period"]

        # Check tenant override
        override = await db.fetchrow("""
            SELECT soft_limit, hard_limit FROM tenant_overrides
            WHERE tenant_id = $1 AND resource = $2
            AND valid_from <= NOW() AND (valid_until IS NULL OR valid_until > NOW())
            ORDER BY valid_from DESC LIMIT 1
        """, tenant_id, resource)

        if override:
            soft = override["soft_limit"] or soft
            hard = override["hard_limit"] or hard

        result = {"soft_limit": soft, "hard_limit": hard, "reset_period": reset}
        await self.redis.setex(cache_key, 60, json.dumps(result))
        return result
```

### 9.2 UsageAggregator

```python
class UsageAggregator:
    """Aggregate usage data for reporting and forecasting."""

    async def daily_rollup(self):
        """Persist daily counters to DB and check thresholds."""
        # Flush Redis -> usage_counters table
        keys = await self.redis.keys("usage:*:daily:*")
        for key in keys:
            parts = key.split(":")
            tenant_id, resource, date_str = parts[1], parts[2], parts[4]
            count = int(await self.redis.get(key))
            await self.db.execute("""
                INSERT INTO usage_counters (tenant_id, resource, period_type, period_key, counter)
                VALUES ($1, $2, 'daily', $3, $4)
                ON CONFLICT (tenant_id, resource, period_type, period_key)
                DO UPDATE SET counter = EXCLUDED.counter, updated_at = NOW()
            """, tenant_id, resource, date_str, count)
        await self._check_all_thresholds()

    async def forecasting(self, tenant_id: UUID) -> list:
        """Return forecast for all resources."""
        forecaster = UsageForecaster()
        resources = ["whatsapp_per_day", "sms_per_day", "ai_calls_per_month",
                     "storage_mb", "api_calls_per_day"]
        forecasts = []
        for resource in resources:
            f = await forecaster.forecast(tenant_id, resource)
            if f["forecast_days"] and f["forecast_days"] <= 30:
                forecasts.append(f)
        return forecasts
```

---

## 10. LIMIT CHECK MIDDLEWARE

```python
from fastapi import Request, HTTPException
from starlette.middleware.base import BaseHTTPMiddleware

class UsageLimitMiddleware(BaseHTTPMiddleware):
    """Automatically check usage limits on decorated endpoints."""

    RESOURCE_MAP = {
        "POST:/api/v1/whatsapp/send": "whatsapp_per_day",
        "POST:/api/v1/sms/send": "sms_per_day",
        "POST:/api/v1/ai/receptionist": "ai_calls_per_month",
        "POST:/api/v1/upload": "storage_mb",
        "POST:/api/v1/branches": "branches",
        "POST:/api/v1/staff": "staff_accounts",
    }

    async def dispatch(self, request: Request, call_next):
        route_key = f"{request.method}:{request.url.path}"
        resource = self.RESOURCE_MAP.get(route_key)

        if resource and hasattr(request.state, "tenant"):
            enforcer = LimitEnforcer(request.state.redis, request.state.db_pool, None)
            try:
                await enforcer.enforce(request.state.tenant["tenant_id"], resource)
            except HTTPException:
                # Allow through — middleware only logs warnings
                # Actual enforcement happens in the endpoint via decorator
                pass

        response = await call_next(request)
        return response
```

---

## 11. SCHEDULED JOBS

| Job | Frequency | Description |
|-----|-----------|-------------|
| Daily limit reset | Daily 00:01 IST | Clear daily Redis counters, persist final counts |
| Monthly limit reset | Daily 00:05 IST | Reset monthly counters for tenants with new billing period |
| Soft limit alerts | Every 15 min | Check all tenants for soft limit crossings (recently active) |
| Usage forecasting | Daily 02:00 IST | Generate trend analysis for tenants near limits |
| Burst cooldown cleanup | Every hour | Clean up expired burst cooldown keys |
| Daily report generation | Daily 06:00 IST | Email usage summary to admins at 80%+ for any resource |
| Override expiry | Hourly | Deactivate expired tenant_overrides, clear cache |
