---
file_id: "1203"
module_name: "Global Expansion Strategy"
version: "2.0"
status: "Draft"
phase: "Phase 12 - Future"
dependencies: ["1200_ROADMAP.md"]
related_files: ["1201_PRODUCT_IDEAS.md", "1202_AI_IDEAS.md"]
last_updated: "2026-07-09"
priority: "Low"
ai_tags: ["ghos", "global", "expansion", "localization", "international"]
---

# GHOS — Global Expansion Strategy

> **"Think global, act local — adapt to each market's regulatory, linguistic, and workflow realities."**
> GHOS's global expansion is not about transplanting an Indian product into foreign markets. It's about understanding each market's healthcare ecosystem deeply and building a version of GHOS that feels native to that market.

---

## 1. EXPANSION PHILOSOPHY

### Core Tenets
1. **Market-first, product-second:** Enter a market only when we deeply understand its regulatory, payment, and workflow landscape
2. **Local partners first:** Never enter a market without a local implementation partner who understands the terrain
3. **Offline matters:** Many target markets have unreliable internet — GHOS must work offline-first in these regions
4. **Local compliance is non-negotiable:** Full regulatory compliance before launching in any market
5. **Pricing for purchasing power:** Price according to local PPP, not US/SaaS benchmarks
6. **Language is culture:** Translation is not enough — workflows, terminology, and UX must feel native

### Expansion Readiness Criteria
Before entering any new market, GHOS must meet these thresholds:

| Criterion | Requirement | Verification |
|-----------|-------------|--------------|
| Market size | > 10M population, > 40% smartphone penetration | World Bank / GSMA data |
| Private healthcare | Growing private clinic/hospital sector | Industry reports |
| Regulatory environment | Navigable for SaaS health-tech | Legal review |
| Language feasibility | English + 1 local language deployable | Linguist assessment |
| Payment infrastructure | Digital payments feasible | Local payment partner |
| Internet reliability | > 50% clinics have reliable internet | Ookla / local data |
| Competitive landscape | No dominant player with equivalent features | Market research |

---

## 2. PHASE 1 — INDIA (2026-2027)

### Market Profile
| Parameter | Detail |
|-----------|--------|
| Population | 1.4B |
| Clinics (target segment) | 200,000+ small-to-mid-size private clinics |
| Smartphone penetration | 65%+ and growing |
| Internet reliability | Major cities: 95%+; Tier 2-3: 70-80% |
| Regulatory framework | DPDP Act 2023, ABDM, CDSCO |
| Payment landscape | UPI dominant (80%+ digital payments) |
| Competition | Practo, QMe, DocPulse, MyClinic |
| GHOS advantage | Free tier, deep India workflows, AI features |

### India-Specific Features
| Feature | Status | Priority |
|---------|--------|----------|
| Hindi + English UI | Phase 1 (Q3 2026) | Critical |
| Regional languages (Tamil, Telugu, Kannada, Malayalam, Marathi, Gujarati, Bengali, Punjabi) | Phase 2 (Q4 2026) | High |
| Razorpay / PhonePe payment integration | Phase 1 | Critical |
| UPI QR code on bills | Phase 1 | High |
| GST-compliant invoicing | Phase 3 (Q1 2027) | Critical |
| Ayushman Bharat PM-JAY integration | 2028+ | Strategic |
| ABDM (Ayushman Bharat Digital Mission) — ABHA, HIP/HIU | Phase 5 (H2 2027) | High |
| Indian numbering system (lakh/crore) | Phase 1 | Medium |
| Indian holiday calendar | Phase 1 | Low |
| Indian drug database (generic + brand names) | Phase 2 | High |
| Aadhaar-based patient lookup (opt-in) | Phase 2 | Medium |

### India Rollout Plan
| Stage | Timeline | Cities | Clinic Target | Focus |
|-------|----------|--------|---------------|-------|
| Alpha | Q3 2026 | Bangalore, Mumbai | 10 | Core queue management |
| Beta | Q4 2026 | Top 10 cities | 50 | Clinical modules |
| Growth | Q1 2027 | Top 30 cities | 200 | Multi-branch, billing |
| Scale | Q2 2027 | Top 50 cities | 500 | AI features |
| Mass | H2 2027 | Pan-India | 1,000 | Full product suite |
| Dominance | 2028 | All India | 5,000+ | Enterprise + government |

### India Target: 5,000+ clinics by end of 2028

---

## 3. PHASE 2 — SEA + MIDDLE EAST (2028)

### 3.1 Southeast Asia

#### Priority Market Assessment

| Market | Population | Smartphone | Private Healthcare | Regulatory | Payment | GHOS Fit |
|--------|-----------|------------|-------------------|------------|---------|----------|
| Indonesia | 275M | 65% | Growing (50% private) | BPJS (universal coverage) | GoPay, OVO, Dana | High — large market, private clinics growing |
| Malaysia | 33M | 80% | Strong private sector | MOH Malaysia | Touch 'n Go, GrabPay | High — English proficient, strong economy |
| Thailand | 70M | 75% | Medical tourism hub | Thai FDA | PromptPay, TrueMoney | High — medical tourism synergy |
| Vietnam | 98M | 70% | Rapidly growing private | MOH Vietnam | MoMo, ZaloPay | Medium — high growth, but fragmented |
| Philippines | 115M | 65% | Growing, US-influenced | DOH Philippines | GCash, PayMaya | Medium — English speaking, but low healthcare spend |
| Singapore | 5.6M | 90% | Mature, expensive | MOH Singapore | PayNow, GrabPay | Low — small market, high competition |

#### Primary Targets (2028)
1. **Indonesia** — Large population, growing private clinic market, BPJS creates demand for clinic management
2. **Malaysia** — English proficient, strong economy, good APAC beachhead
3. **Thailand** — Medical tourism hub, synergy with India-clinic base

#### Localization Requirements
| Element | Indonesia | Malaysia | Thailand |
|---------|-----------|----------|----------|
| Language | Bahasa Indonesia | Bahasa Melayu (English fallback) | Thai script |
| Number format | 1.234,56 (European) | 1,234.56 (Western) | 1,234.56 (Western) |
| Currency | IDR (Rp) | MYR (RM) | THB (Bt) |
| Date format | DD/MM/YYYY | DD/MM/YYYY | DD/MM/YYYY (Buddhist year) |
| Medical terms | Bahasa medical terminology | English medical terms prevail | Thai medical terminology |
| Payment gateways | GoPay, OVO, Dana | Touch 'n Go, GrabPay | PromptPay, TrueMoney |

#### Compliance Requirements
| Market | Regulatory Body | Key Requirements | Data Residency |
|--------|----------------|-----------------|---------------|
| Indonesia | MoH Indonesia, Kominfo | BPJS Kesehatan integration, PDP Law compliance | In-country required |
| Malaysia | MOH Malaysia, MDEC | Private Healthcare Facilities Act, Personal Data Protection Act | In-country recommended |
| Thailand | Thai FDA, MoPH | Health Data Protection Act, Medical Device registration | In-country required for health data |

#### Engagement Model
| Aspect | SEA Strategy |
|--------|-------------|
| Entry mode | Local distributor/reseller partnership |
| Implementation partner | Local IT services firm with clinic network |
| Pricing | $29/mo (Pro tier) |
| Sales approach | Direct to clinic chains, partner-assisted for SMB |
| Support | Local language support via partner, GHOS remote escalation |
| Payment processing | Local payment gateway integration via partner |

**Target:** 300 clinics across SEA (150 Indonesia, 100 Malaysia, 50 Thailand)

---

### 3.2 Middle East

#### Priority Market Assessment

| Market | Population | Smartphone | Private Healthcare | Regulatory | Payment | GHOS Fit |
|--------|-----------|------------|-------------------|------------|---------|----------|
| UAE | 10M | 95% | 80%+ private | DHA, HAAD, DHD | Apple Pay, card, buy now pay later | High — wealthy market, stringent compliance |
| Saudi Arabia | 35M | 90% | Growing (Vision 2030) | Saudi MoH, CCHI | Mada, STC Pay | High — massive healthcare investment |
| Qatar | 2.8M | 90% | Mostly private | MoPH Qatar | QNB, card | Medium — small market |
| Kuwait | 4.3M | 85% | Mixed public/private | MoH Kuwait | KNET | Low — small, public-dominant |
| Oman | 4.5M | 80% | Growing | MoH Oman | card, mobile | Low — small market |

#### Primary Targets (2028)
1. **UAE** — Highest per-capita healthcare spend, DHA regulations are a moat for compliant players
2. **Saudi Arabia** — Vision 2030 is privatizing healthcare, massive market opening up

#### Localization Requirements
| Element | UAE | Saudi Arabia |
|---------|-----|-------------|
| Language | Arabic + English | Arabic + English |
| Number format | 1,234.56 | 1,234.56 (Arabic-Indic digits optional) |
| Currency | AED (Dh) | SAR (SR) |
| Date format | DD/MM/YYYY | DD/MM/YYYY (Islamic calendar optional) |
| Medical terms | English medical terms standard | English medical terms standard |
| Payment gateways | Card (Visa/MC), BNPL (Tabby, Tamara), Apple Pay | Mada, STC Pay, BNPL (Tamara) |
| Week start | Sunday (UAE: Monday for some) | Sunday |

#### Compliance Requirements
**UAE — Dubai Health Authority (DHA)**
- DHA licensing for any health data processing
- DHA Data Protection Regulation (similar to GDPR)
- Electronic Medical Record system certification
- Data must be hosted in UAE (or DHA-approved cloud)
- Patient consent management for data sharing
- Audit trail for all health data access

**Saudi Arabia — Ministry of Health (MoH) / CCHI**
- CCHI (Council for Cooperative Health Insurance) compliance
- PDPL (Personal Data Protection Law) — enacted 2022
- Health data must remain in Saudi Arabia
- NPHIES (National Platform for Health and Insurance Exchange Services) integration
- Sehhaty app integration for patient portal

**Target:** 200 clinics across Middle East (100 UAE, 100 Saudi Arabia)

---

## 4. PHASE 3 — AFRICA (2029-2030)

### Market Assessment

| Market | Population | Smartphone | Internet Reliability | Private Healthcare | Language | GHOS Fit |
|--------|-----------|------------|---------------------|-------------------|----------|----------|
| Nigeria | 220M | 40% | 40-50% reliable | Growing (60%+ private) | English, Hausa, Yoruba | High — massive population, private clinic ecosystem |
| Kenya | 55M | 55% | 50-60% reliable | Strong private sector | English, Swahili | High — M-Pesa ecosystem, strong startup scene |
| South Africa | 60M | 60% | 60-70% reliable | Developed private sector | English, Zulu, Afrikaans | Medium — developed but competitive |
| Ghana | 33M | 45% | 40-50% reliable | Growing | English, Twi | Medium — stable, but small |
| Ethiopia | 120M | 20% | < 30% reliable | Very limited private | Amharic, Oromo | Low — too early, offline-only needed |

### Primary Targets
1. **Nigeria** — Largest population, growing private clinics, English speaking
2. **Kenya** — Strong tech ecosystem, M-Pesa for payments, English + Swahili
3. **South Africa** — Developed private healthcare market, potential for premium

### Africa-Specific Architecture

**Offline-First is Mandatory**
```
[Clinic Local Server]
    |--- GHOS core (queue, registration, basic billing)
    |--- SQLite local database
    |--- ONNX runtime for basic AI features (offline)
    |--- Local LAN for multi-workstation clinics
    |
    v
[Sync Engine] — When internet is available:
    |--- De-duplicated patient records sync to cloud
    |--- Prioritized sync: billing data first, then clinical, then analytics
    |--- Compression: 10:1 reduction for slow connections
    |--- Resume capability: handles interrupted syncs
    |
    v
[Cloud GHOS]
    |--- Centralized analytics
    |--- Backup and recovery
    |--- Remote support access
    |--- Software update distribution
```

**USSD Fallback** (For basic operations when smartphone not available)
```
Patient dials *123# 
    |
    v
USSD Menu:
    1. Get my token number
    2. Check appointment status
    3. Get clinic address/timing
    4. Speak to reception
    |
    v
Response via SMS with token number and instructions
```

#### Localization Requirements
| Element | Nigeria | Kenya | South Africa |
|---------|---------|-------|-------------|
| Language | English, Hausa, Yoruba, Igbo | English, Swahili | English, Zulu, Afrikaans |
| Payment | Bank transfer, cash, USSD | M-Pesa (90%+ digital) | Card, EFT, SnapScan |
| Internet | 40-50% reliable | 50-60% reliable | 60-70% reliable |
| Key feature | Offline-first, USSD fallback | M-Pesa integration | Medical aid scheme integration |
| Regulatory | NPHCDA, FMOH | KMPDC, MoH Kenya | SAHPRA, HPCSA |
| Data residency | In-country preferred | In-country preferred | In-country required (POPIA) |

**Target:** 200 clinics across Africa (100 Nigeria, 50 Kenya, 50 South Africa)

---

## 5. PHASE 4 — LATAM (2030+)

### Market Assessment

| Market | Population | Smartphone | Private Healthcare | Regulatory | GHOS Fit |
|--------|-----------|------------|-------------------|------------|----------|
| Brazil | 215M | 75% | Strong private (50M insured) | ANVISA, LGPD | High — large market, private healthcare culture |
| Mexico | 130M | 70% | Growing private (30M insured) | COFEPRIS, NOM standards | High — proximity to US, strong private clinics |
| Colombia | 52M | 65% | Growing private | INVIMA, MoH Colombia | Medium — growing but regulatory complexity |
| Argentina | 46M | 75% | Strong private, economic volatility | ANMAT | Low — economic instability |

### Primary Targets
1. **Brazil** — Largest LATAM market, strong private healthcare sector, LGPD compliance is a moat
2. **Mexico** — Growing clinic market, proximity to US market

#### Localization Requirements
| Element | Brazil | Mexico |
|---------|--------|--------|
| Language | Portuguese (Brazilian) | Spanish (Mexican) |
| Number format | 1.234,56 | 1,234.56 |
| Currency | BRL (R$) | MXN ($) |
| Date format | DD/MM/YYYY | DD/MM/YYYY |
| Payment | Pix (instant), Boleto, card | OXXO, SPEI, card |
| Medical terms | Portuguese medical terminology | Spanish medical terminology |
| Compliance | ANVISA (health regulator), LGPD (data protection) | COFEPRIS, NOM-024 (EHR standard) |

**Target:** 200 clinics across LATAM (150 Brazil, 50 Mexico)

---

## 6. LOCALIZATION STRATEGY

### Translation Pipeline
```
Phase 1 — Automated + Human Review:
    [i18n JSON files] 
        |--- Key: "reception.token_generated"
        |--- Value: "Token #{token} generated for {patient}"
        |
        v
    [Translation Management System] — Weblate or Locize
        |--- Auto-translate via LLM (Mistral + medical glossary)
        |--- Human reviewer (native speaker, medical background)
        |--- Context screenshots for translators
        |
        v
    [QA Process]
        |--- Automated: Key count matches source (no missing translations)
        |--- Automated: Placeholder count matches (no broken templates)
        |--- Manual: UX flow walkthrough by native speaker
        |
        v
    [Release]
        |--- Language pack embedded in build
        |--- Over-the-air updates for language packs
```

### Cultural Adaptation Checklist
| Element | Adaptation Required | Examples |
|---------|--------------------|----------|
| Color schemes | Avoid culturally sensitive colors | Red in China = luck, SA = danger; Green in Indonesia = sacred |
| Iconography | Replace culturally specific icons | Handshake icon may not translate; use universal symbols |
| Date formats | Locale-specific | Indian: DD/MM/YYYY, US: MM/DD/YYYY, Thai: Buddhist year |
| Time formats | 12h vs 24h | India: 12h, most others: 24h |
| Currency symbols | Native format | Rs, $, AED, SAR, Rp, RM |
| Number systems | Indian vs Western vs Arabic | India: 1,23,456; Arabic: Arabic-Indic digits |
| Names | Field order and validation | Indian names: Given + Father + Surname; Arabic: Long patronymic chains |
| Addresses | Locale-specific format | India: Area/City/State/Pin; UAE: Building/Street/Area/Emirate |
| Medical terminology | Local medical vocab | India: "BP" for blood pressure; UK: "obs" for observations |
| Holidays | Local holiday calendar | Diwali, Eid, Christmas, Chinese New Year |
| Week start | Sunday vs Monday | UAE: Sunday; most others: Monday |
| Prayer times | Muslim-majority countries | Show prayer break schedules in UAE/SA |

### i18n Technical Architecture
```
[Source of Truth]
    locale/en.json — English (base language)
    locale/hi.json — Hindi
    locale/ta.json — Tamil
    ...
    |
    v
[React i18next] — Client-side hydration
    |--- Namespaced: common.json, clinic.json, patient.json, billing.json
    |--- ICU MessageFormat for pluralization: {count} patient|{count} patients
    |--- Interpolation: "Hello, {{name}}" -> "Namaste, {{name}}"
    |--- Context-aware: "delete" in menu vs "delete" in confirmation dialog
    |
    v
[Backend]
    |--- All user-facing strings from backend use locale keys
    |--- Error messages are locale-aware
    |--- Reports generated in user's locale
    |--- PDF templates per locale
```

---

## 7. REGULATORY STRATEGY

### Per-Country Compliance Checklist Template

| Requirement | UAE | SA | ID | MY | NG | BR |
|-------------|-----|----|----|----|----|-----|
| Health data regulation | DHA Data Protection | PDPL | PDP Law | PDPA | NDPR | LGPD |
| Data residency required | Yes | Yes | Yes | Recommended | Recommended | Yes |
| Health tech registration | DHA license | MoH clearance | MoH registration | MDA registration | NPHCDA clearance | ANVISA registration |
| EHR certification | DHA EHR cert | NPHIES compliance | SatuSehat integration | MyHDW | No | TISS/PEP |
| Patient consent required | Yes | Yes | Yes | Yes | Yes | Yes |
| Audit logging required | Yes | Yes | Yes | Yes | Yes | Yes |
| Breach notification | 72 hours | 72 hours | 72 hours | PDPA timeline | NDPR timeline | 72 hours |
| Local representative | Required | Required | Required | Recommended | Recommended | Required |

### Legal Partner Network
| Region | Legal Partner Type | Coverage |
|--------|-------------------|----------|
| India | In-house legal | Full coverage |
| SEA | Local law firm per country | Regulatory, data protection, employment |
| Middle East | Regional law firm (e.g., Al Tamimi) | UAE, Saudi, Qatar |
| Africa | Local law firm per country | Nigeria, Kenya, South Africa |
| LATAM | Regional law firm | Brazil, Mexico |

---

## 8. PARTNERSHIP MODEL

### Distributor/Reseller Structure
```
GHOS (SaaS Product)
    |
    v
[Regional Distributor / Reseller]
    |--- Licensed to sell GHOS in specific territory
    |--- 30% revenue share to partner
    |--- Territory exclusivity (based on performance)
    |--- Non-exclusive for underperforming partners
    |
    v
[Implementation Partner]
    |--- Clinic onboarding, training, support (Level 1)
    |--- Localization and customization
    |--- Billed separately by partner (recommended pricing provided)
    |
    v
[End Clinic]
    |--- Pro tier pricing (varies by market)
    |--- Enterprise tier pricing (custom)
    |--- GHOS support: Level 2 and 3 escalation
```

### Partner Requirements
| Criterion | Minimum Requirement |
|-----------|-------------------|
| Healthcare IT experience | 3+ years in relevant market |
| Clinic network access | 50+ clinic relationships |
| Technical capability | Able to deploy Docker, configure network |
| Language capability | Native language + English |
| Support team | 5+ support staff for Level 1 |
| Financial stability | Bank guarantee for subscription commitment |

### Revenue Share Model
| Tier | Partner Share | GHOS Share | Partner Responsibilities |
|------|-------------|------------|------------------------|
| Pro ($29-49/mo) | 30% | 70% | Sales, onboarding, L1 support |
| Enterprise (custom) | 20% | 80% | Sales support, L1 support |
| Implementation services | 100% | 0% | All services revenue to partner |
| Add-ons (AI features) | 15% | 85% | L1 support for AI features |

---

## 9. PRICING BY MARKET

### Pro Tier Pricing (Local Currency)

| Market | Pro Tier (Local) | Pro Tier (USD eq.) | Enterprise Tier (USD eq.) | Basis |
|--------|-----------------|-------------------|--------------------------|-------|
| India | Rs 999/mo | $12/mo | $60/mo | Indian PPP adjustment |
| Indonesia | IDR 450,000/mo | $29/mo | $145/mo | SEA market pricing |
| Malaysia | MYR 129/mo | $29/mo | $145/mo | SEA market pricing |
| Thailand | THB 999/mo | $29/mo | $145/mo | SEA market pricing |
| UAE | AED 179/mo | $49/mo | $245/mo | Middle East premium |
| Saudi Arabia | SAR 184/mo | $49/mo | $245/mo | Middle East premium |
| Nigeria | NGN 29,000/mo | $19/mo | $95/mo | Africa PPP adjustment |
| Kenya | KES 2,500/mo | $19/mo | $95/mo | Africa PPP adjustment |
| South Africa | ZAR 349/mo | $19/mo | $95/mo | Africa PPP adjustment |
| Brazil | BRL 149/mo | $29/mo | $145/mo | LATAM market pricing |
| Mexico | MXN 499/mo | $29/mo | $145/mo | LATAM market pricing |

### Pricing Principles
| Principle | Rationale |
|-----------|-----------|
| PPP-adjusted | Price relative to local purchasing power, not US dollar |
| Competitive floor | Priced at or below local competitors |
| Free tier always | Free tier available in every market (basic queue + registration) |
| Local payment | Accept preferred local payment methods |
| Annual discount | 20% discount for annual commitment (in all markets) |
| No hidden fees | Transparent pricing — no per-patient or per-transaction fees |
| Volume discounts | For clinic chains (5+ branches): 15% discount |

---

## 10. EXPANSION TEAM STRUCTURE

### Central Expansion Team (India HQ)
| Role | Responsibility |
|------|---------------|
| VP International | Overall expansion strategy, partner negotiations |
| Localization Manager | i18n pipeline, cultural adaptation, translator management |
| Compliance Officer | Per-country regulatory tracking, legal partner coordination |
| International Support Lead | Multi-timezone support team management |
| Technical Lead - Intl | Multi-region infrastructure, local hosting, CDN strategy |

### In-Market Team (Per Region)
| Role | Full-time | Part-time / Contractor |
|------|-----------|----------------------|
| Country Manager | Yes | — |
| Implementation Specialist | Yes (first 6 months) | — |
| Support Engineer (L1) | Yes | — |
| Localization Reviewer | — | Contractor (native speaker) |
| Legal Counsel | — | Local law firm |
| Sales Representative | — | Partner-provided |

---

## 11. EXPANSION RISKS & MITIGATION

| Risk | Market | Probability | Impact | Mitigation |
|------|--------|------------|--------|------------|
| Regulatory delays | All (esp. UAE, SA) | Medium | Critical | Engage local legal 12 months before launch |
| Partner underperformance | SEA, Africa | High | High | Quarterly performance reviews, non-exclusive terms, multi-partner strategy |
| Payment integration complexity | Africa | High | Medium | Partner with fintech aggregators (Stripe, Paystack, Flutterwave) |
| Cultural misalignment | LATAM | Medium | High | Hire local cultural consultant, user testing with local clinics |
| Competition from local players | All | Medium | Medium | Differentiate on AI, India-proven workflows, free tier |
| Currency volatility | Africa, LATAM | Medium | Medium | Price in USD for enterprise, hedge via annual contracts |
| Internet reliability | Africa | High | High | Offline-first architecture, USSD fallback |
| Data residency cost | All (esp. UAE, SA) | Medium | Medium | Cloud provider's local zones, shared hosting for non-critical data |
