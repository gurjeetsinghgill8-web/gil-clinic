"""
GHOS Queue Engine — Configuration
====================================
Pydantic Settings loaded from environment variables.
"""

from pydantic_settings import BaseSettings
from typing import List, Optional
import json


class Settings(BaseSettings):
    # App
    app_name: str = "GHOS-Queue-Engine"
    version: str = "1.0.0"
    environment: str = "development"
    debug: bool = True
    log_level: str = "INFO"

    # CORS
    cors_origins: list = ["*"]

    # Database
    database_url: str = "postgresql+asyncpg://ghos:ghos_secret@localhost:5432/ghos_queue"
    database_pool_size: int = 10
    database_max_overflow: int = 20

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Server
    host: str = "0.0.0.0"
    port: int = 8002

    # Queue Engine
    default_avg_service_time_seconds: int = 600
    max_queue_depth: int = 100
    delay_warning_threshold_seconds: int = 300
    delay_critical_threshold_seconds: int = 600

    # Default departments (parsed from semicolon-separated string)
    default_departments: str = (
        "ECG,ECG,600,ECG Room 1,🫀;"
        "Echo,ECH,1200,Echo Room 1,🔬;"
        "TMT,TMT,1800,TMT Room 1,🏃;"
        "OPD,OPD,600,OPD Room 1,🩺;"
        "Reception,REC,300,Reception Desk,📋;"
        "Doctor,DOC,900,Doctor Room,👨‍⚕️;"
        "Pharmacy,PHA,300,Pharmacy Counter,💊;"
        "Lab,LAB,1200,Lab Room,🧪"
    )

    # Patient ID prefix
    patient_id_prefix: str = "GHOS"
    hospital_id: str = "default"
    branch_id: str = "main"

    @property
    def parsed_departments(self) -> List[dict]:
        """Parse default_departments string into list of dept dicts."""
        depts = []
        for item in self.default_departments.split(";"):
            parts = [p.strip() for p in item.split(",")]
            if len(parts) >= 5:
                depts.append({
                    "name": parts[0],
                    "short_code": parts[1],
                    "avg_time_seconds": int(parts[2]),
                    "room": parts[3],
                    "icon": parts[4],
                })
        return depts

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
