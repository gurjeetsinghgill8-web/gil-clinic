"""
GHOS Queue Engine — Delay Detection
======================================
Monitors department queues for delays and triggers alerts.

Delay is calculated as: elapsed_time_of_current - avg_service_time
- Warning threshold: 5 minutes (300s)
- Critical threshold: 10 minutes (600s)
"""

from datetime import datetime, timezone
from typing import Optional

from app.config import settings


class DelayResult:
    """Result of a delay check for a department."""

    def __init__(
        self,
        department_id: str,
        department_name: str,
        elapsed_seconds: int,
        avg_time_seconds: int,
        waiting_count: int,
        delay_seconds: int,
        severity: str,
    ):
        self.department_id = department_id
        self.department_name = department_name
        self.elapsed_seconds = elapsed_seconds
        self.avg_time_seconds = avg_time_seconds
        self.waiting_count = waiting_count
        self.delay_seconds = delay_seconds
        self.severity = severity  # "none" | "warning" | "critical"

    @property
    def delay_minutes(self) -> int:
        return self.delay_seconds // 60

    def to_dict(self) -> dict:
        return {
            "department_id": self.department_id,
            "department_name": self.department_name,
            "delay_minutes": self.delay_minutes,
            "delay_seconds": self.delay_seconds,
            "waiting_count": self.waiting_count,
            "severity": self.severity,
            "elapsed_seconds": self.elapsed_seconds,
            "avg_time_seconds": self.avg_time_seconds,
        }


def check_delay(
    department_id: str,
    department_name: str,
    called_at: Optional[datetime],
    avg_time_seconds: int,
    waiting_count: int,
) -> Optional[DelayResult]:
    """
    Check if a department is running behind schedule.

    Args:
        department_id: UUID of the department
        department_name: Display name of the department
        called_at: When the current patient was called (None if no current patient)
        avg_time_seconds: Average service time for this department
        waiting_count: Number of patients waiting in queue

    Returns:
        DelayResult if delay detected, None otherwise
    """
    if called_at is None:
        return None

    now = datetime.now(timezone.utc)
    elapsed_seconds = int((now - called_at).total_seconds())
    delay_seconds = elapsed_seconds - avg_time_seconds

    if delay_seconds <= 0:
        return None

    # Determine severity
    if delay_seconds >= settings.delay_critical_threshold_seconds:
        severity = "critical"
    elif delay_seconds >= settings.delay_warning_threshold_seconds:
        severity = "warning"
    else:
        return None  # Below warning threshold

    return DelayResult(
        department_id=department_id,
        department_name=department_name,
        elapsed_seconds=elapsed_seconds,
        avg_time_seconds=avg_time_seconds,
        waiting_count=waiting_count,
        delay_seconds=delay_seconds,
        severity=severity,
    )
