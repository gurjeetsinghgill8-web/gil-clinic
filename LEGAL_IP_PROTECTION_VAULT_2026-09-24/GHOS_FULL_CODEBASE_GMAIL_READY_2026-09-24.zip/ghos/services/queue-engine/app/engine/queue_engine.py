"""
GHOS Queue Engine — Core Algorithms
==========================================
The heart of GHOS. Manages queue lifecycle:
- Enqueue: Add patient to department queue
- Dequeue: Call next patient (highest priority)
- Wait time: Calculate and cache estimated wait
- Skip/Complete: Update queue entry status
"""

from datetime import datetime, timezone, date
from typing import Optional, List, Tuple
import json

from sqlalchemy import select, func, and_
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import QueueEntry, Visit, Department, QueueStatus, VisitStatus, PriorityLevel
from app.engine.priority import calculate_priority_score, validate_priority
from app.engine.delay import check_delay, DelayResult
from app import redis as cache
from app.config import settings


# ─── Enqueue ───────────────────────────────────────────────────────────────────

async def enqueue(
    db: AsyncSession,
    visit_id: str,
    department_id: str,
    priority: int = 0,
    source_department_id: Optional[str] = None,
) -> QueueEntry:
    """
    Add a patient to a department queue.

    Flow:
    1. Generate sequential token number
    2. Calculate priority score
    3. Create queue entry in PostgreSQL
    4. Add to Redis sorted set
    5. Calculate estimated wait time
    6. Publish WebSocket event
    7. If source_department, mark previous entry as completed

    Returns:
        QueueEntry with full details
    """
    priority = validate_priority(priority)

    # 1. Generate token number (atomic Redis counter)
    token_number = await cache.increment_and_get_token(department_id)

    # 2. Calculate priority score
    priority_score = calculate_priority_score(priority, token_number)

    # 3. Create queue entry in PostgreSQL
    now = datetime.now(timezone.utc)
    entry = QueueEntry(
        visit_id=visit_id,
        department_id=department_id,
        token_number=token_number,
        status=QueueStatus.WAITING,
        priority=priority,
        priority_score=priority_score,
        entered_at=now,
        queue_date=date.today(),
    )
    db.add(entry)
    await db.flush()  # Get ID without committing

    # 4. Add to Redis sorted set
    await cache.add_to_queue(department_id, entry.id, priority_score)

    # 5. Calculate estimated wait time
    wait_time = await calculate_wait_time(db, department_id, priority_score)
    entry.estimated_wait_seconds = wait_time
    await cache.set_wait_time(department_id, wait_time)

    # 6. Publish WebSocket event
    await cache.publish_event("queue.entry_added", {
        "type": "queue.entry_added",
        "department_id": department_id,
        "entry_id": entry.id,
        "visit_id": visit_id,
        "token_number": token_number,
        "priority": priority,
        "estimated_wait_seconds": wait_time,
        "timestamp": now.isoformat(),
    })

    # 7. Mark previous department's entry as completed
    if source_department_id:
        await _complete_source_entry(db, visit_id, source_department_id)

    return entry


# ─── Dequeue ───────────────────────────────────────────────────────────────────

async def dequeue(
    db: AsyncSession,
    department_id: str,
) -> Optional[QueueEntry]:
    """
    Call the next patient from the department queue.

    Algorithm:
    1. ZPOPMIN from Redis sorted set (lowest score = highest priority)
    2. Fetch full entry from PostgreSQL
    3. Validate still 'waiting' — skip if already called
    4. Update status to 'called' with timestamp
    5. Cache wait time for remaining patients
    6. Publish WebSocket event

    Returns:
        QueueEntry if a patient was called, None if queue empty
    """
    while True:
        # 1. Pop entry with lowest score from Redis
        popped = await cache.pop_min_from_queue(department_id)
        if popped is None:
            return None

        entry_id, score = popped

        # 2. Fetch from PostgreSQL
        result = await db.execute(
            select(QueueEntry).where(QueueEntry.id == entry_id)
        )
        entry = result.scalar_one_or_none()

        if entry is None:
            continue  # Entry doesn't exist in DB, get next

        # 3. Validate entry is still waiting
        if entry.status != QueueStatus.WAITING:
            continue  # Already handled, get next

        # 4. Update status
        now = datetime.now(timezone.utc)
        entry.status = QueueStatus.CALLED
        entry.called_at = now
        await db.flush()

        # 5. Recalculate wait time for remaining patients
        remaining_count = await cache.get_queue_length(department_id)
        if remaining_count > 0:
            dept = await db.get(Department, department_id)
            avg_time = dept.avg_service_time_seconds if dept else settings.default_avg_service_time_seconds
            new_wait = await calculate_wait_time(db, department_id)
            await cache.set_wait_time(department_id, new_wait)

        # 6. Publish event
        await cache.publish_event("queue.patient_called", {
            "type": "queue.patient_called",
            "department_id": department_id,
            "entry_id": entry.id,
            "visit_id": entry.visit_id,
            "token_number": entry.token_number,
            "priority": entry.priority,
            "called_at": now.isoformat(),
            "remaining": remaining_count,
        })

        return entry


# ─── Wait Time Calculation ─────────────────────────────────────────────────────

async def calculate_wait_time(
    db: AsyncSession,
    department_id: str,
    new_entry_score: Optional[float] = None,
) -> int:
    """
    Calculate estimated wait time in seconds for a department.

    Formula: (ahead_count * avg_service_time) - elapsed_time_of_current

    Where ahead_count = entries with lower priority score than this entry
    (or all waiting entries if new_entry_score is None)

    Args:
        department_id: UUID of the department
        new_entry_score: Optional score of a new entry (count only ahead of it)

    Returns:
        int: Estimated wait time in seconds
    """
    # 1. Get the department's average service time
    dept = await db.get(Department, department_id)
    avg_time = dept.avg_service_time_seconds if dept else settings.default_avg_service_time_seconds

    # 2. Count entries ahead (or all waiting)
    if new_entry_score is not None:
        ahead_count = await cache.count_ahead_of_score(department_id, new_entry_score)
    else:
        ahead_count = await cache.get_queue_length(department_id)

    # 3. Check elapsed time of current patient
    current = await get_current_patient(db, department_id)
    elapsed = 0
    if current and current.called_at:
        elapsed = int((datetime.now(timezone.utc) - current.called_at).total_seconds())

    # 4. Delay penalty (if current patient is taking longer than average)
    delay_penalty = max(0, elapsed - avg_time)

    # 5. Calculate wait time
    wait = (ahead_count * avg_time) + delay_penalty

    return wait


# ─── Skip Patient ──────────────────────────────────────────────────────────────

async def skip_patient(
    db: AsyncSession,
    entry_id: str,
) -> Optional[QueueEntry]:
    """
    Mark a queue entry as skipped.

    Removes the entry from the Redis queue and updates status.
    """
    entry = await db.get(QueueEntry, entry_id)
    if entry is None or entry.status != QueueStatus.WAITING:
        return None

    entry.status = QueueStatus.SKIPPED
    await cache.remove_from_queue(entry.department_id, entry_id)

    await cache.publish_event("queue.patient_skipped", {
        "type": "queue.patient_skipped",
        "department_id": entry.department_id,
        "entry_id": entry.id,
        "visit_id": entry.visit_id,
        "token_number": entry.token_number,
        "timestamp": datetime.now(timezone.utc).isoformat(),
    })

    return entry


# ─── Complete Patient ──────────────────────────────────────────────────────────

async def complete_patient(
    db: AsyncSession,
    entry_id: str,
) -> Optional[QueueEntry]:
    """
    Mark a queue entry as completed.
    """
    entry = await db.get(QueueEntry, entry_id)
    if entry is None:
        return None

    now = datetime.now(timezone.utc)
    entry.status = QueueStatus.COMPLETED
    entry.completed_at = now

    # Remove from Redis in case it's still there
    await cache.remove_from_queue(entry.department_id, entry_id)

    await cache.publish_event("queue.patient_completed", {
        "type": "queue.patient_completed",
        "department_id": entry.department_id,
        "entry_id": entry.id,
        "visit_id": entry.visit_id,
        "token_number": entry.token_number,
        "completed_at": now.isoformat(),
    })

    return entry


# ─── Queue Status ──────────────────────────────────────────────────────────────

async def get_queue_status(
    db: AsyncSession,
    department_id: str,
) -> dict:
    """
    Get full queue status for a department.

    Returns:
        dict with current patient, waiting list, and stats
    """
    today = date.today()

    # Current patient (called or in_progress)
    current = await get_current_patient(db, department_id)

    # Waiting entries
    waiting_result = await db.execute(
        select(QueueEntry)
        .where(
            QueueEntry.department_id == department_id,
            QueueEntry.queue_date == today,
            QueueEntry.status == QueueStatus.WAITING,
        )
        .order_by(QueueEntry.priority_score.asc())
    )
    waiting = list(waiting_result.scalars().all())

    # Stats
    stats_result = await db.execute(
        select(
            QueueEntry.status,
            func.count(QueueEntry.id).label("count"),
        )
        .where(
            QueueEntry.department_id == department_id,
            QueueEntry.queue_date == today,
        )
        .group_by(QueueEntry.status)
    )
    stats = {row.status.value: row.count for row in stats_result}

    # Cached wait time
    cached_wait = await cache.get_wait_time(department_id)

    return {
        "department_id": department_id,
        "current": _entry_to_dict(current) if current else None,
        "waiting_count": len(waiting),
        "waiting": [_entry_to_dict(e) for e in waiting],
        "stats": {
            "waiting": stats.get("waiting", 0),
            "called": stats.get("called", 0),
            "in_progress": stats.get("in_progress", 0),
            "completed": stats.get("completed", 0),
            "skipped": stats.get("skipped", 0),
        },
        "estimated_wait_seconds": cached_wait,
    }


# ─── Current Patient ──────────────────────────────────────────────────────────

async def get_current_patient(
    db: AsyncSession,
    department_id: str,
) -> Optional[QueueEntry]:
    """Get the currently active patient for a department."""
    result = await db.execute(
        select(QueueEntry)
        .where(
            QueueEntry.department_id == department_id,
            QueueEntry.queue_date == date.today(),
            QueueEntry.status.in_([QueueStatus.CALLED, QueueStatus.IN_PROGRESS]),
        )
        .order_by(QueueEntry.called_at.desc())
        .limit(1)
    )
    return result.scalar_one_or_none()


async def start_patient(
    db: AsyncSession,
    entry_id: str,
) -> Optional[QueueEntry]:
    """Mark a called patient as in_progress."""
    entry = await db.get(QueueEntry, entry_id)
    if entry is None or entry.status != QueueStatus.CALLED:
        return None

    entry.status = QueueStatus.IN_PROGRESS
    entry.started_at = datetime.now(timezone.utc)
    await db.flush()
    return entry


# ─── Position in Queue ─────────────────────────────────────────────────────────

async def get_position(
    db: AsyncSession,
    entry_id: str,
) -> Optional[dict]:
    """
    Get the current position and estimated wait for a queue entry.
    """
    entry = await db.get(QueueEntry, entry_id)
    if entry is None:
        return None

    rank = await cache.get_queue_position(entry.department_id, entry.id)
    wait = await cache.get_wait_time(entry.department_id)

    return {
        "entry_id": entry.id,
        "token_number": entry.token_number,
        "status": entry.status.value,
        "position": rank + 1 if rank is not None else None,
        "total_ahead": rank if rank is not None else None,
        "estimated_wait_seconds": wait,
    }


# ─── Delay Detection ───────────────────────────────────────────────────────────

async def get_wait_time_for_department(
    db: AsyncSession,
    department_id: str,
    new_entry_score: Optional[float] = None,
) -> int:
    """
    Get the current estimated wait time for a department.

    Checks Redis cache first, recalculates if not cached.
    """
    # Try cache first
    cached = await cache.get_wait_time(department_id)
    if cached is not None and new_entry_score is None:
        return cached

    # Recalculate
    wait = await calculate_wait_time(db, department_id, new_entry_score)
    await cache.set_wait_time(department_id, wait)
    return wait


async def check_department_delay(
    db: AsyncSession,
    department_id: str,
) -> Optional[DelayResult]:
    """
    Check if a department is running behind schedule.
    """
    dept = await db.get(Department, department_id)
    if dept is None:
        return None

    current = await get_current_patient(db, department_id)
    waiting_count = await cache.get_queue_length(department_id)

    result = check_delay(
        department_id=department_id,
        department_name=dept.name,
        called_at=current.called_at if current else None,
        avg_time_seconds=dept.avg_service_time_seconds,
        waiting_count=waiting_count,
    )

    if result:
        await cache.publish_event("queue.delay_alert", {
            "type": "queue.delay_alert",
            **result.to_dict(),
        })

    return result


# ─── Helpers ───────────────────────────────────────────────────────────────────

async def _complete_source_entry(
    db: AsyncSession,
    visit_id: str,
    department_id: str,
) -> None:
    """Mark the source department's active entry as completed."""
    result = await db.execute(
        select(QueueEntry)
        .where(
            QueueEntry.visit_id == visit_id,
            QueueEntry.department_id == department_id,
            QueueEntry.status.in_([QueueStatus.CALLED, QueueStatus.IN_PROGRESS]),
        )
        .limit(1)
    )
    entry = result.scalar_one_or_none()
    if entry:
        entry.status = QueueStatus.COMPLETED
        entry.completed_at = datetime.now(timezone.utc)
        await cache.remove_from_queue(department_id, entry.id)


def _entry_to_dict(entry: QueueEntry) -> dict:
    """Convert a QueueEntry ORM object to a dictionary for API responses."""
    return {
        "id": entry.id,
        "visit_id": entry.visit_id,
        "department_id": entry.department_id,
        "token_number": entry.token_number,
        "status": entry.status.value,
        "priority": entry.priority,
        "priority_score": entry.priority_score,
        "entered_at": entry.entered_at.isoformat() if entry.entered_at else None,
        "called_at": entry.called_at.isoformat() if entry.called_at else None,
        "started_at": entry.started_at.isoformat() if entry.started_at else None,
        "completed_at": entry.completed_at.isoformat() if entry.completed_at else None,
        "estimated_wait_seconds": entry.estimated_wait_seconds,
        "queue_date": str(entry.queue_date) if entry.queue_date else None,
    }
