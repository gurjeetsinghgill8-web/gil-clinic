"""
GHOS Queue Engine — Priority Scoring
========================================
Priority score determines a patient's position in the queue.
Lower score = earlier in queue.

Formula: priority_score = (priority_level * 1000) + token_number

Priority Levels:
  0 = Normal (default)
  1 = Senior Citizen (60+)  — +1000
  2 = Emergency             — +2000
  3 = VIP                   — +3000
  0 = Staff Family          — -100 (preferred, negative offset)
"""

from typing import Optional


# ─── Priority Constants ────────────────────────────────────────────────────────

PRIORITY_NORMAL = 0
PRIORITY_SENIOR = 1
PRIORITY_EMERGENCY = 2
PRIORITY_VIP = 3
PRIORITY_STAFF = 0  # Same level as normal, but with offset

# Score multipliers per priority level
# score = (priority * 1000) + token_number
PRIORITY_MULTIPLIER = 1000

# Special offsets (applied in addition to base priority)
OFFSET_STAFF_PREFERRED = -100  # Staff family goes ahead of normal patients


def calculate_priority_score(priority: int, token_number: int) -> float:
    """
    Calculate the priority score for a queue entry.

    Args:
        priority: Priority level (0=normal, 1=senior, 2=emergency, 3=VIP)
        token_number: Sequential token number for the department

    Returns:
        float: Priority score (lower = earlier in queue)
    """
    # Invert: higher priority = lower score = earlier in queue
    return float(token_number - (priority * PRIORITY_MULTIPLIER))


def get_priority_name(priority: int) -> str:
    """Get a human-readable name for a priority level."""
    names = {
        0: "Normal",
        1: "Senior Citizen",
        2: "Emergency",
        3: "VIP",
    }
    return names.get(priority, f"Priority-{priority}")


def validate_priority(priority: int) -> int:
    """Validate and clamp priority to valid range."""
    if priority < 0:
        return 0
    if priority > 3:
        return 3
    return priority
