"""
GHOS Queue Engine — SQLAlchemy ORM Models
=============================================
PostgreSQL tables for queue management.
"""

import uuid
from datetime import datetime, date
from typing import Optional, List
from sqlalchemy import (
    Column, String, Integer, Boolean, DateTime, Date, Float,
    ForeignKey, Enum as SAEnum, Text, JSON, UniqueConstraint, Index
)
from sqlalchemy.dialects.postgresql import UUID, ENUM as PGENUM
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column, relationship
from sqlalchemy.sql import func
import enum


class Base(DeclarativeBase):
    pass


# ─── Enums ────────────────────────────────────────────────────────────────────

class QueueStatus(str, enum.Enum):
    WAITING = "waiting"
    CALLED = "called"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    SKIPPED = "skipped"
    NO_SHOW = "no_show"


class VisitStatus(str, enum.Enum):
    REGISTERED = "registered"
    IN_PROGRESS = "in_progress"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


class PriorityLevel(int, enum.Enum):
    NORMAL = 0
    SENIOR = 1
    EMERGENCY = 2
    VIP = 3
    STAFF_PREFERRED = 0  # Same as normal but with negative offset


# ─── Helper: generate UUID ────────────────────────────────────────────────────

def gen_uuid() -> str:
    return str(uuid.uuid4())


# ─── Departments ───────────────────────────────────────────────────────────────

class Department(Base):
    __tablename__ = "departments"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    short_code: Mapped[str] = mapped_column(String(10), nullable=False)
    avg_service_time_seconds: Mapped[int] = mapped_column(Integer, default=600)
    room: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    icon: Mapped[Optional[str]] = mapped_column(String(10), nullable=True)
    active: Mapped[bool] = mapped_column(Boolean, default=True)
    sort_order: Mapped[int] = mapped_column(Integer, default=0)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    # Relationships
    queue_entries: Mapped[List["QueueEntry"]] = relationship(
        "QueueEntry", back_populates="department"
    )

    def __repr__(self) -> str:
        return f"<Department {self.short_code}: {self.name}>"


# ─── Queue Entries ─────────────────────────────────────────────────────────────

class QueueEntry(Base):
    __tablename__ = "queue_entries"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    visit_id: Mapped[str] = mapped_column(String(36), ForeignKey("visits.id"), nullable=False)
    department_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("departments.id"), nullable=False
    )
    token_number: Mapped[int] = mapped_column(Integer, nullable=False)
    status: Mapped[QueueStatus] = mapped_column(
        SAEnum(QueueStatus, name="queue_status", create_constraint=True),
        default=QueueStatus.WAITING,
        nullable=False,
    )
    priority: Mapped[int] = mapped_column(Integer, default=0)
    priority_score: Mapped[float] = mapped_column(Float, default=0.0)
    entered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    called_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    started_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    estimated_wait_seconds: Mapped[Optional[int]] = mapped_column(
        Integer, nullable=True
    )
    queue_date: Mapped[date] = mapped_column(
        Date, server_default=func.current_date(), nullable=False
    )
    extra_data: Mapped[Optional[dict]] = mapped_column("extra_data", JSON, nullable=True, default=dict)

    # Relationships
    department: Mapped["Department"] = relationship(
        "Department", back_populates="queue_entries"
    )
    visit: Mapped["Visit"] = relationship("Visit", back_populates="queue_entries")

    __table_args__ = (
        Index("idx_queue_date_dept_status", "queue_date", "department_id", "status"),
        Index("idx_queue_visit", "visit_id"),
        Index("idx_queue_dept_date", "department_id", "queue_date"),
    )

    def __repr__(self) -> str:
        return f"<QueueEntry {self.token_number} [{self.status.value}]>"


# ─── Visits ────────────────────────────────────────────────────────────────────

class Visit(Base):
    __tablename__ = "visits"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    patient_id: Mapped[str] = mapped_column(String(50), nullable=False, index=True)
    visit_token: Mapped[str] = mapped_column(String(50), unique=True, nullable=False)
    status: Mapped[VisitStatus] = mapped_column(
        SAEnum(VisitStatus, name="visit_status", create_constraint=True),
        default=VisitStatus.REGISTERED,
        nullable=False,
    )
    hospital_id: Mapped[str] = mapped_column(String(36), default="default")
    branch_id: Mapped[str] = mapped_column(String(36), default="main")
    current_department_id: Mapped[Optional[str]] = mapped_column(
        String(36), ForeignKey("departments.id"), nullable=True
    )
    entered_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    completed_at: Mapped[Optional[datetime]] = mapped_column(
        DateTime(timezone=True), nullable=True
    )
    extra_data: Mapped[Optional[dict]] = mapped_column("extra_data", JSON, nullable=True, default=dict)

    # Relationships
    queue_entries: Mapped[List["QueueEntry"]] = relationship(
        "QueueEntry", back_populates="visit"
    )

    def __repr__(self) -> str:
        return f"<Visit {self.visit_token} [{self.status.value}]>"
