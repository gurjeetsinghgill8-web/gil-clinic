"""
GHOS Queue Engine — Pydantic Schemas
========================================
Request/Response models for all API endpoints.
"""

from datetime import datetime, date
from typing import Optional, List, Any
from pydantic import BaseModel, Field, field_validator


# ─── Enqueue ───────────────────────────────────────────────────────────────────

class EnqueueRequest(BaseModel):
    visit_id: str = Field(..., description="UUID of the visit")
    department_id: str = Field(..., description="UUID of the target department")
    priority: int = Field(default=0, ge=0, le=3, description="0=Normal, 1=Senior, 2=Emergency, 3=VIP")
    source_department_id: Optional[str] = Field(default=None, description="Previous department to auto-complete")


class EnqueueResponse(BaseModel):
    success: bool = True
    data: dict
    error: Optional[str] = None


# ─── Dequeue ───────────────────────────────────────────────────────────────────

class DequeueResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None
    meta: Optional[dict] = None


# ─── Queue Status ──────────────────────────────────────────────────────────────

class QueueStats(BaseModel):
    waiting: int = 0
    called: int = 0
    in_progress: int = 0
    completed: int = 0
    skipped: int = 0


class QueueEntryOut(BaseModel):
    id: str
    visit_id: str
    department_id: str
    token_number: int
    status: str
    priority: int
    priority_score: float
    entered_at: Optional[str] = None
    called_at: Optional[str] = None
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    estimated_wait_seconds: Optional[int] = None
    queue_date: Optional[str] = None


class QueueStatusResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None

    class Config:
        from_attributes = True


# ─── Position ──────────────────────────────────────────────────────────────────

class PositionResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None


# ─── Skip / Complete ──────────────────────────────────────────────────────────

class ActionResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None


# ─── Wait Time ─────────────────────────────────────────────────────────────────

class WaitTimeResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None


# ─── Token ────────────────────────────────────────────────────────────────────

class TokenResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[str] = None


# ─── Error ────────────────────────────────────────────────────────────────────

class ErrorResponse(BaseModel):
    success: bool = False
    data: Optional[Any] = None
    error: Optional[dict] = Field(
        default=None,
        description="Error details with code, message, and optional details",
    )
    meta: Optional[Any] = None


# ─── Generic ───────────────────────────────────────────────────────────────────

class HealthResponse(BaseModel):
    status: str = "ok"
    service: str = "ghos-queue-engine"
    version: str = "1.0.0"
    database: str = "connected"
    redis: str = "connected"
