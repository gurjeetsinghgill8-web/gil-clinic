"""
GHOS Queue Engine — WebSocket Manager
=========================================
Manages WebSocket connections and Redis Pub/Sub for real-time events.

Architecture:
  Queue Engine publishes events to Redis channels.
  The WebSocket manager subscribes to Redis and forwards events
  to all connected WebSocket clients.

Redis Channels:
  - queue:events — All queue-related events
  - queue:{department_id} — Department-specific events
"""

import json
import asyncio
import logging
from typing import Set, Dict, Optional
from fastapi import WebSocket, WebSocketDisconnect

from app import redis as cache

logger = logging.getLogger(__name__)


class ConnectionManager:
    """
    Manages WebSocket connections and Redis Pub/Sub forwarding.
    """

    def __init__(self):
        # All active WebSocket connections
        self.active_connections: Set[WebSocket] = set()

        # Per-department subscription sets
        # {department_id: {websocket, ...}}
        self.department_connections: Dict[str, Set[WebSocket]] = {}

        # Redis Pub/Sub listener task
        self._pubsub_task: Optional[asyncio.Task] = None

    async def connect(self, websocket: WebSocket, department_id: Optional[str] = None):
        """Accept a new WebSocket connection."""
        await websocket.accept()
        self.active_connections.add(websocket)

        if department_id:
            if department_id not in self.department_connections:
                self.department_connections[department_id] = set()
            self.department_connections[department_id].add(websocket)

        logger.info(f"WebSocket connected. Total: {len(self.active_connections)}")

    async def disconnect(self, websocket: WebSocket, department_id: Optional[str] = None):
        """Remove a WebSocket connection."""
        self.active_connections.discard(websocket)

        if department_id and department_id in self.department_connections:
            self.department_connections[department_id].discard(websocket)
            if not self.department_connections[department_id]:
                del self.department_connections[department_id]

        logger.info(f"WebSocket disconnected. Total: {len(self.active_connections)}")

    async def broadcast(self, event: dict):
        """Send an event to ALL connected WebSocket clients."""
        message = json.dumps(event)
        stale = set()
        for connection in self.active_connections:
            try:
                await connection.send_text(message)
            except Exception:
                stale.add(connection)

        for conn in stale:
            await self.disconnect(conn)

    async def broadcast_to_department(self, department_id: str, event: dict):
        """Send an event to clients subscribed to a specific department."""
        message = json.dumps(event)
        stale = set()

        if department_id in self.department_connections:
            for connection in self.department_connections[department_id]:
                try:
                    await connection.send_text(message)
                except Exception:
                    stale.add(connection)

            for conn in stale:
                await self.department_connections[department_id].discard(conn)

    async def start_redis_listener(self):
        """
        Start listening to Redis Pub/Sub for queue events
        and forward them to connected WebSocket clients.
        """
        r = cache.get_redis()
        pubsub = r.pubsub()

        # Subscribe to all queue events
        await pubsub.subscribe("queue:events")

        logger.info("Redis Pub/Sub listener started")

        try:
            async for message in pubsub.listen():
                if message["type"] != "message":
                    continue

                try:
                    event = json.loads(message["data"])
                    # Broadcast to all connected clients
                    await self.broadcast(event)

                    # Also broadcast to department-specific channel
                    dept_id = event.get("department_id")
                    if dept_id:
                        await self.broadcast_to_department(dept_id, event)
                except json.JSONDecodeError:
                    logger.warning(f"Invalid JSON in Redis message: {message['data']}")
                except Exception as e:
                    logger.error(f"Error forwarding Redis message: {e}")
        except asyncio.CancelledError:
            logger.info("Redis Pub/Sub listener stopped")
        finally:
            await pubsub.unsubscribe("queue:events")
            await pubsub.close()


    async def shutdown(self):
        """Cancel the Redis listener task and close all connections."""
        if self._pubsub_task and not self._pubsub_task.done():
            self._pubsub_task.cancel()
            try:
                await self._pubsub_task
            except asyncio.CancelledError:
                pass

        # Close all WebSocket connections
        for connection in list(self.active_connections):
            try:
                await connection.close()
            except Exception:
                pass
        self.active_connections.clear()
        self.department_connections.clear()
        logger.info("All WebSocket connections closed")


# Global connection manager instance
manager = ConnectionManager()
