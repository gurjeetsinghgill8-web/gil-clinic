"""
GHOS Queue Engine — Main Application Entry Point
====================================================
FastAPI application with:
- CORS middleware for cross-origin requests
- Router inclusion (queue, tokens)
- WebSocket endpoint for real-time queue updates
- Startup: init DB tables, seed departments
- Shutdown: close connections gracefully
- Health check endpoint
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, Query
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db, close_db
from app.schemas import HealthResponse
from app.ws.manager import ConnectionManager

logger = logging.getLogger(__name__)

# ----------------------------------------------------------------
# Global WebSocket connection manager
# ----------------------------------------------------------------
ws_manager = ConnectionManager()


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown events."""
    # Startup
    logger.info(f"🚀 {settings.app_name} v{settings.version} starting...")
    await init_db()
    logger.info("✅ Database tables initialized")

    # Start Redis pub/sub listener for WebSocket broadcasting
    await ws_manager.start_redis_listener()
    logger.info("✅ Redis Pub/Sub listener started")

    yield

    # Shutdown
    logger.info("🛑 Shutting down...")
    await ws_manager.shutdown()
    await close_db()
    logger.info("✅ Connections closed gracefully")


app = FastAPI(
    title=settings.app_name,
    description="GHOS Queue Engine — Real-time queue management microservice",
    version=settings.version,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# ----------------------------------------------------------------
# CORS — Allow all origins in development
# ----------------------------------------------------------------
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ----------------------------------------------------------------
# Routers
# ----------------------------------------------------------------
from app.routes import queue  # noqa: E402
from app.routes import tokens  # noqa: E402

app.include_router(queue.router)
app.include_router(tokens.router)


# ----------------------------------------------------------------
# Root endpoint
# ----------------------------------------------------------------
@app.get("/")
async def root():
    """Root redirect to API docs."""
    return {"message": f"GHOS Queue Engine v{settings.version}", "docs": "/docs"}


# ----------------------------------------------------------------
# Health check
# ----------------------------------------------------------------
@app.get("/health", response_model=HealthResponse)
async def health():
    """
    Health check endpoint.
    Returns service status, database and Redis connectivity.
    """
    db_ok = False
    redis_ok = False

    try:
        from app.database import async_session_factory
        from sqlalchemy import text

        async with async_session_factory() as session:
            await session.execute(text("SELECT 1"))
        db_ok = True
    except Exception as e:
        logger.warning(f"Health check — DB unavailable: {e}")

    try:
        import app.redis as cache

        await cache.ping()
        redis_ok = True
    except Exception as e:
        logger.warning(f"Health check — Redis unavailable: {e}")

    return HealthResponse(
        data={
            "status": "healthy" if (db_ok and redis_ok) else "degraded",
            "service": settings.app_name,
            "version": settings.version,
            "database": "connected" if db_ok else "disconnected",
            "redis": "connected" if redis_ok else "disconnected",
        }
    )


# ----------------------------------------------------------------
# WebSocket endpoint for real-time queue updates
# ----------------------------------------------------------------
@app.websocket("/ws/queue")
async def websocket_queue(
    websocket: WebSocket,
    department_id: str = Query(None, description="Filter by department"),
):
    """
    WebSocket endpoint for real-time queue events.

    Query params:
    - department_id: Optional — subscribe to a specific department's events

    Events received:
    - queue.entry_added
    - queue.patient_called
    - queue.patient_skipped
    - queue.patient_completed
    - queue.wait_time_updated
    - queue.delay_alert
    """
    await ws_manager.connect(websocket, department_id)
    try:
        while True:
            # Keep connection alive by receiving (and discarding) messages
            # This also detects client disconnect
            data = await websocket.receive_text()
            # Client can send ping messages
            if data == "ping":
                await websocket.send_json({"type": "pong"})
    except WebSocketDisconnect:
        ws_manager.disconnect(websocket, department_id)
    except Exception as e:
        logger.error(f"WebSocket error: {e}")
        ws_manager.disconnect(websocket, department_id)


# ----------------------------------------------------------------
# Exception handlers
# ----------------------------------------------------------------
@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    """Catch-all exception handler returning a structured error response."""
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "data": None,
            "error": {
                "code": "INTERNAL_ERROR",
                "message": "An unexpected error occurred",
            },
            "meta": None,
        },
    )
