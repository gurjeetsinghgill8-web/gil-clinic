"""
GHOS Queue Engine — Redis Client
===================================
Async Redis client with connection pool for:
- Queue sorted sets (department queues)
- Wait time cache
- Token counters
- Pub/Sub for WebSocket events
"""

from typing import Optional, Tuple, List
from datetime import date

from redis.asyncio import Redis as AsyncRedis, ConnectionPool

from app.config import settings


# ─── Redis Client Singleton ────────────────────────────────────────────────────

_pool: Optional[ConnectionPool] = None
_redis: Optional[AsyncRedis] = None


def get_redis() -> AsyncRedis:
    """Get the global Redis client instance."""
    global _redis, _pool
    if _redis is None:
        _pool = ConnectionPool.from_url(
            settings.redis_url,
            decode_responses=True,
            max_connections=20,
        )
        _redis = AsyncRedis(connection_pool=_pool)
    return _redis


async def ping() -> bool:
    """Check if Redis is reachable."""
    r = get_redis()
    try:
        return await r.ping()
    except Exception:
        return False


async def close_redis():
    """Close the Redis connection pool."""
    global _redis, _pool
    if _redis:
        await _redis.aclose()
        _redis = None
    if _pool:
        await _pool.disconnect()
        _pool = None


# ─── Key Builders ──────────────────────────────────────────────────────────────

def queue_key(department_id: str, when: Optional[date] = None) -> str:
    """Redis sorted set key for a department's queue on a given date."""
    d = when or date.today()
    return f"queue:{department_id}:{d.isoformat()}"


def wait_time_key(department_id: str) -> str:
    """Redis string key for cached wait time."""
    return f"waittime:{department_id}"


def token_seq_key(department_id: str, when: Optional[date] = None) -> str:
    """Redis counter key for department token sequence."""
    d = when or date.today()
    return f"token:seq:{department_id}:{d.isoformat()}"


def visit_token_seq_key(when: Optional[date] = None) -> str:
    """Redis counter key for visit ID sequence."""
    d = when or date.today()
    return f"token:seq:visit:{d.isoformat()}"


# ─── Queue Operations ──────────────────────────────────────────────────────────

async def add_to_queue(department_id: str, entry_id: str, score: float) -> None:
    """Add an entry to the department queue sorted set."""
    r = get_redis()
    await r.zadd(queue_key(department_id), {entry_id: score})


async def pop_min_from_queue(department_id: str) -> Optional[Tuple[str, float]]:
    """Pop the entry with the lowest score from the queue."""
    r = get_redis()
    result = await r.zpopmin(queue_key(department_id))
    if result:
        member, score = result[0]
        return str(member), float(score)
    return None


async def remove_from_queue(department_id: str, entry_id: str) -> None:
    """Remove a specific entry from the queue."""
    r = get_redis()
    await r.zrem(queue_key(department_id), entry_id)


async def get_queue_length(department_id: str) -> int:
    """Get the number of entries waiting in the queue."""
    r = get_redis()
    return await r.zcard(queue_key(department_id))


async def get_queue_position(department_id: str, entry_id: str) -> Optional[int]:
    """Get the rank (0-based) of an entry in the queue."""
    r = get_redis()
    rank = await r.zrank(queue_key(department_id), entry_id)
    return rank


async def count_ahead_of_score(department_id: str, score: float) -> int:
    """Count entries with a score lower than the given score."""
    r = get_redis()
    return await r.zcount(queue_key(department_id), 0, score - 1)


async def get_all_queue_entries(department_id: str) -> List[Tuple[str, float]]:
    """Get all entries in the queue sorted by score ascending."""
    r = get_redis()
    return await r.zrange(queue_key(department_id), 0, -1, withscores=True)


# ─── Wait Time Cache ───────────────────────────────────────────────────────────

async def set_wait_time(department_id: str, seconds: int, ttl: int = 60) -> None:
    """Cache the estimated wait time for a department."""
    r = get_redis()
    await r.setex(wait_time_key(department_id), ttl, str(seconds))


async def get_wait_time(department_id: str) -> Optional[int]:
    """Get the cached wait time, or None if not set."""
    r = get_redis()
    val = await r.get(wait_time_key(department_id))
    if val is not None:
        return int(val)
    return None


# ─── Token Counters ────────────────────────────────────────────────────────────

async def increment_and_get_token(department_id: str) -> int:
    """Atomically increment and return the next token number for a department."""
    r = get_redis()
    key = token_seq_key(department_id)
    return await r.incr(key)


async def increment_and_get_visit_seq() -> int:
    """Atomically increment and return the next visit sequence number."""
    r = get_redis()
    key = visit_token_seq_key()
    return await r.incr(key)


async def reset_daily_counters(department_ids: List[str]) -> None:
    """Reset all daily counters at midnight. Keys expire naturally."""
    pass  # Keys expire via TTL; or we just let them accumulate


# ─── Pub/Sub ──────────────────────────────────────────────────────────────────

async def publish_event(channel: str, event_data: dict) -> None:
    """Publish an event to a Redis channel for WebSocket broadcast."""
    r = get_redis()
    import json
    await r.publish(channel, json.dumps(event_data))
