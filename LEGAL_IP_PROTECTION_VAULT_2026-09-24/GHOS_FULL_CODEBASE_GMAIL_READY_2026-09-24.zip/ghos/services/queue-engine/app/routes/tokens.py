"""
GHOS Queue Engine — Token Routes
====================================
Token generation endpoints:
- Generate visit tokens
- Generate department tokens
- QR code generation
"""

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app import redis as cache
from app.schemas import TokenResponse, ErrorResponse
from app.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/tokens", tags=["tokens"])


@router.get("/generate/{department_id}", response_model=TokenResponse)
async def generate_department_token(department_id: str):
    """
    Generate the next sequential token number for a department.

    Tokens are sequential per department per day, resetting at midnight.
    """
    try:
        token_number = await cache.increment_and_get_token(department_id)
        return TokenResponse(
            data={
                "department_id": department_id,
                "token_number": token_number,
                "date": datetime.now(timezone.utc).strftime("%Y-%m-%d"),
            }
        )
    except Exception as e:
        logger.error(f"Error generating token: {e}")
        return TokenResponse(
            success=False,
            error={"code": "TOKEN_GENERATION_FAILED", "message": str(e)},
        )


@router.get("/generate-visit", response_model=TokenResponse)
async def generate_visit_token():
    """
    Generate the next sequential visit ID.

    Format: {PREFIX}-{YYYYMMDD}-{NNN}
    Example: GHOS-20260709-042
    """
    try:
        seq = await cache.increment_and_get_visit_seq()
        today = datetime.now(timezone.utc).strftime("%Y%m%d")
        visit_token = f"{settings.patient_id_prefix}-{today}-{seq:03d}"

        return TokenResponse(
            data={
                "visit_token": visit_token,
                "sequence": seq,
                "date": today,
            }
        )
    except Exception as e:
        logger.error(f"Error generating visit token: {e}")
        return TokenResponse(
            success=False,
            error={"code": "VISIT_TOKEN_FAILED", "message": str(e)},
        )
