"""
GHOS Queue Engine — Queue Routes
====================================
REST API endpoints for queue operations:
- Enqueue / Dequeue
- Skip / Complete / Start
- Status / Wait Time / Position
"""

import logging
from datetime import datetime, timezone
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Path, Query
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas import (
    EnqueueRequest,
    EnqueueResponse,
    DequeueResponse,
    QueueStatusResponse,
    PositionResponse,
    ActionResponse,
    WaitTimeResponse,
    ErrorResponse,
)
from app.engine.queue_engine import (
    enqueue,
    dequeue,
    skip_patient,
    complete_patient,
    start_patient,
    get_queue_status,
    get_wait_time_for_department,
    get_position,
    check_department_delay,
)

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/queue", tags=["queue"])


@router.post("/enqueue", response_model=EnqueueResponse, status_code=201)
async def api_enqueue(
    request: EnqueueRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Add a patient to a department queue.

    Returns the queue entry with token number and estimated wait time.
    If source_department_id is provided, the patient's previous department
    entry is automatically marked as completed (routing between departments).
    """
    try:
        entry = await enqueue(
            db=db,
            visit_id=request.visit_id,
            department_id=request.department_id,
            priority=request.priority,
            source_department_id=request.source_department_id,
        )

        # Calculate estimated wait time for response
        wait_time = await get_wait_time_for_department(
            db, request.department_id, entry.priority_score
        )

        return EnqueueResponse(
            data={
                "entry_id": str(entry.id),
                "visit_id": str(entry.visit_id),
                "department_id": str(entry.department_id),
                "token_number": entry.token_number,
                "priority": entry.priority,
                "priority_score": entry.priority_score,
                "estimated_wait_seconds": wait_time,
                "position": None,  # will be filled if needed
            }
        )
    except ValueError as e:
        return EnqueueResponse(
            success=False,
            error={"code": "ENQUEUE_FAILED", "message": str(e)},
        )
    except Exception as e:
        logger.error(f"Enqueue error: {e}", exc_info=True)
        return EnqueueResponse(
            success=False,
            error={"code": "INTERNAL_ERROR", "message": "Failed to enqueue patient"},
        )


@router.post("/dequeue/{department_id}", response_model=DequeueResponse)
async def api_dequeue(
    department_id: str = Path(..., description="Department UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Call the next waiting patient from a department queue.

    Returns the highest-priority (or longest-waiting) patient.
    Returns 204 with null data if queue is empty.
    """
    try:
        entry = await dequeue(db, department_id)

        if not entry:
            return DequeueResponse(
                data=None,
                meta={"department_id": department_id, "message": "Queue is empty"},
            )

        return DequeueResponse(
            data={
                "entry_id": str(entry.id),
                "visit_id": str(entry.visit_id),
                "department_id": str(entry.department_id),
                "token_number": entry.token_number,
                "priority": entry.priority,
                "status": entry.status.value,
                "called_at": entry.called_at.isoformat() if entry.called_at else None,
                "patient": None,  # patient details can be fetched from patient service
            }
        )
    except Exception as e:
        logger.error(f"Dequeue error: {e}", exc_info=True)
        return DequeueResponse(
            success=False,
            error={"code": "DEQUEUE_FAILED", "message": str(e)},
        )


@router.post("/skip/{entry_id}", response_model=ActionResponse)
async def api_skip(
    entry_id: str = Path(..., description="Queue Entry UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Skip a patient in queue.

    Moves them from WAITING → SKIPPED.
    They can re-queue later without losing their place entirely.
    """
    try:
        entry = await skip_patient(db, entry_id)
        if not entry:
            return ActionResponse(
                success=False,
                error={
                    "code": "ENTRY_NOT_FOUND",
                    "message": f"Queue entry {entry_id} not found",
                },
            )

        return ActionResponse(
            data={
                "entry_id": str(entry.id),
                "visit_id": str(entry.visit_id),
                "token_number": entry.token_number,
                "previous_status": "waiting",
                "new_status": entry.status.value,
                "action": "skipped",
            }
        )
    except Exception as e:
        logger.error(f"Skip error: {e}", exc_info=True)
        return ActionResponse(
            success=False,
            error={"code": "SKIP_FAILED", "message": str(e)},
        )


@router.post("/complete/{entry_id}", response_model=ActionResponse)
async def api_complete(
    entry_id: str = Path(..., description="Queue Entry UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Mark a patient's queue entry as completed.

    Moves from IN_PROGRESS → COMPLETED.
    This triggers next-patient-ready for the department.
    """
    try:
        entry = await complete_patient(db, entry_id)
        if not entry:
            return ActionResponse(
                success=False,
                error={
                    "code": "ENTRY_NOT_FOUND",
                    "message": f"Queue entry {entry_id} not found",
                },
            )

        return ActionResponse(
            data={
                "entry_id": str(entry.id),
                "visit_id": str(entry.visit_id),
                "token_number": entry.token_number,
                "previous_status": "in_progress",
                "new_status": entry.status.value,
                "action": "completed",
            }
        )
    except Exception as e:
        logger.error(f"Complete error: {e}", exc_info=True)
        return ActionResponse(
            success=False,
            error={"code": "COMPLETE_FAILED", "message": str(e)},
        )


@router.post("/start/{entry_id}", response_model=ActionResponse)
async def api_start(
    entry_id: str = Path(..., description="Queue Entry UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Mark a patient's test/service as started.

    Moves from CALLED → IN_PROGRESS.
    The patient has arrived at the department and testing has begun.
    """
    try:
        entry = await start_patient(db, entry_id)
        if not entry:
            return ActionResponse(
                success=False,
                error={
                    "code": "ENTRY_NOT_FOUND",
                    "message": f"Queue entry {entry_id} not found",
                },
            )

        return ActionResponse(
            data={
                "entry_id": str(entry.id),
                "visit_id": str(entry.visit_id),
                "token_number": entry.token_number,
                "previous_status": "called",
                "new_status": entry.status.value,
                "action": "started",
            }
        )
    except Exception as e:
        logger.error(f"Start error: {e}", exc_info=True)
        return ActionResponse(
            success=False,
            error={"code": "START_FAILED", "message": str(e)},
        )


@router.get("/status/{department_id}", response_model=QueueStatusResponse)
async def api_queue_status(
    department_id: str = Path(..., description="Department UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Get full queue status for a department.

    Returns:
    - Current patient being served
    - Waiting list with estimated wait times
    - Stats (waiting, called, in_progress, completed, skipped counts)
    - Average service time for the department
    """
    try:
        status = await get_queue_status(db, department_id)
        return QueueStatusResponse(data=status)
    except Exception as e:
        logger.error(f"Status error: {e}", exc_info=True)
        return QueueStatusResponse(
            success=False,
            error={"code": "STATUS_FAILED", "message": str(e)},
        )


@router.get("/wait-time/{department_id}", response_model=WaitTimeResponse)
async def api_wait_time(
    department_id: str = Path(..., description="Department UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Get the current estimated wait time for a department.

    Returns wait time in seconds, number of patients ahead,
    and department average service time.
    """
    try:
        wait_time = await get_wait_time_for_department(db, department_id)
        return WaitTimeResponse(
            data={
                "department_id": department_id,
                "estimated_wait_seconds": wait_time,
            }
        )
    except Exception as e:
        logger.error(f"Wait time error: {e}", exc_info=True)
        return WaitTimeResponse(
            success=False,
            error={"code": "WAIT_TIME_FAILED", "message": str(e)},
        )


@router.get("/position/{entry_id}", response_model=PositionResponse)
async def api_position(
    entry_id: str = Path(..., description="Queue Entry UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Get the current queue position for a patient entry.

    Returns their position in queue, total patients ahead,
    and estimated wait time.
    """
    try:
        position = await get_position(db, entry_id)
        if not position:
            return PositionResponse(
                success=False,
                error={
                    "code": "ENTRY_NOT_FOUND",
                    "message": f"Entry {entry_id} not found or not waiting",
                },
            )

        return PositionResponse(data=position)
    except Exception as e:
        logger.error(f"Position error: {e}", exc_info=True)
        return PositionResponse(
            success=False,
            error={"code": "POSITION_FAILED", "message": str(e)},
        )


@router.post("/delay-check/{department_id}", response_model=ActionResponse)
async def api_delay_check(
    department_id: str = Path(..., description="Department UUID"),
    db: AsyncSession = Depends(get_db),
):
    """
    Check if a department is running behind schedule.

    Triggers delay alerts if the current patient is taking longer
    than the department's average service time.
    Severity: "warning" (>5min delay), "critical" (>10min delay)
    """
    try:
        delay = await check_department_delay(db, department_id)
        if delay:
            return ActionResponse(
                data={
                    "department_id": department_id,
                    "delay_seconds": delay.delay_seconds,
                    "severity": delay.severity,
                    "message": f"Department is {delay.delay_minutes} min behind",
                }
            )

        return ActionResponse(
            data={
                "department_id": department_id,
                "delay_seconds": 0,
                "severity": "none",
                "message": "Department is on schedule",
            }
        )
    except Exception as e:
        logger.error(f"Delay check error: {e}", exc_info=True)
        return ActionResponse(
            success=False,
            error={"code": "DELAY_CHECK_FAILED", "message": str(e)},
        )
