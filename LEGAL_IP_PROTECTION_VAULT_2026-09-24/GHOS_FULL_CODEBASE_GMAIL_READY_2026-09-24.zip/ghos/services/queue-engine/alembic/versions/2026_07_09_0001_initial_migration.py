"""initial_migration

Create Date: 2026-07-09
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

# revision identifiers, used by Alembic.
revision: str = "2026_07_09_0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ─── Enums ────────────────────────────────────────────────────────────────────
    sa.Enum("waiting", "called", "in_progress", "completed", "skipped",
            "no_show", name="queue_status").create(op.get_bind())
    sa.Enum("registered", "in_progress", "completed", "cancelled",
            name="visit_status").create(op.get_bind())

    # ─── Departments Table ────────────────────────────────────────────────────────
    op.create_table(
        "departments",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("short_code", sa.String(10), nullable=False),
        sa.Column("avg_service_time_seconds", sa.Integer(), server_default="600"),
        sa.Column("room", sa.String(200), nullable=True),
        sa.Column("icon", sa.String(10), nullable=True),
        sa.Column("active", sa.Boolean(), server_default="true"),
        sa.Column("sort_order", sa.Integer(), server_default="0"),
        sa.Column(
            "created_at", sa.DateTime(timezone=True),
            server_default=sa.func.now()
        ),
        sa.Column(
            "updated_at", sa.DateTime(timezone=True),
            server_default=sa.func.now()
        ),
    )

    # ─── Visits Table ─────────────────────────────────────────────────────────────
    op.create_table(
        "visits",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("patient_id", sa.String(50), nullable=False, index=True),
        sa.Column("visit_token", sa.String(50), unique=True, nullable=False),
        sa.Column(
            "status", sa.Enum("registered", "in_progress", "completed",
                              "cancelled", name="visit_status"),
            nullable=False, server_default="registered"
        ),
        sa.Column("hospital_id", sa.String(36), server_default="default"),
        sa.Column("branch_id", sa.String(36), server_default="main"),
        sa.Column("current_department_id", sa.String(36),
                  sa.ForeignKey("departments.id"), nullable=True),
        sa.Column(
            "entered_at", sa.DateTime(timezone=True),
            server_default=sa.func.now()
        ),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("extra_data", postgresql.JSON(), nullable=True),
    )

    # ─── Queue Entries Table ──────────────────────────────────────────────────────
    op.create_table(
        "queue_entries",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("visit_id", sa.String(36),
                  sa.ForeignKey("visits.id"), nullable=False),
        sa.Column("department_id", sa.String(36),
                  sa.ForeignKey("departments.id"), nullable=False),
        sa.Column("token_number", sa.Integer(), nullable=False),
        sa.Column(
            "status", sa.Enum("waiting", "called", "in_progress",
                              "completed", "skipped", "no_show",
                              name="queue_status"),
            nullable=False, server_default="waiting"
        ),
        sa.Column("priority", sa.Integer(), server_default="0"),
        sa.Column("priority_score", sa.Float(), server_default="0.0"),
        sa.Column(
            "entered_at", sa.DateTime(timezone=True),
            server_default=sa.func.now()
        ),
        sa.Column("called_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("started_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("completed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("estimated_wait_seconds", sa.Integer(), nullable=True),
        sa.Column(
            "queue_date", sa.Date(),
            server_default=sa.func.current_date(), nullable=False
        ),
        sa.Column("extra_data", postgresql.JSON(), nullable=True),
    )

    # ─── Indexes ──────────────────────────────────────────────────────────────────
    op.create_index(
        "idx_queue_date_dept_status", "queue_entries",
        ["queue_date", "department_id", "status"],
    )
    op.create_index(
        "idx_queue_visit", "queue_entries", ["visit_id"],
    )
    op.create_index(
        "idx_queue_dept_date", "queue_entries",
        ["department_id", "queue_date"],
    )


def downgrade() -> None:
    # Drop indexes
    op.drop_index("idx_queue_dept_date", table_name="queue_entries")
    op.drop_index("idx_queue_visit", table_name="queue_entries")
    op.drop_index("idx_queue_date_dept_status", table_name="queue_entries")

    # Drop tables
    op.drop_table("queue_entries")
    op.drop_table("visits")
    op.drop_table("departments")

    # Drop enums
    op.execute("DROP TYPE IF EXISTS queue_status")
    op.execute("DROP TYPE IF EXISTS visit_status")
