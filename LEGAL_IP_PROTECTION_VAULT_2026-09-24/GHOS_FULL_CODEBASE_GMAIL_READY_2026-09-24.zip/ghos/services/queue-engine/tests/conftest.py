"""
GHOS Queue Engine — Test Configuration
=========================================
Pytest fixtures and configuration for queue engine tests.
Uses SQLite in-memory for fast, isolated testing.
"""

import pytest
import pytest_asyncio
from datetime import datetime, timezone, date
from typing import AsyncGenerator, Generator
from unittest.mock import AsyncMock, patch

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool

from app.models import Base, Department, QueueEntry, Visit, QueueStatus, VisitStatus


# ─── Test Database Engine (SQLite in-memory) ─────────────────────────────────

@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Create a fresh in-memory SQLite database for each test.

    Uses StaticPool to keep a single connection — critical for in-memory SQLite
    so that CREATE TABLE and subsequent queries see the same database.
    """
    engine = create_async_engine(
        "sqlite+aiosqlite://",
        echo=False,
        poolclass=StaticPool,
    )

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with session_factory() as session:
        yield session

    await engine.dispose()


# ─── Mock Redis Fixture ──────────────────────────────────────────────────────

@pytest.fixture
def mock_redis():
    """Mock the Redis client for isolated queue testing."""
    with patch("app.engine.queue_engine.cache") as mock:
        mock.add_to_queue = AsyncMock()
        mock.pop_min_from_queue = AsyncMock(return_value=None)
        mock.remove_from_queue = AsyncMock()
        mock.increment_and_get_token = AsyncMock(return_value=1)
        mock.increment_and_get_visit_seq = AsyncMock(return_value=1)
        mock.get_queue_length = AsyncMock(return_value=0)
        mock.get_queue_position = AsyncMock(return_value=None)
        mock.count_ahead_of_score = AsyncMock(return_value=0)
        mock.get_wait_time = AsyncMock(return_value=None)
        mock.set_wait_time = AsyncMock()
        mock.get_all_queue_entries = AsyncMock(return_value=[])
        mock.publish_event = AsyncMock()
        yield mock


# ─── Sample Data Fixtures ────────────────────────────────────────────────────

@pytest.fixture
def sample_department() -> Department:
    """Create a sample department for testing."""
    return Department(
        id="dept-ecg-001",
        name="ECG",
        short_code="ECG",
        avg_service_time_seconds=600,
        room="ECG Room 1",
        icon="🫀",
        active=True,
        sort_order=1,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
    )


@pytest.fixture
def sample_visit() -> Visit:
    """Create a sample visit for testing."""
    return Visit(
        id="visit-001",
        patient_id="P-001",
        visit_token="GHOS-20260709-001",
        status=VisitStatus.REGISTERED,
        hospital_id="default",
        branch_id="main",
        entered_at=datetime.now(timezone.utc),
    )


@pytest_asyncio.fixture
async def seeded_db(db_session, sample_department, sample_visit):
    """Seed the database with sample department and visit.

    Uses raw INSERT to avoid SQLAlchemy RETURNING compatibility issues with
    server_default columns on SQLite.
    """
    # Use SQLAlchemy ORM insert directly. StaticPool ensures the same connection,
    # so the session sees the tables created by create_all().
    db_session.add(sample_department)
    db_session.add(sample_visit)
    await db_session.commit()
    return db_session
