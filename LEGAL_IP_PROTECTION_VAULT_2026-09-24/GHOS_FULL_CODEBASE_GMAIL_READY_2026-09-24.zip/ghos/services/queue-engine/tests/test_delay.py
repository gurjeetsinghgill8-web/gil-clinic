"""
Tests for the delay detection module.
"""

import pytest
from datetime import datetime, timezone, timedelta
from app.engine.delay import check_delay, DelayResult


class TestDelayDetection:
    """Tests for delay detection logic."""

    def test_no_delay_when_recently_called(self):
        """No delay when current patient was just called."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=60),
            avg_time_seconds=600,
            waiting_count=5,
        )
        assert result is None, "Should not detect delay for recent call"

    def test_warning_delay_at_5_minutes(self):
        """Warning severity at 5+ minutes over average."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=900),  # 15 min
            avg_time_seconds=600,  # 10 min average
            waiting_count=3,
        )
        assert result is not None
        assert result.severity == "warning"
        assert result.delay_seconds == 300  # 15 - 10 = 5 min delay

    def test_critical_delay_at_10_minutes(self):
        """Critical severity at 10+ minutes over average."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=1200),  # 20 min
            avg_time_seconds=600,  # 10 min average
            waiting_count=5,
        )
        assert result is not None
        assert result.severity == "critical"
        assert result.delay_seconds == 600  # 20 - 10 = 10 min delay

    def test_no_delay_when_ahead_of_schedule(self):
        """No delay if current patient is ahead of schedule."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=300),  # 5 min
            avg_time_seconds=600,  # 10 min average
            waiting_count=10,
        )
        assert result is None, "Should not detect delay when ahead of schedule"

    def test_no_current_patient_returns_none(self):
        """No delay when no patient is currently being served."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=None,
            avg_time_seconds=600,
            waiting_count=0,
        )
        assert result is None, "Should not detect delay with no current patient"

    def test_delay_at_exact_threshold_warning(self):
        """Exactly at warning threshold (300s delay = 5min)."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=900),
            avg_time_seconds=600,
            waiting_count=2,
        )
        assert result is not None
        assert result.delay_seconds == 300
        assert result.severity == "warning"

    def test_delay_minutes_property(self):
        """Delay minutes should be integer division of seconds by 60."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=1500),
            avg_time_seconds=600,
            waiting_count=1,
        )
        assert result is not None
        assert result.delay_minutes == 15  # (1500 - 600) / 60 = 15

    def test_to_dict_format(self):
        """DelayResult.to_dict() should return correct structure."""
        result = check_delay(
            department_id="dept-ecg-001",
            department_name="ECG",
            called_at=datetime.now(timezone.utc) - timedelta(seconds=1200),
            avg_time_seconds=600,
            waiting_count=3,
        )
        d = result.to_dict()
        assert d["department_id"] == "dept-ecg-001"
        assert d["department_name"] == "ECG"
        assert d["delay_seconds"] == 600
        assert d["severity"] == "critical"
        assert d["waiting_count"] == 3
        assert d["elapsed_seconds"] == 1200
