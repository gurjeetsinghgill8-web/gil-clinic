"""
Tests for the queue engine core algorithms.
"""

import pytest
from datetime import datetime, timezone, date
from unittest.mock import AsyncMock, patch

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import QueueEntry, QueueStatus, VisitStatus, Department, Visit
from app.engine.queue_engine import (
    enqueue,
    dequeue,
    start_patient,
    skip_patient,
    complete_patient,
    get_queue_status,
    get_current_patient,
    get_position,
    get_wait_time_for_department,
    calculate_wait_time,
)


class TestEnqueue:
    """Tests for the enqueue operation."""

    @pytest.mark.asyncio
    async def test_enqueue_creates_entry(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Enqueue should create a QueueEntry with WAITING status."""
        mock_redis.increment_and_get_token.return_value = 1

        entry = await enqueue(
            db=seeded_db,
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            priority=0,
        )

        assert entry is not None
        assert entry.token_number == 1
        assert entry.status == QueueStatus.WAITING
        assert entry.visit_id == sample_visit.id
        assert entry.department_id == sample_department.id
        assert entry.priority == 0
        assert entry.priority_score == 1.0  # (0 * 1000) + 1

    @pytest.mark.asyncio
    async def test_enqueue_high_priority(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Enqueue with emergency priority should calculate higher score."""
        mock_redis.increment_and_get_token.return_value = 5

        entry = await enqueue(
            db=seeded_db,
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            priority=2,  # Emergency
        )

        assert entry.priority == 2
        assert entry.priority_score == -1995.0  # 5 - (2 * 1000) = -1995

    @pytest.mark.asyncio
    async def test_enqueue_calls_redis(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Enqueue should add entry to Redis sorted set."""
        mock_redis.increment_and_get_token.return_value = 1

        await enqueue(
            db=seeded_db,
            visit_id=sample_visit.id,
            department_id=sample_department.id,
        )

        mock_redis.add_to_queue.assert_called_once()
        mock_redis.publish_event.assert_called_once()

    @pytest.mark.asyncio
    async def test_enqueue_with_source_department(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Enqueue with source_department should not error."""
        mock_redis.increment_and_get_token.return_value = 1

        # No previous entry exists for the source, so it should just skip
        entry = await enqueue(
            db=seeded_db,
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            source_department_id="dept-nonexistent",
        )

        assert entry is not None
        assert entry.status == QueueStatus.WAITING


class TestDequeue:
    """Tests for the dequeue operation."""

    @pytest.mark.asyncio
    async def test_dequeue_empty_returns_none(self, seeded_db, mock_redis, sample_department):
        """Dequeue from empty queue should return None."""
        mock_redis.pop_min_from_queue.return_value = None

        entry = await dequeue(seeded_db, sample_department.id)
        assert entry is None

    @pytest.mark.asyncio
    async def test_dequeue_calls_patient(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Dequeue should mark entry as CALLED and set called_at."""
        # Create a waiting entry
        entry = QueueEntry(
            id="qe-001",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.WAITING,
            priority=0,
            priority_score=1.0,
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        # Mock Redis to return our entry
        mock_redis.pop_min_from_queue.return_value = ("qe-001", 1.0)
        mock_redis.get_queue_length.return_value = 0

        called = await dequeue(seeded_db, sample_department.id)

        assert called is not None
        assert called.id == "qe-001"
        assert called.status == QueueStatus.CALLED
        assert called.called_at is not None
        mock_redis.publish_event.assert_called_once()

    @pytest.mark.asyncio
    async def test_dequeue_skips_already_called(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Dequeue should skip entries that are already called."""
        # Create a called entry (should be skipped)
        entry = QueueEntry(
            id="qe-called",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.CALLED,  # Already called!
            priority=0,
            priority_score=1.0,
            called_at=datetime.now(timezone.utc),
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        # Mock Redis to return the called entry first, then None
        mock_redis.pop_min_from_queue.side_effect = [("qe-called", 1.0), None]

        called = await dequeue(seeded_db, sample_department.id)
        assert called is None  # No more entries after skipping


class TestSkipComplete:
    """Tests for skip and complete operations."""

    @pytest.mark.asyncio
    async def test_skip_waiting_entry(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Skip should move WAITING → SKIPPED."""
        entry = QueueEntry(
            id="qe-skip",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.WAITING,
            priority=0,
            priority_score=1.0,
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        skipped = await skip_patient(seeded_db, "qe-skip")
        assert skipped is not None
        assert skipped.status == QueueStatus.SKIPPED
        mock_redis.remove_from_queue.assert_called_once_with(sample_department.id, "qe-skip")

    @pytest.mark.asyncio
    async def test_complete_in_progress_entry(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Complete should move IN_PROGRESS → COMPLETED."""
        entry = QueueEntry(
            id="qe-complete",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.IN_PROGRESS,
            priority=0,
            priority_score=1.0,
            started_at=datetime.now(timezone.utc),
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        completed = await complete_patient(seeded_db, "qe-complete")
        assert completed is not None
        assert completed.status == QueueStatus.COMPLETED
        assert completed.completed_at is not None

    @pytest.mark.asyncio
    async def test_start_called_entry(self, seeded_db, mock_redis, sample_department, sample_visit):
        """Start should move CALLED → IN_PROGRESS."""
        entry = QueueEntry(
            id="qe-start",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.CALLED,
            priority=0,
            priority_score=1.0,
            called_at=datetime.now(timezone.utc),
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        started = await start_patient(seeded_db, "qe-start")
        assert started is not None
        assert started.status == QueueStatus.IN_PROGRESS
        assert started.started_at is not None


class TestQueueStatus:
    """Tests for queue status queries."""

    @pytest.mark.asyncio
    async def test_get_queue_status_empty(self, seeded_db, mock_redis, sample_department):
        """Queue status for empty queue should show zero counts."""
        mock_redis.get_wait_time.return_value = None

        status = await get_queue_status(seeded_db, sample_department.id)

        assert status["department_id"] == sample_department.id
        assert status["current"] is None
        assert status["waiting_count"] == 0
        assert status["stats"]["waiting"] == 0

    @pytest.mark.asyncio
    async def test_get_current_patient(self, seeded_db, mock_redis, sample_department, sample_visit):
        """get_current_patient should return the active patient."""
        entry = QueueEntry(
            id="qe-current",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.CALLED,
            priority=0,
            priority_score=1.0,
            called_at=datetime.now(timezone.utc),
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        current = await get_current_patient(seeded_db, sample_department.id)
        assert current is not None
        assert current.id == "qe-current"
        assert current.status == QueueStatus.CALLED


class TestPosition:
    """Tests for position queries."""

    @pytest.mark.asyncio
    async def test_get_position_waiting(self, seeded_db, mock_redis, sample_department, sample_visit):
        """get_position should return position for waiting entry."""
        entry = QueueEntry(
            id="qe-pos",
            visit_id=sample_visit.id,
            department_id=sample_department.id,
            token_number=1,
            status=QueueStatus.WAITING,
            priority=0,
            priority_score=1.0,
            entered_at=datetime.now(timezone.utc),
            queue_date=date.today(),
        )
        seeded_db.add(entry)
        await seeded_db.commit()

        mock_redis.get_queue_position.return_value = 0  # First position (0-indexed)
        mock_redis.get_wait_time.return_value = 300

        pos = await get_position(seeded_db, "qe-pos")
        assert pos is not None
        assert pos["position"] == 1  # 1-indexed
        assert pos["total_ahead"] == 0
        assert pos["estimated_wait_seconds"] == 300

    @pytest.mark.asyncio
    async def test_get_position_nonexistent(self, seeded_db, mock_redis):
        """get_position should return None for nonexistent entry."""
        pos = await get_position(seeded_db, "nonexistent-id")
        assert pos is None
