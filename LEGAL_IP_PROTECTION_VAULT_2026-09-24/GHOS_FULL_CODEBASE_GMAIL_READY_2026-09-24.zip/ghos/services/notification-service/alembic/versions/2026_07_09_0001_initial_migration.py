"""Initial migration: notifications, notification_templates, delivery_logs

Revision ID: 0001
Revises:
Create Date: 2026-07-09
"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa

# revision identifiers
revision: str = "0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ─── Enum types ──────────────────────────────────────────────────────────
    op.execute("CREATE TYPE notif_type AS ENUM ("
               "'patient_called', 'patient_routed', 'report_ready', "
               "'appointment_reminder', 'followup_reminder', "
               "'missed_call_alert', 'registration', 'queue_update', "
               "'system_alert', 'payment_reminder', 'otp', 'custom')")

    op.execute("CREATE TYPE notif_channel AS ENUM ("
               "'websocket', 'push', 'whatsapp', 'sms', "
               "'console', 'voice', 'email')")

    op.execute("CREATE TYPE notif_priority AS ENUM ("
               "'critical', 'high', 'medium', 'low')")

    op.execute("CREATE TYPE notif_status AS ENUM ("
               "'pending', 'queued', 'sent', 'delivered', "
               "'failed', 'read', 'cancelled')")

    # ─── Table: notifications ────────────────────────────────────────────────
    op.create_table(
        "notifications",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("notification_type", sa.Enum("patient_called", "patient_routed",
                  "report_ready", "appointment_reminder", "followup_reminder",
                  "missed_call_alert", "registration", "queue_update",
                  "system_alert", "payment_reminder", "otp", "custom",
                  name="notif_type", create_type=False), nullable=False),
        sa.Column("channel", sa.Enum("websocket", "push", "whatsapp", "sms",
                  "console", "voice", "email",
                  name="notif_channel", create_type=False), nullable=False),
        sa.Column("priority", sa.Enum("critical", "high", "medium", "low",
                  name="notif_priority", create_type=False),
                  nullable=False, server_default="medium"),
        sa.Column("status", sa.Enum("pending", "queued", "sent", "delivered",
                  "failed", "read", "cancelled",
                  name="notif_status", create_type=False),
                  nullable=False, server_default="pending"),
        sa.Column("recipient_id", sa.String(36), nullable=True, index=True),
        sa.Column("recipient_name", sa.String(100), nullable=True),
        sa.Column("recipient_mobile", sa.String(20), nullable=True),
        sa.Column("recipient_email", sa.String(200), nullable=True),
        sa.Column("title", sa.String(200), nullable=True),
        sa.Column("body", sa.Text, nullable=True),
        sa.Column("template_id", sa.String(36), nullable=True),
        sa.Column("template_vars", sa.JSON, nullable=True),
        sa.Column("language", sa.String(10), nullable=False, server_default="hi"),
        sa.Column("hospital_id", sa.String(36), nullable=False, server_default="default"),
        sa.Column("branch_id", sa.String(36), nullable=False, server_default="main"),
        sa.Column("provider", sa.String(50), nullable=True),
        sa.Column("provider_message_id", sa.String(200), nullable=True),
        sa.Column("attempt_count", sa.Integer, nullable=False, server_default="0"),
        sa.Column("max_attempts", sa.Integer, nullable=False, server_default="3"),
        sa.Column("last_error", sa.Text, nullable=True),
        sa.Column("delivered_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("read_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True),
                  server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True),
                  server_default=sa.func.now(), nullable=False),
        sa.Column("scheduled_at", sa.DateTime(timezone=True), nullable=True),
    )

    op.create_index("idx_notif_status", "notifications", ["status", "priority"])
    op.create_index("idx_notif_recipient", "notifications", ["recipient_id", "created_at"])
    op.create_index("idx_notif_type", "notifications", ["notification_type", "status"])

    # ─── Table: notification_templates ────────────────────────────────────────
    op.create_table(
        "notification_templates",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("notification_type", sa.Enum("patient_called", "patient_routed",
                  "report_ready", "appointment_reminder", "followup_reminder",
                  "missed_call_alert", "registration", "queue_update",
                  "system_alert", "payment_reminder", "otp", "custom",
                  name="notif_type", create_type=False), nullable=False),
        sa.Column("channel", sa.Enum("websocket", "push", "whatsapp", "sms",
                  "console", "voice", "email",
                  name="notif_channel", create_type=False), nullable=False),
        sa.Column("language", sa.String(10), nullable=False, server_default="hi"),
        sa.Column("subject", sa.String(200), nullable=True),
        sa.Column("body_template", sa.Text, nullable=False),
        sa.Column("variables", sa.JSON, nullable=True),
        sa.Column("active", sa.Boolean, nullable=False, server_default="true"),
        sa.Column("created_at", sa.DateTime(timezone=True),
                  server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True),
                  server_default=sa.func.now(), nullable=False),
    )

    op.create_index("idx_template_lookup", "notification_templates",
                    ["notification_type", "channel", "language"])

    # ─── Table: delivery_logs ────────────────────────────────────────────────
    op.create_table(
        "delivery_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("notification_id", sa.String(36),
                  sa.ForeignKey("notifications.id"), nullable=False, index=True),
        sa.Column("channel", sa.String(20), nullable=False),
        sa.Column("provider", sa.String(50), nullable=True),
        sa.Column("status", sa.String(20), nullable=False),
        sa.Column("status_code", sa.Integer, nullable=True),
        sa.Column("provider_message_id", sa.String(200), nullable=True),
        sa.Column("request_body", sa.JSON, nullable=True),
        sa.Column("response_body", sa.Text, nullable=True),
        sa.Column("error_message", sa.Text, nullable=True),
        sa.Column("latency_ms", sa.Integer, nullable=True),
        sa.Column("attempt_number", sa.Integer, nullable=False, server_default="1"),
        sa.Column("created_at", sa.DateTime(timezone=True),
                  server_default=sa.func.now(), nullable=False),
    )


def downgrade() -> None:
    op.drop_table("delivery_logs")
    op.drop_table("notification_templates")
    op.drop_table("notifications")

    op.execute("DROP TYPE IF EXISTS notif_status")
    op.execute("DROP TYPE IF EXISTS notif_priority")
    op.execute("DROP TYPE IF EXISTS notif_channel")
    op.execute("DROP TYPE IF EXISTS notif_type")
