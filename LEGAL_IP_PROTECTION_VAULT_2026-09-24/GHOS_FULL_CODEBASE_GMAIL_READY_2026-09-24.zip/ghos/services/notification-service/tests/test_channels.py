"""
GHOS Notification Service — Channel Tests
============================================
Tests all 5 delivery channels: console, websocket, whatsapp, sms, push.
"""

import pytest
from unittest.mock import AsyncMock, patch

from app.channels.base import Message
from app.channels.console_channel import ConsoleChannel
from app.channels.websocket_channel import WebSocketChannel
from app.channels.whatsapp_channel import WhatsAppChannel
from app.channels.sms_channel import SMSChannel
from app.channels.push_channel import PushChannel


pytestmark = pytest.mark.asyncio


# ─── Sample Messages ─────────────────────────────────────────────────────────

@pytest.fixture
def sample_message():
    return Message(
        notification_id="notif-001",
        notification_type="patient_called",
        channel="console",
        priority="high",
        recipient_id="P-001",
        recipient_name="Test Patient",
        recipient_mobile="9999999999",
        recipient_email="test@example.com",
        title="Your turn",
        body="Please proceed to ECG Room 1",
        language="en",
        hospital_id="default",
        branch_id="main",
    )


@pytest.fixture
def sample_message_no_mobile():
    return Message(
        notification_id="notif-002",
        notification_type="patient_called",
        channel="whatsapp",
        priority="high",
        recipient_id="P-002",
        recipient_name="No Mobile",
        recipient_mobile=None,
        body="Test message",
        language="en",
    )


@pytest.fixture
def sample_message_no_id():
    return Message(
        notification_id="notif-003",
        notification_type="report_ready",
        channel="push",
        priority="medium",
        recipient_id=None,
        recipient_name="No Device",
        body="Test push",
        language="en",
    )


# ─── Console Channel ─────────────────────────────────────────────────────────

class TestConsoleChannel:
    async def test_send_always_succeeds(self, sample_message):
        ch = ConsoleChannel()
        result = await ch.send(sample_message)
        assert result.success is True
        assert result.provider == "console"
        assert result.status_code == 200

    async def test_channel_name(self):
        ch = ConsoleChannel()
        assert ch.name == "console"

    async def test_validate_always_passes(self, sample_message):
        ch = ConsoleChannel()
        error = await ch.validate(sample_message)
        assert error is None


# ─── WebSocket Channel ───────────────────────────────────────────────────────

class TestWebSocketChannel:
    async def test_send_success(self, sample_message, mock_redis):
        ch = WebSocketChannel()
        result = await ch.send(sample_message)
        assert result.success is True
        assert result.provider == "redis_pubsub"

    async def test_send_redis_failure(self, sample_message):
        ch = WebSocketChannel()
        with patch("app.channels.websocket_channel.get_redis",
                   side_effect=Exception("Redis down")):
            result = await ch.send(sample_message)
            assert result.success is False
            assert "Redis down" in (result.error_message or "")

    async def test_channel_name(self):
        ch = WebSocketChannel()
        assert ch.name == "websocket"

    async def test_validate_always_passes(self, sample_message):
        ch = WebSocketChannel()
        error = await ch.validate(sample_message)
        assert error is None


# ─── WhatsApp Channel ────────────────────────────────────────────────────────

class TestWhatsAppChannel:
    async def test_send_success_dev_mode(self, sample_message):
        ch = WhatsAppChannel()
        result = await ch.send(sample_message)
        assert result.success is True
        assert result.provider == "whatsapp"
        assert result.status_code == 202

    async def test_validate_requires_mobile(self, sample_message_no_mobile):
        ch = WhatsAppChannel()
        error = await ch.validate(sample_message_no_mobile)
        assert error is not None
        assert "recipient_mobile" in error

    async def test_channel_name(self):
        ch = WhatsAppChannel()
        assert ch.name == "whatsapp"


# ─── SMS Channel ─────────────────────────────────────────────────────────────

class TestSMSChannel:
    async def test_send_success_console_provider(self, sample_message):
        with patch("app.config.settings.sms_provider", "console"):
            ch = SMSChannel()
            result = await ch.send(sample_message)
            assert result.success is True
            assert result.status_code == 202

    async def test_send_unknown_provider(self, sample_message):
        with patch("app.config.settings.sms_provider", "nonexistent"):
            ch = SMSChannel()
            result = await ch.send(sample_message)
            assert result.success is True  # Falls back gracefully
            assert result.status_code == 501
            assert "not implemented" in (result.error_message or "")

    async def test_validate_requires_mobile(self, sample_message_no_mobile):
        ch = SMSChannel()
        error = await ch.validate(sample_message_no_mobile)
        assert error is not None
        assert "recipient_mobile" in error

    async def test_channel_name(self):
        ch = SMSChannel()
        assert ch.name == "sms"


# ─── Push Channel ────────────────────────────────────────────────────────────

class TestPushChannel:
    async def test_send_success_dev_mode(self, sample_message):
        ch = PushChannel()
        result = await ch.send(sample_message)
        assert result.success is True
        assert result.provider == "fcm_stub"
        assert result.status_code == 202

    async def test_validate_requires_recipient_id(self, sample_message_no_id):
        ch = PushChannel()
        error = await ch.validate(sample_message_no_id)
        assert error is not None
        assert "recipient_id" in error

    async def test_channel_name(self):
        ch = PushChannel()
        assert ch.name == "push"


# ─── Channel Registry Consistency ───────────────────────────────────────────

class TestChannelNames:
    """Ensure all channel names match the NotificationChannel enum."""

    @pytest.mark.parametrize("channel_cls,expected_name", [
        (ConsoleChannel, "console"),
        (WebSocketChannel, "websocket"),
        (WhatsAppChannel, "whatsapp"),
        (SMSChannel, "sms"),
        (PushChannel, "push"),
    ])
    async def test_channel_name_consistency(self, channel_cls, expected_name):
        ch = channel_cls()
        assert ch.name == expected_name

    async def test_all_channels_have_send(self):
        """Every channel must implement send()."""
        channels = [
            ConsoleChannel(),
            WebSocketChannel(),
            WhatsAppChannel(),
            SMSChannel(),
            PushChannel(),
        ]
        for ch in channels:
            msg = Message(
                notification_id="test",
                notification_type="custom",
                channel=ch.name,
                priority="low",
                body="test",
                language="en",
            )
            result = await ch.send(msg)
            assert hasattr(result, "success")
            assert hasattr(result, "provider")
            assert hasattr(result, "provider_message_id")
