"""
GHOS Notification Service — Test Configuration
=================================================
Pytest fixtures: in-memory SQLite DB, mock Redis, sample data.
"""

import pytest
import pytest_asyncio
from datetime import datetime, timezone
from typing import AsyncGenerator
from unittest.mock import AsyncMock, patch

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool

from app.models import Base, Notification, NotificationType, NotificationChannel, NotificationPriority, NotificationStatus
from app.channels.base import DeliveryResult


# ─── Test Database Engine (SQLite in-memory) ─────────────────────────────────

@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Create a fresh in-memory SQLite database for each test."""
    engine = create_async_engine(
        "sqlite+aiosqlite://",
        echo=False,
        poolclass=StaticPool,
    )

    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )

    async with session_factory() as session:
        yield session

    await engine.dispose()


# ─── Mock Redis Fixture ──────────────────────────────────────────────────────

@pytest.fixture
def mock_redis():
    """Mock the Redis client.

    get_redis() is synchronous (not async), so we patch with a function
    that returns a mock whose .publish() is awaitable.
    """
    mock = AsyncMock()
    mock.ping = AsyncMock(return_value=True)
    mock.publish = AsyncMock(return_value=1)

    async def fake_get_redis():
        return mock

    with patch("app.channels.websocket_channel.get_redis", side_effect=fake_get_redis):
        yield mock


# ─── Sample Notification Fixtures ────────────────────────────────────────────

@pytest.fixture
def sample_notification_data() -> dict:
    """Sample notification send request data."""
    return {
        "notification_type": "patient_called",
        "channel": "console",
        "priority": "high",
        "recipient_id": "P-001",
        "recipient_name": "Test Patient",
        "recipient_mobile": "9999999999",
        "title": "Your turn has arrived",
        "body": "Test Patient, your turn has arrived at ECG. Please proceed to ECG Room 1.",
        "language": "en",
        "hospital_id": "default",
        "branch_id": "main",
    }


@pytest.fixture
def sample_notification() -> Notification:
    """Create a sample Notification ORM object."""
    return Notification(
        id="notif-001",
        notification_type=NotificationType.PATIENT_CALLED,
        channel=NotificationChannel.CONSOLE,
        priority=NotificationPriority.HIGH,
        status=NotificationStatus.QUEUED,
        recipient_id="P-001",
        recipient_name="Test Patient",
        recipient_mobile="9999999999",
        body="Test Patient, your turn has arrived at ECG.",
        language="en",
        hospital_id="default",
        branch_id="main",
        max_attempts=3,
    )


@pytest.fixture
def console_delivery_success() -> DeliveryResult:
    """Successful delivery result from console channel."""
    return DeliveryResult(
        success=True,
        provider="console",
        provider_message_id="console_notif-001",
        status_code=200,
        latency_ms=0,
    )


@pytest.fixture
def console_delivery_failure() -> DeliveryResult:
    """Failed delivery result."""
    return DeliveryResult(
        success=False,
        provider="console",
        error_message="Simulated failure",
        status_code=500,
    )
