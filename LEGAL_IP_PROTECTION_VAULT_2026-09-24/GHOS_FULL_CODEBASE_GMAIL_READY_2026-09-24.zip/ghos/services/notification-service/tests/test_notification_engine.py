"""
GHOS Notification Service — Notification Engine Tests
========================================================
Tests the orchestrator: template selection, channel routing,
database persistence, status tracking, and retry logic.
"""

import pytest
from datetime import datetime, timezone
from unittest.mock import AsyncMock, patch

from sqlalchemy import select

from app.models import Notification, NotificationStatus, DeliveryLog
from app.engine.notification_engine import NotificationEngine, CHANNEL_REGISTRY


pytestmark = pytest.mark.asyncio


class TestSendNotification:
    """Test the main send() method."""

    async def test_send_with_console_channel_success(self, db_session, sample_notification_data):
        """Should send a notification via console and persist it."""
        engine = NotificationEngine()
        result = await engine.send(db=db_session, **sample_notification_data)

        assert result["notification_id"] is not None
        assert result["status"] == "sent"
        assert result["channel"] == "console"
        assert result["error"] is None

        # Verify persisted in DB
        db_result = await db_session.execute(
            select(Notification).where(Notification.id == result["notification_id"])
        )
        notif = db_result.scalar_one_or_none()
        assert notif is not None
        assert notif.status == NotificationStatus.SENT
        assert notif.recipient_name == "Test Patient"

        # Verify delivery log created
        log_result = await db_session.execute(
            select(DeliveryLog).where(DeliveryLog.notification_id == notif.id)
        )
        logs = log_result.scalars().all()
        assert len(logs) >= 1
        assert logs[0].status == "delivered"

    async def test_send_with_auto_routing(self, db_session, sample_notification_data):
        """Should auto-route when no channel specified."""
        data = {**sample_notification_data, "channel": None}
        engine = NotificationEngine()

        with patch.object(engine, "_render_notification",
                          AsyncMock(return_value={"body": "Rendered body"})):
            result = await engine.send(db=db_session, **data)

        assert result["notification_id"] is not None
        assert result["status"] in ("sent", "failed")

    async def test_send_persists_priority_and_type(self, db_session, sample_notification_data):
        """Should persist notification type and priority correctly."""
        engine = NotificationEngine()
        result = await engine.send(db=db_session, **sample_notification_data)

        db_result = await db_session.execute(
            select(Notification).where(Notification.id == result["notification_id"])
        )
        notif = db_result.scalar_one()
        assert notif.notification_type.value == "patient_called"
        assert notif.priority.value == "high"
        assert notif.language == "en"

    async def test_send_hindi_language(self, db_session):
        """Should handle Hindi language notifications."""
        data = {
            "notification_type": "patient_called",
            "channel": "console",
            "priority": "high",
            "recipient_name": "राम",
            "body": "राम जी, आपका नंबर आ गया है।",
            "language": "hi",
        }
        engine = NotificationEngine()
        result = await engine.send(db=db_session, **data)
        assert result["status"] == "sent"

    async def test_send_no_available_channel(self, db_session, sample_notification_data):
        """Should handle case when all channels fail."""
        from app.channels.base import DeliveryResult

        data = {**sample_notification_data, "channel": "whatsapp"}

        failed_result = DeliveryResult(
            success=False,
            provider="whatsapp",
            error_message="Simulated failure",
            status_code=500,
            latency_ms=0,
        )
        with patch.object(CHANNEL_REGISTRY["whatsapp"], "send",
                          AsyncMock(return_value=failed_result)):
            engine = NotificationEngine()
            result = await engine.send(db=db_session, **data)
            assert result["status"] == "failed"

    async def test_send_with_template_vars(self, db_session):
        """Should handle template variables."""
        data = {
            "notification_type": "patient_called",
            "channel": "console",
            "priority": "medium",
            "recipient_name": "Test",
            "template_vars": {"patient_name": "Test", "department": "ECG"},
            "language": "en",
            "body": "Hello {{ patient_name }} at {{ department }}",
        }
        engine = NotificationEngine()
        result = await engine.send(db=db_session, **data)
        assert result["status"] == "sent"

        # Verify body was rendered
        db_result = await db_session.execute(
            select(Notification).where(Notification.id == result["notification_id"])
        )
        notif = db_result.scalar_one()
        # Template vars are stored, body is the raw template
        assert notif.template_vars == {"patient_name": "Test", "department": "ECG"}


class TestRetryNotification:
    """Test retry logic for failed notifications."""

    async def test_retry_failed_notification(self, db_session, sample_notification_data):
        """Should retry a failed notification."""
        # First send with a channel that will fail
        data = {**sample_notification_data, "channel": "whatsapp"}
        engine = NotificationEngine()
        send_result = await engine.send(db=db_session, **data)

        # Now retry with console
        retry_result = await engine.retry(
            db=db_session,
            notification_id=send_result["notification_id"],
            channel="console",
        )
        assert retry_result.get("error") is None
        assert retry_result["status"] == "sent"

    async def test_retry_max_attempts(self, db_session):
        """Should reject retry when max attempts reached."""
        engine = NotificationEngine()

        # Create a notification that already has max attempts
        from app.models import Notification, NotificationStatus, NotificationType, NotificationChannel, NotificationPriority
        notif = Notification(
            id="maxed-out",
            notification_type=NotificationType.PATIENT_CALLED,
            channel=NotificationChannel.CONSOLE,
            priority=NotificationPriority.MEDIUM,
            status=NotificationStatus.FAILED,
            body="Test",
            language="en",
            attempt_count=3,
            max_attempts=3,
        )
        db_session.add(notif)
        await db_session.commit()

        result = await engine.retry(db=db_session, notification_id="maxed-out")
        assert "error" in result
        assert "Max retry attempts" in result["error"]

    async def test_retry_nonexistent(self, db_session):
        """Should return error for nonexistent notification."""
        engine = NotificationEngine()
        result = await engine.retry(db=db_session, notification_id="nonexistent")
        assert "error" in result
        assert "not found" in result["error"]


class TestGetNotificationStatus:
    """Test status retrieval."""

    async def test_get_status(self, db_session, sample_notification_data):
        """Should return notification status with delivery logs."""
        engine = NotificationEngine()
        send_result = await engine.send(db=db_session, **sample_notification_data)

        status = await engine.get_status(db=db_session, notification_id=send_result["notification_id"])
        assert status is not None
        assert status["id"] == send_result["notification_id"]
        assert status["type"] == "patient_called"
        assert status["status"] == "sent"
        assert len(status["delivery_logs"]) >= 1
        assert status["recipient"]["name"] == "Test Patient"

    async def test_get_status_not_found(self, db_session):
        """Should return None for nonexistent notification."""
        engine = NotificationEngine()
        status = await engine.get_status(db=db_session, notification_id="nonexistent")
        assert status is None


class TestChannelRouting:
    """Test channel routing logic."""

    async def test_patient_called_routes_to_websocket_first(self):
        """patient_called should try websocket first per routing config."""
        from app.engine.notification_engine import CHANNEL_ROUTING_ORDER
        channels = CHANNEL_ROUTING_ORDER.get("patient_called", [])
        assert channels[0] == "websocket"

    async def test_report_ready_routes_to_whatsapp_first(self):
        """report_ready should try whatsapp first."""
        from app.engine.notification_engine import CHANNEL_ROUTING_ORDER
        channels = CHANNEL_ROUTING_ORDER.get("report_ready", [])
        assert channels[0] == "whatsapp"

    async def test_all_types_have_routes(self):
        """Every notification type should have at least one fallback channel."""
        from app.engine.notification_engine import CHANNEL_ROUTING_ORDER
        assert len(CHANNEL_ROUTING_ORDER) > 0
        for ntype, channels in CHANNEL_ROUTING_ORDER.items():
            assert len(channels) >= 1
            # Last fallback should always be 'console'
            # (not enforced, but good practice)

    async def test_console_is_fallback(self):
        """console should be in every routing chain as ultimate fallback."""
        from app.engine.notification_engine import CHANNEL_ROUTING_ORDER
        for ntype, channels in CHANNEL_ROUTING_ORDER.items():
            assert "console" in channels, f"{ntype} lacks console fallback"


class TestDatabaseEdgeCases:
    """Test database edge cases."""

    async def test_empty_db_send(self, db_session, sample_notification_data):
        """Should work with empty database."""
        engine = NotificationEngine()
        result = await engine.send(db=db_session, **sample_notification_data)
        assert result["status"] == "sent"

    async def test_multiple_notifications_same_recipient(self, db_session, sample_notification_data):
        """Should handle multiple notifications for same recipient."""
        engine = NotificationEngine()
        for i in range(3):
            data = {**sample_notification_data, "title": f"Notification {i}"}
            result = await engine.send(db=db_session, **data)
            assert result["status"] == "sent"

        # Verify all persisted
        db_result = await db_session.execute(
            select(Notification).where(Notification.recipient_id == "P-001")
        )
        notifications = db_result.scalars().all()
        assert len(notifications) == 3
