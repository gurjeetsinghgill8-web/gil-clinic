"""
GHOS Notification Service — Template Engine Tests
=====================================================
Tests Jinja2 template rendering with bilingual support.
"""

import pytest
from app.engine.template_engine import TemplateEngine, get_default_template, DEFAULT_TEMPLATES


class TestGetDefaultTemplate:
    """Test default template lookup."""

    def test_existing_template_hindi(self):
        """Should return Hindi template for patient_called."""
        tmpl = get_default_template("patient_called", "hi")
        assert tmpl is not None
        assert "body" in tmpl
        assert "नंबर आ गया है" in tmpl["body"]

    def test_existing_template_english(self):
        """Should return English template for patient_called."""
        tmpl = get_default_template("patient_called", "en")
        assert tmpl is not None
        assert "body" in tmpl
        assert "your turn has arrived" in tmpl["body"]

    def test_fallback_to_hindi_when_language_missing(self):
        """Should fall back to Hindi when language not found."""
        tmpl = get_default_template("patient_called", "fr")
        assert tmpl is not None
        # Falls back to "hi"
        assert "नंबर आ गया है" in tmpl["body"]

    def test_unknown_type_returns_none(self):
        """Should return None for unknown notification type."""
        tmpl = get_default_template("unknown_type", "hi")
        assert tmpl is None

    def test_all_types_have_defaults(self):
        """All notification types should have at least Hindi defaults."""
        for ntype in ["patient_called", "report_ready", "registration", "otp",
                      "appointment_reminder", "queue_update", "missed_call_alert"]:
            tmpl = get_default_template(ntype, "hi")
            assert tmpl is not None, f"Missing default template for {ntype}"
            assert "body" in tmpl


@pytest.mark.asyncio
class TestTemplateEngine:
    """Test TemplateEngine class."""

    async def test_render_simple(self):
        """Should render a simple template with variables."""
        engine = TemplateEngine()
        result = await engine.render("Hello {{ name }}!", {"name": "World"})
        assert result == "Hello World!"

    async def test_render_hindi_template(self):
        """Should render Hindi template with patient variables."""
        engine = TemplateEngine()
        result = await engine.render(
            "{{ name }} जी, आपका नंबर आ गया है।",
            {"name": "राम"},
        )
        assert result == "राम जी, आपका नंबर आ गया है।"

    async def test_render_missing_variable(self):
        """Should handle missing variables gracefully (Jinja2 undefined)."""
        engine = TemplateEngine()
        result = await engine.render("Hello {{ name }}!", {})
        # Jinja2 by default renders undefined as empty string
        assert result == "Hello !"

    async def test_render_template_error(self):
        """Should handle template syntax errors gracefully."""
        engine = TemplateEngine()
        # TemplateSyntaxError — Jinja2 handles syntax errors at compile time
        result = await engine.render("{{ broken", {})
        assert result is not None  # Falls back to raw template string

    async def test_render_notification_with_default_template(self):
        """Should render a full notification using default template."""
        engine = TemplateEngine()
        result = await engine.render_notification(
            notification_type="patient_called",
            language="en",
            variables={
                "patient_name": "John",
                "department_name": "ECG",
                "room": "Room 101",
            },
        )
        assert "John" in result["body"]
        assert "ECG" in result["body"]
        assert "Room 101" in result["body"]
        assert "your turn has arrived" in result["body"]

    async def test_render_notification_with_custom_body(self):
        """Should use provided db_template_body over default."""
        engine = TemplateEngine()
        result = await engine.render_notification(
            notification_type="patient_called",
            language="en",
            variables={"name": "John"},
            db_template_body="Custom: {{ name }}",
        )
        assert result["body"] == "Custom: John"

    async def test_render_notification_hindi_default(self):
        """Should render Hindi notification correctly."""
        engine = TemplateEngine()
        result = await engine.render_notification(
            notification_type="patient_called",
            language="hi",
            variables={
                "patient_name": "राम",
                "department_name": "ईसीजी",
                "room": "कक्ष 101",
            },
        )
        assert "राम" in result["body"]
        assert "ईसीजी" in result["body"]

    async def test_all_default_templates_render_with_variables(self):
        """All default templates should render without errors."""
        engine = TemplateEngine()
        sample_vars = {
            "patient_name": "Test",
            "department_name": "ECG",
            "room": "Room 1",
            "test_name": "Blood Test",
            "token_number": "A-101",
            "otp": "123456",
            "time": "10:00 AM",
            "ahead_count": "5",
            "wait_time": "15",
        }

        for ntype in DEFAULT_TEMPLATES:
            for lang in ["hi", "en"]:
                result = await engine.render_notification(
                    notification_type=ntype,
                    language=lang,
                    variables=sample_vars,
                )
                assert result["body"] is not None, f"Failed to render {ntype}/{lang}"
                assert len(result["body"]) > 0, f"Empty body for {ntype}/{lang}"
