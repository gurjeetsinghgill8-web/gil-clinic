"""
GHOS Notification Service — Configuration
=============================================
Pydantic Settings for notification engine, channels, and providers.
"""

from pydantic_settings import BaseSettings
from typing import List, Optional


class Settings(BaseSettings):
    # App
    app_name: str = "GHOS-Notification-Service"
    version: str = "1.0.0"
    environment: str = "development"
    debug: bool = True
    log_level: str = "INFO"
    cors_origins: List[str] = ["*"]

    # Database
    database_url: str = "postgresql+asyncpg://ghos:ghos_secret@localhost:5432/ghos_queue"
    database_pool_size: int = 10
    database_max_overflow: int = 20

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Server
    host: str = "0.0.0.0"
    port: int = 8004

    # ─── Hospital Defaults ──────────────────────────────────────────────────
    hospital_id: str = "default"
    branch_id: str = "main"
    default_language: str = "hi"

    # ─── Notification Defaults ─────────────────────────────────────────────
    notification_retry_max_attempts: int = 3
    notification_retry_delay_seconds: int = 30
    notification_queue_processor_interval: float = 1.0

    # ─── WhatsApp ──────────────────────────────────────────────────────────
    whatsapp_api_url: str = "https://graph.facebook.com/v18.0/"
    whatsapp_phone_number_id: str = ""
    whatsapp_api_token: str = ""

    # ─── SMS ───────────────────────────────────────────────────────────────
    sms_provider: str = "console"  # console | twilio | msg91
    sms_api_key: str = ""
    sms_sender_id: str = "GHOS"

    # ─── Push (FCM) ────────────────────────────────────────────────────────
    fcm_server_key: str = ""
    fcm_api_url: str = "https://fcm.googleapis.com/fcm/send"

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
