"""
GHOS Notification Service — Template Engine
===============================================
Jinja2 template rendering with bilingual support (Hindi/English).
Templates are stored in the database and rendered at send-time.
"""

import logging
from typing import Optional, Dict, Any
from datetime import datetime, timezone

from jinja2 import Template as JinjaTemplate, TemplateError

logger = logging.getLogger(__name__)

# Default templates (used when no DB template is found)
DEFAULT_TEMPLATES = {
    "patient_called": {
        "hi": {
            "body": "{{ patient_name }} जी, आपका {{ department_name }} में नंबर आ गया है। कृपया {{ room }} पर आएं।",
        },
        "en": {
            "body": "{{ patient_name }}, your turn has arrived at {{ department_name }}. Please proceed to {{ room }}.",
        },
    },
    "report_ready": {
        "hi": {
            "body": "{{ patient_name }} जी, आपकी {{ test_name }} रिपोर्ट तैयार है। कृपया जांचें।",
        },
        "en": {
            "body": "{{ patient_name }}, your {{ test_name }} report is ready. Please check.",
        },
    },
    "registration": {
        "hi": {
            "body": "{{ patient_name }} जी, आपका रजिस्ट्रेशन हो गया है। आपका टोकन नंबर {{ token_number }} है।",
        },
        "en": {
            "body": "{{ patient_name }}, you have been registered. Your token number is {{ token_number }}.",
        },
    },
    "otp": {
        "hi": {
            "body": "आपका OTP {{ otp }} है। यह 5 मिनट के लिए वैध है।",
        },
        "en": {
            "body": "Your OTP is {{ otp }}. Valid for 5 minutes.",
        },
    },
    "appointment_reminder": {
        "hi": {
            "body": "{{ patient_name }} जी, कल {{ time }} पर आपकी अपॉइंटमेंट है। कृपया समय पर आएं।",
        },
        "en": {
            "body": "{{ patient_name }}, you have an appointment tomorrow at {{ time }}. Please arrive on time.",
        },
    },
    "queue_update": {
        "hi": {
            "body": "{{ department_name }} में आपके सामने {{ ahead_count }} मरीज़ बाकी हैं। अनुमानित प्रतीक्षा: {{ wait_time }} मिनट।",
        },
        "en": {
            "body": "{{ ahead_count }} patients ahead of you at {{ department_name }}. Estimated wait: {{ wait_time }} minutes.",
        },
    },
    "missed_call_alert": {
        "hi": {
            "body": "{{ patient_name }} जी, आपका मिस्ड कॉल रिकॉर्ड हो गया है। जल्द ही संपर्क करेंगे।",
        },
        "en": {
            "body": "{{ patient_name }}, your missed call has been recorded. We'll contact you shortly.",
        },
    },
}


def get_default_template(notification_type: str, language: str) -> Optional[dict]:
    """Get a default template for a notification type and language."""
    type_templates = DEFAULT_TEMPLATES.get(notification_type, {})
    return type_templates.get(language, type_templates.get("hi"))


class TemplateEngine:
    """Renders notification templates using Jinja2."""

    async def render(
        self,
        body_template: str,
        variables: Dict[str, Any],
    ) -> str:
        """Render a Jinja2 template with the given variables."""
        try:
            template = JinjaTemplate(body_template)
            return template.render(**variables)
        except TemplateError as e:
            logger.error(f"Template rendering error: {e}")
            return body_template  # Fallback: return raw template

    async def render_notification(
        self,
        notification_type: str,
        language: str,
        variables: Dict[str, Any],
        db_template_body: Optional[str] = None,
    ) -> dict:
        """Render a full notification (body + optional subject).

        Uses DB template if provided, otherwise falls back to default templates.
        """
        body = db_template_body
        if not body:
            default = get_default_template(notification_type, language)
            if default:
                body = default["body"]
            else:
                body = "{{ notification_type }} notification"

        rendered_body = await self.render(body, variables)
        return {"body": rendered_body}


# Global instance
template_engine = TemplateEngine()
