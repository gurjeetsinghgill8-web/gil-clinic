"""
GHOS Notification Service — Notification Engine
==================================================
Central orchestrator that:
1. Receives a send request
2. Selects the best channel (auto-routing)
3. Renders the template (Jinja2, bilingual)
4. Sends via the channel
5. Persists notification + delivery log to database
6. Updates status (queued → sent → delivered/failed)
7. Supports retry with backoff
"""

import logging
import time
from typing import Optional, List, Dict, Any
from datetime import datetime, timezone

from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.models import (
    Notification,
    NotificationTemplate,
    DeliveryLog,
    NotificationStatus,
    NotificationChannel,
    NotificationPriority,
)
from app.engine.template_engine import template_engine
from app.channels.base import BaseChannel, Message, DeliveryResult
from app.channels.console_channel import ConsoleChannel
from app.channels.websocket_channel import WebSocketChannel
from app.channels.whatsapp_channel import WhatsAppChannel
from app.channels.sms_channel import SMSChannel
from app.channels.push_channel import PushChannel

logger = logging.getLogger(__name__)

# Priority → max_attempts mapping
PRIORITY_RETRY_MAP = {
    "critical": 5,
    "high": 3,
    "medium": 3,
    "low": 1,
}

# Channel registry — all available channels
CHANNEL_REGISTRY: Dict[str, BaseChannel] = {
    "console": ConsoleChannel(),
    "websocket": WebSocketChannel(),
    "whatsapp": WhatsAppChannel(),
    "sms": SMSChannel(),
    "push": PushChannel(),
}

# Channel routing priority: best channels first
CHANNEL_ROUTING_ORDER = {
    # Notification type → ordered list of channels to try
    "patient_called": ["websocket", "push", "whatsapp", "console"],
    "patient_routed": ["websocket", "whatsapp", "console"],
    "report_ready": ["whatsapp", "sms", "push", "console"],
    "registration": ["whatsapp", "sms", "console"],
    "otp": ["whatsapp", "sms", "console"],
    "appointment_reminder": ["whatsapp", "sms", "console"],
    "followup_reminder": ["whatsapp", "sms", "console"],
    "missed_call_alert": ["websocket", "console"],
    "queue_update": ["websocket", "console"],
    "system_alert": ["push", "websocket", "console"],
    "payment_reminder": ["whatsapp", "sms", "console"],
    "custom": ["console"],
}


class NotificationEngine:
    """Central orchestrator for sending notifications."""

    async def send(
        self,
        db: AsyncSession,
        notification_type: str,
        channel: Optional[str] = None,
        priority: str = "medium",
        recipient_id: Optional[str] = None,
        recipient_name: Optional[str] = None,
        recipient_mobile: Optional[str] = None,
        recipient_email: Optional[str] = None,
        title: Optional[str] = None,
        body: Optional[str] = None,
        template_id: Optional[str] = None,
        template_vars: Optional[Dict[str, Any]] = None,
        language: str = "hi",
        hospital_id: str = "default",
        branch_id: str = "main",
        scheduled_at: Optional[datetime] = None,
    ) -> dict:
        """Send a notification. Auto-routes to best channel if not specified."""
        # ─── 1. Resolve channel ──────────────────────────────────────────
        if channel:
            channels_to_try = [channel]
        else:
            channels_to_try = CHANNEL_ROUTING_ORDER.get(
                notification_type, ["console"]
            )

        # ─── 2. Resolve priority → max attempts ─────────────────────────
        max_attempts = PRIORITY_RETRY_MAP.get(priority, 3)

        # ─── 3. Render body if not provided ──────────────────────────────
        if not body:
            rendered = await self._render_notification(
                db=db,
                notification_type=notification_type,
                channel=channels_to_try[0],
                language=language,
                template_id=template_id,
                template_vars=template_vars or {},
            )
            body = rendered["body"]

        # ─── 4. Create notification record ──────────────────────────────
        notif = Notification(
            notification_type=notification_type,
            channel=NotificationChannel(channels_to_try[0]),
            priority=NotificationPriority(priority),
            status=NotificationStatus.QUEUED,
            recipient_id=recipient_id,
            recipient_name=recipient_name,
            recipient_mobile=recipient_mobile,
            recipient_email=recipient_email,
            title=title,
            body=body,
            template_id=template_id,
            template_vars=template_vars,
            language=language,
            hospital_id=hospital_id,
            branch_id=branch_id,
            max_attempts=max_attempts,
            scheduled_at=scheduled_at,
        )
        db.add(notif)
        await db.flush()  # Get notif.id without committing

        # ─── 5. Try each channel in order ───────────────────────────────
        last_result: Optional[DeliveryResult] = None
        for ch_name in channels_to_try:
            ch = CHANNEL_REGISTRY.get(ch_name)
            if not ch:
                logger.warning(f"Channel '{ch_name}' not found in registry, skipping")
                continue

            # Validate
            msg = Message(
                notification_id=notif.id,
                notification_type=notification_type,
                channel=ch_name,
                priority=priority,
                recipient_id=recipient_id,
                recipient_name=recipient_name,
                recipient_mobile=recipient_mobile,
                recipient_email=recipient_email,
                title=title,
                body=body,
                template_id=template_id,
                template_vars=template_vars,
                language=language,
                hospital_id=hospital_id,
                branch_id=branch_id,
            )
            validation_error = await ch.validate(msg)
            if validation_error:
                logger.debug(f"Channel '{ch_name}' validation failed: {validation_error}")
                continue

            # Send
            start = time.monotonic()
            try:
                result = await ch.send(msg)
            except Exception as e:
                result = DeliveryResult(
                    success=False,
                    provider=ch_name,
                    error_message=str(e),
                    status_code=500,
                )
            latency = int((time.monotonic() - start) * 1000)
            result.latency_ms = latency
            last_result = result

            # Log delivery attempt
            delivery_log = DeliveryLog(
                notification_id=notif.id,
                channel=ch_name,
                provider=result.provider,
                status="delivered" if result.success else "failed",
                status_code=result.status_code,
                provider_message_id=result.provider_message_id,
                error_message=result.error_message,
                latency_ms=latency,
                attempt_number=1,
            )
            db.add(delivery_log)

            if result.success:
                # Update notification status
                notif.status = NotificationStatus.SENT
                notif.provider = result.provider
                notif.provider_message_id = result.provider_message_id
                notif.attempt_count = 1
                break
            else:
                logger.warning(
                    f"Channel '{ch_name}' failed: {result.error_message}"
                )

        if not last_result or not last_result.success:
            notif.status = NotificationStatus.FAILED
            notif.last_error = last_result.error_message if last_result else "No channel available"
            notif.attempt_count = 1

        await db.commit()
        await db.refresh(notif)

        return {
            "notification_id": notif.id,
            "status": notif.status.value,
            "channel": notif.channel.value if notif.channel else None,
            "provider": notif.provider,
            "provider_message_id": notif.provider_message_id,
            "error": notif.last_error,
        }

    async def retry(
        self,
        db: AsyncSession,
        notification_id: str,
        channel: Optional[str] = None,
    ) -> dict:
        """Retry a failed notification."""
        result = await db.execute(
            select(Notification).where(Notification.id == notification_id)
        )
        notif = result.scalar_one_or_none()
        if not notif:
            return {"error": "Notification not found"}

        if notif.attempt_count >= notif.max_attempts:
            return {"error": "Max retry attempts reached"}

        channels_to_try = [channel] if channel else [notif.channel.value]

        last_result = None
        for ch_name in channels_to_try:
            ch = CHANNEL_REGISTRY.get(ch_name)
            if not ch:
                continue

            msg = Message(
                notification_id=notif.id,
                notification_type=notif.notification_type.value,
                channel=ch_name,
                priority=notif.priority.value,
                recipient_id=notif.recipient_id,
                recipient_name=notif.recipient_name,
                recipient_mobile=notif.recipient_mobile,
                recipient_email=notif.recipient_email,
                title=notif.title,
                body=notif.body,
                template_id=notif.template_id,
                template_vars=notif.template_vars,
                language=notif.language,
                hospital_id=notif.hospital_id,
                branch_id=notif.branch_id,
            )

            validation_error = await ch.validate(msg)
            if validation_error:
                continue

            start = time.monotonic()
            try:
                result = await ch.send(msg)
            except Exception as e:
                result = DeliveryResult(
                    success=False, provider=ch_name, error_message=str(e), status_code=500
                )
            latency = int((time.monotonic() - start) * 1000)
            result.latency_ms = latency
            last_result = result

            delivery_log = DeliveryLog(
                notification_id=notif.id,
                channel=ch_name,
                provider=result.provider,
                status="delivered" if result.success else "failed",
                status_code=result.status_code,
                provider_message_id=result.provider_message_id,
                error_message=result.error_message,
                latency_ms=latency,
                attempt_number=notif.attempt_count + 1,
            )
            db.add(delivery_log)

            if result.success:
                notif.status = NotificationStatus.SENT
                notif.provider = result.provider
                notif.provider_message_id = result.provider_message_id
                notif.attempt_count += 1
                break

        if not last_result or not last_result.success:
            notif.attempt_count += 1
            notif.last_error = last_result.error_message if last_result else "Retry failed"
            if notif.attempt_count >= notif.max_attempts:
                notif.status = NotificationStatus.FAILED

        await db.commit()
        await db.refresh(notif)

        return {
            "notification_id": notif.id,
            "status": notif.status.value,
            "attempt_count": notif.attempt_count,
            "error": notif.last_error,
        }

    async def get_status(
        self,
        db: AsyncSession,
        notification_id: str,
    ) -> Optional[dict]:
        """Get notification status with delivery logs."""
        result = await db.execute(
            select(Notification).where(Notification.id == notification_id)
        )
        notif = result.scalar_one_or_none()
        if not notif:
            return None

        # Get delivery logs
        logs_result = await db.execute(
            select(DeliveryLog)
            .where(DeliveryLog.notification_id == notification_id)
            .order_by(DeliveryLog.created_at)
        )
        logs = logs_result.scalars().all()

        return {
            "id": notif.id,
            "type": notif.notification_type.value,
            "channel": notif.channel.value,
            "priority": notif.priority.value,
            "status": notif.status.value,
            "recipient": {
                "id": notif.recipient_id,
                "name": notif.recipient_name,
                "mobile": notif.recipient_mobile,
                "email": notif.recipient_email,
            },
            "body": notif.body,
            "attempt_count": notif.attempt_count,
            "max_attempts": notif.max_attempts,
            "provider": notif.provider,
            "provider_message_id": notif.provider_message_id,
            "last_error": notif.last_error,
            "delivered_at": notif.delivered_at.isoformat() if notif.delivered_at else None,
            "read_at": notif.read_at.isoformat() if notif.read_at else None,
            "created_at": notif.created_at.isoformat() if notif.created_at else None,
            "delivery_logs": [
                {
                    "id": log.id,
                    "channel": log.channel,
                    "provider": log.provider,
                    "status": log.status,
                    "status_code": log.status_code,
                    "error": log.error_message,
                    "latency_ms": log.latency_ms,
                    "attempt": log.attempt_number,
                    "timestamp": log.created_at.isoformat() if log.created_at else None,
                }
                for log in logs
            ],
        }

    async def _render_notification(
        self,
        db: AsyncSession,
        notification_type: str,
        channel: str,
        language: str,
        template_id: Optional[str] = None,
        template_vars: Optional[Dict[str, Any]] = None,
    ) -> dict:
        """Render notification body from template."""
        # Try to load a specific template from DB
        db_template_body = None

        if template_id:
            result = await db.execute(
                select(NotificationTemplate).where(
                    NotificationTemplate.id == template_id,
                    NotificationTemplate.active == True,
                )
            )
            tmpl = result.scalar_one_or_none()
            if tmpl:
                db_template_body = tmpl.body_template
        else:
            # Try to find a matching template by type + channel + language
            result = await db.execute(
                select(NotificationTemplate).where(
                    NotificationTemplate.notification_type == notification_type,
                    NotificationTemplate.channel == channel,
                    NotificationTemplate.language == language,
                    NotificationTemplate.active == True,
                ).limit(1)
            )
            tmpl = result.scalar_one_or_none()
            if tmpl:
                db_template_body = tmpl.body_template

        return await template_engine.render_notification(
            notification_type=notification_type,
            language=language,
            variables=template_vars or {},
            db_template_body=db_template_body,
        )


# Global singleton
notification_engine = NotificationEngine()
