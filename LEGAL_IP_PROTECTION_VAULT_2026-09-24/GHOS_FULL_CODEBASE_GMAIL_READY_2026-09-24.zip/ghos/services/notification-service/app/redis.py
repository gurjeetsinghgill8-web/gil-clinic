"""
GHOS Notification Service — Redis Client
============================================
Async Redis client for:
- Notification queue (list)
- Rate limiting per channel
- Deduplication cache
"""

from typing import Optional

from redis.asyncio import Redis as AsyncRedis, ConnectionPool

from app.config import settings

_pool: Optional[ConnectionPool] = None
_redis: Optional[AsyncRedis] = None


def get_redis() -> AsyncRedis:
    global _redis, _pool
    if _redis is None:
        _pool = ConnectionPool.from_url(
            settings.redis_url,
            decode_responses=True,
            max_connections=20,
        )
        _redis = AsyncRedis(connection_pool=_pool)
    return _redis


async def close_redis():
    global _redis, _pool
    if _redis:
        await _redis.aclose()
        _redis = None
    if _pool:
        await _pool.disconnect()
        _pool = None


async def ping() -> bool:
    r = get_redis()
    try:
        return await r.ping()
    except Exception:
        return False
