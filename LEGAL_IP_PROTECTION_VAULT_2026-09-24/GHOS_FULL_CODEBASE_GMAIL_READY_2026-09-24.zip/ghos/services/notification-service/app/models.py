"""
GHOS Notification Service — SQLAlchemy ORM Models
=====================================================
PostgreSQL tables for notifications, templates, and delivery tracking.
"""

import uuid
from datetime import datetime
from typing import Optional, List
from sqlalchemy import (
    Column, String, Integer, Boolean, DateTime, Text,
    ForeignKey, Enum as SAEnum, JSON, Index
)
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column
from sqlalchemy.sql import func
import enum


class Base(DeclarativeBase):
    pass


# ─── Enums ────────────────────────────────────────────────────────────────────

class NotificationType(str, enum.Enum):
    PATIENT_CALLED = "patient_called"
    PATIENT_ROUTED = "patient_routed"
    REPORT_READY = "report_ready"
    APPOINTMENT_REMINDER = "appointment_reminder"
    FOLLOWUP_REMINDER = "followup_reminder"
    MISSED_CALL_ALERT = "missed_call_alert"
    REGISTRATION = "registration"
    QUEUE_UPDATE = "queue_update"
    SYSTEM_ALERT = "system_alert"
    PAYMENT_REMINDER = "payment_reminder"
    OTP = "otp"
    CUSTOM = "custom"


class NotificationChannel(str, enum.Enum):
    WEBSOCKET = "websocket"
    PUSH = "push"
    WHATSAPP = "whatsapp"
    SMS = "sms"
    CONSOLE = "console"
    VOICE = "voice"
    EMAIL = "email"


class NotificationPriority(str, enum.Enum):
    CRITICAL = "critical"
    HIGH = "high"
    MEDIUM = "medium"
    LOW = "low"


class NotificationStatus(str, enum.Enum):
    PENDING = "pending"
    QUEUED = "queued"
    SENT = "sent"
    DELIVERED = "delivered"
    FAILED = "failed"
    READ = "read"
    CANCELLED = "cancelled"


# ─── Helper ───────────────────────────────────────────────────────────────────

def gen_uuid() -> str:
    return str(uuid.uuid4())


# ─── Notifications ────────────────────────────────────────────────────────────

class Notification(Base):
    __tablename__ = "notifications"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    notification_type: Mapped[NotificationType] = mapped_column(
        SAEnum(NotificationType, name="notif_type", create_constraint=True),
        nullable=False,
    )
    channel: Mapped[NotificationChannel] = mapped_column(
        SAEnum(NotificationChannel, name="notif_channel", create_constraint=True),
        nullable=False,
    )
    priority: Mapped[NotificationPriority] = mapped_column(
        SAEnum(NotificationPriority, name="notif_priority", create_constraint=True),
        default=NotificationPriority.MEDIUM,
    )
    status: Mapped[NotificationStatus] = mapped_column(
        SAEnum(NotificationStatus, name="notif_status", create_constraint=True),
        default=NotificationStatus.PENDING,
    )

    recipient_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True, index=True)
    recipient_name: Mapped[Optional[str]] = mapped_column(String(100), nullable=True)
    recipient_mobile: Mapped[Optional[str]] = mapped_column(String(20), nullable=True)
    recipient_email: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    title: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    body: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    template_id: Mapped[Optional[str]] = mapped_column(String(36), nullable=True)
    template_vars: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    language: Mapped[str] = mapped_column(String(10), default="hi")

    hospital_id: Mapped[str] = mapped_column(String(36), default="default")
    branch_id: Mapped[str] = mapped_column(String(36), default="main")

    # Delivery tracking
    provider: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)
    provider_message_id: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    attempt_count: Mapped[int] = mapped_column(Integer, default=0)
    max_attempts: Mapped[int] = mapped_column(Integer, default=3)
    last_error: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    delivered_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)
    read_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )
    scheduled_at: Mapped[Optional[datetime]] = mapped_column(DateTime(timezone=True), nullable=True)

    __table_args__ = (
        Index("idx_notif_status", "status", "priority"),
        Index("idx_notif_recipient", "recipient_id", "created_at"),
        Index("idx_notif_type", "notification_type", "status"),
    )

    def __repr__(self) -> str:
        return f"<Notification {self.notification_type.value} [{self.status.value}]>"


# ─── Notification Templates ─────────────────────────────────────────────────

class NotificationTemplate(Base):
    __tablename__ = "notification_templates"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    name: Mapped[str] = mapped_column(String(100), nullable=False)
    notification_type: Mapped[NotificationType] = mapped_column(
        SAEnum(NotificationType, name="notif_type", create_constraint=True),
        nullable=False,
    )
    channel: Mapped[NotificationChannel] = mapped_column(
        SAEnum(NotificationChannel, name="notif_channel", create_constraint=True),
        nullable=False,
    )
    language: Mapped[str] = mapped_column(String(10), default="hi")

    subject: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)
    body_template: Mapped[str] = mapped_column(Text, nullable=False)
    variables: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)

    active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )
    updated_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now(), onupdate=func.now()
    )

    __table_args__ = (
        Index("idx_template_lookup", "notification_type", "channel", "language"),
    )

    def __repr__(self) -> str:
        return f"<Template {self.name} [{self.language}]>"


# ─── Delivery Logs ───────────────────────────────────────────────────────────

class DeliveryLog(Base):
    __tablename__ = "delivery_logs"

    id: Mapped[str] = mapped_column(String(36), primary_key=True, default=gen_uuid)
    notification_id: Mapped[str] = mapped_column(
        String(36), ForeignKey("notifications.id"), nullable=False, index=True
    )
    channel: Mapped[str] = mapped_column(String(20), nullable=False)
    provider: Mapped[Optional[str]] = mapped_column(String(50), nullable=True)

    status: Mapped[str] = mapped_column(String(20), nullable=False)
    status_code: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    provider_message_id: Mapped[Optional[str]] = mapped_column(String(200), nullable=True)

    request_body: Mapped[Optional[dict]] = mapped_column(JSON, nullable=True)
    response_body: Mapped[Optional[str]] = mapped_column(Text, nullable=True)
    error_message: Mapped[Optional[str]] = mapped_column(Text, nullable=True)

    latency_ms: Mapped[Optional[int]] = mapped_column(Integer, nullable=True)
    attempt_number: Mapped[int] = mapped_column(Integer, default=1)

    created_at: Mapped[datetime] = mapped_column(
        DateTime(timezone=True), server_default=func.now()
    )

    def __repr__(self) -> str:
        return f"<DeliveryLog attempt={self.attempt_number} [{self.status}]>"
