"""
GHOS Notification Service — Pydantic Schemas
================================================
"""

from datetime import datetime
from typing import Optional, List, Any, Dict
from pydantic import BaseModel, Field


# ─── Send Notification ─────────────────────────────────────────────────────

class SendNotificationRequest(BaseModel):
    notification_type: str = Field(..., description="patient_called, report_ready, etc.")
    channel: Optional[str] = Field(default=None, description="Auto-select if omitted")
    priority: str = Field(default="medium", pattern="^(critical|high|medium|low)$")

    recipient_id: Optional[str] = None
    recipient_name: Optional[str] = None
    recipient_mobile: Optional[str] = None
    recipient_email: Optional[str] = None

    title: Optional[str] = None
    body: Optional[str] = None
    template_id: Optional[str] = None
    template_vars: Optional[Dict[str, Any]] = None
    language: str = Field(default="hi", pattern="^(hi|en)$")

    hospital_id: str = "default"
    branch_id: str = "main"
    scheduled_at: Optional[datetime] = None


# ─── Template CRUD ─────────────────────────────────────────────────────────

class CreateTemplateRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    notification_type: str
    channel: str
    language: str = "hi"
    subject: Optional[str] = None
    body_template: str = Field(..., min_length=1)
    variables: Optional[Dict[str, str]] = None


class UpdateTemplateRequest(BaseModel):
    name: Optional[str] = None
    subject: Optional[str] = None
    body_template: Optional[str] = None
    variables: Optional[Dict[str, str]] = None
    active: Optional[bool] = None


# ─── Webhook (DLR) ─────────────────────────────────────────────────────────

class DeliveryReceipt(BaseModel):
    provider: str
    provider_message_id: str = Field(..., alias="message_id")
    status: str = Field(..., pattern="^(delivered|failed|sent|read)$")
    status_code: Optional[int] = None
    error: Optional[str] = None
    timestamp: Optional[str] = None


# ─── Responses ─────────────────────────────────────────────────────────────

class ApiResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[dict] = None
    meta: Optional[dict] = None


class HealthResponse(BaseModel):
    status: str = "ok"
    service: str = "ghos-notification-service"
    version: str = "1.0.0"
    database: str = "connected"
    redis: str = "connected"
