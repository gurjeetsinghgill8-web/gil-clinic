"""
GHOS Notification Service — Template Routes
==============================================
CRUD for notification templates (Jinja2, bilingual).
POST /   — Create template
GET  /   — List templates
GET  /{id} — Get template
PUT  /{id} — Update template
DEL  /{id} — Delete template
"""

import logging
from typing import Optional

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas import CreateTemplateRequest, UpdateTemplateRequest, ApiResponse
from app.models import NotificationTemplate, NotificationType, NotificationChannel

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/templates", tags=["templates"])


@router.post("", response_model=ApiResponse, status_code=201)
async def create_template(
    req: CreateTemplateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Create a new notification template."""
    try:
        # Validate enums
        try:
            notif_type = NotificationType(req.notification_type)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid notification_type: {req.notification_type}"
            )
        try:
            notif_channel = NotificationChannel(req.channel)
        except ValueError:
            raise HTTPException(
                status_code=400,
                detail=f"Invalid channel: {req.channel}"
            )

        # Check for duplicate
        existing = await db.execute(
            select(NotificationTemplate).where(
                NotificationTemplate.notification_type == notif_type,
                NotificationTemplate.channel == notif_channel,
                NotificationTemplate.language == req.language,
                NotificationTemplate.name == req.name,
            )
        )
        if existing.scalar_one_or_none():
            raise HTTPException(
                status_code=409,
                detail="Template with same name/type/channel/language already exists"
            )

        template = NotificationTemplate(
            name=req.name,
            notification_type=notif_type,
            channel=notif_channel,
            language=req.language,
            subject=req.subject,
            body_template=req.body_template,
            variables=req.variables,
        )
        db.add(template)
        await db.commit()
        await db.refresh(template)

        return ApiResponse(
            data={
                "id": template.id,
                "name": template.name,
                "notification_type": template.notification_type.value,
                "channel": template.channel.value,
                "language": template.language,
                "active": template.active,
                "created_at": template.created_at.isoformat() if template.created_at else None,
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.get("", response_model=ApiResponse)
async def list_templates(
    notification_type: Optional[str] = Query(None),
    channel: Optional[str] = Query(None),
    language: Optional[str] = Query(None),
    active: Optional[bool] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """List notification templates with optional filters."""
    try:
        query = select(NotificationTemplate)

        if notification_type:
            query = query.where(NotificationTemplate.notification_type == notification_type)
        if channel:
            query = query.where(NotificationTemplate.channel == channel)
        if language:
            query = query.where(NotificationTemplate.language == language)
        if active is not None:
            query = query.where(NotificationTemplate.active == active)

        count_query = select(func.count()).select_from(query.subquery())
        total_result = await db.execute(count_query)
        total = total_result.scalar()

        query = query.order_by(desc(NotificationTemplate.created_at))
        query = query.offset(offset).limit(limit)
        result = await db.execute(query)
        templates = result.scalars().all()

        return ApiResponse(
            data={
                "items": [
                    {
                        "id": t.id,
                        "name": t.name,
                        "notification_type": t.notification_type.value,
                        "channel": t.channel.value,
                        "language": t.language,
                        "subject": t.subject,
                        "body_template": t.body_template,
                        "variables": t.variables,
                        "active": t.active,
                        "created_at": t.created_at.isoformat() if t.created_at else None,
                    }
                    for t in templates
                ],
                "total": total,
                "limit": limit,
                "offset": offset,
            }
        )
    except Exception as e:
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.get("/{template_id}", response_model=ApiResponse)
async def get_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get a single template by ID."""
    try:
        result = await db.execute(
            select(NotificationTemplate).where(NotificationTemplate.id == template_id)
        )
        template = result.scalar_one_or_none()
        if not template:
            raise HTTPException(status_code=404, detail="Template not found")

        return ApiResponse(
            data={
                "id": template.id,
                "name": template.name,
                "notification_type": template.notification_type.value,
                "channel": template.channel.value,
                "language": template.language,
                "subject": template.subject,
                "body_template": template.body_template,
                "variables": template.variables,
                "active": template.active,
                "created_at": template.created_at.isoformat() if template.created_at else None,
                "updated_at": template.updated_at.isoformat() if template.updated_at else None,
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.put("/{template_id}", response_model=ApiResponse)
async def update_template(
    template_id: str,
    req: UpdateTemplateRequest,
    db: AsyncSession = Depends(get_db),
):
    """Update a notification template."""
    try:
        result = await db.execute(
            select(NotificationTemplate).where(NotificationTemplate.id == template_id)
        )
        template = result.scalar_one_or_none()
        if not template:
            raise HTTPException(status_code=404, detail="Template not found")

        if req.name is not None:
            template.name = req.name
        if req.subject is not None:
            template.subject = req.subject
        if req.body_template is not None:
            template.body_template = req.body_template
        if req.variables is not None:
            template.variables = req.variables
        if req.active is not None:
            template.active = req.active

        await db.commit()
        await db.refresh(template)

        return ApiResponse(
            data={
                "id": template.id,
                "name": template.name,
                "active": template.active,
                "updated_at": template.updated_at.isoformat() if template.updated_at else None,
            }
        )
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.delete("/{template_id}", response_model=ApiResponse)
async def delete_template(
    template_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Delete a notification template."""
    try:
        result = await db.execute(
            select(NotificationTemplate).where(NotificationTemplate.id == template_id)
        )
        template = result.scalar_one_or_none()
        if not template:
            raise HTTPException(status_code=404, detail="Template not found")

        await db.delete(template)
        await db.commit()

        return ApiResponse(data={"deleted": True, "id": template_id})
    except HTTPException:
        raise
    except Exception as e:
        await db.rollback()
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )
