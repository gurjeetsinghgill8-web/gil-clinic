"""
GHOS Notification Service — Webhook Routes
==============================================
Receives delivery receipt (DLR) callbacks from providers.
POST /dlr — Delivery receipt from provider
POST /whatsapp — WhatsApp Business API webhook
"""

import logging
from datetime import datetime, timezone
from typing import Optional, Dict, Any

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas import DeliveryReceipt, ApiResponse
from app.models import Notification, DeliveryLog, NotificationStatus

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/webhooks", tags=["webhooks"])


@router.post("/dlr", response_model=ApiResponse)
async def delivery_receipt(
    receipt: DeliveryReceipt,
    db: AsyncSession = Depends(get_db),
):
    """Handle delivery receipt (DLR) callback from a provider.

    Providers send these when the message status changes (sent → delivered, failed, read).
    """
    try:
        # Find the notification by provider_message_id
        result = await db.execute(
            select(Notification).where(
                Notification.provider_message_id == receipt.provider_message_id
            )
        )
        notif = result.scalar_one_or_none()

        if not notif:
            # Try to find via delivery logs
            log_result = await db.execute(
                select(DeliveryLog).where(
                    DeliveryLog.provider_message_id == receipt.provider_message_id
                )
            )
            log = log_result.scalar_one_or_none()
            if log:
                notif_result = await db.execute(
                    select(Notification).where(Notification.id == log.notification_id)
                )
                notif = notif_result.scalar_one_or_none()

        if not notif:
            logger.warning(
                f"DLR received for unknown message: {receipt.provider_message_id}"
            )
            return ApiResponse(
                success=False,
                error={"message": "Notification not found for this provider_message_id"},
            )

        # Map provider status to our status
        status_map = {
            "sent": NotificationStatus.SENT,
            "delivered": NotificationStatus.DELIVERED,
            "failed": NotificationStatus.FAILED,
            "read": NotificationStatus.READ,
        }
        new_status = status_map.get(receipt.status)
        if new_status:
            notif.status = new_status
            if new_status == NotificationStatus.DELIVERED:
                notif.delivered_at = datetime.now(timezone.utc)
            elif new_status == NotificationStatus.READ:
                notif.read_at = datetime.now(timezone.utc)

        # Update the last delivery log for this notification
        log_result = await db.execute(
            select(DeliveryLog)
            .where(DeliveryLog.notification_id == notif.id)
            .order_by(DeliveryLog.created_at.desc())
            .limit(1)
        )
        last_log = log_result.scalar_one_or_none()
        if last_log:
            last_log.status = receipt.status
            if receipt.status_code:
                last_log.status_code = receipt.status_code
            if receipt.error:
                last_log.error_message = receipt.error

        await db.commit()

        logger.info(
            f"DLR processed: {notif.id} → {receipt.status} "
            f"(provider: {receipt.provider})"
        )

        return ApiResponse(
            data={
                "notification_id": notif.id,
                "status": notif.status.value,
            }
        )
    except Exception as e:
        logger.exception("Failed to process DLR")
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.post("/whatsapp")
async def whatsapp_webhook(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Handle incoming WhatsApp Business API webhook.

    This receives incoming messages, delivery receipts, and
    message read events from Meta's WhatsApp Cloud API.
    """
    try:
        body = await request.json()

        # Meta's webhook verification challenge
        if "hub.challenge" in request.query_params:
            challenge = request.query_params["hub.challenge"]
            logger.info("WhatsApp webhook challenge verified")
            return int(challenge)

        logger.debug(f"WhatsApp webhook received: {body}")

        # Process the webhook payload
        entries = body.get("entry", [])
        for entry in entries:
            changes = entry.get("changes", [])
            for change in changes:
                value = change.get("value", {})

                # Handle incoming messages
                messages = value.get("messages", [])
                for msg in messages:
                    await self._process_incoming_whatsapp(msg, db)

                # Handle status updates (DLR)
                statuses = value.get("statuses", [])
                for status_update in statuses:
                    await self._process_whatsapp_status(status_update, db)

        return ApiResponse(data={"status": "ok"})
    except Exception as e:
        logger.exception("Failed to process WhatsApp webhook")
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )

    async def _process_incoming_whatsapp(self, msg: Dict[str, Any], db: AsyncSession):
        """Process an incoming WhatsApp message."""
        msg_id = msg.get("id")
        from_number = msg.get("from")
        msg_type = msg.get("type", "text")

        text = ""
        if msg_type == "text":
            text = msg.get("text", {}).get("body", "")

        logger.info(
            f"Incoming WhatsApp from {from_number}: "
            f"[{msg_type}] {text[:100]}"
        )

        # Incoming messages can be logged or trigger automated replies
        # This is a placeholder for future implementation

    async def _process_whatsapp_status(self, status_update: Dict[str, Any], db: AsyncSession):
        """Process a WhatsApp status update (DLR)."""
        msg_id = status_update.get("id")
        status = status_update.get("status")  # sent, delivered, read, failed
        timestamp = status_update.get("timestamp")

        if status:
            receipt = DeliveryReceipt(
                provider="whatsapp",
                message_id=msg_id,
                status=status,
                timestamp=timestamp,
            )
            await delivery_receipt(receipt, db)
