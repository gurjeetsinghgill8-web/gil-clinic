"""
GHOS Notification Service — Notification Routes
===================================================
POST /send — Send a notification
GET  /{id}  — Get notification status
POST /{id}/retry — Retry failed notification
GET  /       — List notifications
"""

import logging
from typing import Optional
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import select, func, desc
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.schemas import SendNotificationRequest, ApiResponse
from app.models import Notification, NotificationStatus
from app.engine.notification_engine import notification_engine

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/notifications", tags=["notifications"])


@router.post("/send", response_model=ApiResponse)
async def send_notification(
    req: SendNotificationRequest,
    db: AsyncSession = Depends(get_db),
):
    """Send a notification. Auto-routes to best channel if not specified."""
    try:
        result = await notification_engine.send(
            db=db,
            notification_type=req.notification_type,
            channel=req.channel,
            priority=req.priority,
            recipient_id=req.recipient_id,
            recipient_name=req.recipient_name,
            recipient_mobile=req.recipient_mobile,
            recipient_email=req.recipient_email,
            title=req.title,
            body=req.body,
            template_id=req.template_id,
            template_vars=req.template_vars,
            language=req.language,
            hospital_id=req.hospital_id,
            branch_id=req.branch_id,
            scheduled_at=req.scheduled_at,
        )
        return ApiResponse(data=result)
    except Exception as e:
        logger.exception("Failed to send notification")
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.get("/{notification_id}", response_model=ApiResponse)
async def get_notification(
    notification_id: str,
    db: AsyncSession = Depends(get_db),
):
    """Get notification status with delivery logs."""
    try:
        result = await notification_engine.get_status(db, notification_id)
        if not result:
            raise HTTPException(status_code=404, detail="Notification not found")
        return ApiResponse(data=result)
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.post("/{notification_id}/retry", response_model=ApiResponse)
async def retry_notification(
    notification_id: str,
    channel: Optional[str] = Query(None, description="Override channel for retry"),
    db: AsyncSession = Depends(get_db),
):
    """Retry a failed notification."""
    try:
        result = await notification_engine.retry(
            db=db,
            notification_id=notification_id,
            channel=channel,
        )
        if "error" in result:
            status_code = 404 if result["error"] == "Notification not found" else 400
            raise HTTPException(status_code=status_code, detail=result["error"])
        return ApiResponse(data=result)
    except HTTPException:
        raise
    except Exception as e:
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )


@router.get("", response_model=ApiResponse)
async def list_notifications(
    notification_type: Optional[str] = Query(None),
    status: Optional[str] = Query(None),
    recipient_id: Optional[str] = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
    db: AsyncSession = Depends(get_db),
):
    """List notifications with optional filters."""
    try:
        query = select(Notification)

        if notification_type:
            query = query.where(Notification.notification_type == notification_type)
        if status:
            query = query.where(Notification.status == status)
        if recipient_id:
            query = query.where(Notification.recipient_id == recipient_id)

        # Count total
        count_query = select(func.count()).select_from(query.subquery())
        total_result = await db.execute(count_query)
        total = total_result.scalar()

        # Fetch page
        query = query.order_by(desc(Notification.created_at))
        query = query.offset(offset).limit(limit)
        result = await db.execute(query)
        notifications = result.scalars().all()

        return ApiResponse(
            data={
                "items": [
                    {
                        "id": n.id,
                        "type": n.notification_type.value,
                        "channel": n.channel.value if n.channel else None,
                        "priority": n.priority.value,
                        "status": n.status.value,
                        "recipient_name": n.recipient_name,
                        "recipient_mobile": n.recipient_mobile,
                        "title": n.title,
                        "body": n.body,
                        "attempt_count": n.attempt_count,
                        "last_error": n.last_error,
                        "created_at": n.created_at.isoformat() if n.created_at else None,
                        "delivered_at": n.delivered_at.isoformat() if n.delivered_at else None,
                    }
                    for n in notifications
                ],
                "total": total,
                "limit": limit,
                "offset": offset,
            }
        )
    except Exception as e:
        return ApiResponse(
            success=False,
            error={"message": str(e)},
        )
