"""
GHOS Notification Service — FastAPI Entry Point
==================================================
Combines Notification Engine + Communication Engine into one service.
Auto-seeds default bilingual templates on first startup.
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.database import engine, Base
from app.redis import get_redis

# Routes
from app.routes import notifications, templates, webhooks

logger = logging.getLogger(__name__)

# ─── Default template seed data ─────────────────────────────────────────────
DEFAULT_TEMPLATES = [
    # patient_called
    {
        "name": "Patient Called (Hindi)",
        "notification_type": "patient_called",
        "channel": "whatsapp",
        "language": "hi",
        "body_template": "{{ patient_name }} जी, आपका {{ department_name }} में नंबर आ गया है। कृपया {{ room }} पर आएं।",
        "variables": {"patient_name": "Patient name", "department_name": "Department", "room": "Room number"},
    },
    {
        "name": "Patient Called (English)",
        "notification_type": "patient_called",
        "channel": "whatsapp",
        "language": "en",
        "body_template": "{{ patient_name }}, your turn has arrived at {{ department_name }}. Please proceed to {{ room }}.",
        "variables": {"patient_name": "Patient name", "department_name": "Department", "room": "Room number"},
    },
    # report_ready
    {
        "name": "Report Ready (Hindi)",
        "notification_type": "report_ready",
        "channel": "whatsapp",
        "language": "hi",
        "body_template": "{{ patient_name }} जी, आपकी {{ test_name }} रिपोर्ट तैयार है। कृपया जांचें।",
        "variables": {"patient_name": "Patient name", "test_name": "Test name"},
    },
    {
        "name": "Report Ready (English)",
        "notification_type": "report_ready",
        "channel": "whatsapp",
        "language": "en",
        "body_template": "{{ patient_name }}, your {{ test_name }} report is ready. Please check.",
        "variables": {"patient_name": "Patient name", "test_name": "Test name"},
    },
    # registration
    {
        "name": "Registration (Hindi)",
        "notification_type": "registration",
        "channel": "whatsapp",
        "language": "hi",
        "body_template": "{{ patient_name }} जी, आपका रजिस्ट्रेशन हो गया है। आपका टोकन नंबर {{ token_number }} है।",
        "variables": {"patient_name": "Patient name", "token_number": "Token number"},
    },
    {
        "name": "Registration (English)",
        "notification_type": "registration",
        "channel": "whatsapp",
        "language": "en",
        "body_template": "{{ patient_name }}, you have been registered. Your token number is {{ token_number }}.",
        "variables": {"patient_name": "Patient name", "token_number": "Token number"},
    },
    # otp
    {
        "name": "OTP (Hindi)",
        "notification_type": "otp",
        "channel": "sms",
        "language": "hi",
        "body_template": "आपका OTP {{ otp }} है। यह 5 मिनट के लिए वैध है।",
        "variables": {"otp": "OTP code"},
    },
    {
        "name": "OTP (English)",
        "notification_type": "otp",
        "channel": "sms",
        "language": "en",
        "body_template": "Your OTP is {{ otp }}. Valid for 5 minutes.",
        "variables": {"otp": "OTP code"},
    },
    # patient_called (SMS fallback)
    {
        "name": "Patient Called SMS (Hindi)",
        "notification_type": "patient_called",
        "channel": "sms",
        "language": "hi",
        "body_template": "{{ patient_name }} जी, {{ department_name }} में अपना नंबर देखें।",
        "variables": {"patient_name": "Patient name", "department_name": "Department"},
    },
    {
        "name": "Patient Called SMS (English)",
        "notification_type": "patient_called",
        "channel": "sms",
        "language": "en",
        "body_template": "{{ patient_name }}, check your turn at {{ department_name }}.",
        "variables": {"patient_name": "Patient name", "department_name": "Department"},
    },
]


async def seed_default_templates():
    """Seed default notification templates if the table is empty."""
    from sqlalchemy import select, func
    from app.database import async_session_factory
    from app.models import NotificationTemplate

    async with async_session_factory() as db:
        result = await db.execute(select(func.count()).select_from(NotificationTemplate))
        count = result.scalar()
        if count > 0:
            logger.info(f"Templates table already has {count} templates, skipping seed")
            return

        logger.info("Seeding default notification templates...")
        for tmpl_data in DEFAULT_TEMPLATES:
            template = NotificationTemplate(**tmpl_data)
            db.add(template)

        await db.commit()
        logger.info(f"Seeded {len(DEFAULT_TEMPLATES)} default templates")


async def check_database():
    """Verify database connectivity."""
    try:
        async with engine.connect() as conn:
            await conn.execute(Base.metadata.tables["notifications"].select().limit(1))
        logger.info("Database connection OK")
        return True
    except Exception as e:
        logger.warning(f"Database connection failed: {e}")
        return False


async def check_redis():
    """Verify Redis connectivity."""
    try:
        r = await get_redis()
        await r.ping()
        logger.info("Redis connection OK")
        return True
    except Exception as e:
        logger.warning(f"Redis connection failed: {e}")
        return False


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan: startup tasks and shutdown cleanup."""
    logger.info(f"Starting {settings.app_name} v{settings.version}")

    # Startup
    try:
        async with engine.begin() as conn:
            await conn.run_sync(Base.metadata.create_all)
        logger.info("Database tables created/verified")
    except Exception as e:
        logger.warning(f"Could not create tables: {e}")

    await seed_default_templates()
    await check_database()
    await check_redis()

    yield

    # Shutdown
    logger.info("Shutting down Notification Service")
    await engine.dispose()


# ─── FastAPI App ─────────────────────────────────────────────────────────────

app = FastAPI(
    title=settings.app_name,
    version=settings.version,
    lifespan=lifespan,
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Routes
app.include_router(notifications.router)
app.include_router(templates.router)
app.include_router(webhooks.router)


# Health check
@app.get("/health", tags=["system"])
async def health_check():
    """Health check endpoint."""
    db_ok = await check_database()
    redis_ok = await check_redis()

    status = "ok" if db_ok and redis_ok else "degraded"
    return {
        "status": status,
        "service": settings.app_name,
        "version": settings.version,
        "database": "connected" if db_ok else "disconnected",
        "redis": "connected" if redis_ok else "disconnected",
    }
