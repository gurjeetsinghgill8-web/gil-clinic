"""
GHOS Notification Service — WhatsApp Channel
===============================================
Sends messages via WhatsApp Business API (Meta Cloud API).
Stubbed for development — returns 202 without calling the API.

In production, uncomment the httpx call and set WHATSAPP_API_TOKEN
in the environment.
"""

import logging
from typing import Optional

from .base import BaseChannel, Message, DeliveryResult
from app.config import settings

logger = logging.getLogger(__name__)


class WhatsAppChannel(BaseChannel):
    """WhatsApp Business API delivery channel."""

    @property
    def name(self) -> str:
        return "whatsapp"

    async def validate(self, message: Message) -> Optional[str]:
        if not message.recipient_mobile:
            return "recipient_mobile is required for WhatsApp"
        return None

    async def send(self, message: Message) -> DeliveryResult:
        # ─── Dev mode: log and return success ────────────────────────────
        logger.info(
            f"[WHATSAPP] To: {message.recipient_mobile} | "
            f"Body: {message.body or '(no body)'}"
        )

        # In production, uncomment this block and set WHATSAPP_API_TOKEN:
        #
        # import httpx
        # if not settings.whatsapp_api_token:
        #     return DeliveryResult(
        #         success=False,
        #         provider="whatsapp",
        #         error_message="WhatsApp API token not configured",
        #         status_code=503,
        #     )
        #
        # url = f"{settings.whatsapp_api_url}/{settings.whatsapp_phone_number_id}/messages"
        # phone = message.recipient_mobile
        # if not phone.startswith("+"):
        #     phone = f"+91{phone}"
        #
        # payload = {
        #     "messaging_product": "whatsapp",
        #     "to": phone,
        #     "type": "text",
        #     "text": {"body": message.body or ""},
        # }
        #
        # async with httpx.AsyncClient(timeout=15) as client:
        #     resp = await client.post(
        #         url,
        #         json=payload,
        #         headers={
        #             "Authorization": f"Bearer {settings.whatsapp_api_token}",
        #             "Content-Type": "application/json",
        #         },
        #     )
        #     data = resp.json()
        #     msg_id = data.get("messages", [{}])[0].get("id") if resp.ok else None
        #
        #     return DeliveryResult(
        #         success=resp.ok,
        #         provider="whatsapp",
        #         provider_message_id=msg_id,
        #         status_code=resp.status_code,
        #         error_message=str(data) if not resp.ok else None,
        #     )

        return DeliveryResult(
            success=True,
            provider="whatsapp",
            provider_message_id=f"dev_wa_{message.notification_id}",
            status_code=202,
            latency_ms=0,
        )
