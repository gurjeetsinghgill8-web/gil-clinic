"""
GHOS Notification Service — SMS Channel
==========================================
Sends SMS via configurable provider (console | twilio | msg91).
Stubbed for development — logs to console and returns success.
"""

import logging
from typing import Optional

from .base import BaseChannel, Message, DeliveryResult
from app.config import settings

logger = logging.getLogger(__name__)


class SMSChannel(BaseChannel):
    """SMS delivery channel with provider abstraction."""

    @property
    def name(self) -> str:
        return "sms"

    async def validate(self, message: Message) -> Optional[str]:
        if not message.recipient_mobile:
            return "recipient_mobile is required for SMS"
        return None

    async def send(self, message: Message) -> DeliveryResult:
        provider = settings.sms_provider

        if provider == "console" or not provider:
            logger.info(
                f"[SMS/{provider}] To: {message.recipient_mobile} | "
                f"Body: {message.body or '(no body)'}"
            )
            return DeliveryResult(
                success=True,
                provider="sms_console",
                provider_message_id=f"dev_sms_{message.notification_id}",
                status_code=202,
                latency_ms=0,
            )

        # ─── Production providers (stubs) ────────────────────────────────
        # When integrating a real SMS provider, add the implementation here.
        # Example structure:
        #
        # if provider == "twilio":
        #     # from twilio.rest import Client
        #     # client = Client(settings.twilio_sid, settings.twilio_token)
        #     # msg = client.messages.create(...)
        #     ...
        # elif provider == "msg91":
        #     # import httpx
        #     # resp = await httpx.post(...)
        #     ...

        logger.warning(f"SMS provider '{provider}' not implemented, falling back to console")
        return DeliveryResult(
            success=True,
            provider=f"sms_{provider}",
            provider_message_id=f"stub_{message.notification_id}",
            status_code=501,
            error_message=f"Provider '{provider}' not implemented",
        )
