"""
GHOS Notification Service — Push Notification Channel (FCM)
==============================================================
Sends push notifications via Firebase Cloud Messaging (FCM).
Stubbed for development — logs to console and returns success.
"""

import json
import logging
from typing import Optional

from .base import BaseChannel, Message, DeliveryResult
from app.config import settings

logger = logging.getLogger(__name__)


class PushChannel(BaseChannel):
    """Firebase Cloud Messaging push notification channel."""

    @property
    def name(self) -> str:
        return "push"

    async def validate(self, message: Message) -> Optional[str]:
        if not message.recipient_id:
            return "recipient_id (device token) is required for push"
        return None

    async def send(self, message: Message) -> DeliveryResult:
        # ─── Dev mode: log and return success ────────────────────────────
        logger.info(
            f"[PUSH] To: {message.recipient_id} | "
            f"Title: {message.title} | Body: {message.body or '(no body)'}"
        )

        # In production, uncomment this block and set FCM_SERVER_KEY:
        #
        # import httpx
        # if not settings.fcm_server_key:
        #     return DeliveryResult(
        #         success=False,
        #         provider="fcm",
        #         error_message="FCM server key not configured",
        #         status_code=503,
        #     )
        #
        # payload = {
        #     "to": message.recipient_id,
        #     "notification": {
        #         "title": message.title or "",
        #         "body": message.body or "",
        #     },
        #     "data": {
        #         "notification_id": message.notification_id,
        #         "type": message.notification_type,
        #     },
        #     "priority": "high" if message.priority in ("critical", "high") else "normal",
        # }
        #
        # async with httpx.AsyncClient(timeout=10) as client:
        #     resp = await client.post(
        #         settings.fcm_api_url,
        #         json=payload,
        #         headers={
        #             "Authorization": f"key={settings.fcm_server_key}",
        #             "Content-Type": "application/json",
        #         },
        #     )
        #     data = resp.json()
        #     msg_id = data.get("message_id") if resp.ok else None
        #
        #     return DeliveryResult(
        #         success=resp.ok,
        #         provider="fcm",
        #         provider_message_id=msg_id,
        #         status_code=resp.status_code,
        #         error_message=data.get("error") if not resp.ok else None,
        #     )

        return DeliveryResult(
            success=True,
            provider="fcm_stub",
            provider_message_id=f"dev_push_{message.notification_id}",
            status_code=202,
            latency_ms=0,
        )
