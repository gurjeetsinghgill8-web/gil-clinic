"""
GHOS Notification Service — Console Channel
==============================================
Development fallback: logs every message to stdout with emoji indicators.
Always succeeds — never fails in dev mode.
"""

import json
import logging
from datetime import datetime, timezone

from .base import BaseChannel, Message, DeliveryResult

logger = logging.getLogger(__name__)


class ConsoleChannel(BaseChannel):
    """Logs messages to console. Default in development."""

    @property
    def name(self) -> str:
        return "console"

    async def send(self, message: Message) -> DeliveryResult:
        priority_emoji = {
            "critical": "🔴",
            "high": "🟠",
            "medium": "🟡",
            "low": "🔵",
        }
        emoji = priority_emoji.get(message.priority, "⚪")

        log_lines = [
            f"\n{'='*60}",
            f"{emoji} [{message.notification_type.upper()}] via {message.channel}",
            f"{'='*60}",
            f"  ID:       {message.notification_id}",
            f"  To:       {message.recipient_name or '?'} "
            f"({message.recipient_mobile or message.recipient_email or 'no-contact'})",
            f"  Priority: {message.priority}",
            f"  Language: {message.language}",
            f"  Time:     {datetime.now(timezone.utc).isoformat()}",
        ]

        if message.title:
            log_lines.append(f"  Title:    {message.title}")
        if message.body:
            log_lines.append(f"  Body:     {message.body}")
        if message.template_vars:
            log_lines.append(f"  Vars:     {json.dumps(message.template_vars, ensure_ascii=False)}")
        if message.extra:
            log_lines.append(f"  Extra:    {json.dumps(message.extra, ensure_ascii=False)}")

        log_lines.append("=" * 60)
        logger.info("\n".join(log_lines))

        return DeliveryResult(
            success=True,
            provider="console",
            provider_message_id=f"console_{message.notification_id}",
            status_code=200,
            latency_ms=0,
        )
