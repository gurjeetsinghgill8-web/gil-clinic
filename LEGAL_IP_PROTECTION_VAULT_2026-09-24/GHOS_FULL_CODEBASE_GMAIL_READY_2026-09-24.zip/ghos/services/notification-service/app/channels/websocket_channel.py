"""
GHOS Notification Service — WebSocket Channel
=================================================
Publishes notifications to Redis Pub/Sub so the Queue Engine's
WebSocket manager can relay them to connected clients.

This channel does NOT maintain WebSocket connections itself.
It publishes to a Redis channel that the Queue Engine's WS manager subscribes to.
"""

import json
import logging
from typing import Optional

from .base import BaseChannel, Message, DeliveryResult
from app.redis import get_redis

logger = logging.getLogger(__name__)

REDIS_PUBSUB_CHANNEL = "ghos:notifications"


class WebSocketChannel(BaseChannel):
    """Publishes notification events to Redis Pub/Sub for WS relay."""

    @property
    def name(self) -> str:
        return "websocket"

    async def send(self, message: Message) -> DeliveryResult:
        try:
            payload = {
                "type": "notification",
                "notification_id": message.notification_id,
                "notification_type": message.notification_type,
                "priority": message.priority,
                "recipient_id": message.recipient_id,
                "recipient_name": message.recipient_name,
                "title": message.title,
                "body": message.body,
                "language": message.language,
                "hospital_id": message.hospital_id,
                "branch_id": message.branch_id,
                "extra": message.extra,
            }

            r = await get_redis()
            await r.publish(REDIS_PUBSUB_CHANNEL, json.dumps(payload, ensure_ascii=False))

            logger.debug(f"Published notification {message.notification_id} to Redis Pub/Sub")

            return DeliveryResult(
                success=True,
                provider="redis_pubsub",
                provider_message_id=f"pubsub_{message.notification_id}",
                status_code=200,
                latency_ms=0,
            )
        except Exception as e:
            logger.error(f"Redis Pub/Sub publish failed: {e}")
            return DeliveryResult(
                success=False,
                provider="redis_pubsub",
                error_message=str(e),
                status_code=500,
            )
