"""
GHOS Notification Service — Abstract Channel Interface
=========================================================
All delivery channels implement this interface.
Adding a new channel = 1 file implementing `send(message) -> DeliveryResult`.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class DeliveryResult:
    """Standard result returned by every channel's send() method."""
    success: bool
    provider: str
    provider_message_id: Optional[str] = None
    status_code: Optional[int] = None
    error_message: Optional[str] = None
    latency_ms: Optional[int] = None
    raw_response: Optional[Dict[str, Any]] = None


@dataclass
class Message:
    """Standard message envelope passed to every channel."""
    notification_id: str
    notification_type: str
    channel: str
    priority: str
    recipient_id: Optional[str] = None
    recipient_name: Optional[str] = None
    recipient_mobile: Optional[str] = None
    recipient_email: Optional[str] = None
    title: Optional[str] = None
    body: Optional[str] = None
    template_id: Optional[str] = None
    template_vars: Optional[Dict[str, Any]] = None
    language: str = "hi"
    hospital_id: str = "default"
    branch_id: str = "main"
    extra: Dict[str, Any] = field(default_factory=dict)


class BaseChannel(ABC):
    """Abstract base for all delivery channels."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Channel name (websocket, whatsapp, sms, etc.)."""
        ...

    @abstractmethod
    async def send(self, message: Message) -> DeliveryResult:
        """Deliver a message. Must return a DeliveryResult."""
        ...

    async def validate(self, message: Message) -> Optional[str]:
        """Validate a message before sending. Return error string or None."""
        return None
