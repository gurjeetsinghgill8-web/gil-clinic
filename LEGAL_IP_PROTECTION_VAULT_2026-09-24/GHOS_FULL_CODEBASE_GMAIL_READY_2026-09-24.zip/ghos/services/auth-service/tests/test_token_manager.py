"""
Tests for Token Manager — JWT creation, verification, refresh, signed links.
"""

import time
from datetime import datetime, timedelta, timezone

import pytest
from app.services.token_manager import token_manager


class TestStaffTokens:
    """Tests for staff JWT token creation and verification."""

    def test_create_staff_token(self):
        """Create a valid staff access token."""
        token = token_manager.create_staff_token(
            user_id="user-001",
            role="admin",
            name="Test Admin",
        )
        assert token is not None
        assert isinstance(token, str)
        assert len(token) > 50  # Typical JWT length

    def test_verify_valid_token(self):
        """Verify a valid token returns the payload."""
        token = token_manager.create_staff_token(
            user_id="user-001",
            role="doctor",
            name="Dr. Test",
        )
        payload = token_manager.verify_token(token)
        assert payload is not None
        assert payload["sub"] == "user-001"
        assert payload["role"] == "doctor"
        assert payload["name"] == "Dr. Test"
        assert payload["type"] == "staff"
        assert "jti" in payload
        assert "exp" in payload
        assert "iat" in payload

    def test_token_contains_required_claims(self):
        """Token must contain sub, type, iat, exp, jti."""
        token = token_manager.create_staff_token(
            user_id="user-001",
            role="receptionist",
            name="Reception",
        )
        payload = token_manager.verify_token(token)
        for claim in ["sub", "type", "iat", "exp", "jti", "role", "name"]:
            assert claim in payload, f"Missing claim: {claim}"

    def test_invalid_token_returns_none(self):
        """Invalid token should return None."""
        result = token_manager.verify_token("invalid.jwt.token")
        assert result is None

    def test_expired_token_returns_none(self):
        """Expired token should return None."""
        import jwt as pyjwt
        # Create an already-expired token
        expired = pyjwt.encode(
            {
                "sub": "test",
                "type": "staff",
                "iat": int(time.time()) - 3600,
                "exp": int(time.time()) - 1800,
                "jti": "test-jti",
            },
            token_manager.secret_key,
            algorithm=token_manager.algorithm,
        )
        result = token_manager.verify_token(expired)
        assert result is None

    def test_tampered_token_returns_none(self):
        """Token with modified payload should fail verification."""
        token = token_manager.create_staff_token(
            user_id="user-001",
            role="admin",
            name="Admin",
        )
        # Tamper with the payload part
        parts = token.split(".")
        tampered = parts[0] + ".tampered." + parts[2]
        result = token_manager.verify_token(tampered)
        assert result is None


class TestRefreshTokens:
    """Tests for refresh token flow."""

    def test_create_refresh_token(self):
        """Create a valid refresh token."""
        token = token_manager.create_staff_refresh_token("user-001")
        assert token is not None
        payload = token_manager.verify_token(token)
        assert payload is not None
        assert payload["type"] == "refresh"

    def test_access_token_refresh(self):
        """Exchange a refresh token for a new access token."""
        refresh = token_manager.create_staff_refresh_token("user-001")
        user_data = {
            "sub": "user-001",
            "role": "admin",
            "name": "Admin",
            "hospital_id": "default",
            "branch_id": "main",
        }
        new_access = token_manager.refresh_access_token(refresh, user_data)
        assert new_access is not None
        payload = token_manager.verify_token(new_access)
        assert payload is not None
        assert payload["type"] == "staff"
        assert payload["sub"] == "user-001"

    def test_refresh_with_invalid_token_returns_none(self):
        """Invalid refresh token should return None."""
        result = token_manager.refresh_access_token("bad.token.here", {})
        assert result is None


class TestPatientTokens:
    """Tests for patient tokens."""

    def test_create_patient_token(self):
        """Create a valid patient token."""
        token = token_manager.create_patient_token(
            patient_id="pat-001",
            visit_id="visit-001",
        )
        assert token is not None
        payload = token_manager.verify_token(token)
        assert payload is not None
        assert payload["type"] == "patient"
        assert payload["visit_id"] == "visit-001"
        assert "view_status" in payload.get("scope", [])

    def test_patient_token_limited_scope(self):
        """Patient token should only have view scope."""
        token = token_manager.create_patient_token("pat-001", "visit-001")
        payload = token_manager.verify_token(token)
        assert payload is not None
        assert set(payload.get("scope", [])) == {"view_status", "view_reports"}


class TestSignedLinks:
    """Tests for signed links (WhatsApp/SMS click-through)."""

    def test_create_signed_link(self):
        """Create a valid signed link token."""
        link = token_manager.create_signed_link("pat-001", "visit-001")
        assert link is not None
        assert "." in link  # data.signature format

    def test_verify_valid_signed_link(self):
        """Verify a valid signed link returns the payload."""
        link = token_manager.create_signed_link("pat-001", "visit-001")
        payload = token_manager.verify_signed_link(link)
        assert payload is not None
        assert payload["pid"] == "pat-001"
        assert payload["vid"] == "visit-001"
        assert "exp" in payload

    def test_invalid_signed_link_returns_none(self):
        """Invalid signed link should return None."""
        result = token_manager.verify_signed_link("invalid.data.signature")
        assert result is None

    def test_tampered_signed_link_returns_none(self):
        """Tampered signed link should fail verification."""
        link = token_manager.create_signed_link("pat-001", "visit-001")
        parts = link.split(".")
        tampered = parts[0] + ".badbadbadbad"
        result = token_manager.verify_signed_link(tampered)
        assert result is None
