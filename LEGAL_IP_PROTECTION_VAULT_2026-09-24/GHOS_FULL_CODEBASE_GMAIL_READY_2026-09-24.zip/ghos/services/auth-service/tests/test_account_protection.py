"""
Tests for Account Protection — lockout, IP blacklisting.
Uses the fallback store (no Redis dependency in tests).
"""

import pytest
from app.services.account_protection import AccountProtection


@pytest.fixture
def protection():
    """AccountProtection instance with fallback store."""
    return AccountProtection(redis_client=None)


class TestAccountLockout:
    """Tests for account lockout logic."""

    @pytest.mark.asyncio
    async def test_failed_attempt_tracking(self, protection):
        """Failed attempts should be tracked per user."""
        await protection.record_failed_attempt("user-001", "192.168.1.1")

        # Should not be locked yet (only 1 attempt)
        status = await protection.is_account_locked("user-001")
        assert status["locked"] is False

    @pytest.mark.asyncio
    async def test_account_locks_after_threshold(self, protection):
        """Account should lock after threshold failed attempts."""
        for _ in range(protection.FAILED_ATTEMPT_THRESHOLD):
            await protection.record_failed_attempt("user-001", "192.168.1.1")

        status = await protection.is_account_locked("user-001")
        assert status["locked"] is True
        assert status["remaining_seconds"] > 0

    @pytest.mark.asyncio
    async def test_lock_and_unlock(self, protection):
        """Manually lock and unlock an account."""
        await protection.lock_account("user-001")
        status = await protection.is_account_locked("user-001")
        assert status["locked"] is True

        await protection.unlock_account("user-001")
        status = await protection.is_account_locked("user-001")
        assert status["locked"] is False

    @pytest.mark.asyncio
    async def test_successful_login_clears_failures(self, protection):
        """Successful login should clear failure count."""
        for _ in range(3):
            await protection.record_failed_attempt("user-001", "192.168.1.1")

        await protection.record_successful_login("user-001", "192.168.1.1")

        status = await protection.is_account_locked("user-001")
        assert status["locked"] is False


class TestIPBlacklist:
    """Tests for IP blacklisting."""

    @pytest.mark.asyncio
    async def test_ip_not_blacklisted_initially(self, protection):
        """IP should not be blacklisted initially."""
        blacklisted = await protection.is_ip_blacklisted("192.168.1.1")
        assert blacklisted is False

    @pytest.mark.asyncio
    async def test_ip_blacklisted_after_threshold(self, protection):
        """IP should be blacklisted after threshold failed attempts."""
        for _ in range(protection.IP_BLACKLIST_THRESHOLD):
            await protection.record_failed_attempt("user-001", "192.168.1.1")

        blacklisted = await protection.is_ip_blacklisted("192.168.1.1")
        assert blacklisted is True
