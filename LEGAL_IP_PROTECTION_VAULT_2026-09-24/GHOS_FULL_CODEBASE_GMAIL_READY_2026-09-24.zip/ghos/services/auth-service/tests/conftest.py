"""
GHOS Auth Service — Test Configuration
=========================================
Pytest fixtures for auth service testing.
Uses SQLite in-memory with StaticPool for isolated tests.
"""

import pytest
import pytest_asyncio
from datetime import datetime, timezone
from typing import AsyncGenerator
from unittest.mock import AsyncMock, patch

from sqlalchemy.ext.asyncio import create_async_engine, AsyncSession, async_sessionmaker
from sqlalchemy.pool import StaticPool

from app.models import Base, StaffUser, UserRole


# ─── Test Database ────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def db_session() -> AsyncGenerator[AsyncSession, None]:
    """Create a fresh in-memory SQLite database for each test."""
    engine = create_async_engine(
        "sqlite+aiosqlite://",
        echo=False,
        poolclass=StaticPool,
    )
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)

    session_factory = async_sessionmaker(
        engine,
        class_=AsyncSession,
        expire_on_commit=False,
    )
    async with session_factory() as session:
        yield session
    await engine.dispose()


# ─── Mock Redis ──────────────────────────────────────────────────────────

@pytest.fixture
def mock_redis():
    """Mock Redis for OTP and account protection tests."""
    with patch("app.services.otp_service.get_redis", new=AsyncMock()) as mock:
        # OTP service uses fallback store in tests — no Redis mock needed
        yield


# ─── Sample Data ─────────────────────────────────────────────────────────

@pytest_asyncio.fixture
async def admin_user(db_session) -> StaffUser:
    """Create a sample admin user."""
    from app.services.password_auth import password_auth

    pw_hash = await password_auth.hash_password("Admin@123")
    user = StaffUser(
        id="admin-001",
        name="Test Admin",
        mobile="9999999999",
        role=UserRole.ADMIN,
        password_hash=pw_hash,
        password_changed_at=datetime.now(timezone.utc),
    )
    db_session.add(user)
    await db_session.commit()
    return user


@pytest_asyncio.fixture
async def staff_user(db_session) -> StaffUser:
    """Create a sample staff user (no password — OTP only)."""
    user = StaffUser(
        id="staff-001",
        name="Test Staff",
        mobile="8888888888",
        role=UserRole.DOCTOR,
    )
    db_session.add(user)
    await db_session.commit()
    return user


@pytest_asyncio.fixture
async def seeded_db(db_session, admin_user, staff_user):
    """Seed with admin and staff users."""
    return db_session
