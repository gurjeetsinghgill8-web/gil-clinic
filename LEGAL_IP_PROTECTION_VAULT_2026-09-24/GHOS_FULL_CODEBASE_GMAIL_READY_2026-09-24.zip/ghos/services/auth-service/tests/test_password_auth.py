"""
Tests for Password Authentication — Argon2id hashing, strength checking.
"""

import pytest
from app.services.password_auth import password_auth


class TestPasswordHashing:
    """Tests for Argon2id password hashing and verification."""

    @pytest.mark.asyncio
    async def test_hash_and_verify(self):
        """Hash a password and verify it matches."""
        pw_hash = await password_auth.hash_password("Test@123")
        assert pw_hash is not None
        assert len(pw_hash) > 50  # Argon2id hash is long

        valid = await password_auth.verify_password("Test@123", pw_hash)
        assert valid is True

    @pytest.mark.asyncio
    async def test_wrong_password_fails(self):
        """Wrong password should fail verification."""
        pw_hash = await password_auth.hash_password("Correct@123")
        valid = await password_auth.verify_password("Wrong@123", pw_hash)
        assert valid is False

    @pytest.mark.asyncio
    async def test_empty_hash_returns_false(self):
        """Empty hash should return False."""
        valid = await password_auth.verify_password("test", "")
        assert valid is False


class TestPasswordStrength:
    """Tests for password strength checking."""

    @pytest.mark.asyncio
    async def test_strong_password(self):
        """Strong password should pass all checks."""
        result = await password_auth.check_password_strength("StrongP@ss1")
        assert result["is_strong"] is True
        assert result["score"] >= 75
        assert len(result["errors"]) == 0

    @pytest.mark.asyncio
    async def test_short_password(self):
        """Short password should fail."""
        result = await password_auth.check_password_strength("Ab1")
        assert result["is_strong"] is False
        assert any("characters" in e for e in result["errors"])

    @pytest.mark.asyncio
    async def test_no_uppercase(self):
        """Password without uppercase should fail."""
        result = await password_auth.check_password_strength("abcdefgh1")
        assert result["is_strong"] is False
        assert any("uppercase" in e for e in result["errors"])

    @pytest.mark.asyncio
    async def test_no_number(self):
        """Password without number should fail."""
        result = await password_auth.check_password_strength("Abcdefgh")
        assert result["is_strong"] is False
        assert any("number" in e for e in result["errors"])

    @pytest.mark.asyncio
    async def test_common_password(self):
        """Common password should be rejected."""
        result = await password_auth.check_password_strength("Admin@123")
        assert result["is_strong"] is False
        assert any("common" in e.lower() for e in result["errors"])

    @pytest.mark.asyncio
    async def test_score_based_on_errors(self):
        """Score should decrease with more errors."""
        perfect = await password_auth.check_password_strength("StrongP@ss1")
        weak = await password_auth.check_password_strength("ab")
        assert perfect["score"] > weak["score"]
