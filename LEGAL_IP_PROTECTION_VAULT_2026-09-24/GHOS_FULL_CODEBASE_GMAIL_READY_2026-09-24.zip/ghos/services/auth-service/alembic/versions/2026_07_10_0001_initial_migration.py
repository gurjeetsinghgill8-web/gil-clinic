"""initial_migration — auth tables

Create Date: 2026-07-10
"""
from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa
from sqlalchemy.dialects import postgresql

revision: str = "2026_07_10_0001"
down_revision: Union[str, None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    # ─── Enums ────────────────────────────────────────────────────────────────
    sa.Enum(
        "admin", "doctor", "receptionist", "nurse", "lab_technician",
        "pharmacist", "accountant", "manager",
        name="user_role",
    ).create(op.get_bind())

    # ─── Staff Users ──────────────────────────────────────────────────────────
    op.create_table(
        "staff_users",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("hospital_id", sa.String(36), server_default="default"),
        sa.Column("branch_id", sa.String(36), server_default="main"),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("mobile", sa.String(20), unique=True, nullable=False, index=True),
        sa.Column("email", sa.String(200), nullable=True),
        sa.Column(
            "role", sa.Enum("admin", "doctor", "receptionist", "nurse",
                            "lab_technician", "pharmacist", "accountant",
                            "manager", name="user_role"),
            nullable=False,
        ),
        sa.Column("department_id", sa.String(36), nullable=True),
        sa.Column("password_hash", sa.String(256), nullable=True),
        sa.Column("active", sa.Boolean(), server_default="true"),
        sa.Column("is_locked", sa.Boolean(), server_default="false"),
        sa.Column("locked_until", sa.DateTime(timezone=True), nullable=True),
        sa.Column("failed_login_attempts", sa.Integer(), server_default="0"),
        sa.Column("last_login_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_login_ip", sa.String(45), nullable=True),
        sa.Column("password_changed_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("mfa_enabled", sa.Boolean(), server_default="false"),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_staff_hospital_role", "staff_users", ["hospital_id", "role"])

    # ─── Patients ─────────────────────────────────────────────────────────────
    op.create_table(
        "patients",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("mobile", sa.String(20), nullable=False, index=True),
        sa.Column("email", sa.String(200), nullable=True),
        sa.Column("language", sa.String(10), server_default="hi"),
        sa.Column("fcm_token", sa.String(500), nullable=True),
        sa.Column("is_online", sa.Boolean(), server_default="false"),
        sa.Column("last_active_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ─── Sessions ─────────────────────────────────────────────────────────────
    op.create_table(
        "sessions",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36), nullable=False, index=True),
        sa.Column("user_type", sa.String(20), nullable=False),
        sa.Column("token_jti", sa.String(100), unique=True, nullable=False),
        sa.Column("refresh_token_jti", sa.String(100), nullable=True),
        sa.Column("device_info", sa.Text(), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("last_activity_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_sessions_user", "sessions", ["user_id", "user_type"])
    op.create_index("idx_sessions_active", "sessions", ["expires_at"])

    # ─── Password History ─────────────────────────────────────────────────────
    op.create_table(
        "password_history",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("user_id", sa.String(36),
                  sa.ForeignKey("staff_users.id"), nullable=False, index=True),
        sa.Column("password_hash", sa.String(256), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )

    # ─── API Keys ─────────────────────────────────────────────────────────────
    op.create_table(
        "api_keys",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("hospital_id", sa.String(36), server_default="default"),
        sa.Column("name", sa.String(100), nullable=False),
        sa.Column("key_hash", sa.String(64), unique=True, nullable=False),
        sa.Column("permissions", postgresql.JSON(), nullable=True),
        sa.Column("rate_limit_per_minute", sa.Integer(), server_default="60"),
        sa.Column("active", sa.Boolean(), server_default="true"),
        sa.Column("created_by", sa.String(36), nullable=True),
        sa.Column("expires_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("last_used_at", sa.DateTime(timezone=True), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_apikeys_hospital", "api_keys", ["hospital_id", "active"])

    # ─── API Key Usage Log ────────────────────────────────────────────────────
    op.create_table(
        "api_key_usage",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("api_key_id", sa.String(36),
                  sa.ForeignKey("api_keys.id"), nullable=False),
        sa.Column("endpoint", sa.String(200), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_apikey_usage_key", "api_key_usage", ["api_key_id"])

    # ─── OTP Logs ─────────────────────────────────────────────────────────────
    op.create_table(
        "otp_logs",
        sa.Column("id", sa.String(36), primary_key=True),
        sa.Column("mobile", sa.String(20), nullable=False),
        sa.Column("channel", sa.String(20), nullable=True),
        sa.Column("status", sa.String(20), nullable=True),
        sa.Column("ip_address", sa.String(45), nullable=True),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now()),
    )
    op.create_index("idx_otp_logs_mobile", "otp_logs", ["mobile", "created_at"])


def downgrade() -> None:
    op.drop_index("idx_otp_logs_mobile", table_name="otp_logs")
    op.drop_table("otp_logs")
    op.drop_index("idx_apikey_usage_key", table_name="api_key_usage")
    op.drop_table("api_key_usage")
    op.drop_index("idx_apikeys_hospital", table_name="api_keys")
    op.drop_table("api_keys")
    op.drop_table("password_history")
    op.drop_index("idx_sessions_active", table_name="sessions")
    op.drop_index("idx_sessions_user", table_name="sessions")
    op.drop_table("sessions")
    op.drop_table("patients")
    op.drop_index("idx_staff_hospital_role", table_name="staff_users")
    op.drop_table("staff_users")
    op.execute("DROP TYPE IF EXISTS user_role")
