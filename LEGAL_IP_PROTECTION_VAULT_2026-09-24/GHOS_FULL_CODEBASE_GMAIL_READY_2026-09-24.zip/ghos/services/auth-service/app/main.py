"""
GHOS Auth Service — Main Application Entry Point
====================================================
FastAPI application with:
- CORS middleware
- Auth middleware (JWT validation)
- Router inclusion (auth, admin)
- Startup: init DB tables, seed default admin
- Shutdown: close connections
- Health check endpoint
"""

import logging
from contextlib import asynccontextmanager

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.config import settings
from app.database import init_db, close_db
from app.schemas import HealthResponse
from app.middleware.auth_middleware import AuthMiddleware

logger = logging.getLogger(__name__)


@asynccontextmanager
async def lifespan(app: FastAPI):
    """Application lifespan handler for startup/shutdown events."""
    logger.info(f"🚀 {settings.app_name} v{settings.version} starting...")
    await init_db()
    logger.info("✅ Database tables initialized")

    # Seed default admin user
    await seed_default_admin()
    logger.info("✅ Default admin seeded (if not exists)")

    yield

    logger.info("🛑 Shutting down...")
    await close_db()
    logger.info("✅ Connections closed gracefully")


app = FastAPI(
    title=settings.app_name,
    description="GHOS Auth Service — Authentication & authorization microservice",
    version=settings.version,
    lifespan=lifespan,
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.cors_origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Auth middleware (must be added after CORS)
app.add_middleware(AuthMiddleware)

# Routers
from app.routes import auth  # noqa: E402
from app.routes import admin  # noqa: E402

app.include_router(auth.router)
app.include_router(admin.router)


# ─── Root ─────────────────────────────────────────────────────────────────

@app.get("/")
async def root():
    return {"message": f"GHOS Auth Service v{settings.version}", "docs": "/docs"}


# ─── Health ───────────────────────────────────────────────────────────────

@app.get("/health", response_model=HealthResponse)
async def health():
    db_ok = False
    redis_ok = False

    try:
        from app.database import async_session_factory
        from sqlalchemy import text

        async with async_session_factory() as session:
            await session.execute(text("SELECT 1"))
        db_ok = True
    except Exception as e:
        logger.warning(f"Health check — DB unavailable: {e}")

    try:
        from app import redis as cache

        await cache.ping()
        redis_ok = True
    except Exception as e:
        logger.warning(f"Health check — Redis unavailable: {e}")

    return HealthResponse(
        data={
            "status": "healthy" if (db_ok and redis_ok) else "degraded",
            "service": settings.app_name,
            "version": settings.version,
            "database": "connected" if db_ok else "disconnected",
            "redis": "connected" if redis_ok else "disconnected",
        }
    )


# ─── Seed Default Admin ──────────────────────────────────────────────────

async def seed_default_admin():
    """Create the default admin user if no users exist."""
    from sqlalchemy import select
    from app.database import async_session_factory
    from app.models import StaffUser, UserRole
    from app.services.password_auth import password_auth

    async with async_session_factory() as session:
        result = await session.execute(select(StaffUser).limit(1))
        existing = result.scalar_one_or_none()

        if existing:
            return  # Users already exist

        password_hash = await password_auth.hash_password(settings.default_admin_password)

        admin = StaffUser(
            name=settings.default_admin_name,
            mobile=settings.default_admin_mobile,
            role=UserRole.ADMIN,
            password_hash=password_hash,
            password_changed_at=__import__("datetime").datetime.now(__import__("datetime").timezone.utc),
        )
        session.add(admin)
        await session.commit()

        logger.info(
            f"✅ Default admin created: {settings.default_admin_name} "
            f"({settings.default_admin_mobile})"
        )


# ─── Exception handler ───────────────────────────────────────────────────

@app.exception_handler(Exception)
async def global_exception_handler(request, exc):
    logger.error(f"Unhandled exception: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={
            "success": False,
            "data": None,
            "error": {"code": "INTERNAL_ERROR", "message": "An unexpected error occurred"},
            "meta": None,
        },
    )
