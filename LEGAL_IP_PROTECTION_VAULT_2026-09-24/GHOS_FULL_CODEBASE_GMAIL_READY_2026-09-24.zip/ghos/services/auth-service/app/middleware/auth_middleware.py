"""
GHOS Auth Service — Auth Middleware
========================================
FastAPI middleware for token extraction, verification, and user context.
Public paths bypass auth. All other routes require a valid JWT.

Also provides:
- API key authentication for external systems
- Optional auth (extracts user if token present, doesn't require it)
"""

import logging
from typing import List, Optional

from fastapi import Request, HTTPException
from fastapi.responses import JSONResponse
from starlette.middleware.base import BaseHTTPMiddleware

from app.services.token_manager import token_manager

logger = logging.getLogger(__name__)


# ─── Public paths that don't require authentication ───────────────────────

PUBLIC_PATHS = [
    "/health",
    "/docs",
    "/redoc",
    "/openapi.json",
    "/api/v1/auth/login/otp",
    "/api/v1/auth/verify-otp",
    "/api/v1/auth/login/password",
    "/api/v1/auth/refresh",
]


class AuthMiddleware(BaseHTTPMiddleware):
    """Global auth middleware — validates JWT for every request except public paths."""

    async def dispatch(self, request: Request, call_next):
        # Skip auth for public paths
        path = request.url.path
        if any(path.startswith(p) for p in PUBLIC_PATHS):
            return await call_next(request)

        # Extract token from Authorization header or cookie
        token = self._extract_token(request)
        if not token:
            return JSONResponse(
                status_code=401,
                content={
                    "success": False,
                    "error": {
                        "code": "AUTH_REQUIRED",
                        "message": "Authentication required",
                    },
                    "data": None,
                    "meta": None,
                },
            )

        # Verify token
        token_data = token_manager.verify_token(token)
        if not token_data:
            return JSONResponse(
                status_code=401,
                content={
                    "success": False,
                    "error": {
                        "code": "INVALID_TOKEN",
                        "message": "Invalid or expired token",
                    },
                    "data": None,
                    "meta": None,
                },
            )

        # Attach user info to request state
        request.state.user = token_data
        request.state.user_id = token_data.get("sub")
        request.state.token = token

        return await call_next(request)

    def _extract_token(self, request: Request) -> Optional[str]:
        """Extract JWT from Authorization header or cookie."""
        auth_header = request.headers.get("Authorization", "")
        if auth_header.startswith("Bearer "):
            return auth_header[7:]

        # Check cookie (for web/PWA sessions)
        token = request.cookies.get("access_token", "")
        if token:
            return token

        return None


# ─── Dependency guards ────────────────────────────────────────────────────

async def require_auth(request: Request, roles: Optional[List[str]] = None):
    """FastAPI dependency: require authentication with optional role check."""
    user = getattr(request.state, "user", None)
    if not user:
        raise HTTPException(
            status_code=401,
            detail={"code": "NOT_AUTHENTICATED", "message": "Not authenticated"},
        )

    if roles and user.get("role") not in roles:
        raise HTTPException(
            status_code=403,
            detail={
                "code": "INSUFFICIENT_PERMISSIONS",
                "message": f"Requires one of roles: {roles}",
            },
        )

    return user


async def optional_auth(request: Request):
    """FastAPI dependency: extract user if token available, don't require it."""
    token = request.headers.get("Authorization", "").replace("Bearer ", "")
    if token:
        request.state.user = token_manager.verify_token(token)
    else:
        request.state.user = None
    return request.state.user


async def verify_api_key(request: Request):
    """FastAPI dependency: verify API key for external system access.

    API keys are passed via X-API-Key header.
    Used by lab machines, billing software, and other integrations.
    """
    api_key = request.headers.get("X-API-Key", "")
    if not api_key:
        return None

    # Verify by hashing and checking DB
    import hashlib
    from sqlalchemy import select
    from app.models import APIKey as APIKeyModel
    from app.database import async_session_factory

    key_hash = hashlib.sha256(api_key.encode()).hexdigest()

    async with async_session_factory() as session:
        result = await session.execute(
            select(APIKeyModel).where(
                APIKeyModel.key_hash == key_hash,
                APIKeyModel.active == True,
            )
        )
        key_record = result.scalar_one_or_none()

        if not key_record:
            raise HTTPException(
                status_code=401,
                detail={"code": "INVALID_API_KEY", "message": "Invalid or inactive API key"},
            )

        # Check expiry
        if key_record.expires_at and key_record.expires_at < datetime.now(timezone.utc):
            raise HTTPException(
                status_code=401,
                detail={"code": "API_KEY_EXPIRED", "message": "API key has expired"},
            )

        # Update last used
        key_record.last_used_at = datetime.now(timezone.utc)
        await session.commit()

    return key_record
