"""
GHOS Auth Service — Redis Client
====================================
Async Redis client for:
- OTP storage (hashed)
- Token revocation blocklist
- Rate limiting counters
- IP blacklisting
"""

from typing import Optional

from redis.asyncio import Redis as AsyncRedis, ConnectionPool

from app.config import settings

# Redis client singleton
_pool: Optional[ConnectionPool] = None
_redis: Optional[AsyncRedis] = None


def get_redis() -> AsyncRedis:
    """Get the global Redis client instance."""
    global _redis, _pool
    if _redis is None:
        _pool = ConnectionPool.from_url(
            settings.redis_url,
            decode_responses=True,
            max_connections=20,
        )
        _redis = AsyncRedis(connection_pool=_pool)
    return _redis


async def close_redis():
    """Close the Redis connection pool."""
    global _redis, _pool
    if _redis:
        await _redis.aclose()
        _redis = None
    if _pool:
        await _pool.disconnect()
        _pool = None


async def ping() -> bool:
    """Check if Redis is reachable."""
    r = get_redis()
    try:
        return await r.ping()
    except Exception:
        return False
