"""
GHOS Auth Service — OTP Service
===================================
OTP generation, verification, and rate limiting.
Stores OTP as SHA-256 hash (never plaintext) with server-side pepper.
In development, OTP is logged to console instead of sent via WhatsApp/SMS.
"""

import hashlib
import logging
import random
import string
from datetime import datetime, timezone
from typing import Optional

from app.config import settings

logger = logging.getLogger(__name__)


class OTPService:
    """
    OTP generation, delivery (stubbed), and verification.

    Features:
    - 6-digit numeric OTP
    - 5-minute TTL
    - Max 3 verification attempts
    - Cooldown: 30s between resends
    - Max 5 OTPs per number per hour
    - OTP stored as SHA-256 hash (peppered), never plaintext
    """

    OTP_LENGTH = settings.otp_length
    OTP_TTL_SECONDS = settings.otp_ttl_seconds
    MAX_ATTEMPTS = settings.otp_max_attempts
    RESEND_COOLDOWN = settings.otp_resend_cooldown_seconds
    MAX_PER_HOUR = settings.otp_max_per_hour

    def __init__(self, redis_client=None):
        """
        Args:
            redis_client: Async Redis client. If None, uses a simple dict fallback
                          for testing without Redis.
        """
        self._redis = redis_client
        self._fallback_store: dict = {}  # For testing without Redis

    async def _redis(self):
        """Lazy import to avoid circular imports."""
        if self._redis is None:
            from app.redis import get_redis
            self._redis = get_redis()
        return self._redis

    def _use_fallback(self) -> bool:
        return self._redis is None

    async def _get(self, key: str) -> Optional[str]:
        if self._use_fallback():
            val, expiry = self._fallback_store.get(key, (None, 0))
            if val and datetime.now().timestamp() < expiry:
                return val
            self._fallback_store.pop(key, None)
            return None
        r = await self._redis()
        return await r.get(key)

    async def _setex(self, key: str, ttl: int, value: str):
        if self._use_fallback():
            expiry = datetime.now().timestamp() + ttl
            self._fallback_store[key] = (value, expiry)
        else:
            r = await self._redis()
            await r.setex(key, ttl, value)

    async def _incr(self, key: str) -> int:
        if self._use_fallback():
            val, expiry = self._fallback_store.get(key, (0, 0))
            new_val = int(val) + 1
            self._fallback_store[key] = (str(new_val), expiry)
            return new_val
        r = await self._redis()
        return await r.incr(key)

    async def _expire(self, key: str, ttl: int):
        if not self._use_fallback():
            r = await self._redis()
            await r.expire(key, ttl)

    async def _delete(self, key: str):
        if self._use_fallback():
            self._fallback_store.pop(key, None)
        else:
            r = await self._redis()
            await r.delete(key)

    async def _exists(self, key: str) -> bool:
        if self._use_fallback():
            return await self._get(key) is not None
        r = await self._redis()
        return await r.exists(key)

    async def _ttl(self, key: str) -> int:
        if self._use_fallback():
            val, expiry = self._fallback_store.get(key, (None, 0))
            remaining = int(expiry - datetime.now().timestamp())
            return max(0, remaining)
        r = await self._redis()
        return await r.ttl(key)

    # ─── Public API ───────────────────────────────────────────────────────────

    async def generate_and_send(
        self,
        mobile: str,
        channel: str = "whatsapp",
        user_name: Optional[str] = None,
    ) -> dict:
        """Generate OTP and log it (stubbed — prints to console in dev)."""
        # Rate limit check
        hourly_key = f"otp:hourly:{mobile}"
        hourly_count = await self._incr(hourly_key)
        if hourly_count == 1:
            await self._expire(hourly_key, 3600)

        if hourly_count > self.MAX_PER_HOUR:
            return {
                "success": False,
                "error": "rate_limited",
                "message": "Maximum OTP requests reached. Try again later.",
            }

        # Cooldown check
        cooldown_key = f"otp:cooldown:{mobile}"
        if await self._exists(cooldown_key):
            remaining = await self._ttl(cooldown_key)
            return {
                "success": False,
                "error": "cooldown",
                "message": f"Please wait {remaining} seconds before requesting again.",
            }

        # Generate OTP
        otp = "".join(random.choices(string.digits, k=self.OTP_LENGTH))

        # Store SHA-256 hash (never plaintext)
        otp_hash = hashlib.sha256(
            f"{mobile}:{otp}:{settings.otp_pepper}".encode()
        ).hexdigest()
        await self._setex(f"otp:{mobile}", self.OTP_TTL_SECONDS, otp_hash)
        await self._setex(f"otp:attempts:{mobile}", self.OTP_TTL_SECONDS, "0")
        await self._setex(cooldown_key, self.RESEND_COOLDOWN, "1")

        # In development, log OTP to console
        name_tag = f" {user_name}" if user_name else ""
        logger.info(
            f"📱 OTP for{name_tag} ({mobile}): {otp} — "
            f"Valid for {self.OTP_TTL_SECONDS // 60} min via {channel}"
        )

        return {
            "success": True,
            "message": f"OTP sent via {channel}",
            "ttl_seconds": self.OTP_TTL_SECONDS,
        }

    async def verify(self, mobile: str, otp: str) -> dict:
        """Verify an OTP. Returns success dict with user-friendly messages."""
        # Check attempts
        attempts_key = f"otp:attempts:{mobile}"
        attempts_val = await self._get(attempts_key)
        attempts = int(attempts_val) if attempts_val else 0

        if attempts >= self.MAX_ATTEMPTS:
            await self._delete(f"otp:{mobile}")
            return {
                "success": False,
                "error": "max_attempts",
                "message": "Maximum OTP attempts exceeded. Request a new OTP.",
            }

        # Get stored hash
        otp_key = f"otp:{mobile}"
        stored_hash = await self._get(otp_key)

        if not stored_hash:
            return {
                "success": False,
                "error": "expired",
                "message": "OTP expired or not requested. Please request a new OTP.",
            }

        # Increment attempts
        await self._setex(attempts_key, self.OTP_TTL_SECONDS, str(attempts + 1))

        # Verify hash
        computed_hash = hashlib.sha256(
            f"{mobile}:{otp}:{settings.otp_pepper}".encode()
        ).hexdigest()

        if computed_hash == stored_hash:
            # Success — clean up
            await self._delete(otp_key)
            await self._delete(attempts_key)
            await self._delete(f"otp:cooldown:{mobile}")
            return {"success": True, "message": "OTP verified successfully."}

        remaining = self.MAX_ATTEMPTS - (attempts + 1)
        return {
            "success": False,
            "error": "invalid",
            "message": f"Invalid OTP. {remaining} attempt(s) remaining.",
        }


# Global instance
otp_service = OTPService()
