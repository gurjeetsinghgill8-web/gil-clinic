"""
GHOS Auth Service — Password Authentication
===============================================
Argon2id password hashing, verification, strength checking,
and password change with history enforcement.

Security standards:
- Argon2id hashing (memory-hard, resists GPU/ASIC attacks)
- Min 8 characters, must include uppercase + number
- Password history: last 5 passwords remembered
- Force password change every 90 days
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError, InvalidHashError

from app.config import settings

logger = logging.getLogger(__name__)

# Common passwords that should never be allowed
COMMON_PASSWORDS = {
    "password", "password123", "12345678", "admin123", "admin@123",
    "qwerty123", "letmein", "welcome", "monkey", "dragon",
    "abcdefgh", "abc12345", "passw0rd", "p@ssw0rd", "pass@123",
}


class PasswordAuth:
    """Argon2id password hashing and policy enforcement."""

    def __init__(self):
        self.argon2 = PasswordHasher(
            time_cost=3,        # 3 iterations
            memory_cost=65536,   # 64 MB
            parallelism=4,
            hash_len=32,
            salt_len=16,
        )

    async def hash_password(self, password: str) -> str:
        """Hash password using Argon2id."""
        return self.argon2.hash(password)

    async def verify_password(self, password: str, password_hash: str) -> bool:
        """Verify password against Argon2id hash.

        Handles rehashing if parameters change.
        """
        try:
            return self.argon2.verify(password_hash, password)
        except VerifyMismatchError:
            return False
        except (VerificationError, InvalidHashError) as e:
            logger.error(f"Password verification error: {e}")
            return False

    async def check_password_strength(self, password: str) -> dict:
        """Check password strength and return feedback."""
        errors = []

        if len(password) < settings.password_min_length:
            errors.append(f"At least {settings.password_min_length} characters required")

        if settings.password_require_uppercase and not any(c.isupper() for c in password):
            errors.append("At least one uppercase letter required")

        if settings.password_require_number and not any(c.isdigit() for c in password):
            errors.append("At least one number required")

        if password.lower() in COMMON_PASSWORDS:
            errors.append("This password is too common")

        # Score: 100 minus 25 points per error
        score = max(0, 100 - (len(errors) * 25))

        return {
            "score": score,
            "is_strong": score >= 100 and len(errors) == 0,
            "errors": errors,
        }

    async def needs_password_change(self, password_changed_at: Optional[datetime]) -> bool:
        """Check if password needs to be changed due to age."""
        if password_changed_at is None:
            return True  # Never changed
        age = datetime.now(timezone.utc) - password_changed_at
        return age.days >= settings.password_force_change_days


# Global instance
password_auth = PasswordAuth()
