"""
GHOS Auth Service — Account Protection
===========================================
Brute force prevention, IP blacklisting, account lockout,
concurrent session limits, and inactivity timeout.

Protection layers:
1. Rate limiting — Max 5 OTP requests/hour per number
2. IP blacklisting — Temporarily block IPs with >20 failed attempts
3. Account lockout — Lock account after 5 failed password attempts
4. Concurrent session limit — Max 5 active sessions per staff user
5. Inactivity timeout — Auto-logout after 30 min of inactivity
"""

import logging
from datetime import datetime, timezone, timedelta
from typing import Optional

from app.config import settings

logger = logging.getLogger(__name__)


class AccountProtection:
    """Account lockout, IP blacklisting, and session limits."""

    FAILED_ATTEMPT_THRESHOLD = settings.max_failed_attempts
    LOCKOUT_DURATION = timedelta(minutes=settings.lockout_minutes)
    IP_BLACKLIST_THRESHOLD = settings.ip_blacklist_threshold
    IP_BLACKLIST_DURATION = timedelta(hours=settings.ip_blacklist_hours)
    MAX_CONCURRENT_SESSIONS = settings.max_concurrent_sessions
    INACTIVITY_TIMEOUT = timedelta(minutes=settings.inactivity_timeout_minutes)

    def __init__(self, redis_client=None):
        self._redis = redis_client
        self._fallback_store: dict = {}

    async def _redis(self):
        if self._redis is None:
            from app.redis import get_redis
            self._redis = get_redis()
        return self._redis

    def _use_fallback(self) -> bool:
        return self._redis is None

    async def _incr(self, key: str) -> int:
        if self._use_fallback():
            val = int(self._fallback_store.get(key, 0))
            val += 1
            self._fallback_store[key] = str(val)
            return val
        r = await self._redis()
        return await r.incr(key)

    async def _setex(self, key: str, ttl: int, value: str):
        if self._use_fallback():
            expiry = datetime.now().timestamp() + ttl
            self._fallback_store[key] = value
        else:
            r = await self._redis()
            await r.setex(key, ttl, value)

    async def _delete(self, key: str):
        if self._use_fallback():
            self._fallback_store.pop(key, None)
        else:
            r = await self._redis()
            await r.delete(key)

    async def _exists(self, key: str) -> bool:
        if self._use_fallback():
            return key in self._fallback_store
        r = await self._redis()
        return await r.exists(key)

    # ─── Public API ───────────────────────────────────────────────────────────

    async def record_failed_attempt(self, user_id: str, ip_address: str):
        """Record a failed login attempt.

        Returns True if account is now locked, False otherwise.
        """
        # Track failed attempts per user with a TTL equal to lockout duration
        fail_key = f"auth:failed:{user_id}"
        count = await self._incr(fail_key)
        if count == 1:
            await self._setex(fail_key, int(self.LOCKOUT_DURATION.total_seconds()), str(count))

        # Auto-lock if threshold exceeded
        if count >= self.FAILED_ATTEMPT_THRESHOLD:
            await self.lock_account(user_id)

        # Track per-IP failed attempts
        ip_key = f"auth:failed_ip:{ip_address}"
        ip_count = await self._incr(ip_key)
        if ip_count == 1:
            await self._setex(ip_key, 3600, str(ip_count))

        if ip_count >= self.IP_BLACKLIST_THRESHOLD:
            await self._setex(
                f"auth:blacklisted_ip:{ip_address}",
                int(self.IP_BLACKLIST_DURATION.total_seconds()),
                "1",
            )
            logger.warning(f"IP blacklisted: {ip_address} ({ip_count} failed attempts)")

    async def is_account_locked(self, user_id: str) -> dict:
        """Check if account is locked. Returns dict with lock status."""
        locked_key = f"auth:locked:{user_id}"
        if not await self._exists(locked_key):
            return {"locked": False}

        # For the fallback store, we know it's locked if it exists
        if self._use_fallback():
            return {"locked": True, "remaining_seconds": 900}

        # Get remaining lockout time from Redis
        from app.redis import get_redis as get_redis_client
        r = await get_redis_client()
        ttl = await r.ttl(locked_key)
        return {"locked": True, "remaining_seconds": max(0, ttl)}

    async def lock_account(self, user_id: str):
        """Manually lock an account."""
        await self._setex(
            f"auth:locked:{user_id}",
            int(self.LOCKOUT_DURATION.total_seconds()),
            "1",
        )
        logger.info(f"Account locked: {user_id}")

    async def unlock_account(self, user_id: str):
        """Manually unlock an account."""
        await self._delete(f"auth:locked:{user_id}")
        await self._delete(f"auth:failed:{user_id}")
        logger.info(f"Account unlocked: {user_id}")

    async def is_ip_blacklisted(self, ip_address: str) -> bool:
        """Check if an IP address is blacklisted."""
        return await self._exists(f"auth:blacklisted_ip:{ip_address}")

    async def check_concurrent_sessions(self, user_id: str) -> int:
        """Get the number of active sessions for a user.

        Returns the count. Caller should enforce MAX_CONCURRENT_SESSIONS.
        """
        # This is done by counting sessions in the DB — caller handles it.
        # Redis just provides the count tracking via the sessions table.
        return 0  # Caller must check DB

    async def record_successful_login(self, user_id: str, ip_address: str):
        """Record a successful login — clean up failure tracking."""
        await self._delete(f"auth:failed:{user_id}")
        await self._delete(f"auth:locked:{user_id}")
        await self._delete(f"auth:failed_ip:{ip_address}")


# Global instance
account_protection = AccountProtection()
