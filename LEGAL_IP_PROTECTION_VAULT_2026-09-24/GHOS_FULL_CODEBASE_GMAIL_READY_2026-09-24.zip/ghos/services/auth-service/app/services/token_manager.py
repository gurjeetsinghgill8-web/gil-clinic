"""
GHOS Auth Service — Token Manager
=====================================
JWT creation, verification, and refresh. Also handles signed links
for patient self-service access (WhatsApp/SMS click-through).

Token types:
- access_token: 24h TTL, used for API authorization
- refresh_token: 7 day TTL, used to renew access tokens
- patient_token: 24h TTL, visit-scoped for patient self-service
- signed_link: 15min TTL, one-time use for QR/login links
"""

import json
import base64
import hashlib
import hmac
import logging
from datetime import datetime, timedelta, timezone
from typing import Optional
from uuid import uuid4

import jwt as pyjwt

from app.config import settings

logger = logging.getLogger(__name__)


class TokenManager:
    """Manages all token types: JWT, signed links, patient tokens."""

    ACCESS_TOKEN_TTL = timedelta(hours=24)
    REFRESH_TOKEN_TTL = timedelta(days=7)
    PATIENT_TOKEN_TTL = timedelta(hours=24)
    SIGNED_LINK_TTL = timedelta(minutes=15)

    def __init__(self):
        self.secret_key = settings.auth_secret_key
        self.algorithm = settings.jwt_algorithm
        self.link_signing_key = settings.link_signing_key

    # ─── Staff JWT Tokens ─────────────────────────────────────────────────────

    def create_staff_token(
        self,
        user_id: str,
        role: str,
        name: str,
        hospital_id: str = "default",
        branch_id: str = "main",
        department_id: Optional[str] = None,
    ) -> str:
        """Create JWT access token for staff members."""
        now = datetime.now(timezone.utc)
        payload = {
            "sub": user_id,
            "type": "staff",
            "role": role,
            "hospital_id": hospital_id,
            "branch_id": branch_id,
            "name": name,
            "iat": int(now.timestamp()),
            "exp": int((now + self.ACCESS_TOKEN_TTL).timestamp()),
            "jti": str(uuid4()),
        }
        if department_id:
            payload["department_id"] = department_id

        return pyjwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    def create_staff_refresh_token(self, user_id: str) -> str:
        """Create longer-lived refresh token."""
        now = datetime.now(timezone.utc)
        payload = {
            "sub": user_id,
            "type": "refresh",
            "iat": int(now.timestamp()),
            "exp": int((now + self.REFRESH_TOKEN_TTL).timestamp()),
            "jti": str(uuid4()),
        }
        return pyjwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    # ─── Patient Token ────────────────────────────────────────────────────────

    def create_patient_token(self, patient_id: str, visit_id: str, hospital_id: str = "default") -> str:
        """Create visit-scoped token for patient self-service."""
        now = datetime.now(timezone.utc)
        payload = {
            "sub": patient_id,
            "type": "patient",
            "visit_id": visit_id,
            "hospital_id": hospital_id,
            "iat": int(now.timestamp()),
            "exp": int((now + self.PATIENT_TOKEN_TTL).timestamp()),
            "scope": ["view_status", "view_reports"],
            "jti": str(uuid4()),
        }
        return pyjwt.encode(payload, self.secret_key, algorithm=self.algorithm)

    # ─── Signed Links ─────────────────────────────────────────────────────────

    def create_signed_link(self, patient_id: str, visit_id: str) -> str:
        """Create one-time signed URL (for WhatsApp/SMS links)."""
        expiry = datetime.now(timezone.utc) + self.SIGNED_LINK_TTL
        payload = {
            "pid": patient_id,
            "vid": visit_id,
            "exp": int(expiry.timestamp()),
        }
        data = base64.urlsafe_b64encode(json.dumps(payload).encode()).decode().rstrip("=")
        signature = hmac.new(
            self.link_signing_key.encode(),
            data.encode(),
            hashlib.sha256,
        ).hexdigest()[:16]
        return f"{data}.{signature}"

    def verify_signed_link(self, token: str) -> Optional[dict]:
        """Verify and decode a signed link."""
        try:
            parts = token.split(".")
            if len(parts) != 2:
                return None
            data, signature = parts

            expected_sig = hmac.new(
                self.link_signing_key.encode(),
                data.encode(),
                hashlib.sha256,
            ).hexdigest()[:16]

            if not hmac.compare_digest(signature, expected_sig):
                return None

            # Add padding back for base64 decode
            padded = data + "=" * (4 - len(data) % 4) if len(data) % 4 else data
            payload = json.loads(base64.urlsafe_b64decode(padded))

            if datetime.now(timezone.utc).timestamp() > payload.get("exp", 0):
                return None

            return payload
        except (ValueError, json.JSONDecodeError, KeyError, TypeError) as e:
            logger.warning(f"Signed link verification failed: {e}")
            return None

    # ─── Token Verification ──────────────────────────────────────────────────

    def verify_token(self, token: str) -> Optional[dict]:
        """Verify and decode any JWT token."""
        try:
            payload = pyjwt.decode(
                token,
                self.secret_key,
                algorithms=[self.algorithm],
                options={"require": ["sub", "type", "iat", "exp", "jti"]},
            )
            return payload
        except pyjwt.ExpiredSignatureError:
            logger.debug("Token expired")
            return None
        except pyjwt.InvalidTokenError as e:
            logger.debug(f"Invalid token: {e}")
            return None

    def refresh_access_token(self, refresh_token: str, user_data: dict) -> Optional[str]:
        """Exchange a refresh token for a new access token.

        Args:
            refresh_token: The refresh token string
            user_data: User details dict with sub, role, name, hospital_id, branch_id

        Returns:
            New access token string, or None if invalid
        """
        payload = self.verify_token(refresh_token)
        if not payload or payload.get("type") != "refresh":
            return None

        return self.create_staff_token(
            user_id=user_data["sub"],
            role=user_data["role"],
            name=user_data["name"],
            hospital_id=user_data.get("hospital_id", "default"),
            branch_id=user_data.get("branch_id", "main"),
        )


# Global instance
token_manager = TokenManager()
