"""
GHOS Auth Service — Pydantic Schemas
========================================
Request/Response models for all auth endpoints.
"""

from datetime import datetime
from typing import Optional, List, Any
from pydantic import BaseModel, Field


# ─── Login / OTP ──────────────────────────────────────────────────────────────

class LoginOtpRequest(BaseModel):
    mobile: str = Field(..., min_length=10, max_length=20, description="10-digit mobile number")
    channel: str = Field(default="whatsapp", pattern="^(whatsapp|sms)$")


class VerifyOtpRequest(BaseModel):
    mobile: str = Field(..., min_length=10, max_length=20)
    otp: str = Field(..., min_length=4, max_length=8)


class LoginPasswordRequest(BaseModel):
    mobile: str = Field(..., min_length=10, max_length=20)
    password: str = Field(..., min_length=1)


class RefreshTokenRequest(BaseModel):
    refresh_token: str = Field(..., min_length=1)


class LogoutRequest(BaseModel):
    refresh_token: Optional[str] = None


# ─── Password Change ──────────────────────────────────────────────────────────

class ChangePasswordRequest(BaseModel):
    old_password: str = Field(..., min_length=1)
    new_password: str = Field(..., min_length=8)


# ─── Admin: User Management ───────────────────────────────────────────────────

class CreateUserRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    mobile: str = Field(..., min_length=10, max_length=20)
    email: Optional[str] = None
    role: str = Field(..., pattern="^(admin|doctor|receptionist|nurse|lab_technician|pharmacist|accountant|manager)$")
    department_id: Optional[str] = None
    password: Optional[str] = Field(default=None, min_length=8)


class UpdateUserLockRequest(BaseModel):
    is_locked: bool
    reason: Optional[str] = None


# ─── Admin: API Keys ─────────────────────────────────────────────────────────

class CreateApiKeyRequest(BaseModel):
    name: str = Field(..., min_length=1, max_length=100)
    permissions: Optional[dict] = None
    rate_limit_per_minute: int = Field(default=60, ge=1, le=10000)


# ─── Token Metadata (internal) ─────────────────────────────────────────────────

class TokenData(BaseModel):
    sub: str
    type: str = "access"
    role: Optional[str] = None
    hospital_id: Optional[str] = None
    branch_id: Optional[str] = None
    name: Optional[str] = None
    jti: Optional[str] = None
    exp: Optional[int] = None
    iat: Optional[int] = None


# ─── Response Models ──────────────────────────────────────────────────────────

class AuthResponse(BaseModel):
    success: bool = True
    data: Optional[dict] = None
    error: Optional[dict] = None
    meta: Optional[dict] = None


class UserOut(BaseModel):
    id: str
    name: str
    mobile: str
    email: Optional[str] = None
    role: str
    department_id: Optional[str] = None
    active: bool
    is_locked: bool
    last_login_at: Optional[str] = None
    created_at: Optional[str] = None


class ApiKeyOut(BaseModel):
    id: str
    name: str
    key_preview: Optional[str] = None  # First 8 chars of the key
    permissions: Optional[dict] = None
    rate_limit_per_minute: int
    active: bool
    last_used_at: Optional[str] = None
    created_at: Optional[str] = None


class SessionOut(BaseModel):
    id: str
    device_info: Optional[str] = None
    ip_address: Optional[str] = None
    last_activity_at: Optional[str] = None
    created_at: Optional[str] = None
    is_current: bool = False


class HealthResponse(BaseModel):
    status: str = "ok"
    service: str = "ghos-auth-service"
    version: str = "1.0.0"
    database: str = "connected"
    redis: str = "connected"
