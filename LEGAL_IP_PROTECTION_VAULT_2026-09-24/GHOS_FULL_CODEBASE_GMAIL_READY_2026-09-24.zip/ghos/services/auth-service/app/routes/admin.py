"""
GHOS Auth Service — Admin Routes
====================================
Admin-only endpoints for user management and API key management.
Requires 'admin' role.
"""

import hashlib
import secrets
import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import StaffUser, APIKey, APIKeyUsage
from app.schemas import (
    CreateUserRequest, UpdateUserLockRequest, CreateApiKeyRequest,
    AuthResponse, UserOut, ApiKeyOut,
)
from app.services.password_auth import password_auth
from app.services.account_protection import account_protection
from app.config import settings

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/admin", tags=["admin"])


# ─── Require Admin Role ────────────────────────────────────────────────────

async def require_admin(request: Request):
    """Dependency: verify the user has admin role."""
    user = getattr(request.state, "user", None)
    if not user:
        raise HTTPException(status_code=401, detail="Not authenticated")
    if user.get("role") != "admin":
        raise HTTPException(status_code=403, detail="Admin access required")
    return user


# ─── Create User ───────────────────────────────────────────────────────────

@router.post("/users", response_model=AuthResponse)
async def create_user(
    body: CreateUserRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """Create a new staff user (admin only)."""
    # Check if mobile already exists
    result = await db.execute(
        select(StaffUser).where(StaffUser.mobile == body.mobile)
    )
    if result.scalar_one_or_none():
        return AuthResponse(
            success=False,
            error={"code": "MOBILE_EXISTS", "message": "A user with this mobile already exists"},
        )

    # Hash password if provided
    password_hash = None
    if body.password:
        strength = await password_auth.check_password_strength(body.password)
        if not strength["is_strong"]:
            return AuthResponse(
                success=False,
                error={
                    "code": "WEAK_PASSWORD",
                    "message": " | ".join(strength["errors"]),
                },
            )
        password_hash = await password_auth.hash_password(body.password)

    # Create user
    from app.models import UserRole
    user = StaffUser(
        name=body.name,
        mobile=body.mobile,
        email=body.email,
        role=UserRole(body.role),
        department_id=body.department_id,
        password_hash=password_hash,
        password_changed_at=datetime.now(timezone.utc) if password_hash else None,
    )
    db.add(user)
    await db.flush()

    logger.info(f"User created: {user.name} ({user.mobile}) as {user.role.value}")

    return AuthResponse(
        data={
            "id": user.id,
            "name": user.name,
            "mobile": user.mobile,
            "email": user.email,
            "role": user.role.value,
            "department_id": user.department_id,
            "active": user.active,
        }
    )


# ─── List Users ───────────────────────────────────────────────────────────

@router.get("/users", response_model=AuthResponse)
async def list_users(
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """List all staff users (admin only)."""
    result = await db.execute(
        select(StaffUser).order_by(StaffUser.name)
    )
    users = result.scalars().all()

    return AuthResponse(
        data={
            "users": [
                {
                    "id": u.id,
                    "name": u.name,
                    "mobile": u.mobile,
                    "email": u.email,
                    "role": u.role.value,
                    "department_id": u.department_id,
                    "active": u.active,
                    "is_locked": u.is_locked,
                    "last_login_at": u.last_login_at.isoformat() if u.last_login_at else None,
                    "created_at": u.created_at.isoformat() if u.created_at else None,
                }
                for u in users
            ],
            "count": len(users),
        }
    )


# ─── Get User ─────────────────────────────────────────────────────────────

@router.get("/users/{user_id}", response_model=AuthResponse)
async def get_user(
    user_id: str,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """Get a specific user's details (admin only)."""
    result = await db.execute(select(StaffUser).where(StaffUser.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        return AuthResponse(
            success=False,
            error={"code": "USER_NOT_FOUND", "message": "User not found"},
        )

    return AuthResponse(
        data={
            "id": user.id,
            "name": user.name,
            "mobile": user.mobile,
            "email": user.email,
            "role": user.role.value,
            "department_id": user.department_id,
            "active": user.active,
            "is_locked": user.is_locked,
            "has_password": user.password_hash is not None,
            "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None,
            "last_login_ip": user.last_login_ip,
            "failed_login_attempts": user.failed_login_attempts,
            "created_at": user.created_at.isoformat() if user.created_at else None,
        }
    )


# ─── Lock/Unlock User ────────────────────────────────────────────────────

@router.put("/users/{user_id}/lock", response_model=AuthResponse)
async def lock_user(
    user_id: str,
    body: UpdateUserLockRequest,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """Lock or unlock a user account (admin only)."""
    result = await db.execute(select(StaffUser).where(StaffUser.id == user_id))
    user = result.scalar_one_or_none()

    if not user:
        return AuthResponse(
            success=False,
            error={"code": "USER_NOT_FOUND", "message": "User not found"},
        )

    user.is_locked = body.is_locked

    if body.is_locked:
        await account_protection.lock_account(user.id)
        logger.info(f"User {user.name} locked by admin. Reason: {body.reason or 'Not specified'}")
    else:
        await account_protection.unlock_account(user.id)
        user.failed_login_attempts = 0
        logger.info(f"User {user.name} unlocked by admin")

    await db.flush()

    return AuthResponse(
        data={
            "id": user.id,
            "name": user.name,
            "is_locked": user.is_locked,
        }
    )


# ─── Create API Key ───────────────────────────────────────────────────────

@router.post("/api-keys", response_model=AuthResponse)
async def create_api_key(
    body: CreateApiKeyRequest,
    request: Request,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """Generate a new API key for external system integration (admin only).

    Returns the full key only once (on creation). Store it securely.
    """
    # Generate key
    raw_key = f"ghos_{secrets.token_urlsafe(32)}"
    key_hash = hashlib.sha256(raw_key.encode()).hexdigest()

    api_key = APIKey(
        name=body.name,
        key_hash=key_hash,
        permissions=body.permissions or {},
        rate_limit_per_minute=body.rate_limit_per_minute,
        created_by=admin.get("sub"),
    )
    db.add(api_key)
    await db.flush()

    logger.info(f"API key created: {body.name}")

    return AuthResponse(
        data={
            "id": api_key.id,
            "name": api_key.name,
            "api_key": raw_key,  # Only time this is shown
            "permissions": api_key.permissions,
            "rate_limit_per_minute": api_key.rate_limit_per_minute,
        }
    )


# ─── List API Keys ───────────────────────────────────────────────────────

@router.get("/api-keys", response_model=AuthResponse)
async def list_api_keys(
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """List all API keys (admin only). Shows key previews, not full keys."""
    result = await db.execute(
        select(APIKey).where(APIKey.active == True).order_by(APIKey.name)
    )
    keys = result.scalars().all()

    return AuthResponse(
        data={
            "api_keys": [
                {
                    "id": k.id,
                    "name": k.name,
                    "key_preview": None,  # Full key never stored for retrieval
                    "permissions": k.permissions,
                    "rate_limit_per_minute": k.rate_limit_per_minute,
                    "active": k.active,
                    "last_used_at": k.last_used_at.isoformat() if k.last_used_at else None,
                    "created_at": k.created_at.isoformat() if k.created_at else None,
                }
                for k in keys
            ],
            "count": len(keys),
        }
    )


# ─── Revoke API Key ──────────────────────────────────────────────────────

@router.delete("/api-keys/{key_id}", response_model=AuthResponse)
async def revoke_api_key(
    key_id: str,
    db: AsyncSession = Depends(get_db),
    admin: dict = Depends(require_admin),
):
    """Revoke an API key (admin only)."""
    result = await db.execute(
        select(APIKey).where(APIKey.id == key_id)
    )
    api_key = result.scalar_one_or_none()

    if not api_key:
        return AuthResponse(
            success=False,
            error={"code": "API_KEY_NOT_FOUND", "message": "API key not found"},
        )

    api_key.active = False
    await db.flush()

    logger.info(f"API key revoked: {api_key.name}")

    return AuthResponse(data={"message": "API key revoked"})
