"""
GHOS Auth Service — Auth Routes
===================================
Public authentication endpoints:
- OTP login (request + verify)
- Password login (for admin/owner)
- Token refresh
- Logout
- Get current user / sessions
- Change password
"""

import logging
from datetime import datetime, timezone

from fastapi import APIRouter, Depends, Request, HTTPException
from sqlalchemy import select
from sqlalchemy.ext.asyncio import AsyncSession

from app.database import get_db
from app.models import StaffUser, Session, PasswordHistory
from app.schemas import (
    LoginOtpRequest, VerifyOtpRequest, LoginPasswordRequest,
    RefreshTokenRequest, LogoutRequest, ChangePasswordRequest,
    AuthResponse, SessionOut,
)
from app.services.token_manager import token_manager
from app.services.otp_service import otp_service
from app.services.password_auth import password_auth
from app.services.account_protection import account_protection

logger = logging.getLogger(__name__)

router = APIRouter(prefix="/api/v1/auth", tags=["auth"])


# ─── OTP Login: Request ─────────────────────────────────────────────────────

@router.post("/login/otp", response_model=AuthResponse)
async def login_otp(
    request: Request,
    body: LoginOtpRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Request an OTP for login.

    The user provides their mobile number. If the number exists and is active,
    an OTP is generated and sent via the specified channel.
    """
    # Check IP blacklist
    client_ip = request.client.host if request.client else "unknown"
    if await account_protection.is_ip_blacklisted(client_ip):
        return AuthResponse(
            success=False,
            error={
                "code": "IP_BLACKLISTED",
                "message": "Too many failed attempts. Try again later.",
            },
        )

    # Find user by mobile
    result = await db.execute(
        select(StaffUser).where(StaffUser.mobile == body.mobile, StaffUser.active == True)
    )
    user = result.scalar_one_or_none()

    if not user:
        # Don't reveal whether the number exists
        return AuthResponse(
            data={
                "message": "If this number is registered, an OTP has been sent.",
                "ttl_seconds": otp_service.OTP_TTL_SECONDS,
            }
        )

    # Check account lock
    lock_status = await account_protection.is_account_locked(user.id)
    if lock_status["locked"]:
        return AuthResponse(
            success=False,
            error={
                "code": "ACCOUNT_LOCKED",
                "message": f"Account is locked. Try again in {lock_status['remaining_seconds']} seconds.",
            },
        )

    # Generate and send OTP
    result = await otp_service.generate_and_send(
        mobile=body.mobile,
        channel=body.channel,
        user_name=user.name,
    )

    if not result["success"]:
        return AuthResponse(success=False, error=result)

    return AuthResponse(
        data={
            "message": f"OTP sent via {body.channel}",
            "ttl_seconds": result["ttl_seconds"],
        }
    )


# ─── OTP Login: Verify ─────────────────────────────────────────────────────

@router.post("/verify-otp", response_model=AuthResponse)
async def verify_otp(
    request: Request,
    body: VerifyOtpRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Verify an OTP and return JWT tokens.

    On success, returns access_token, refresh_token, and user info.
    """
    client_ip = request.client.host if request.client else "unknown"

    # Verify OTP
    otp_result = await otp_service.verify(body.mobile, body.otp)
    if not otp_result["success"]:
        return AuthResponse(success=False, error=otp_result)

    # Find user by mobile
    result = await db.execute(
        select(StaffUser).where(StaffUser.mobile == body.mobile, StaffUser.active == True)
    )
    user = result.scalar_one_or_none()

    if not user:
        return AuthResponse(
            success=False,
            error={"code": "USER_NOT_FOUND", "message": "User not found or inactive"},
        )

    # Generate tokens
    access_token = token_manager.create_staff_token(
        user_id=user.id,
        role=user.role.value,
        name=user.name,
        hospital_id=user.hospital_id,
        branch_id=user.branch_id,
        department_id=user.department_id,
    )
    refresh_token = token_manager.create_staff_refresh_token(user.id)

    # Record successful login
    await account_protection.record_successful_login(user.id, client_ip)

    # Update user
    user.last_login_at = datetime.now(timezone.utc)
    user.last_login_ip = client_ip
    user.failed_login_attempts = 0
    user.is_locked = False
    user.locked_until = None

    # Log session in DB
    session = Session(
        user_id=user.id,
        user_type="staff",
        token_jti=token_manager.verify_token(access_token).get("jti", ""),
        refresh_token_jti=token_manager.verify_token(refresh_token).get("jti", ""),
        device_info=request.headers.get("user-agent", ""),
        ip_address=client_ip,
        expires_at=datetime.now(timezone.utc) + token_manager.ACCESS_TOKEN_TTL,
        last_activity_at=datetime.now(timezone.utc),
    )
    db.add(session)
    await db.flush()

    return AuthResponse(
        data={
            "access_token": access_token,
            "refresh_token": refresh_token,
            "token_type": "bearer",
            "expires_in": int(token_manager.ACCESS_TOKEN_TTL.total_seconds()),
            "user": {
                "id": user.id,
                "name": user.name,
                "mobile": user.mobile,
                "role": user.role.value,
                "department_id": user.department_id,
                "hospital_id": user.hospital_id,
                "branch_id": user.branch_id,
            },
        }
    )


# ─── Password Login ────────────────────────────────────────────────────────

@router.post("/login/password", response_model=AuthResponse)
async def login_password(
    request: Request,
    body: LoginPasswordRequest,
    db: AsyncSession = Depends(get_db),
):
    """
    Login with mobile + password (for admin/owner accounts with password set).
    """
    client_ip = request.client.host if request.client else "unknown"

    # Check IP blacklist
    if await account_protection.is_ip_blacklisted(client_ip):
        return AuthResponse(
            success=False,
            error={
                "code": "IP_BLACKLISTED",
                "message": "Too many failed attempts. Try again later.",
            },
        )

    # Find user
    result = await db.execute(
        select(StaffUser).where(StaffUser.mobile == body.mobile, StaffUser.active == True)
    )
    user = result.scalar_one_or_none()

    if not user or not user.password_hash:
        return AuthResponse(
            success=False,
            error={"code": "INVALID_CREDENTIALS", "message": "Invalid mobile or password"},
        )

    # Check account lock
    lock_status = await account_protection.is_account_locked(user.id)
    if lock_status["locked"]:
        return AuthResponse(
            success=False,
            error={
                "code": "ACCOUNT_LOCKED",
                "message": f"Account is locked. Try again later.",
            },
        )

    # Verify password
    valid = await password_auth.verify_password(body.password, user.password_hash)
    if not valid:
        await account_protection.record_failed_attempt(user.id, client_ip)
        return AuthResponse(
            success=False,
            error={"code": "INVALID_CREDENTIALS", "message": "Invalid mobile or password"},
        )

    # Check if password needs change
    needs_change = await password_auth.needs_password_change(user.password_changed_at)

    # Generate tokens
    access_token = token_manager.create_staff_token(
        user_id=user.id,
        role=user.role.value,
        name=user.name,
        hospital_id=user.hospital_id,
        branch_id=user.branch_id,
        department_id=user.department_id,
    )
    refresh_token = token_manager.create_staff_refresh_token(user.id)

    # Record success
    await account_protection.record_successful_login(user.id, client_ip)
    user.last_login_at = datetime.now(timezone.utc)
    user.last_login_ip = client_ip
    user.failed_login_attempts = 0

    # Log session
    session = Session(
        user_id=user.id,
        user_type="staff",
        token_jti=token_manager.verify_token(access_token).get("jti", ""),
        refresh_token_jti=token_manager.verify_token(refresh_token).get("jti", ""),
        device_info=request.headers.get("user-agent", ""),
        ip_address=client_ip,
        expires_at=datetime.now(timezone.utc) + token_manager.ACCESS_TOKEN_TTL,
        last_activity_at=datetime.now(timezone.utc),
    )
    db.add(session)
    await db.flush()

    response_data = {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "token_type": "bearer",
        "expires_in": int(token_manager.ACCESS_TOKEN_TTL.total_seconds()),
        "user": {
            "id": user.id,
            "name": user.name,
            "mobile": user.mobile,
            "role": user.role.value,
            "department_id": user.department_id,
            "hospital_id": user.hospital_id,
            "branch_id": user.branch_id,
        },
    }
    if needs_change:
        response_data["password_needs_change"] = True

    return AuthResponse(data=response_data)


# ─── Token Refresh ─────────────────────────────────────────────────────────

@router.post("/refresh", response_model=AuthResponse)
async def refresh_token(
    body: RefreshTokenRequest,
    db: AsyncSession = Depends(get_db),
):
    """Exchange a refresh token for a new access token."""
    # Verify the refresh token
    payload = token_manager.verify_token(body.refresh_token)
    if not payload or payload.get("type") != "refresh":
        return AuthResponse(
            success=False,
            error={"code": "INVALID_REFRESH_TOKEN", "message": "Invalid or expired refresh token"},
        )

    # Find user
    user_id = payload["sub"]
    result = await db.execute(
        select(StaffUser).where(StaffUser.id == user_id, StaffUser.active == True)
    )
    user = result.scalar_one_or_none()

    if not user:
        return AuthResponse(
            success=False,
            error={"code": "USER_NOT_FOUND", "message": "User not found or inactive"},
        )

    # Generate new access token
    access_token = token_manager.create_staff_token(
        user_id=user.id,
        role=user.role.value,
        name=user.name,
        hospital_id=user.hospital_id,
        branch_id=user.branch_id,
        department_id=user.department_id,
    )

    return AuthResponse(
        data={
            "access_token": access_token,
            "token_type": "bearer",
            "expires_in": int(token_manager.ACCESS_TOKEN_TTL.total_seconds()),
        }
    )


# ─── Logout ────────────────────────────────────────────────────────────────

@router.post("/logout", response_model=AuthResponse)
async def logout(
    request: Request,
    body: LogoutRequest,
    db: AsyncSession = Depends(get_db),
):
    """Logout — revoke current session/token."""
    token = getattr(request.state, "token", None) or request.headers.get("Authorization", "").replace("Bearer ", "")

    if token:
        payload = token_manager.verify_token(token)
        if payload:
            jti = payload.get("jti")
            # Remove session from DB
            if jti:
                result = await db.execute(
                    select(Session).where(Session.token_jti == jti)
                )
                session = result.scalar_one_or_none()
                if session:
                    await db.delete(session)
                    await db.flush()

    return AuthResponse(data={"message": "Logged out successfully"})


# ─── Get Current User ─────────────────────────────────────────────────────

@router.get("/me", response_model=AuthResponse)
async def get_me(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Get the current authenticated user's profile."""
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        return AuthResponse(
            success=False,
            error={"code": "NOT_AUTHENTICATED", "message": "Not authenticated"},
        )

    result = await db.execute(
        select(StaffUser).where(StaffUser.id == user_id)
    )
    user = result.scalar_one_or_none()

    if not user:
        return AuthResponse(
            success=False,
            error={"code": "USER_NOT_FOUND", "message": "User not found"},
        )

    return AuthResponse(
        data={
            "id": user.id,
            "name": user.name,
            "mobile": user.mobile,
            "email": user.email,
            "role": user.role.value,
            "department_id": user.department_id,
            "active": user.active,
            "is_locked": user.is_locked,
            "last_login_at": user.last_login_at.isoformat() if user.last_login_at else None,
            "created_at": user.created_at.isoformat() if user.created_at else None,
        }
    )


# ─── List Sessions ────────────────────────────────────────────────────────

@router.get("/sessions", response_model=AuthResponse)
async def list_sessions(
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """List all active sessions for the current user."""
    user_id = getattr(request.state, "user_id", None)
    current_jti = getattr(request.state, "token", None)
    if current_jti:
        payload = token_manager.verify_token(current_jti)
        current_jti = payload.get("jti") if payload else None

    if not user_id:
        return AuthResponse(
            success=False,
            error={"code": "NOT_AUTHENTICATED", "message": "Not authenticated"},
        )

    now = datetime.now(timezone.utc)
    result = await db.execute(
        select(Session)
        .where(Session.user_id == user_id, Session.expires_at > now)
        .order_by(Session.last_activity_at.desc())
    )
    sessions = result.scalars().all()

    sessions_out = []
    for s in sessions:
        sessions_out.append(
            {
                "id": s.id,
                "device_info": s.device_info,
                "ip_address": s.ip_address,
                "last_activity_at": s.last_activity_at.isoformat() if s.last_activity_at else None,
                "created_at": s.created_at.isoformat() if s.created_at else None,
                "is_current": s.token_jti == current_jti,
            }
        )

    return AuthResponse(data={"sessions": sessions_out, "count": len(sessions_out)})


# ─── Terminate Session ────────────────────────────────────────────────────

@router.delete("/sessions/{session_id}", response_model=AuthResponse)
async def terminate_session(
    session_id: str,
    request: Request,
    db: AsyncSession = Depends(get_db),
):
    """Terminate a specific session."""
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        return AuthResponse(
            success=False,
            error={"code": "NOT_AUTHENTICATED", "message": "Not authenticated"},
        )

    result = await db.execute(
        select(Session).where(Session.id == session_id, Session.user_id == user_id)
    )
    session = result.scalar_one_or_none()

    if not session:
        return AuthResponse(
            success=False,
            error={"code": "SESSION_NOT_FOUND", "message": "Session not found"},
        )

    await db.delete(session)
    await db.flush()

    return AuthResponse(data={"message": "Session terminated"})


# ─── Change Password ──────────────────────────────────────────────────────

@router.post("/change-password", response_model=AuthResponse)
async def change_password(
    request: Request,
    body: ChangePasswordRequest,
    db: AsyncSession = Depends(get_db),
):
    """Change the current user's password."""
    user_id = getattr(request.state, "user_id", None)
    if not user_id:
        return AuthResponse(
            success=False,
            error={"code": "NOT_AUTHENTICATED", "message": "Not authenticated"},
        )

    result = await db.execute(select(StaffUser).where(StaffUser.id == user_id))
    user = result.scalar_one_or_none()

    if not user or not user.password_hash:
        return AuthResponse(
            success=False,
            error={"code": "PASSWORD_NOT_SET", "message": "Password login not enabled for this account"},
        )

    # Verify old password
    if not await password_auth.verify_password(body.old_password, user.password_hash):
        return AuthResponse(
            success=False,
            error={"code": "INVALID_PASSWORD", "message": "Current password is incorrect"},
        )

    # Check strength
    strength = await password_auth.check_password_strength(body.new_password)
    if not strength["is_strong"]:
        return AuthResponse(
            success=False,
            error={
                "code": "WEAK_PASSWORD",
                "message": " | ".join(strength["errors"]),
            },
        )

    # Check password history (last N passwords)
    history_result = await db.execute(
        select(PasswordHistory)
        .where(PasswordHistory.user_id == user.id)
        .order_by(PasswordHistory.created_at.desc())
        .limit(settings.password_history_count)
    )
    for history_entry in history_result.scalars().all():
        if await password_auth.verify_password(body.new_password, history_entry.password_hash):
            return AuthResponse(
                success=False,
                error={"code": "PASSWORD_REUSED", "message": "Cannot reuse a recent password"},
            )

    # Hash and save new password
    old_hash = user.password_hash
    new_hash = await password_auth.hash_password(body.new_password)
    user.password_hash = new_hash
    user.password_changed_at = datetime.now(timezone.utc)

    # Add old password to history
    history = PasswordHistory(user_id=user.id, password_hash=old_hash)
    db.add(history)
    await db.flush()

    return AuthResponse(data={"message": "Password changed successfully"})
