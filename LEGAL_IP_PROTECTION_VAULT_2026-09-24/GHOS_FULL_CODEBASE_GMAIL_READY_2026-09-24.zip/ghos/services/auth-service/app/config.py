"""
GHOS Auth Service — Configuration
=====================================
Pydantic Settings loaded from environment variables.
"""

from pydantic_settings import BaseSettings
from typing import List


class Settings(BaseSettings):
    # App
    app_name: str = "GHOS-Auth-Service"
    version: str = "1.0.0"
    environment: str = "development"
    debug: bool = True
    log_level: str = "INFO"

    # CORS
    cors_origins: List[str] = ["*"]

    # Database
    database_url: str = "postgresql+asyncpg://ghos:ghos_secret@localhost:5432/ghos_queue"
    database_pool_size: int = 10
    database_max_overflow: int = 20

    # Redis
    redis_url: str = "redis://localhost:6379/0"

    # Server
    host: str = "0.0.0.0"
    port: int = 8003

    # ─── JWT ─────────────────────────────────────────────────────────────────
    auth_secret_key: str = "change-this-secret-key-in-production-min-32-chars!"
    jwt_algorithm: str = "HS256"
    access_token_ttl_hours: int = 24
    refresh_token_ttl_days: int = 7
    link_signing_key: str = "change-this-link-signing-key-in-production"

    # ─── OTP ─────────────────────────────────────────────────────────────────
    otp_length: int = 6
    otp_ttl_seconds: int = 300
    otp_max_attempts: int = 3
    otp_resend_cooldown_seconds: int = 30
    otp_max_per_hour: int = 5
    otp_pepper: str = "change-this-otp-pepper-in-production"

    # ─── Password Policy ─────────────────────────────────────────────────────
    password_min_length: int = 8
    password_require_uppercase: bool = True
    password_require_number: bool = True
    password_history_count: int = 5
    password_force_change_days: int = 90

    # ─── Account Protection ──────────────────────────────────────────────────
    max_failed_attempts: int = 5
    lockout_minutes: int = 15
    ip_blacklist_threshold: int = 20
    ip_blacklist_hours: int = 1
    max_concurrent_sessions: int = 5
    inactivity_timeout_minutes: int = 30

    # ─── API Keys ────────────────────────────────────────────────────────────
    api_key_length: int = 32
    api_key_default_rate_limit: int = 60

    # ─── Hospital/Branch defaults ────────────────────────────────────────────
    hospital_id: str = "default"
    branch_id: str = "main"

    # ─── Default Admin ───────────────────────────────────────────────────────
    default_admin_name: str = "Admin"
    default_admin_mobile: str = "9999999999"
    default_admin_password: str = "Admin@123"
    default_admin_role: str = "admin"

    class Config:
        env_file = ".env"
        case_sensitive = False


settings = Settings()
