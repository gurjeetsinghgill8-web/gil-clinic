"""
Run this script to restore all sanitized file extensions (.js.txt -> .js, .bat.txt -> .bat, etc.)
Usage: python RESTORE_FILES.py
"""
import os

BLOCKED_CONVERSIONS = [".js.txt", ".bat.txt", ".ps1.txt", ".sh.txt", ".cmd.txt"]

for root, dirs, files in os.walk("."):
    for file in files:
        for ext in BLOCKED_CONVERSIONS:
            if file.endswith(ext):
                original_name = file[:-4]  # Remove .txt
                old_path = os.path.join(root, file)
                new_path = os.path.join(root, original_name)
                os.rename(old_path, new_path)
                print(f"Restored: {file} -> {original_name}")

print("All files restored successfully!")
