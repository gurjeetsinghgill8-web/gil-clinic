"""
╔══════════════════════════════════════════════════════════════════╗
║   BHARAT AI CLINIC — LAB REPORT BATCH SCANNER                   ║
║   Lego Module — Works standalone OR imported into main app       ║
║   Usage: streamlit run lab_scanner.py                            ║
╚══════════════════════════════════════════════════════════════════╝
"""

import streamlit as st
from PIL import Image
import requests, base64, io, json, re, datetime, os
from fpdf import FPDF
import urllib.parse

# ── STANDALONE mode: set page config ─────────────────────────────
try:
    st.set_page_config(
        page_title="Lab Report Scanner — Bharat AI Clinic",
        page_icon="🔬", layout="wide"
    )
except: pass  # Already set if imported into main app

# ══════════════════════════════════════════════════════════════════
# 1. API ENGINE
# ══════════════════════════════════════════════════════════════════
def _get_key():
    try:    return st.secrets["GROQ_API_KEY"]
    except: return st.session_state.get("groq_key","") or os.getenv("GROQ_API_KEY","")

def _img_to_b64(img: Image.Image) -> str:
    buf = io.BytesIO()
    img.convert("RGB").save(buf, "JPEG", quality=88)
    return base64.b64encode(buf.getvalue()).decode()

def analyze_lab_image(img: Image.Image, patient_name: str = "", extra_context: str = "") -> dict:
    """
    Send ONE lab report image to Groq Vision.
    Returns structured dict with all findings.
    """
    key = _get_key()
    if not key:
        return {"error": "API Key missing"}

    b64 = _img_to_b64(img)
    context_hint = f"Patient: {patient_name}. " if patient_name else ""
    extra_hint   = f"Context: {extra_context}. " if extra_context else ""

    prompt = f"""{context_hint}{extra_hint}
You are an expert Indian pathologist reading a lab report.

EXTRACT CAREFULLY:
1. Test names and their values
2. Reference ranges (normal ranges)
3. Flag each value: NORMAL / HIGH ⬆️ / LOW ⬇️ / CRITICAL 🚨
4. Patient name if visible
5. Lab name and date if visible

RETURN ONLY valid JSON — no markdown, no extra text:
{{
  "patient_name": "",
  "lab_name": "",
  "report_date": "",
  "tests": [
    {{
      "name": "Hemoglobin",
      "value": "11.2",
      "unit": "g/dL",
      "reference": "13-17",
      "flag": "LOW",
      "clinical_note": "Mild anemia"
    }}
  ],
  "abnormal_summary": "Brief summary of abnormal findings only",
  "normal_tests": ["Test1", "Test2"],
  "critical_flags": ["Any critical/panic values"],
  "report_type": "CBC / LFT / RFT / Lipid / etc"
}}"""

    try:
        r = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={
                "model": "meta-llama/llama-4-scout-17b-16e-instruct",
                "temperature": 0.0,
                "messages": [{"role": "user", "content": [
                    {"type": "text", "text": prompt},
                    {"type": "image_url", "image_url": {"url": f"data:image/jpeg;base64,{b64}"}}
                ]}]
            }, timeout=45
        )
        if r.status_code == 200:
            txt = r.json()["choices"][0]["message"]["content"].strip()
            txt = txt.replace("```json","").replace("```","").strip()
            s = txt.find("{"); e = txt.rfind("}")
            if s >= 0 and e > s:
                return json.loads(txt[s:e+1])
    except Exception as ex:
        return {"error": str(ex)}
    return {"error": f"API error {r.status_code}"}

def generate_clinical_interpretation(all_results: list, patient_name: str, patient_history: str = "") -> str:
    """
    After all reports processed — generate clinical interpretation + advice.
    """
    key = _get_key()
    if not key: return "API Key missing."

    # Build compact summary of all findings
    summary_lines = []
    for i, res in enumerate(all_results):
        if res.get("error"): continue
        rt = res.get("report_type", f"Report {i+1}")
        abnormal = res.get("abnormal_summary", "")
        critical = res.get("critical_flags", [])
        tests = res.get("tests", [])
        abnormal_tests = [t for t in tests if t.get("flag","") not in ["NORMAL",""]]
        if abnormal_tests or critical:
            summary_lines.append(f"[{rt}] Abnormal: {abnormal}")
            if critical:
                summary_lines.append(f"  🚨 CRITICAL: {', '.join(critical)}")

    if not summary_lines:
        summary_lines = ["All results appear within normal limits"]

    history_hint = f"\nPatient History: {patient_history}" if patient_history else ""

    prompt = f"""You are a Senior Indian Physician reviewing lab reports for {patient_name or 'this patient'}.{history_hint}

LAB FINDINGS SUMMARY:
{chr(10).join(summary_lines)}

Provide a CLINICAL INTERPRETATION with these sections:

**📊 KEY ABNORMAL FINDINGS:**
[Bullet points — only the important abnormal values and what they mean clinically]

**🚨 CRITICAL / URGENT VALUES:**
[Any panic values needing immediate action — or "None"]

**🔍 PROBABLE CLINICAL CORRELATION:**
[What diseases/conditions do these results suggest?]

**💊 TREATMENT IMPLICATIONS:**
[What medicines/doses may need adjustment based on these reports?]

**🔬 FURTHER INVESTIGATIONS ADVISED:**
[What additional tests should be done and why?]

**📋 DIFFERENTIAL DIAGNOSIS TO CONSIDER:**
[For doctor's reference — not for patient]

**✅ NORMAL PARAMETERS:**
[One line summary of what's normal]

**📅 FOLLOW-UP RECOMMENDATION:**
[When to repeat which tests]

RULES: ENGLISH only. Be specific and clinical. This is for the treating doctor."""

    try:
        r = requests.post(
            "https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization": f"Bearer {key}", "Content-Type": "application/json"},
            json={
                "model": "llama-3.3-70b-versatile",
                "temperature": 0.1,
                "messages": [{"role": "user", "content": prompt}]
            }, timeout=60
        )
        if r.status_code == 200:
            return r.json()["choices"][0]["message"]["content"]
        return f"AI error: {r.status_code}"
    except Exception as e:
        return f"Error: {e}"

# ══════════════════════════════════════════════════════════════════
# 2. PDF GENERATOR
# ══════════════════════════════════════════════════════════════════
def _safe(t): return str(t).encode("latin-1","replace").decode("latin-1")

def create_lab_pdf(patient_name: str, results: list, interpretation: str,
                   clinic_name: str = "Bharat AI Clinic",
                   doc_name: str = "Doctor") -> bytes:
    """Create a complete lab report summary PDF"""
    pdf = FPDF(); pdf.add_page()

    # Header
    pdf.set_fill_color(240, 248, 255); pdf.rect(0, 0, 210, 35, "F")
    pdf.set_font("Helvetica","B",16); pdf.set_text_color(0,51,102)
    pdf.cell(0,10,_safe(clinic_name),ln=True,align="C")
    pdf.set_font("Helvetica","I",9); pdf.set_text_color(80,80,80)
    pdf.cell(0,6,f"{_safe(doc_name)} | Lab Report Analysis",ln=True,align="C")
    pdf.set_text_color(0,0,0); pdf.ln(5)

    # Patient info
    pdf.set_font("Helvetica","B",11)
    pdf.cell(0,7,f"Patient: {_safe(patient_name)}",ln=True)
    pdf.cell(0,7,f"Date: {datetime.date.today().strftime('%d-%b-%Y')}",ln=True)
    pdf.cell(0,7,f"Reports Analyzed: {len(results)}",ln=True)
    y = pdf.get_y(); pdf.line(10,y+2,200,y+2); pdf.ln(6)

    # Each report summary
    for i, res in enumerate(results):
        if res.get("error"): continue
        pdf.set_font("Helvetica","B",11)
        rt = res.get("report_type", f"Report {i+1}")
        pdf.set_fill_color(230,240,255)
        pdf.cell(0,7,_safe(f"  {rt}  |  {res.get('lab_name','')}  |  {res.get('report_date','')}"),
                 ln=True, fill=True)
        pdf.set_font("Helvetica","",10)

        tests = res.get("tests",[])
        if tests:
            # Table header
            pdf.set_font("Helvetica","B",9)
            pdf.cell(65,6,"Test",border=1)
            pdf.cell(30,6,"Value",border=1)
            pdf.cell(35,6,"Reference",border=1)
            pdf.cell(55,6,"Status",border=1,ln=True)
            pdf.set_font("Helvetica","",9)
            for t in tests:
                flag = t.get("flag","")
                if flag in ["HIGH","CRITICAL"]:
                    pdf.set_text_color(180,0,0)
                elif flag == "LOW":
                    pdf.set_text_color(0,0,180)
                else:
                    pdf.set_text_color(0,120,0)
                val_str = f"{t.get('value','')} {t.get('unit','')}"
                flag_str = f"{flag} — {t.get('clinical_note','')}"
                pdf.cell(65,6,_safe(t.get("name","")),border=1)
                pdf.cell(30,6,_safe(val_str),border=1)
                pdf.cell(35,6,_safe(t.get("reference","")),border=1)
                pdf.cell(55,6,_safe(flag_str[:40]),border=1,ln=True)
            pdf.set_text_color(0,0,0)

        # Critical flags
        critical = res.get("critical_flags",[])
        if critical:
            pdf.set_font("Helvetica","B",10); pdf.set_text_color(180,0,0)
            pdf.cell(0,7,_safe("🚨 CRITICAL: " + ", ".join(critical)),ln=True)
            pdf.set_text_color(0,0,0)
        pdf.ln(3)

    # Interpretation
    y2 = pdf.get_y(); pdf.line(10,y2,200,y2); pdf.ln(4)
    pdf.set_font("Helvetica","B",12)
    pdf.cell(0,8,"CLINICAL INTERPRETATION (For Doctor's Reference)",ln=True)
    pdf.set_font("Helvetica","",10)
    clean = interpretation.replace("**","").replace("* ","- ")
    clean = _safe(clean)
    pdf.multi_cell(0,6,clean)

    return pdf.output(dest="S").encode("latin-1")

# ══════════════════════════════════════════════════════════════════
# 3. MAIN UI
# ══════════════════════════════════════════════════════════════════
def run_lab_scanner(
    groq_key: str = "",
    clinic_name: str = "Bharat AI Clinic",
    doc_name: str = "Doctor",
    show_header: bool = True
):
    """
    Main function — call this from main app OR run standalone.
    groq_key: pass from main app if available
    """
    # Set API key if passed
    if groq_key:
        st.session_state["groq_key"] = groq_key

    if show_header:
        st.markdown("""
        <div style='background:linear-gradient(135deg,#1565C0,#0D47A1);
                    padding:18px;border-radius:10px;margin-bottom:16px'>
          <h2 style='color:white;margin:0;text-align:center'>
            🔬 Lab Report Batch Scanner
          </h2>
          <p style='color:#B3E5FC;margin:4px 0 0;text-align:center;font-size:14px'>
            Upload 1–30 reports • AI reads each one • Complete clinical interpretation
          </p>
        </div>
        """, unsafe_allow_html=True)

    # ── PATIENT INFO ─────────────────────────────────────────────
    with st.expander("👤 Patient Info (optional but recommended)", expanded=True):
        pc1, pc2, pc3 = st.columns(3)
        pt_name    = pc1.text_input("Patient Name", key="lab_pt_name",
                                    placeholder="Ramesh Kumar")
        pt_history = pc2.text_input("Known Conditions", key="lab_pt_hist",
                                    placeholder="DM, HTN, CKD...")
        pt_phone   = pc3.text_input("Phone (for WhatsApp)", key="lab_pt_ph",
                                    placeholder="9876543210")

    # ── UPLOAD ZONE ───────────────────────────────────────────────
    st.markdown("### 📤 Upload Lab Reports")
    st.caption("JPG, PNG — multiple files ek saath select kar sakte hain (phone mein long press + select all)")

    up_files = st.file_uploader(
        "Lab report photos upload karein",
        type=["jpg","jpeg","png","webp"],
        accept_multiple_files=True,
        key="lab_batch_files",
        label_visibility="collapsed"
    )
    cam_file = st.camera_input("Ya direct camera se lein", key="lab_cam")

    all_files = list(up_files) if up_files else []
    if cam_file:
        all_files.insert(0, cam_file)

    if not all_files:
        st.info("☝️ Reports upload karo — phir AI automatically ek ek karke padh lega")
        return

    # Show thumbnails
    st.success(f"✅ **{len(all_files)} report(s)** selected")
    thumb_cols = st.columns(min(6, len(all_files)))
    for ti, tf in enumerate(all_files[:6]):
        try:
            thumb_cols[ti].image(Image.open(tf),
                caption=f"#{ti+1}", use_container_width=True)
        except:
            thumb_cols[ti].caption(f"#{ti+1} ⚠️")
    if len(all_files) > 6:
        st.caption(f"...aur {len(all_files)-6} reports hain")

    # ── PROCESS BUTTON ────────────────────────────────────────────
    st.markdown("---")
    col_btn1, col_btn2 = st.columns(2)
    with col_btn1:
        go_btn = st.button(
            f"🚀 Process All {len(all_files)} Reports",
            type="primary", use_container_width=True,
            key="lab_process_btn"
        )
    with col_btn2:
        if st.session_state.get("lab_results"):
            st.info(f"✅ Previous results ready — scroll down")

    if go_btn:
        if not _get_key():
            st.error("❌ Groq API Key nahi hai. Admin PIN se login karke set karein.")
            return

        # Reset results
        st.session_state["lab_results"] = []
        st.session_state["lab_interp"]  = ""

        prog_bar  = st.progress(0, text="Starting...")
        stat_box  = st.empty()
        total     = len(all_files)

        import time
        all_results = []

        for i, f in enumerate(all_files):
            prog_val = (i) / total
            prog_bar.progress(prog_val,
                text=f"🔬 Reading report {i+1} of {total}... please wait")
            stat_box.info(f"📄 Processing: **{getattr(f,'name', f'Report #{i+1}')}**")

            try:
                img = Image.open(f)
                result = analyze_lab_image(img, pt_name, pt_history)
                result["_file_name"] = getattr(f, "name", f"Report_{i+1}")
                result["_index"] = i + 1
                all_results.append(result)
            except Exception as e:
                all_results.append({
                    "_file_name": getattr(f,"name",f"Report_{i+1}"),
                    "_index": i+1,
                    "error": str(e)
                })

            # Brief pause to avoid Groq rate limit
            if (i+1) % 4 == 0 and (i+1) < total:
                time.sleep(1.5)

        prog_bar.progress(1.0, text="✅ All reports processed!")
        stat_box.success(f"✅ {len([r for r in all_results if not r.get('error')])} reports successfully read!")

        st.session_state["lab_results"] = all_results

        # Now generate clinical interpretation
        with st.spinner("🧠 AI clinical interpretation generate kar raha hai..."):
            interp = generate_clinical_interpretation(all_results, pt_name, pt_history)
            st.session_state["lab_interp"] = interp

        st.rerun()

    # ── RESULTS ───────────────────────────────────────────────────
    if not st.session_state.get("lab_results"):
        return

    results   = st.session_state["lab_results"]
    interp    = st.session_state.get("lab_interp","")
    good_res  = [r for r in results if not r.get("error")]
    err_res   = [r for r in results if r.get("error")]

    st.markdown("---")
    st.markdown(f"## 📊 Results — {len(good_res)} Reports Analyzed")

    if err_res:
        with st.expander(f"⚠️ {len(err_res)} report(s) could not be read"):
            for r in err_res:
                st.write(f"• {r['_file_name']}: {r['error']}")

    # ── INDIVIDUAL REPORT CARDS ──────────────────────────────────
    for res in good_res:
        tests    = res.get("tests", [])
        critical = res.get("critical_flags", [])
        abnormal = [t for t in tests if t.get("flag","") not in ["NORMAL",""]]
        normal   = [t for t in tests if t.get("flag","") == "NORMAL"]
        rt       = res.get("report_type", f"Report #{res['_index']}")

        # Card color based on criticality
        border_color = "#c0392b" if critical else ("#e67e22" if abnormal else "#27ae60")

        with st.expander(
            f"{'🚨' if critical else '⚠️' if abnormal else '✅'} "
            f"**{rt}** | {res.get('lab_name','')} | {res.get('report_date','')} "
            f"| {len(abnormal)} abnormal / {len(normal)} normal",
            expanded=bool(critical)
        ):
            if critical:
                st.error(f"🚨 **CRITICAL VALUES:** {', '.join(critical)}")

            # Tests table
            if tests:
                col_heads = st.columns([3,1.5,2,2])
                col_heads[0].markdown("**Test**")
                col_heads[1].markdown("**Value**")
                col_heads[2].markdown("**Reference**")
                col_heads[3].markdown("**Status**")
                st.markdown("<hr style='margin:2px 0'>", unsafe_allow_html=True)

                for t in tests:
                    flag = t.get("flag","")
                    emoji = "🚨" if flag=="CRITICAL" else "⬆️" if flag=="HIGH" else "⬇️" if flag=="LOW" else "✅"
                    color = "#c0392b" if flag in ["CRITICAL","HIGH"] else "#2980b9" if flag=="LOW" else "#27ae60"
                    tc = st.columns([3,1.5,2,2])
                    tc[0].write(t.get("name",""))
                    tc[1].markdown(f"<span style='color:{color};font-weight:bold'>"
                                   f"{t.get('value','')} {t.get('unit','')}</span>",
                                   unsafe_allow_html=True)
                    tc[2].write(t.get("reference",""))
                    tc[3].markdown(f"{emoji} **{flag}** — {t.get('clinical_note','')[:35]}",
                                   unsafe_allow_html=True)

            if res.get("abnormal_summary"):
                st.info(f"📋 **Summary:** {res['abnormal_summary']}")

    # ── CLINICAL INTERPRETATION ───────────────────────────────────
    if interp:
        st.markdown("---")
        st.markdown("## 🩺 Clinical Interpretation *(Doctor's Reference)*")
        st.markdown("""
        <div style='background:#FFF3E0;padding:10px;border-radius:6px;
                    border-left:4px solid #E65100;margin-bottom:8px'>
        <small>⚕️ For treating doctor only — not for direct sharing with patient</small>
        </div>""", unsafe_allow_html=True)
        st.markdown(interp)

        # Regenerate button
        if st.button("🔄 Regenerate Interpretation", key="lab_regen"):
            with st.spinner("Regenerating..."):
                new_interp = generate_clinical_interpretation(
                    good_res, pt_name, pt_history)
                st.session_state["lab_interp"] = new_interp
                st.rerun()

    # ── ACTIONS ───────────────────────────────────────────────────
    st.markdown("---")
    st.markdown("### 📥 Download & Share")

    ac1, ac2, ac3 = st.columns(3)

    with ac1:
        # Download PDF
        if good_res and interp:
            pdf_bytes = create_lab_pdf(
                pt_name or "Patient",
                good_res, interp,
                clinic_name, doc_name
            )
            st.download_button(
                "📄 Download Full Report PDF",
                data=pdf_bytes,
                file_name=f"{(pt_name or 'Patient').replace(' ','_')}_LabReport_{datetime.date.today()}.pdf",
                mime="application/pdf",
                use_container_width=True,
                key="lab_pdf_dl"
            )

    with ac2:
        # WhatsApp share — simplified summary
        if pt_phone and interp:
            # Create short WhatsApp message
            abnormal_all = []
            for r in good_res:
                for t in r.get("tests",[]):
                    if t.get("flag","") not in ["NORMAL",""]:
                        abnormal_all.append(
                            f"{t['name']}: {t['value']} {t.get('unit','')} ({t['flag']})")
            wa_lines = [f"Namaste, {pt_name or 'Patient'}", "",
                        "📋 Your Lab Report Summary:", ""]
            for rt_item in good_res:
                rt_name = rt_item.get("report_type","Report")
                critical = rt_item.get("critical_flags",[])
                if critical:
                    wa_lines.append(f"🚨 {rt_name}: Critical — {', '.join(critical)}")
            if abnormal_all:
                wa_lines.append("\nAbnormal values found:")
                for a in abnormal_all[:8]:
                    wa_lines.append(f"• {a}")
            wa_lines += ["","For complete report and advice, please visit the clinic."]
            wa_msg = urllib.parse.quote("\n".join(wa_lines))
            st.link_button(
                "💬 Send WhatsApp Summary",
                f"https://wa.me/91{pt_phone}?text={wa_msg}",
                use_container_width=True
            )
        else:
            st.caption("Phone number dalo WhatsApp ke liye")

    with ac3:
        # Clear and start fresh
        if st.button("🗑️ Clear — New Patient", use_container_width=True, key="lab_clear"):
            for k in ["lab_results","lab_interp","lab_pt_name",
                      "lab_pt_hist","lab_pt_ph"]:
                st.session_state.pop(k, None)
            st.rerun()

    # ── ADD TO MAIN APP (if patient already in OPD) ───────────────
    st.markdown("---")
    st.markdown("### ➕ Add This Report to OPD Record")
    st.caption("Agar yeh patient aaj ki OPD mein hai to lab findings directly Rx mein add ho jaayengi")

    if good_res and interp:
        add_col1, add_col2 = st.columns(2)
        with add_col1:
            # Build compact lab summary text for OPD notes
            lab_note_lines = [f"LAB REPORTS — {datetime.date.today().strftime('%d-%b-%Y')}"]
            for r in good_res:
                rt_name = r.get("report_type","Report")
                abn = [t for t in r.get("tests",[]) if t.get("flag","") not in ["NORMAL",""]]
                if abn:
                    lab_note_lines.append(f"\n{rt_name} — ABNORMAL:")
                    for t in abn:
                        lab_note_lines.append(
                            f"  • {t['name']}: {t['value']} {t.get('unit','')} [{t['flag']}]"
                        )
            lab_note_text = "\n".join(lab_note_lines)

            st.text_area("Lab Summary for OPD Notes:",
                          value=lab_note_text, height=150, key="lab_opd_note")
            if st.button("📋 Copy to New Rx Notes",
                          use_container_width=True, key="lab_copy_opd"):
                # Set override so main app picks it up
                existing = st.session_state.get("_note_override",
                               st.session_state.get("notes_main",""))
                st.session_state["_note_override"] = existing + "\n\n" + lab_note_text
                st.session_state["lab_pt_name_for_rx"] = pt_name
                st.success("✅ Copied! 📝 New Rx tab mein jayen — notes mein lab summary add ho gayi.")

        with add_col2:
            st.markdown("**AI Differential Diagnosis from Labs:**")
            # Extract differential from interpretation
            diff_match = re.search(
                r'DIFFERENTIAL DIAGNOSIS.*?\n(.*?)(?:\n\*\*|\Z)',
                interp, re.DOTALL | re.IGNORECASE)
            if diff_match:
                st.info(diff_match.group(1).strip()[:500])
            else:
                st.caption("Differential diagnosis interpretation mein dekhen")


# ══════════════════════════════════════════════════════════════════
# 4. STANDALONE ENTRY POINT
# ══════════════════════════════════════════════════════════════════
if __name__ == "__main__" or "streamlit" in str(type(st)):
    # Standalone mode: show API key input if not set
    if not _get_key():
        st.warning("⚠️ API Key nahi mila. Neeche enter karein:")
        ak = st.text_input("Groq API Key (gsk_...)", type="password", key="standalone_key")
        if ak: st.session_state["groq_key"] = ak; st.rerun()
    else:
        run_lab_scanner(show_header=True)
