import streamlit as st
from PIL import Image
import os, requests, datetime, re, base64, io, json, sqlite3, pathlib, urllib.parse
from datetime import timedelta
from fpdf import FPDF

try:
    import fitz
    HAS_FITZ = True
except ImportError:
    HAS_FITZ = False

# ══════════════════════════════════════════════════════════════
# 1. APP CONFIG
# ══════════════════════════════════════════════════════════════
st.set_page_config(page_title="Bharat AI Clinic", page_icon="🩺", layout="wide")

CHIEF_PIN  = "5554"
JUNIOR_PIN = "1234"
ADMIN_PIN  = "1010"

# ══════════════════════════════════════════════════════════════
# 2. SUPABASE PERMANENT DATABASE
# Setup: Go to supabase.com → New project → Settings → API
# Add SUPABASE_URL and SUPABASE_KEY to Streamlit secrets
# ══════════════════════════════════════════════════════════════
def _get_supa_creds():
    try:
        url = st.secrets["SUPABASE_URL"]
        key = st.secrets["SUPABASE_KEY"]
        return url, key
    except:
        return None, None

def _supa_headers():
    _, key = _get_supa_creds()
    if not key: return None
    return {
        "apikey": key,
        "Authorization": f"Bearer {key}",
        "Content-Type": "application/json",
        "Prefer": "return=minimal"
    }

def _supa_available():
    url, key = _get_supa_creds()
    return bool(url and key and len(key) > 10)

def supa_auto_create_tables():
    """
    Auto-create all required tables using Supabase REST API.
    Uses the /rpc/exec_sql endpoint OR direct table creation via INSERT trick.
    Called once on startup.
    """
    if not _supa_available(): return
    if st.session_state.get("tables_created"): return
    url, key = _get_supa_creds()
    # Use Supabase SQL via REST RPC
    sql = """
CREATE TABLE IF NOT EXISTS patients (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  date TEXT, patient_name TEXT, phone TEXT,
  vitals TEXT, fee TEXT DEFAULT '0',
  complaints TEXT, medicines TEXT,
  investigations TEXT DEFAULT '',
  specialty TEXT DEFAULT 'General Physician'
);
CREATE TABLE IF NOT EXISTS drug_history (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  drug_name TEXT, dose TEXT,
  use_count INTEGER DEFAULT 1, last_used TEXT
);
CREATE TABLE IF NOT EXISTS specialty_upgrades (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  date TEXT, patient_name TEXT, vitals TEXT,
  original_rx TEXT, specialty TEXT,
  upgraded_rx TEXT, evidence TEXT,
  is_starred INTEGER DEFAULT 0, star_note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS templates (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  category TEXT, name TEXT, content TEXT,
  UNIQUE(doctor_id, name)
);
CREATE TABLE IF NOT EXISTS licenses (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT UNIQUE NOT NULL,
  doctor_name TEXT, doctor_email TEXT, doctor_phone TEXT,
  pin TEXT UNIQUE NOT NULL, clinic_name TEXT, specialty TEXT,
  expiry_date TEXT, is_active INTEGER DEFAULT 1,
  created_date TEXT, notes TEXT DEFAULT ''
);
ALTER TABLE patients DISABLE ROW LEVEL SECURITY;
ALTER TABLE drug_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE specialty_upgrades DISABLE ROW LEVEL SECURITY;
ALTER TABLE templates DISABLE ROW LEVEL SECURITY;
ALTER TABLE licenses DISABLE ROW LEVEL SECURITY;
"""
    try:
        r = requests.post(
            f"{url}/rest/v1/rpc/exec_sql",
            headers={
                "apikey": key,
                "Authorization": f"Bearer {key}",
                "Content-Type": "application/json"
            },
            json={"sql": sql},
            timeout=15
        )
        if r.status_code in [200, 201, 204]:
            st.session_state["tables_created"] = True
            return
    except: pass
    # Fallback: try pg_meta endpoint (Supabase Management API)
    try:
        statements = [s.strip() for s in sql.split(";") if s.strip()]
        for stmt in statements:
            requests.post(
                f"{url}/rest/v1/rpc/exec_sql",
                headers={"apikey": key, "Authorization": f"Bearer {key}",
                         "Content-Type": "application/json"},
                json={"query": stmt},
                timeout=10
            )
        st.session_state["tables_created"] = True
    except: pass

def supa_insert(table, data):
    """Insert/upsert a row into Supabase. Returns (True, 'ok') or (False, error_msg)."""
    if not _supa_available(): return False, "no_creds"
    url, _ = _get_supa_creds()
    try:
        r = requests.post(
            f"{url}/rest/v1/{table}",
            headers={**_supa_headers(), "Prefer": "return=minimal"},
            json=data, timeout=10)
        if r.status_code in [200, 201]: return True, "ok"
        # Log exact error
        err = f"HTTP_{r.status_code}: {r.text[:300]}"
        return False, err
    except Exception as e:
        return False, str(e)

def supa_select(table, filters=None, order="id.desc", limit=500):
    """Select rows from Supabase table — correct PostgREST filter format"""
    if not _supa_available(): return []
    url, _ = _get_supa_creds()
    hdrs = {**_supa_headers(), "Prefer": "return=representation"}
    # Build URL manually to avoid requests double-encoding issues
    filter_parts = []
    if filters:
        for k, v in filters.items():
            filter_parts.append(f"{k}={v}")
    filter_str = "&".join(filter_parts)
    full_url = f"{url}/rest/v1/{table}?order={order}&limit={limit}"
    if filter_str:
        full_url += f"&{filter_str}"
    try:
        r = requests.get(full_url, headers=hdrs, timeout=10)
        if r.status_code == 200:
            data = r.json()
            return data if isinstance(data, list) else []
        return []
    except:
        return []

def supa_verify_and_save(data_dict):
    """
    Smart save to Supabase — if table missing, show setup instructions once.
    Returns 'ok', 'no_table', 'no_creds', 'error'
    """
    if not _supa_available(): return 'no_creds'
    url, _ = _get_supa_creds()
    try:
        r = requests.post(
            f"{url}/rest/v1/patients",
            headers={**_supa_headers(), "Prefer": "return=minimal"},
            json=data_dict, timeout=10)
        if r.status_code in [200, 201]: return 'ok'
        if r.status_code == 404: return 'no_table'
        if r.status_code == 401: return 'bad_key'
        return f'error_{r.status_code}'
    except Exception as e:
        return f'exception'
    """Update row(s) in Supabase"""
    if not _supa_available(): return False
    url, _ = _get_supa_creds()
    try:
        r = requests.patch(f"{url}/rest/v1/{table}?{match_col}=eq.{match_val}",
                           headers=_supa_headers(), json=data, timeout=8)
        return r.status_code in [200, 204]
    except: return False

def supa_init_tables():
    """Create tables in Supabase via SQL RPC (run once)"""
    if not _supa_available(): return
    url, _ = _get_supa_creds()
    sql = """
    CREATE TABLE IF NOT EXISTS patients (
        id BIGSERIAL PRIMARY KEY,
        doctor_id TEXT NOT NULL DEFAULT 'chief',
        date TEXT, patient_name TEXT, phone TEXT,
        vitals TEXT, fee TEXT DEFAULT '0',
        complaints TEXT, medicines TEXT,
        investigations TEXT DEFAULT '',
        specialty TEXT DEFAULT 'General Physician'
    );
    CREATE TABLE IF NOT EXISTS drug_history (
        id BIGSERIAL PRIMARY KEY,
        doctor_id TEXT NOT NULL,
        drug_name TEXT, dose TEXT,
        use_count INTEGER DEFAULT 1, last_used TEXT
    );
    CREATE TABLE IF NOT EXISTS specialty_upgrades (
        id BIGSERIAL PRIMARY KEY,
        doctor_id TEXT NOT NULL DEFAULT 'chief',
        date TEXT, patient_name TEXT, vitals TEXT,
        original_rx TEXT, specialty TEXT,
        upgraded_rx TEXT, evidence TEXT,
        is_starred INTEGER DEFAULT 0, star_note TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS templates (
        id BIGSERIAL PRIMARY KEY,
        doctor_id TEXT NOT NULL DEFAULT 'chief',
        category TEXT, name TEXT, content TEXT,
        UNIQUE(doctor_id, name)
    );
    CREATE TABLE IF NOT EXISTS licenses (
        id BIGSERIAL PRIMARY KEY,
        doctor_id TEXT UNIQUE NOT NULL,
        doctor_name TEXT, doctor_email TEXT, doctor_phone TEXT,
        pin TEXT UNIQUE NOT NULL,
        clinic_name TEXT, specialty TEXT,
        expiry_date TEXT, is_active INTEGER DEFAULT 1,
        created_date TEXT, notes TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS settings (
        doctor_id TEXT PRIMARY KEY,
        clinic_name TEXT DEFAULT 'My Clinic',
        doc_name TEXT DEFAULT 'Doctor',
        doc_subtitle TEXT DEFAULT 'MBBS'
    );
    """
    try:
        requests.post(f"{url}/rest/v1/rpc/exec_sql",
                      headers=_supa_headers(), json={"sql": sql}, timeout=10)
    except: pass

# ══════════════════════════════════════════════════════════════
# 2B. SQLITE LOCAL CACHE (fast reads, fallback if Supabase down)
# ══════════════════════════════════════════════════════════════
DB_PATH = pathlib.Path("/tmp/gill_opd_cache.db")

def _conn():
    return sqlite3.connect(str(DB_PATH), check_same_thread=False)

def init_db():
    c = _conn()
    c.executescript("""
    CREATE TABLE IF NOT EXISTS patients (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT    NOT NULL DEFAULT 'chief',
        date         TEXT,
        patient_name TEXT,
        phone        TEXT,
        vitals       TEXT,
        fee          TEXT    DEFAULT '0',
        complaints   TEXT,
        medicines    TEXT,
        investigations TEXT  DEFAULT '',
        specialty    TEXT    DEFAULT 'General Physician'
    );
    CREATE TABLE IF NOT EXISTS drug_history (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT NOT NULL,
        drug_name    TEXT,
        dose         TEXT,
        use_count    INTEGER DEFAULT 1,
        last_used    TEXT
    );
    CREATE TABLE IF NOT EXISTS specialty_upgrades (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT NOT NULL DEFAULT 'chief',
        date         TEXT,
        patient_name TEXT,
        vitals       TEXT,
        original_rx  TEXT,
        specialty    TEXT,
        upgraded_rx  TEXT,
        evidence     TEXT,
        is_starred   INTEGER DEFAULT 0,
        star_note    TEXT    DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS templates (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT NOT NULL DEFAULT 'chief',
        category     TEXT,
        name         TEXT,
        content      TEXT,
        UNIQUE(doctor_id, name)
    );
    CREATE TABLE IF NOT EXISTS licenses (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT UNIQUE NOT NULL,
        doctor_name  TEXT,
        doctor_email TEXT,
        doctor_phone TEXT,
        pin          TEXT UNIQUE NOT NULL,
        clinic_name  TEXT,
        specialty    TEXT,
        expiry_date  TEXT,
        is_active    INTEGER DEFAULT 1,
        created_date TEXT,
        notes        TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS settings (
        doctor_id    TEXT PRIMARY KEY,
        clinic_name  TEXT DEFAULT 'My Clinic',
        doc_name     TEXT DEFAULT 'Doctor',
        doc_subtitle TEXT DEFAULT 'MBBS',
        doc_degree   TEXT DEFAULT '',
        doc_reg_no   TEXT DEFAULT '',
        doc_email    TEXT DEFAULT '',
        doc_phone    TEXT DEFAULT '',
        clinic_address TEXT DEFAULT '',
        doc_extra_quals TEXT DEFAULT ''
    );
    CREATE TABLE IF NOT EXISTS pending_scans (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        doctor_id    TEXT NOT NULL DEFAULT 'chief',
        uploaded_at  TEXT,
        image_b64    TEXT,
        patient_name TEXT DEFAULT '',
        phone        TEXT DEFAULT '',
        vitals       TEXT DEFAULT '',
        fee          TEXT DEFAULT '0',
        complaints   TEXT DEFAULT '',
        medicines    TEXT DEFAULT '',
        investigations TEXT DEFAULT '',
        status       TEXT DEFAULT 'pending'
    );
    """)
    c.commit(); c.close()

init_db()

# ── On startup: sync from Supabase → local SQLite (fills cache) ──
def sync_from_supabase():
    """Pull ALL patient data from Supabase into local SQLite on every login"""
    if not _supa_available(): return
    if st.session_state.get("supa_synced"): return
    did = st.session_state.get("doctor_id", "chief")
    try:
        # ── SETTINGS (highest priority — must load before anything else) ──
        if "_sett_cache" not in st.session_state:
            sett_rows = supa_select("settings",
                                    filters={"doctor_id": f"eq.{did}"}, limit=1)
            if sett_rows:
                r = sett_rows[0]
                sett = {
                    "clinic_name":    r.get("clinic_name",""),
                    "doc_name":       r.get("doc_name",""),
                    "doc_subtitle":   r.get("doc_subtitle",""),
                    "doc_degree":     r.get("doc_degree",""),
                    "doc_reg_no":     r.get("doc_reg_no",""),
                    "doc_email":      r.get("doc_email",""),
                    "doc_phone":      r.get("doc_phone",""),
                    "clinic_address": r.get("clinic_address",""),
                    "doc_extra_quals":r.get("doc_extra_quals","")
                }
                # Only cache if meaningful data exists
                if sett.get("clinic_name") or sett.get("doc_name"):
                    st.session_state["_sett_cache"] = sett
                    # Also save to SQLite
                    c = _conn()
                    c.execute("INSERT OR REPLACE INTO settings (doctor_id,clinic_name,doc_name,doc_subtitle,doc_degree,doc_reg_no,doc_email,doc_phone,clinic_address,doc_extra_quals) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (did, sett["clinic_name"], sett["doc_name"], sett["doc_subtitle"],
                         sett["doc_degree"], sett["doc_reg_no"], sett["doc_email"],
                         sett["doc_phone"], sett["clinic_address"], sett["doc_extra_quals"]))
                    c.commit(); c.close()

        # ── PATIENTS ──────────────────────────────────────────────
        rows = supa_select("patients",
                           filters={"doctor_id": f"eq.{did}"},
                           order="id.desc", limit=1000)
        if rows:
            c = _conn()
            inserted = 0
            for row in rows:
                nm = row.get("patient_name","")
                dt = row.get("date","")
                if not nm: continue
                ex = c.execute(
                    "SELECT id FROM patients WHERE doctor_id=? AND patient_name=? AND date=?",
                    (did, nm, dt)).fetchone()
                if not ex:
                    c.execute(
                        "INSERT INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (did, dt, nm,
                         row.get("phone",""), row.get("vitals",""),
                         row.get("fee","0"), row.get("complaints",""),
                         row.get("medicines",""), row.get("investigations",""),
                         row.get("specialty","GP")))
                    inserted += 1
            c.commit(); c.close()
            if inserted > 0:
                st.session_state["supa_sync_msg"] = f"✅ {inserted} patients synced from cloud"

        # ── LICENSES ──────────────────────────────────────────────
        lic_rows = supa_select("licenses", {}, limit=200)
        if lic_rows:
            c = _conn()
            for row in lic_rows:
                c.execute(
                    "INSERT OR REPLACE INTO licenses (doctor_id,doctor_name,doctor_email,doctor_phone,pin,clinic_name,specialty,expiry_date,is_active,created_date,notes) VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                    (row.get("doctor_id",""), row.get("doctor_name",""),
                     row.get("doctor_email",""), row.get("doctor_phone",""),
                     row.get("pin",""), row.get("clinic_name",""),
                     row.get("specialty",""), row.get("expiry_date",""),
                     row.get("is_active",1), row.get("created_date",""),
                     row.get("notes","")))
            c.commit(); c.close()

        # ── TEMPLATES ─────────────────────────────────────────────
        tmpl_rows = supa_select("templates",
                                filters={"doctor_id": f"eq.{did}"}, limit=100)
        if tmpl_rows:
            c = _conn()
            for row in tmpl_rows:
                c.execute(
                    "INSERT OR REPLACE INTO templates (doctor_id,category,name,content) VALUES (?,?,?,?)",
                    (did, row.get("category",""), row.get("name",""), row.get("content","")))
            c.commit(); c.close()

        st.session_state["supa_synced"] = True
    except Exception as e:
        st.session_state["supa_sync_error"] = str(e)

# ⚠️ /tmp/ data warning
def _show_db_warning():
    if st.session_state.get("db_warn_shown"): return
    c=_conn(); count=c.execute("SELECT COUNT(*) FROM patients").fetchone()[0]; c.close()
    if count==0 and not _supa_available():
        st.session_state["db_warn_shown"]=True
        st.warning("⚠️ **Permanent DB not configured.** Data will reset on server restart. Setup: Admin panel → 'Supabase Setup' tab.")
    elif count==0 and _supa_available():
        st.session_state["db_warn_shown"]=True
        st.info("ℹ️ Syncing data from cloud... If old patients missing, check OPD Roster.")
def _clean_fee(f):
    n = re.findall(r'\d+', str(f))
    return int(n[0]) if n else 0

def _did():
    """Current doctor's unique ID"""
    return st.session_state.get("doctor_id", "chief")

# ── patients ───────────────────────────────────────────────────
def db_save_patient(name, phone, vitals, fee, complaints, medicines, investigations="", specialty="General Physician"):
    did = _did()
    date_str = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    name = str(name).strip(); phone = str(phone).strip()

    # ══ LAYER 1: SQLite local (ALWAYS — instant, primary) ═════════
    sqlite_ok = False
    try:
        c = _conn()
        c.execute(
            "INSERT INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
            (did, date_str, name, phone, str(vitals), str(fee), str(complaints), str(medicines), str(investigations), specialty))
        c.commit(); c.close()
        sqlite_ok = True
    except Exception as e:
        sqlite_ok = False

    # ══ LAYER 2: Supabase (permanent cloud) ════════════════════
    supa_ok, supa_err = supa_insert("patients", {
        "doctor_id": did, "date": date_str, "patient_name": name,
        "phone": phone, "vitals": str(vitals), "fee": str(fee),
        "complaints": str(complaints), "medicines": str(medicines),
        "investigations": str(investigations), "specialty": specialty
    })
    if not supa_ok:
        # Store error so it shows in UI
        st.session_state["last_supa_err"] = supa_err
    supa_status = "ok" if supa_ok else supa_err

    # ══ LAYER 3: Google Sheet (backup — ensures data survives /tmp/ reset) ═
    sheet_ok = False
    if WEBHOOK_URL.startswith("http"):
        try:
            r = requests.post(WEBHOOK_URL, json={
                "patient_name": name, "phone": phone,
                "vitals": str(vitals), "fee": str(fee),
                "complaints": str(complaints), "diagnosis": "AI Generated",
                "medicines": str(medicines), "advice": "Included",
                "follow_up": "See Rx", "date": date_str,
                "doctor_id": did, "specialty": specialty
            }, timeout=5)
            sheet_ok = r.status_code == 200
        except: sheet_ok = False

    # Auto-learn drug names for autocomplete
    try: _learn_drugs(str(medicines), did)
    except: pass

    return {"sqlite": sqlite_ok, "supa": supa_status, "sheet": sheet_ok}

def _learn_drugs(rx_text, did):
    """Parse Rx text and store each drug in drug_history for autocomplete"""
    c = _conn()
    now = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    # match lines like: 1. Tab. Metformin 500mg - BD - After meals - 30 Days
    for line in rx_text.split('\n'):
        m = re.match(r'\d+\.\s*(Tab\.|Cap\.|Syp\.|Inj\.|Drop\.|Cream\.|Gel\.)?\s*([A-Za-z][A-Za-z0-9\s\-]+?)(?:\s+(\d+\s*(?:mg|mcg|ml|g|IU|units)))?(?:\s+-\s*(.+?))?(?:\s+-\s*(.+?))?(?:\s+-\s*(\d+\s*Days?))?$', line.strip(), re.IGNORECASE)
        if m:
            drug = (m.group(2) or "").strip()
            dose = (m.group(3) or "").strip()
            if drug and len(drug) > 2:
                existing = c.execute("SELECT id,use_count FROM drug_history WHERE doctor_id=? AND drug_name=? AND dose=?", (did, drug, dose)).fetchone()
                if existing:
                    c.execute("UPDATE drug_history SET use_count=use_count+1, last_used=? WHERE id=?", (now, existing[0]))
                else:
                    c.execute("INSERT INTO drug_history (doctor_id,drug_name,dose,last_used) VALUES (?,?,?,?)", (did, drug, dose, now))
    c.commit(); c.close()

def db_get_drug_suggestions(partial, did=None):
    """Return drug names matching partial text, sorted by frequency"""
    did = did or _did()
    c = _conn()
    rows = c.execute(
        "SELECT drug_name, dose FROM drug_history WHERE doctor_id=? AND drug_name LIKE ? ORDER BY use_count DESC LIMIT 8",
        (did, f"%{partial}%")
    ).fetchall()
    c.close()
    return [f"{r[0]} {r[1]}".strip() for r in rows]

def db_search_patients(q, include_sheet=True):
    """
    Search patients.
    include_sheet=True (default) = search SQLite + Supabase + Google Sheet (comprehensive)
    """
    did = _did()
    q = q.strip()
    if not q: return []

    # ── 1. SQLite local (always, instant) ──────────────────────
    c = _conn()
    rows = c.execute(
        "SELECT * FROM patients WHERE doctor_id=? AND (patient_name LIKE ? OR phone LIKE ?) ORDER BY id DESC LIMIT 50",
        (did, f"%{q}%", f"%{q}%")
    ).fetchall()
    c.close()
    cols = ["id","doctor_id","date","patient_name","phone","vitals","fee","complaints","medicines","investigations","specialty"]
    results = [dict(zip(cols, r)) for r in rows]
    seen_keys = {(r["patient_name"].lower(), r["date"][:10]) for r in results}

    # ── 2. Supabase cloud (if configured) ──────────────────────
    if _supa_available():
        try:
            supa_rows = supa_select("patients",
                {"doctor_id": f"eq.{did}", "patient_name": f"ilike.%{q}%"}, limit=20)
            if not supa_rows:
                supa_rows = supa_select("patients",
                    {"doctor_id": f"eq.{did}", "phone": f"ilike.%{q}%"}, limit=20)
            new_from_cloud = []
            for row in supa_rows:
                key = (str(row.get("patient_name","")).lower(), str(row.get("date",""))[:10])
                if key not in seen_keys:
                    pt = {"id":row.get("id",0),"doctor_id":did,"date":row.get("date",""),
                          "patient_name":row.get("patient_name",""),"phone":row.get("phone",""),
                          "vitals":row.get("vitals",""),"fee":row.get("fee","0"),
                          "complaints":row.get("complaints",""),"medicines":row.get("medicines",""),
                          "investigations":row.get("investigations",""),"specialty":row.get("specialty","GP")}
                    results.append(pt); new_from_cloud.append(pt); seen_keys.add(key)
            if new_from_cloud:
                c = _conn()
                for r in new_from_cloud:
                    c.execute("INSERT OR IGNORE INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
                        (did,r["date"],r["patient_name"],r["phone"],r["vitals"],r["fee"],r["complaints"],r["medicines"],r["investigations"],r["specialty"]))
                c.commit(); c.close()
        except: pass

    # ── 3. Google Sheet (only when explicitly requested — slow) ──
    if include_sheet and WEBHOOK_URL.startswith("http"):
        try:
            sheet_rows, _ = fetch_sheet_data()
            q_low = q.lower()
            for row in sheet_rows:
                if (q_low in row.get("patient_name","").lower() or q in row.get("phone","")):
                    key = (row.get("patient_name","").lower(), str(row.get("date",""))[:10])
                    if key not in seen_keys:
                        results.append({"id":0,"doctor_id":did,"date":row.get("date",""),
                            "patient_name":row.get("patient_name",""),"phone":row.get("phone",""),
                            "vitals":row.get("vitals",""),"fee":row.get("fee","0"),
                            "complaints":row.get("complaints",""),"medicines":row.get("medicines",""),
                            "investigations":"","specialty":"Google Sheet"})
                        seen_keys.add(key)
        except: pass

    return results

def db_get_patients_filter(date_filter):
    did = _did()
    # Step 1: Always try Supabase first (source of truth)
    if _supa_available():
        try:
            supa_rows = supa_select("patients",
                filters={"doctor_id": f"eq.{did}"},
                order="id.desc", limit=1000)
            if supa_rows:
                # Cache into SQLite for speed
                c = _conn()
                for row in supa_rows:
                    nm = row.get("patient_name","")
                    dt = row.get("date","")
                    if nm:
                        ex = c.execute(
                            "SELECT id FROM patients WHERE doctor_id=? AND patient_name=? AND date=?",
                            (did, nm, dt)).fetchone()
                        if not ex:
                            c.execute(
                                "INSERT INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
                                (did, dt, nm, row.get("phone",""), row.get("vitals",""),
                                 row.get("fee","0"), row.get("complaints",""),
                                 row.get("medicines",""), row.get("investigations",""),
                                 row.get("specialty","GP")))
                c.commit(); c.close()
        except: pass

    # Step 2: Read from SQLite (now populated from Supabase)
    c = _conn()
    rows = c.execute("SELECT * FROM patients WHERE doctor_id=? ORDER BY id DESC", (did,)).fetchall()
    c.close()
    cols = ["id","doctor_id","date","patient_name","phone","vitals","fee","complaints","medicines","investigations","specialty"]
    all_pts = [dict(zip(cols, r)) for r in rows]

    today = datetime.date.today()
    if date_filter == "All Time": return all_pts
    result = []
    for pt in all_pts:
        try:
            d = datetime.date.fromisoformat(str(pt["date"])[:10])
            if date_filter == "Today" and d == today: result.append(pt)
            elif date_filter == "Yesterday" and d == today - timedelta(days=1): result.append(pt)
            elif date_filter == "Last 5 Days" and 0 <= (today-d).days <= 5: result.append(pt)
        except: pass
    return result

def db_get_all_patients_admin(doctor_id):
    """Admin only — get all patients for a specific doctor"""
    c = _conn()
    rows = c.execute("SELECT * FROM patients WHERE doctor_id=? ORDER BY id DESC", (doctor_id,)).fetchall()
    c.close()
    cols = ["id","doctor_id","date","patient_name","phone","vitals","fee","complaints","medicines","investigations","specialty"]
    return [dict(zip(cols, r)) for r in rows]

# ── upgrades ───────────────────────────────────────────────────
def db_save_upgrade(pt_name, vitals, orig_rx, spec, upg_rx, evidence):
    did = _did()
    c = _conn()
    c.execute("INSERT INTO specialty_upgrades (doctor_id,date,patient_name,vitals,original_rx,specialty,upgraded_rx,evidence) VALUES (?,?,?,?,?,?,?,?)",
              (did, datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), pt_name, vitals, orig_rx, spec, upg_rx, evidence))
    rid = c.execute("SELECT last_insert_rowid()").fetchone()[0]
    c.commit(); c.close()
    return rid

def db_star_upgrade(uid, note=""):
    c = _conn(); c.execute("UPDATE specialty_upgrades SET is_starred=1,star_note=? WHERE id=?", (note, uid)); c.commit(); c.close()

def db_get_starred():
    did = _did()
    c = _conn()
    rows = c.execute("SELECT * FROM specialty_upgrades WHERE doctor_id=? AND is_starred=1 ORDER BY id DESC", (did,)).fetchall()
    c.close()
    cols = ["id","doctor_id","date","patient_name","vitals","original_rx","specialty","upgraded_rx","evidence","is_starred","star_note"]
    return [dict(zip(cols, r)) for r in rows]

# ── templates ──────────────────────────────────────────────────
def db_get_templates(cat):
    did = _did()
    c = _conn()
    rows = c.execute("SELECT name,content FROM templates WHERE doctor_id=? AND category=?", (did, cat)).fetchall()
    c.close()
    return dict(rows)

def db_save_template(cat, name, content):
    did = _did()
    c = _conn()
    c.execute("INSERT OR REPLACE INTO templates (doctor_id,category,name,content) VALUES (?,?,?,?)", (did, cat, name, content))
    c.commit(); c.close()

def db_delete_template(name):
    did = _did()
    c = _conn()
    c.execute("DELETE FROM templates WHERE doctor_id=? AND name=?", (did, name))
    c.commit(); c.close()

# ── ALL upgrades (for admin stats) ────────────────────────────
def db_get_all_upgrades():
    c = _conn()
    rows = c.execute("SELECT * FROM specialty_upgrades ORDER BY id DESC").fetchall()
    c.close()
    cols = ["id","doctor_id","date","patient_name","vitals","original_rx","specialty","upgraded_rx","evidence","is_starred","star_note"]
    return [dict(zip(cols, r)) for r in rows]

# ── Google Sheet config (kept for legacy data access) ──────────
WEBHOOK_URL = "https://script.google.com/macros/s/AKfycbyqbjDZvZEJF7_MRE7dkdp-2RmghWxHHZ3uRye32hqVAKl-GIsOaEDXJsqXbHExMvlt/exec"

def fetch_sheet_data():
    """
    Fetches ALL patient data from Google Sheet.
    Tries GET → POST → GET+param. Normalises all column name variations.
    Returns (list_of_dicts, error_string).
    """
    if not WEBHOOK_URL.startswith("http"):
        return [], "WEBHOOK_URL not set"
    raw = None; err = ""
    for attempt in [
        lambda: requests.get(WEBHOOK_URL, timeout=10),
        lambda: requests.post(WEBHOOK_URL, json={"action":"get_all"}, timeout=10),
        lambda: requests.get(WEBHOOK_URL+"?action=get_all", timeout=10),
    ]:
        try:
            r = attempt()
            if r.status_code == 200 and len(r.text) > 5:
                try:
                    parsed = r.json()
                    if isinstance(parsed, list): raw = parsed; break
                    for k in ["data","rows","patients","records","sheet"]:
                        if k in parsed and isinstance(parsed[k], list):
                            raw = parsed[k]; break
                    if raw: break
                except: pass
        except Exception as e: err = str(e)
    if not raw: return [], f"Could not fetch: {err}"

    FMAP = {
        "patient_name": ["patient_name","name","patient name","Patient Name","patientname"],
        "phone":        ["phone","mobile","phone_number","contact","mob","Phone"],
        "vitals":       ["vitals","vital","bp","vital_signs","Vitals"],
        "fee":          ["fee","fees","amount","charge","Fee"],
        "date":         ["date","datetime","Date","Date & Time","timestamp","created_at"],
        "complaints":   ["complaints","complaint","chief_complaint","symptoms","Complaints"],
        "medicines":    ["medicines","medicine","prescription","rx","medications","Medicines","Rx"],
    }
    def gf(row, field):
        for alias in FMAP.get(field, [field]):
            v = row.get(alias,"")
            if str(v).strip() not in ["","None","null"]: return str(v).strip()
        return ""

    results = []
    for row in raw:
        if not isinstance(row, dict): continue
        name = gf(row, "patient_name")
        if not name or name.lower() in ["patient_name","name","patient name","s.no","#"]: continue
        date_raw = gf(row, "date")
        if "Date & Tim" in date_raw: continue
        results.append({
            "date":          date_raw[:16] or "Unknown",
            "patient_name":  name,
            "phone":         gf(row,"phone"),
            "vitals":        gf(row,"vitals"),
            "fee":           gf(row,"fee") or "0",
            "complaints":    gf(row,"complaints"),
            "medicines":     gf(row,"medicines"),
            "specialty":     "Google Sheet",
            "_source":       "sheet",
        })
    return results, ""

# ── licenses ───────────────────────────────────────────────────
def check_pin(pin):
    pin = pin.strip()
    if pin == CHIEF_PIN:  return "chief",  None
    if pin == JUNIOR_PIN: return "junior", None
    if pin == ADMIN_PIN:  return "admin",  None
    c = _conn()
    row = c.execute("SELECT * FROM licenses WHERE pin=? AND is_active=1", (pin,)).fetchone()
    c.close()
    if row:
        cols = ["id","doctor_id","doctor_name","doctor_email","doctor_phone","pin","clinic_name","specialty","expiry_date","is_active","created_date","notes"]
        lic = dict(zip(cols, row))
        expiry = datetime.date.fromisoformat(str(lic["expiry_date"])[:10])
        if expiry >= datetime.date.today():
            return "licensed", lic
        return "expired", lic
    return None, None

def db_get_all_licenses():
    c = _conn()
    rows = c.execute("SELECT * FROM licenses ORDER BY id DESC").fetchall()
    c.close()
    cols = ["id","doctor_id","doctor_name","doctor_email","doctor_phone","pin","clinic_name","specialty","expiry_date","is_active","created_date","notes"]
    return [dict(zip(cols, r)) for r in rows]

def db_create_license(did, name, email, phone, pin, clinic, spec, expiry, notes=""):
    c = _conn()
    try:
        c.execute("INSERT INTO licenses (doctor_id,doctor_name,doctor_email,doctor_phone,pin,clinic_name,specialty,expiry_date,created_date,notes) VALUES (?,?,?,?,?,?,?,?,?,?)",
                  (did, name, email, phone, pin, clinic, spec, str(expiry), str(datetime.date.today()), notes))
        # init settings for this doctor
        c.execute("INSERT OR IGNORE INTO settings (doctor_id,clinic_name,doc_name,doc_subtitle) VALUES (?,?,?,?)",
                  (did, clinic, name, spec))
        c.commit(); c.close()
        return True
    except: c.close(); return False

def db_delete_license(lid):
    c = _conn(); c.execute("DELETE FROM licenses WHERE id=?", (lid,)); c.commit(); c.close()

# ── settings ───────────────────────────────────────────────────
def db_get_settings():
    did = _did()
    # 1. Session cache (fastest — set when Save is clicked)
    if "_sett_cache" in st.session_state:
        return st.session_state["_sett_cache"]
    # 2. SQLite (add new columns if old DB)
    c = _conn()
    for col, default in [("doc_degree","''"),("doc_reg_no","''"),("doc_email","''"),
                          ("doc_phone","''"),("clinic_address","''"),("doc_extra_quals","''")]:
        try: c.execute(f"ALTER TABLE settings ADD COLUMN {col} TEXT DEFAULT {default}")
        except: pass
    c.commit()
    row = c.execute("SELECT clinic_name,doc_name,doc_subtitle,doc_degree,doc_reg_no,doc_email,doc_phone,clinic_address,doc_extra_quals FROM settings WHERE doctor_id=?", (did,)).fetchone()
    c.close()
    if row and row[0]:  # row[0]=clinic_name must exist
        sett = {"clinic_name":row[0],"doc_name":row[1],"doc_subtitle":row[2],
                "doc_degree":row[3] or "","doc_reg_no":row[4] or "",
                "doc_email":row[5] or "","doc_phone":row[6] or "",
                "clinic_address":row[7] or "","doc_extra_quals":row[8] or ""}
        st.session_state["_sett_cache"] = sett
        return sett
    # 3. Supabase (after server restart — pull saved settings)
    if _supa_available():
        try:
            rows = supa_select("settings",{"doctor_id":f"eq.{did}"},limit=1)
            if rows:
                r = rows[0]
                sett = {"clinic_name":r.get("clinic_name",""),"doc_name":r.get("doc_name",""),
                        "doc_subtitle":r.get("doc_subtitle",""),"doc_degree":r.get("doc_degree",""),
                        "doc_reg_no":r.get("doc_reg_no",""),"doc_email":r.get("doc_email",""),
                        "doc_phone":r.get("doc_phone",""),"clinic_address":r.get("clinic_address",""),
                        "doc_extra_quals":r.get("doc_extra_quals","")}
                # Cache back to SQLite
                c = _conn()
                c.execute("INSERT OR REPLACE INTO settings (doctor_id,clinic_name,doc_name,doc_subtitle,doc_degree,doc_reg_no,doc_email,doc_phone,clinic_address,doc_extra_quals) VALUES (?,?,?,?,?,?,?,?,?,?)",
                    (did,sett["clinic_name"],sett["doc_name"],sett["doc_subtitle"],sett["doc_degree"],
                     sett["doc_reg_no"],sett["doc_email"],sett["doc_phone"],sett["clinic_address"],sett["doc_extra_quals"]))
                c.commit(); c.close()
                st.session_state["_sett_cache"] = sett
                return sett
        except: pass
    # 4. Hardcoded defaults (first time only)
    if did == "chief":
        return {"clinic_name":"Dr. Vasu Memorial Clinic","doc_name":"Dr. G.S. Gill",
                "doc_subtitle":"CARDIO-PHYSICIAN (Non-Invasive)","doc_degree":"MBBS, PGDCCP",
                "doc_reg_no":"","doc_email":"","doc_phone":"","clinic_address":"","doc_extra_quals":""}
    if did == "junior":
        return {"clinic_name":"Dr. Vasu Memorial Clinic","doc_name":"Junior Doctor",
                "doc_subtitle":"MBBS","doc_degree":"MBBS","doc_reg_no":"",
                "doc_email":"","doc_phone":"","clinic_address":"","doc_extra_quals":""}
    return {"clinic_name":"My Clinic","doc_name":"Doctor","doc_subtitle":"MBBS",
            "doc_degree":"","doc_reg_no":"","doc_email":"","doc_phone":"",
            "clinic_address":"","doc_extra_quals":""}

def db_save_settings(clinic, doc_name, doc_sub, doc_degree="", doc_reg="", doc_email="", doc_phone="", clinic_addr="", doc_extra=""):
    did = _did()
    # Layer 1: SQLite (always works)
    c = _conn()
    c.execute("INSERT OR REPLACE INTO settings (doctor_id,clinic_name,doc_name,doc_subtitle,doc_degree,doc_reg_no,doc_email,doc_phone,clinic_address,doc_extra_quals) VALUES (?,?,?,?,?,?,?,?,?,?)",
              (did, clinic, doc_name, doc_sub, doc_degree, doc_reg, doc_email, doc_phone, clinic_addr, doc_extra))
    c.commit(); c.close()

    # Layer 2: Supabase — guaranteed save using DELETE + INSERT
    if _supa_available():
        url_s, _ = _get_supa_creds()
        sett_data = {
            "doctor_id": did, "clinic_name": clinic,
            "doc_name": doc_name, "doc_subtitle": doc_sub,
            "doc_degree": doc_degree, "doc_reg_no": doc_reg,
            "doc_email": doc_email, "doc_phone": doc_phone,
            "clinic_address": clinic_addr, "doc_extra_quals": doc_extra
        }
        try:
            hdrs = {**_supa_headers(), "Prefer": "return=minimal"}
            # Step 1: Delete existing row for this doctor_id
            requests.delete(
                f"{url_s}/rest/v1/settings?doctor_id=eq.{did}",
                headers=hdrs, timeout=8)
            # Step 2: Insert fresh
            r_set = requests.post(
                f"{url_s}/rest/v1/settings",
                headers=hdrs, json=sett_data, timeout=10)
            if r_set.status_code in [200, 201]:
                st.session_state.pop("last_supa_err", None)  # clear any old error
            else:
                st.session_state["last_supa_err"] = (
                    f"Settings HTTP {r_set.status_code}: {r_set.text[:200]}")
        except Exception as e:
            st.session_state["last_supa_err"] = f"Settings save error: {e}"

    # Layer 3: Session cache (immediate use)
    st.session_state["_sett_cache"] = {
        "clinic_name": clinic, "doc_name": doc_name, "doc_subtitle": doc_sub,
        "doc_degree": doc_degree, "doc_reg_no": doc_reg, "doc_email": doc_email,
        "doc_phone": doc_phone, "clinic_address": clinic_addr, "doc_extra_quals": doc_extra
    }

# ── db stats for admin ─────────────────────────────────────────
def db_admin_stats():
    c = _conn()
    total = c.execute("SELECT COUNT(*) FROM patients").fetchone()[0]
    c.close()
    return total

def db_import_rows(rows_list, did=None):
    """Bulk import — for migration tool"""
    did = did or _did()
    c = _conn()
    imported = 0
    for row in rows_list:
        name = str(row.get("patient_name","")).strip()
        if not name or name.lower() in ["patient_name","name",""]: continue
        try:
            c.execute("INSERT INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
                (did,
                 str(row.get("date",""))[:16] or datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                 name,
                 str(row.get("phone","")),
                 str(row.get("vitals","")),
                 str(row.get("fee","0")),
                 str(row.get("complaints","")),
                 str(row.get("medicines","")),
                 str(row.get("investigations","")),
                 str(row.get("specialty","Imported"))
                ))
            imported += 1
        except: pass
    c.commit(); c.close()
    return imported

# ── Scan queue helpers ──────────────────────────────────────────
def db_save_scan(image_b64, pt_name="", phone="", vitals="", fee="0",
                 complaints="", medicines="", investigations=""):
    did = _did()
    c = _conn()
    c.execute("""INSERT INTO pending_scans
        (doctor_id,uploaded_at,image_b64,patient_name,phone,vitals,fee,complaints,medicines,investigations,status)
        VALUES (?,?,?,?,?,?,?,?,?,?,'pending')""",
        (did, datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
         image_b64, pt_name, phone, vitals, fee, complaints, medicines, investigations))
    c.commit(); c.close()

def db_get_pending_scans():
    did = _did()
    c = _conn()
    # ensure table exists
    c.execute("""CREATE TABLE IF NOT EXISTS pending_scans (
        id INTEGER PRIMARY KEY AUTOINCREMENT, doctor_id TEXT, uploaded_at TEXT,
        image_b64 TEXT, patient_name TEXT DEFAULT '', phone TEXT DEFAULT '',
        vitals TEXT DEFAULT '', fee TEXT DEFAULT '0', complaints TEXT DEFAULT '',
        medicines TEXT DEFAULT '', investigations TEXT DEFAULT '', status TEXT DEFAULT 'pending')""")
    rows = c.execute(
        "SELECT * FROM pending_scans WHERE doctor_id=? AND status='pending' ORDER BY id ASC",
        (did,)).fetchall()
    c.close()
    cols=["id","doctor_id","uploaded_at","image_b64","patient_name","phone",
          "vitals","fee","complaints","medicines","investigations","status"]
    return [dict(zip(cols,r)) for r in rows]

def db_update_scan(pid, pt_name, phone, vitals, fee, complaints, medicines, investigations, status="pending"):
    c = _conn()
    c.execute("""UPDATE pending_scans SET
        patient_name=?,phone=?,vitals=?,fee=?,complaints=?,medicines=?,investigations=?,status=?
        WHERE id=?""",
        (pt_name,phone,vitals,fee,complaints,medicines,investigations,status,pid))
    c.commit(); c.close()

def db_approve_scan(pid, pt_name, phone, vitals, fee, complaints, medicines, investigations):
    """Approve scan → save to main patients table via standard 2-layer save"""
    db_save_patient(pt_name, phone, vitals, fee, complaints, medicines, investigations, "Handwritten-Scan")
    c = _conn()
    c.execute("UPDATE pending_scans SET status='approved' WHERE id=?", (pid,))
    c.commit(); c.close()

def db_count_pending_scans():
    did = _did()
    c = _conn()
    try:
        n = c.execute("SELECT COUNT(*) FROM pending_scans WHERE doctor_id=? AND status='pending'", (did,)).fetchone()[0]
    except: n = 0
    c.close()
    return n

def img_to_b64(img):
    buf = io.BytesIO()
    img.convert('RGB').save(buf,'JPEG',quality=82)
    return base64.b64encode(buf.getvalue()).decode()

def call_groq_scan(img, extra=""):
    """Send prescription image to Groq vision - returns properly formatted text"""
    key = _api_key()
    if not key: return {}
    buf = io.BytesIO(); img.convert('RGB').save(buf,'JPEG',quality=92)
    b64 = base64.b64encode(buf.getvalue()).decode()
    prompt = (
        "Read this handwritten Indian prescription carefully. " + extra + "\n\n"
        "RULES:\n"
        "1. Extract ONLY what is VISIBLY WRITTEN. Do NOT add anything.\n"
        "2. For medicines: write as PLAIN TEXT, numbered list format:\n"
        "   1. Tab. [Drug Name] [Dose] - [Frequency] - [Timing] - [Days]\n"
        "   2. Tab. [Drug Name] [Dose] - [Frequency] - [Timing] - [Days]\n"
        "   Do NOT return medicines as JSON array or dict.\n"
        "3. Return ONLY valid JSON - no other text, no markdown.\n\n"
        '{"patient_name":"","phone":"","vitals":"","complaints":"",'
        '"medicines":"1. Tab. ... \\n2. Tab. ...","investigations":"","diagnosis":"","fee":"","follow_up":""}'
    )
    try:
        r = requests.post("https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},
            json={"model":"meta-llama/llama-4-scout-17b-16e-instruct","temperature":0.0,
                  "messages":[{"role":"user","content":[
                      {"type":"text","text":prompt},
                      {"type":"image_url","image_url":{"url":f"data:image/jpeg;base64,{b64}"}}
                  ]}]},timeout=30)
        if r.status_code == 200:
            txt = r.json()["choices"][0]["message"]["content"].strip()
            txt = txt.replace("```json","").replace("```","").strip()
            s = txt.find("{"); e = txt.rfind("}")
            if s>=0 and e>s:
                data = json.loads(txt[s:e+1])
                # Fix: if medicines is a list/dict, convert to plain text
                meds = data.get("medicines","")
                if isinstance(meds, list):
                    lines = []
                    for i, m in enumerate(meds, 1):
                        if isinstance(m, dict):
                            name = m.get("name", m.get("drug",""))
                            dose = m.get("dosage", m.get("dose",""))
                            freq = m.get("frequency", m.get("freq",""))
                            timing = m.get("timing","")
                            days = m.get("days","")
                            line = f"{i}. {name} {dose}".strip()
                            if freq: line += f" - {freq}"
                            if timing: line += f" - {timing}"
                            if days: line += f" - {days}"
                            lines.append(line)
                        else:
                            lines.append(f"{i}. {m}")
                    data["medicines"] = "\n".join(lines)
                elif isinstance(meds, dict):
                    data["medicines"] = str(meds)
                return data
    except: pass
    return {}
# ══════════════════════════════════════════════════════════════
def _api_key():
    try:    return st.secrets["GROQ_API_KEY"]
    except: return st.session_state.get("groq_key","") or os.getenv("GROQ_API_KEY","")

def call_groq(msgs, model=None, temp=0.1):
    key = _api_key()
    if not key or len(key)<10:
        st.error("🚨 Groq API Key missing — Admin se update karwayein (PIN 1010).")
        return None
    content=[]; has_img=False
    for m in msgs:
        if isinstance(m, str):
            content.append({"type":"text","text":m})
        else:
            try:
                buf=io.BytesIO(); img=m.convert('RGB') if m.mode!='RGB' else m; img.save(buf,"JPEG")
                content.append({"type":"image_url","image_url":{"url":f"data:image/jpeg;base64,{base64.b64encode(buf.getvalue()).decode()}"}})
                has_img=True
            except: pass
    mdl = model or ("meta-llama/llama-4-scout-17b-16e-instruct" if has_img else "llama-3.3-70b-versatile")
    try:
        r=requests.post("https://api.groq.com/openai/v1/chat/completions",
            headers={"Authorization":f"Bearer {key}","Content-Type":"application/json"},
            json={"model":mdl,"messages":[{"role":"user","content":content}],"temperature":temp})
        if r.status_code==200: return r.json()['choices'][0]['message']['content']
        st.error(f"Groq Error {r.status_code}: {r.json().get('error',{}).get('message','')}"); return None
    except Exception as e: st.error(f"Groq error: {e}"); return None

def call_whisper(audio_bytes, fname="audio.wav"):
    key=_api_key()
    if not key: return "API Key missing."
    try:
        r=requests.post("https://api.groq.com/openai/v1/audio/transcriptions",
            headers={"Authorization":f"Bearer {key}"},
            files={"file":(fname,audio_bytes,"audio/wav")},
            data={"model":"whisper-large-v3","response_format":"json"})
        return r.json().get("text","") if r.status_code==200 else f"Error: {r.text}"
    except Exception as e: return f"Error: {e}"

# ══════════════════════════════════════════════════════════════
# 4. SPECIALTY CONFIG
# ══════════════════════════════════════════════════════════════
SPECIALTIES = {
    "❤️ Cardiology":      {"persona":"World-Class Cardiologist (DM Cardiology, FACC)",    "guidelines":"ACC/AHA 2024, ESC 2023, CSI",              "focus":"HTN, HF, IHD, arrhythmias, lipids"},
    "🦴 Orthopedics":     {"persona":"Senior Orthopedic Surgeon (MS Ortho, DNB)",          "guidelines":"AAOS, NICE Musculoskeletal, IOA",          "focus":"joint pain, OA, back pain, fractures, bone health"},
    "🫁 Pulmonology":     {"persona":"Senior Pulmonologist (DM Pulmonology)",              "guidelines":"GOLD 2024 COPD, GINA 2024 Asthma, RNTCP", "focus":"asthma, COPD, TB, pneumonia"},
    "👶 Pediatrics":      {"persona":"Senior Pediatrician (MD Pediatrics, FIAP)",          "guidelines":"IAP 2024, WHO Child Growth",               "focus":"fever, infections, growth, vaccines"},
    "🩸 Diabetology":     {"persona":"Senior Diabetologist (DM Endocrinology)",            "guidelines":"ADA 2024, RSSDI, AACE",                    "focus":"DM1/2, insulin, HbA1c, thyroid, metabolic"},
    "🧠 Neurology":       {"persona":"Senior Neurologist (DM Neurology)",                  "guidelines":"AAN, ESO Stroke, IAN",                    "focus":"headache, epilepsy, stroke, Parkinson's, neuropathy"},
    "👩‍⚕️ Gynecology":  {"persona":"Senior Gynecologist (MS OBG, FICOG)",                "guidelines":"FOGSI, RCOG, WHO Reproductive",            "focus":"PCOD, menstrual, pregnancy, menopause"},
    "🫘 Nephrology":      {"persona":"Senior Nephrologist (DM Nephrology)",                "guidelines":"KDIGO 2024, ERA, ISN",                     "focus":"CKD, AKI, dialysis, proteinuria, electrolytes"},
    "🔬 Gastroenterology":{"persona":"Senior Gastroenterologist (DM Gastro)",              "guidelines":"ACG, AASLD, IOIBD",                        "focus":"GERD, IBS, IBD, liver, hepatitis, peptic ulcer"},
}

# ══════════════════════════════════════════════════════════════
# 5. PDF HELPERS
# ══════════════════════════════════════════════════════════════
def _s(t): return str(t).encode('latin-1','replace').decode('latin-1')

def make_rx_pdf(pt_name, vitals, rx_text, investigations="", specialty_label=""):
    sett = db_get_settings()
    pdf = FPDF(); pdf.add_page()

    # ══ LETTERHEAD — Professional 2-column Indian prescription format ══
    # LEFT: Doctor name, degrees, specialty, extra quals
    # RIGHT: Clinic name, address, phone, email, reg no

    pdf.set_fill_color(235,245,255); pdf.rect(0,0,210,54,'F')
    pdf.set_draw_color(0,51,102); pdf.set_line_width(0.8)
    pdf.line(0,54,210,54); pdf.set_line_width(0.2)

    # LEFT: Doctor Name
    pdf.set_xy(8,4)
    pdf.set_font("Helvetica",'B',13); pdf.set_text_color(0,51,102)
    pdf.cell(100,7,_s(sett["doc_name"]),ln=False)

    # RIGHT: Clinic Name
    pdf.set_xy(108,4)
    pdf.set_font("Helvetica",'B',12); pdf.set_text_color(0,51,102)
    pdf.cell(97,7,_s(sett["clinic_name"]),ln=False,align='R')

    # LEFT: Degrees
    pdf.set_xy(8,12)
    pdf.set_font("Helvetica",'B',9); pdf.set_text_color(30,30,120)
    pdf.cell(100,5,_s(sett.get("doc_degree","")),ln=False)

    # RIGHT: Address line 1
    addr = sett.get("clinic_address","")
    addr_lines = [l.strip() for l in addr.split("\n") if l.strip()] if addr else []
    pdf.set_xy(108,12)
    pdf.set_font("Helvetica",'',8); pdf.set_text_color(60,60,60)
    if addr_lines: pdf.cell(97,5,_s(addr_lines[0]),ln=False,align='R')

    # LEFT: Specialty
    pdf.set_xy(8,18)
    pdf.set_font("Helvetica",'I',9); pdf.set_text_color(60,60,120)
    pdf.cell(100,5,_s(sett.get("doc_subtitle","")),ln=False)

    # RIGHT: Address line 2
    pdf.set_xy(108,18)
    pdf.set_font("Helvetica",'',8); pdf.set_text_color(60,60,60)
    if len(addr_lines)>1: pdf.cell(97,5,_s(addr_lines[1]),ln=False,align='R')

    # LEFT: Extra quals
    extra = sett.get("doc_extra_quals","")
    extra_lines = [l.strip() for l in extra.split("\n") if l.strip()] if extra else []
    pdf.set_font("Helvetica",'',7); pdf.set_text_color(70,70,100)
    for i,eq in enumerate(extra_lines[:4]):
        pdf.set_xy(8,24+i*4)
        pdf.cell(100,4,_s(eq),ln=False)

    # RIGHT: Phone
    y_r = 24
    if sett.get("doc_phone"):
        pdf.set_xy(108,y_r)
        pdf.set_font("Helvetica",'',8); pdf.set_text_color(60,60,60)
        pdf.cell(97,4,f"Ph: {_s(sett['doc_phone'])}",ln=False,align='R')
        y_r += 4
    # RIGHT: Email
    if sett.get("doc_email"):
        pdf.set_xy(108,y_r)
        pdf.set_font("Helvetica",'',8); pdf.set_text_color(60,60,60)
        pdf.cell(97,4,_s(sett["doc_email"]),ln=False,align='R')
        y_r += 4
    # RIGHT: Reg No
    if sett.get("doc_reg_no"):
        pdf.set_xy(108,y_r)
        pdf.set_font("Helvetica",'',8); pdf.set_text_color(80,80,80)
        pdf.cell(97,4,f"Reg: {_s(sett['doc_reg_no'])}",ln=False,align='R')

    # CENTER: Specialty label
    if specialty_label:
        pdf.set_xy(8,47)
        pdf.set_font("Helvetica",'B',8); pdf.set_text_color(139,0,0)
        pdf.cell(194,5,f"* Specialty Consultation: {_s(specialty_label)} *",align='C',ln=False)

    # Patient info row
    pdf.set_xy(8,57)
    pdf.set_font("Helvetica",'B',10); pdf.set_text_color(0,0,0)
    pdf.cell(70,6,f"Patient: {_s(pt_name)}",ln=False)
    pdf.cell(60,6,f"Date: {datetime.date.today().strftime('%d-%b-%Y')}",ln=False)
    if vitals:
        pdf.set_font("Helvetica",'',9)
        pdf.cell(65,6,f"Vitals: {_s(vitals)}",ln=False)
    pdf.ln(6)
    y=pdf.get_y(); pdf.line(8,y,202,y); pdf.ln(3)

    # Prescription body
    pdf.set_font("Helvetica",'',10)
    body = re.sub(r'\*\*PHONE.*', '', rx_text)
    body = _s(body.replace('**','').replace('* ','- '))
    pdf.multi_cell(0,5.5,body)

    # Investigations
    if investigations:
        pdf.ln(2); pdf.set_font("Helvetica",'B',10)
        y2=pdf.get_y(); pdf.line(8,y2,202,y2); pdf.ln(2)
        pdf.cell(0,6,"INVESTIGATIONS:",ln=True)
        pdf.set_font("Helvetica",'',10)
        pdf.multi_cell(0,5.5,_s(investigations))

    return pdf.output(dest='S').encode('latin-1')

def make_cme_pdf(topic, content):
    sett = db_get_settings()
    pdf=FPDF(); pdf.add_page()
    pdf.set_fill_color(240,248,255); pdf.rect(0,0,210,30,'F')
    pdf.set_font("Helvetica",'B',14); pdf.set_text_color(0,51,102)
    pdf.cell(0,12,"CLINICAL GUIDELINES & PROTOCOLS",ln=True,align='C')
    pdf.set_font("Helvetica",'I',10)
    pdf.cell(0,7,f"Topic: {_s(topic)} | {_s(sett['doc_name'])}",ln=True,align='C')
    pdf.ln(6); pdf.set_font("Helvetica",'',11); pdf.set_text_color(0,0,0)
    pdf.multi_cell(0,6,_s(content.replace('**','').replace('* ','- ')))
    return pdf.output(dest='S').encode('latin-1')

def show_pdf(pdf_bytes):
    b64=base64.b64encode(pdf_bytes).decode()
    st.markdown(f'<iframe src="data:application/pdf;base64,{b64}" width="100%" height="460"></iframe>',unsafe_allow_html=True)

# ── Aliases to match old code names ───────────────────────────
def create_rx_pdf(name, vitals, rx_text, clinic=None, doc_name=None, subtitle=None, specialty_label=""):
    """Alias of make_rx_pdf — for backward compatibility with old code paths"""
    return make_rx_pdf(name, vitals, rx_text, specialty_label=specialty_label)

def create_cme_pdf(topic, content):
    """Alias of make_cme_pdf"""
    return make_cme_pdf(topic, content)

def display_pdf(pdf_bytes):
    """Alias of show_pdf"""
    show_pdf(pdf_bytes)

def logout():
    for k in list(st.session_state.keys()): del st.session_state[k]
    st.rerun()

# ══════════════════════════════════════════════════════════════
# 6. STATE INIT
# ══════════════════════════════════════════════════════════════
for k,v in [("logged_in",False),("role",None),("doctor_id",None),
            ("waiting_queue",[]),("roster_data",[])]:
    if k not in st.session_state: st.session_state[k]=v

if "groq_key" not in st.session_state:
    st.session_state.groq_key = os.getenv("GROQ_API_KEY","")

# ══════════════════════════════════════════════════════════════
# 7. LOGIN
# ══════════════════════════════════════════════════════════════
if not st.session_state.logged_in:
    st.markdown("""<div style='text-align:center;padding:50px 0 10px'>
    <h1 style='color:#1565C0;font-size:2.3em'>🩺 Bharat AI Clinic</h1>
    <p style='color:#555'>AI-Powered Smart OPD • Multi-Doctor • Secure</p>
    <p style='color:#888;font-size:0.9em'>Powered by Groq Llama 4 — World's Fastest Medical AI</p>
    </div>""",unsafe_allow_html=True)
    _,cc,_ = st.columns([1,1,1])
    with cc:
        pin = st.text_input("🔑 Enter Your PIN",type="password",key="lpin",
                            placeholder="Enter PIN provided by your admin")
        if st.button("🔓 Login",type="primary",use_container_width=True):
            role,lic = check_pin(pin)
            if role=="chief":
                # Chief + Junior share same doctor_id = same clinic data
                st.session_state.update({"logged_in":True,"role":"chief","doctor_id":"clinic_default"}); st.rerun()
            elif role=="junior":
                # Same clinic_default = Junior sees Chief's patients and vice versa
                st.session_state.update({"logged_in":True,"role":"junior","doctor_id":"clinic_default"}); st.rerun()
            elif role=="admin":
                st.session_state.update({"logged_in":True,"role":"admin","doctor_id":"admin"}); st.rerun()
            elif role=="licensed":
                # Licensed doctors get their own isolated doctor_id
                st.session_state.update({"logged_in":True,"role":"licensed","doctor_id":lic["doctor_id"],"lic":lic}); st.rerun()
            elif role=="expired":
                st.error(f"❌ Your license has expired. Please contact your admin to renew.")
            else:
                st.error("❌ Invalid PIN. Please check with your administrator.")
    st.stop()

# ══════════════════════════════════════════════════════════════
# 8. ADMIN PORTAL
# ══════════════════════════════════════════════════════════════
if st.session_state.role == "admin":
    hc1,hc2=st.columns([5,1])
    with hc1: st.title("⚙️ Admin Control Panel — Gill Clinic OPD")
    with hc2:
        if st.button("🔒 Logout"): logout()

    at1,at2,at3,at4,at5 = st.tabs(["🔑 API & System","👨‍⚕️ Doctor Licenses","📊 All Doctors Data","📦 Import Old Data","🚪 Waiting Room"])

    # ── API & System ───────────────────────────────────────────
    with at1:
        st.markdown("### 🔑 Groq API Key")
        new_key = st.text_input("API Key (gsk_...)",value=st.session_state.groq_key,type="password",key="ak")
        if st.button("✅ Save Key",type="primary"):
            st.session_state.groq_key=new_key.strip(); st.success("✅ Saved!")

        st.markdown("---")
        st.markdown("### ☁️ Supabase Permanent DB Status")
        if _supa_available():
            st.success("✅ **Supabase Connected** — Data saves permanently to cloud!")
            st.info("Patient data will NEVER be lost on server restart.")
            # Quick table check
            test = supa_select("patients",{},limit=1)
            if test is not None:
                st.success("✅ 'patients' table exists and is accessible!")
            else:
                st.error("❌ 'patients' table missing! Run the SQL below in Supabase SQL Editor.")
        else:
            st.error("❌ **Supabase NOT configured** — Data resets on server restart!")

        st.markdown("---")
        st.markdown("### 🗄️ Supabase Table Setup (Run once in Supabase SQL Editor)")
        st.info("Supabase → Project → SQL Editor → New Query → paste below → Run")
        st.code("""
CREATE TABLE IF NOT EXISTS patients (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  date TEXT, patient_name TEXT, phone TEXT,
  vitals TEXT, fee TEXT DEFAULT '0',
  complaints TEXT, medicines TEXT,
  investigations TEXT DEFAULT '',
  specialty TEXT DEFAULT 'General Physician'
);

CREATE TABLE IF NOT EXISTS settings (
  doctor_id TEXT PRIMARY KEY,
  clinic_name TEXT, doc_name TEXT, doc_subtitle TEXT,
  doc_degree TEXT DEFAULT '', doc_reg_no TEXT DEFAULT '',
  doc_email TEXT DEFAULT '', doc_phone TEXT DEFAULT '',
  clinic_address TEXT DEFAULT '', doc_extra_quals TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS templates (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  category TEXT, name TEXT, content TEXT
);

CREATE TABLE IF NOT EXISTS specialty_upgrades (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT NOT NULL DEFAULT 'chief',
  date TEXT, patient_name TEXT, vitals TEXT,
  original_rx TEXT, specialty TEXT,
  upgraded_rx TEXT, evidence TEXT,
  is_starred INTEGER DEFAULT 0, star_note TEXT DEFAULT ''
);

CREATE TABLE IF NOT EXISTS licenses (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT UNIQUE NOT NULL,
  doctor_name TEXT, doctor_email TEXT, doctor_phone TEXT,
  pin TEXT UNIQUE NOT NULL, clinic_name TEXT, specialty TEXT,
  expiry_date TEXT, is_active INTEGER DEFAULT 1,
  created_date TEXT, notes TEXT DEFAULT ''
);

-- Enable Row Level Security (optional but recommended)
-- ALTER TABLE patients ENABLE ROW LEVEL SECURITY;
        """, language="sql")

        st.markdown("---")
        st.markdown("### 📊 System Stats")
        total=db_admin_stats()
        st.metric("Total Patients in Local Cache",total)
        if _supa_available():
            try:
                supa_total = len(supa_select("patients", {}, limit=5000))
                st.metric("Total Patients in Cloud (Supabase)", supa_total)
            except: pass

    # ── Doctor Licenses ────────────────────────────────────────
    with at2:
        st.markdown("### ➕ Create New Doctor License")
        with st.form("lic_form",clear_on_submit=True):
            lc1,lc2=st.columns(2)
            l_did   = lc1.text_input("Doctor ID (unique, no spaces) *",placeholder="dr_sharma")
            l_name  = lc2.text_input("Doctor Full Name *")
            lc3,lc4=st.columns(2)
            l_email = lc3.text_input("Email")
            l_phone = lc4.text_input("Phone")
            lc5,lc6=st.columns(2)
            l_pin   = lc5.text_input("Assign PIN * (4-8 digits)",placeholder="e.g. 7777")
            l_clinic= lc6.text_input("Clinic Name")
            lc7,lc8=st.columns(2)
            l_spec  = lc7.text_input("Specialty")
            l_exp   = lc8.date_input("Expiry Date",value=datetime.date.today()+timedelta(days=30),min_value=datetime.date.today())
            l_notes = st.text_area("Notes",height=50)
            if st.form_submit_button("✅ Create License",type="primary"):
                if l_did and l_name and l_pin:
                    l_did_clean = re.sub(r'[^a-z0-9_]','',l_did.lower().replace(' ','_'))
                    ok=db_create_license(l_did_clean,l_name,l_email,l_phone,l_pin,l_clinic,l_spec,l_exp,l_notes)
                    if ok:
                        st.success(f"✅ License created! Doctor ID: `{l_did_clean}` | PIN: `{l_pin}` | Expires: {l_exp}")
                    else:
                        st.error("❌ Doctor ID or PIN already exists. Use different values.")
                else:
                    st.warning("Doctor ID, Name, and PIN are required.")

        st.markdown("---")
        st.markdown("#### 📋 All Licenses")
        for lic in db_get_all_licenses():
            expiry=datetime.date.fromisoformat(str(lic["expiry_date"])[:10])
            days_left=(expiry-datetime.date.today()).days
            status=f"✅ Active ({days_left}d left)" if days_left>=0 else f"❌ Expired ({abs(days_left)}d ago)"
            with st.expander(f"👨‍⚕️ {lic['doctor_name']} | ID:{lic['doctor_id']} | PIN:{lic['pin']} | {status}"):
                st.write(f"📧 {lic['doctor_email']} | 📞 {lic['doctor_phone']} | 🏥 {lic['clinic_name']}")
                st.write(f"📅 Created: {lic['created_date']} | Expires: {lic['expiry_date']}")
                ec1,ec2,ec3=st.columns(3)
                new_exp=ec1.date_input("Extend to:",value=expiry+timedelta(days=30),key=f"ext_{lic['id']}")
                if ec2.button("🔄 Extend",key=f"extb_{lic['id']}"):
                    c=_conn(); c.execute("UPDATE licenses SET expiry_date=? WHERE id=?",(str(new_exp),lic['id'])); c.commit(); c.close()
                    st.success(f"Extended to {new_exp}"); st.rerun()
                if ec3.button("🗑️ Delete",key=f"delb_{lic['id']}"):
                    db_delete_license(lic['id']); st.warning("Deleted"); st.rerun()

    # ── All Doctors Data (Admin Only) ──────────────────────────
    with at3:
        st.markdown("### 📊 All Doctors — Patient Data (Admin View Only)")
        st.info("⚠️ Only Admin can see all doctors' data here. Each doctor only sees their own data in their portal.")
        all_lics = db_get_all_licenses()
        # include built-in doctors
        doctor_options = {"chief (Dr. Gill)": "chief", "junior": "junior"}
        for lic in all_lics:
            doctor_options[f"{lic['doctor_name']} ({lic['doctor_id']})"] = lic["doctor_id"]

        sel_doc = st.selectbox("Select Doctor to View Data:", list(doctor_options.keys()))
        if st.button("📥 Load This Doctor's Data"):
            sel_did = doctor_options[sel_doc]
            pts = db_get_all_patients_admin(sel_did)
            total_rev = sum(_clean_fee(p['fee']) for p in pts)
            st.success(f"✅ {len(pts)} patients | Total Revenue: ₹{total_rev:,}")
            for pt in pts:
                with st.expander(f"👤 {pt['patient_name']} | {str(pt['date'])[:10]} | ₹{pt['fee']}"):
                    st.write(f"📞 {pt['phone']} | Vitals: {pt['vitals']}")
                    st.info(pt['medicines'])

    # ── Import Old Data ────────────────────────────────────────
    with at4:
        st.markdown("### 📦 Import Old Google Sheet Data")
        st.warning("Google Sheet se data automatically nahi aata (Streamlit Cloud limitation). Ek baar manually import karo — hamesha ke liye DB mein save ho jaayega.")

        # Select which doctor to import for
        import_options={"Chief Doctor (Dr. Gill)":"chief"}
        for lic in db_get_all_licenses(): import_options[f"{lic['doctor_name']}"] = lic["doctor_id"]
        imp_doc=st.selectbox("Kiske liye import karein?",list(import_options.keys()),key="imp_doc_sel")
        imp_did=import_options[imp_doc]

        st.markdown("**Google Sheet se CSV download karo: File → Download → CSV**")
        csv_raw=st.text_area("CSV data yahan paste karo:",height=180,key="csv_imp",
            placeholder="patient_name,phone,vitals,fee,date,complaints,medicines\nRamesh,9876543210,BP130/80,300,2026-03-01,Headache,1.Tab Paracetamol...")
        json_raw=st.text_area("Ya JSON data yahan paste karo:",height=100,key="json_imp",
            placeholder='[{"patient_name":"Ramesh","phone":"9876543210","medicines":"..."}]')

        if st.button("🚀 Import Now",type="primary"):
            rows=[]
            if json_raw.strip():
                try: rows=json.loads(json_raw.strip()); rows=rows if isinstance(rows,list) else [rows]
                except: st.error("JSON format galat hai.")
            elif csv_raw.strip():
                lines=csv_raw.strip().split('\n')
                sep='\t' if '\t' in lines[0] else ','
                hdrs=[h.strip().lower().replace(' ','_') for h in lines[0].split(sep)]
                FMAP={"patient_name":["patient_name","name"],"phone":["phone","mobile","contact"],
                      "vitals":["vitals","vital","bp"],"fee":["fee","fees","amount"],
                      "date":["date","datetime"],"complaints":["complaints","complaint"],
                      "medicines":["medicines","medicine","prescription","rx"]}
                def fi(headers,f):
                    for a in FMAP.get(f,[f]):
                        for i,h in enumerate(headers):
                            if a in h or h in a: return i
                    return -1
                cidx={f:fi(hdrs,f) for f in FMAP}
                for line in lines[1:]:
                    if not line.strip(): continue
                    cols=line.split(sep)
                    def gc(f): i=cidx.get(f,-1); return cols[i].strip().strip('"') if 0<=i<len(cols) else ""
                    rows.append({"patient_name":gc("patient_name"),"phone":gc("phone"),"vitals":gc("vitals"),
                                 "fee":gc("fee"),"date":gc("date"),"complaints":gc("complaints"),"medicines":gc("medicines")})
            if rows:
                n=db_import_rows(rows,imp_did)
                st.success(f"✅ {n} patients imported for {imp_doc}!")
            else:
                st.warning("Koi data nahi mila.")

        st.markdown("---")
        st.markdown("#### 🔍 Current DB Contents")
        if st.button("Show All Patients in DB"):
            for did_label,did_val in [("Chief","chief"),("Junior","junior")]:
                pts=db_get_all_patients_admin(did_val)
                if pts: st.write(f"**{did_label}**: {len(pts)} patients")
            for lic in db_get_all_licenses():
                pts=db_get_all_patients_admin(lic["doctor_id"])
                if pts: st.write(f"**{lic['doctor_name']}**: {len(pts)} patients")

    # ── Waiting Room ───────────────────────────────────────────
    with at5:
        st.markdown("### 🚪 Waiting Room — Add Patients to Queue")
        with st.form("wq_form",clear_on_submit=True):
            wc1,wc2=st.columns(2)
            wn=wc1.text_input("Patient Name *")
            wp=wc2.text_input("Phone")
            wc3,wc4=st.columns(2)
            wv=wc3.text_input("Vitals (BP, Sugar, Wt)")
            wf=wc4.text_input("Fee",value="300")
            if st.form_submit_button("➕ Add to Queue",type="primary"):
                if wn:
                    st.session_state.waiting_queue.append({"name":wn,"phone":wp,"vitals":wv,"fee":wf})
                    st.success(f"✅ {wn} added!")
        if st.session_state.waiting_queue:
            st.markdown(f"**Queue: {len(st.session_state.waiting_queue)} waiting**")
            for i,pt in enumerate(st.session_state.waiting_queue):
                c1,c2=st.columns([5,1])
                c1.write(f"#{i+1} {pt['name']} | {pt['phone']} | {pt['vitals']} | ₹{pt['fee']}")
                if c2.button("❌",key=f"rmq_{i}"):
                    st.session_state.waiting_queue.pop(i); st.rerun()

    # ── Migration / Import Tab ─────────────────────────────────
    at_mig = st.tabs(["📦 Import Old Data (Google Sheet → DB"])[0]
    with at_mig:
        st.markdown("### 📦 Google Sheet → SQLite Migration Tool")
        st.warning("""
**Why this is needed:**
Streamlit Cloud servers cannot directly connect to Google Script (DNS block).
So old Google Sheet data doesn't load automatically.

**One-time solution:** Paste your Google Sheet data below → it imports permanently into SQLite DB.
        """)

        # Select which doctor this import is for
        all_lics_for_imp = db_get_all_licenses()
        imp_options = {"Chief Doctor (Dr. Gill)":"chief","Junior Doctor":"junior"}
        for l in all_lics_for_imp: imp_options[f"{l['doctor_name']} ({l['doctor_id']})"] = l["doctor_id"]
        imp_doc_sel = st.selectbox("Kiske liye import karein?", list(imp_options.keys()), key="imp_doc_sel2")
        imp_did = imp_options[imp_doc_sel]

        st.markdown("**Step 1:** Google Sheet → File → Download → CSV (.csv) → open CSV → Ctrl+A → Ctrl+C → paste below")
        csv_raw = st.text_area("CSV data paste karo:",height=160,key="csv_imp2",
            placeholder="patient_name,phone,vitals,fee,date,complaints,medicines\nRamesh,9876543210,BP130/80,300,2026-03-01,Headache,1.Tab Paracetamol 500mg - TDS...")
        st.markdown("**OR** paste JSON:")
        json_raw = st.text_area("JSON data paste karo:",height=100,key="json_imp2",
            placeholder='[{"patient_name":"Ramesh","phone":"9876543210","medicines":"..."}]')

        if st.button("🚀 Import Now", type="primary", use_container_width=True, key="imp_now2"):
            rows=[]
            if json_raw.strip():
                try:
                    parsed=json.loads(json_raw.strip())
                    rows=parsed if isinstance(parsed,list) else [parsed]
                except Exception as e:
                    st.error(f"JSON error: {e}")
            elif csv_raw.strip():
                lines=csv_raw.strip().split('\n')
                sep='\t' if '\t' in lines[0] else ','
                hdrs=[h.strip().lower().replace(' ','_') for h in lines[0].split(sep)]
                FMAP2={"patient_name":["patient_name","name","patient_name"],"phone":["phone","mobile","contact"],
                       "vitals":["vitals","vital","bp"],"fee":["fee","fees","amount"],
                       "date":["date","datetime"],"complaints":["complaints","complaint"],
                       "medicines":["medicines","medicine","prescription","rx"]}
                def fi2(hs,f):
                    for a in FMAP2.get(f,[f]):
                        for i,h in enumerate(hs):
                            if a in h or h in a: return i
                    return -1
                cidx2={f:fi2(hdrs,f) for f in FMAP2}
                for line in lines[1:]:
                    if not line.strip(): continue
                    cols2=line.split(sep)
                    def gc2(f): i=cidx2.get(f,-1); return cols2[i].strip().strip('"') if 0<=i<len(cols2) else ""
                    rows.append({"patient_name":gc2("patient_name"),"phone":gc2("phone"),
                                 "vitals":gc2("vitals"),"fee":gc2("fee"),"date":gc2("date"),
                                 "complaints":gc2("complaints"),"medicines":gc2("medicines")})
            if rows:
                n = db_import_rows(rows, imp_did)
                st.success(f"✅ **{n} patients imported** for {imp_doc_sel}!")
                st.info("Now go to OPD Roster tab → 'All Time' → Fetch Roster to verify.")
            else:
                st.warning("No data found. Please paste CSV or JSON.")

        st.markdown("---")
        st.markdown("#### 🔍 Verify DB Contents")
        if st.button("📋 Show All Patients", key="show_all_db2"):
            for lbl,dv in [("Chief","chief"),("Junior","junior")]:
                pts=db_get_all_patients_admin(dv)
                if pts: st.write(f"**{lbl}**: {len(pts)} patients")
            for lic in db_get_all_licenses():
                pts=db_get_all_patients_admin(lic["doctor_id"])
                if pts: st.write(f"**{lic['doctor_name']}**: {len(pts)} patients")

    st.stop()

# ══════════════════════════════════════════════════════════════
# 9. PROMPTS
# ══════════════════════════════════════════════════════════════
def gp_prompt(pt, vitals, notes, doc, past_ctx, prog_fmt):
    past_warning = ""
    chronic_section = ""
    if past_ctx:
        past_warning = "\n⚠️ PAST RX IS FOR REFERENCE ONLY — DO NOT copy the past diagnosis into this visit. Diagnose fresh from TODAY's notes."
        chronic_section = """
**CHRONIC CONDITIONS TO CONTINUE (from past Rx):**
[List any chronic diseases found in past Rx — e.g. Hypertension, Diabetes, Hypothyroidism, Asthma, CAD — that should be ACKNOWLEDGED and medications continued unless doctor says otherwise]
"""
    return f"""You are a Senior General Physician working for {doc}.

PATIENT: {pt} | VITALS: {vitals}
{past_ctx}DOCTOR'S TODAY'S NOTES: {notes}

🚨 CRITICAL RULES:
1. ENGLISH + HINGLISH only. ZERO Chinese, ZERO Devanagari.
2. TODAY's diagnosis: from TODAY's notes/vitals ONLY.{past_warning}
3. CHRONIC CONDITIONS: Scan past Rx for known chronic diseases. LIST them and CONTINUE their medications unless doctor specifies change.
4. Do NOT invent symptoms. Write ONLY what doctor noted today.
5. Drug format: [N]. Tab./Cap./Syp./Inj. [Name] [Dose] - [Frequency] - [Timing] - [Days]
6. Start directly with format below — no preamble.

{prog_fmt}{chronic_section}**CHIEF COMPLAINTS (TODAY):**
[Only today's new complaints from doctor's notes]

**DIAGNOSIS:**
[Today's diagnosis. Note chronic conditions separately as "Known: HTN, DM2" etc.]

**MEDICATIONS (Rx):**
1. Tab./Cap. [Name] [Dose] - [Frequency] - [Timing] - [Days]  [NEW/CONTINUE/MODIFIED]
2. ...
[For follow-up: Mark each drug clearly as CONTINUE / NEW / MODIFIED / STOPPED]

**INVESTIGATIONS ADVISED:**
[Only if clinically indicated today]

**DIET & LIFESTYLE ADVICE:**
[2-3 practical Hinglish points]

**NEXT FOLLOW-UP:** [Specific timeframe]

**PHONE NUMBER:** [10-digit if found in notes/images, else N/A]"""

def specialty_prompt(pt, vitals, orig_rx, sname, sdata, custom=""):
    persona   = f"Senior Specialist in {custom}" if custom else sdata['persona']
    guidelines= f"Standard guidelines for {custom}" if custom else sdata['guidelines']
    focus     = custom if custom else sdata['focus']
    return f"""You are a {persona}.

PATIENT: {pt} | VITALS: {vitals}

Original GP Prescription:
{orig_rx}

Follow: {guidelines} | Focus: {focus}

Generate a COMPLETE standalone prescription. Mark each drug:
[CONTINUE] = kept | [MODIFIED ✏️] = changed | [NEW ➕] = added | [REMOVED ❌ Reason: ...]

**CHIEF COMPLAINTS ({sname} view):**
**{sname.upper()} DIAGNOSIS:**
**MEDICATIONS (Rx):**
1. Tab./Cap. [Name] [Dose] - [Freq] - [Timing] - [Days] [CONTINUE/MODIFIED/NEW]

**SPECIALTY INVESTIGATIONS:**
**DIET ADVICE:**
**NEXT FOLLOW-UP:**
**EVIDENCE BASE:** [Guideline name + year]
**KEY ADDITIONS vs GP Rx:** [What would have been missed]"""

def validate_rx(text):
    if not text or len(text.strip())<80: return False,["Too short"]
    up=text.upper()
    miss=[s for s in ["CHIEF COMPLAINTS","DIAGNOSIS","MEDICATIONS"] if s not in up]
    return len(miss)==0, miss

# ── Aliases used in older code paths ──────────────────────────
def build_gp_prompt(pt_name, vitals, notes, doc_name, past_ctx, prog_inst, prog_fmt):
    return gp_prompt(pt_name, vitals, notes, doc_name, past_ctx, prog_fmt)

def build_specialty_prompt(pt_name, vitals, orig_rx, spec_name, spec_data, custom_spec=""):
    return specialty_prompt(pt_name, vitals, orig_rx, spec_name, spec_data, custom_spec)

# ══════════════════════════════════════════════════════════════
# PATIENT PROGRESS ENGINE — compares past vs current vitals
# ══════════════════════════════════════════════════════════════
def _extract_vitals_dict(vitals_str):
    """Extract BP systolic, diastolic, sugar, weight from vitals string"""
    v = str(vitals_str).lower()
    result = {}
    # BP: 130/80 or 130/80 mmhg
    bp = re.search(r'(\d{2,3})\s*/\s*(\d{2,3})', v)
    if bp:
        result["sys"] = int(bp.group(1))
        result["dia"] = int(bp.group(2))
    # Sugar: rbs/fbs/sugar/bs = 180
    sg = re.search(r'(?:rbs|fbs|pp|sugar|bs|glucose)\s*[:=]?\s*(\d{2,4})', v)
    if sg: result["sugar"] = int(sg.group(1))
    # Weight: wt/weight = 72
    wt = re.search(r'(?:wt|weight)\s*[:=]?\s*(\d{2,3})', v)
    if wt: result["weight"] = int(wt.group(1))
    # HR/Pulse
    hr = re.search(r'(?:hr|pulse|pr)\s*[:=]?\s*(\d{2,3})', v)
    if hr: result["hr"] = int(hr.group(1))
    return result

def render_patient_progress(past_vitals_str, today_vitals_str, past_date):
    """Render a color-coded progress banner comparing past vs today vitals"""
    past = _extract_vitals_dict(past_vitals_str)
    today = _extract_vitals_dict(today_vitals_str)
    if not past or not today:
        return  # not enough data to compare

    lines = []
    overall_good = 0
    overall_bad  = 0

    # BP assessment
    if "sys" in past and "sys" in today:
        p_sys, t_sys = past["sys"], today["sys"]
        p_dia, t_dia = past.get("dia",0), today.get("dia",0)
        diff_sys = t_sys - p_sys
        if t_sys < 130:
            status = "✅ Controlled"
            overall_good += 1
        elif t_sys <= 140:
            status = "🟡 Borderline"
        else:
            status = "🔴 High"
            overall_bad += 1
        arrow = "↓" if diff_sys < 0 else ("↑" if diff_sys > 0 else "→")
        lines.append(f"**BP:** {p_sys}/{p_dia} → **{t_sys}/{t_dia}** mmHg &nbsp;{arrow} {abs(diff_sys)} &nbsp;{status}")

    # Sugar assessment
    if "sugar" in past and "sugar" in today:
        p_sg, t_sg = past["sugar"], today["sugar"]
        diff_sg = t_sg - p_sg
        if t_sg < 140:
            status = "✅ Normal"
            overall_good += 1
        elif t_sg < 200:
            status = "🟡 Borderline"
        else:
            status = "🔴 High"
            overall_bad += 1
        arrow = "↓" if diff_sg < 0 else ("↑" if diff_sg > 0 else "→")
        lines.append(f"**Sugar:** {p_sg} → **{t_sg}** mg/dL &nbsp;{arrow} {abs(diff_sg)} &nbsp;{status}")

    # Weight assessment
    if "weight" in past and "weight" in today:
        p_wt, t_wt = past["weight"], today["weight"]
        diff_wt = t_wt - p_wt
        arrow = "↓" if diff_wt < 0 else ("↑" if diff_wt > 0 else "→")
        if diff_wt < 0:
            status = "✅ Reduced"
            overall_good += 1
        elif diff_wt == 0:
            status = "→ Same"
        else:
            status = "⚠️ Increased"
        lines.append(f"**Weight:** {p_wt} → **{t_wt}** kg &nbsp;{arrow} {abs(diff_wt)} kg &nbsp;{status}")

    if not lines:
        return

    # Overall verdict
    if overall_bad == 0 and overall_good > 0:
        verdict = "🎉 **OVERALL: IMPROVING** — Patient is responding well to treatment"
        color = "success"
    elif overall_bad > overall_good:
        verdict = "⚠️ **OVERALL: WORSENING** — Review treatment plan"
        color = "error"
    else:
        verdict = "📊 **OVERALL: MIXED** — Some parameters need attention"
        color = "warning"

    st.markdown(f"#### 📈 Patient Progress — Since {past_date}")
    if color == "success":
        st.success(verdict + "\n\n" + "  \n".join(lines))
    elif color == "error":
        st.error(verdict + "\n\n" + "  \n".join(lines))
    else:
        st.warning(verdict + "\n\n" + "  \n".join(lines))

# ══════════════════════════════════════════════════════════════
# 10. MAIN RX FORM
# ══════════════════════════════════════════════════════════════
def render_rx_form(uid="main"):
    RX_KEY   = f"rx_{uid}"
    NOTE_KEY = f"notes_{uid}"
    UPG_KEY  = f"upgrades_{uid}"
    SEL_KEY  = f"sel_specs_{uid}"
    SHOW_UPG = f"show_upg_{uid}"
    SPEC_CHAT= f"spec_chat_{uid}"  # specialty chat history

    if NOTE_KEY not in st.session_state: st.session_state[NOTE_KEY]=""
    # Apply pending note overrides (from drug add / transcription buttons)
    if "_note_override" in st.session_state:
        st.session_state[NOTE_KEY] = st.session_state.pop("_note_override")
    if UPG_KEY  not in st.session_state: st.session_state[UPG_KEY]={}
    if SEL_KEY  not in st.session_state: st.session_state[SEL_KEY]=[]
    if SHOW_UPG not in st.session_state: st.session_state[SHOW_UPG]=False
    if SPEC_CHAT not in st.session_state: st.session_state[SPEC_CHAT]={}  # spec_name -> [messages]

    is_fu     = st.session_state.get("is_followup",False)
    past_vit  = st.session_state.get("past_vitals","")
    past_rx   = st.session_state.get("past_rx","")
    past_date = st.session_state.get("past_date","")
    sett      = db_get_settings()
    did       = _did()

    # EDIT MODE — load existing rx directly into form
    is_edit = bool(st.session_state.get("rx_main",""))
    if is_edit and RX_KEY not in st.session_state:
        st.session_state[RX_KEY] = st.session_state.pop("rx_main","")

    # ── CRITICAL FIX: Pre-fill only works if widget keys are cleared first ──
    # Streamlit ignores value= if widget key already exists in session_state
    # So we: read the pre_ values, delete old widget keys, widget renders fresh
    _has_prefill = any(f"pre_{k}" in st.session_state
                       for k in ["name","phone","vitals","fee"])
    if _has_prefill:
        _pn = st.session_state.pop("pre_name",  st.session_state.get(f"pname_{uid}",""))
        _pp = st.session_state.pop("pre_phone", st.session_state.get(f"pphone_{uid}",""))
        _pv = st.session_state.pop("pre_vitals",st.session_state.get(f"pvit_{uid}",""))
        _pf = st.session_state.pop("pre_fee",   st.session_state.get(f"pfee_{uid}","300"))
        # Delete widget keys so they re-render with new values
        for wk in [f"pname_{uid}", f"pphone_{uid}", f"pvit_{uid}", f"pfee_{uid}"]:
            st.session_state.pop(wk, None)
        # Also clear old notes/rx so fresh generation
        st.session_state.pop(NOTE_KEY, None)
        if not is_edit:
            st.session_state.pop(RX_KEY, None)
        # Store in a stable key (not pre_ which gets popped)
        st.session_state[f"_fill_name_{uid}"]   = _pn
        st.session_state[f"_fill_phone_{uid}"]  = _pp
        st.session_state[f"_fill_vitals_{uid}"] = _pv
        st.session_state[f"_fill_fee_{uid}"]    = _pf

    # Read stable fill values
    _fname  = st.session_state.pop(f"_fill_name_{uid}",  "")
    _fphone = st.session_state.pop(f"_fill_phone_{uid}", "")
    _fvit   = st.session_state.pop(f"_fill_vitals_{uid}","")
    _ffee   = st.session_state.pop(f"_fill_fee_{uid}",   "300")

    # Load templates from DB each render
    rx_tmpl  = db_get_templates("Rx")
    lab_tmpl = db_get_templates("Lab")
    if not rx_tmpl:  rx_tmpl  = {"HTN Standard":"1. Tab. Telmisartan 40mg - OD - After Breakfast - 30 Days"}
    if not lab_tmpl: lab_tmpl = {"Routine Cardiac":"ECG, Lipid Profile, FBS, HbA1c"}

    cL, cR = st.columns([1,1.2],gap="large")

    # ════════════════ LEFT COLUMN ════════════════
    with cL:
        if is_edit:
            st.info("✏️ **EDIT MODE** — Rx loaded. Edit and click 'Update Patient'. No duplicate will be created.")
        st.markdown("### 📝 Patient Details")

        pt_name   = st.text_input("Patient Name *",     value=_fname,   key=f"pname_{uid}")
        pc1,pc2,pc3 = st.columns([2,2,1])
        pt_phone  = pc1.text_input("Phone",             value=_fphone,  key=f"pphone_{uid}")
        pt_vitals = pc2.text_input("Vitals (BP/HR/Sug/Wt)", value=_fvit, key=f"pvit_{uid}")
        pt_fee    = pc3.text_input("Fee ₹",             value=_ffee,    key=f"pfee_{uid}")

        if is_fu:
            st.info(f"🔄 Follow-Up | Past: {past_date} | AI diagnoses only from TODAY's notes.")
            # ── PATIENT PROGRESS TIMELINE ──────────────────────────────
            if past_vit and pt_vitals:
                render_patient_progress(past_vit, pt_vitals, past_date)
            elif past_vit:
                st.caption(f"📋 Past vitals: {past_vit} | Enter today's vitals above to see progress comparison.")

        # ── Templates ──────────────────────────────────────────────
        st.markdown("---")
        st.markdown("**📑 Smart Templates**")
        t1,t2=st.columns(2)
        with t1:
            srx=st.selectbox("💊 Rx Template",["-- Select --"]+list(rx_tmpl.keys()),key=f"srx_{uid}")
            if st.button("➕ Add",key=f"addrx_{uid}") and srx!="-- Select --":
                st.session_state["_note_override"]=st.session_state.get(NOTE_KEY,"")+"\n"+rx_tmpl[srx]; st.rerun()
        with t2:
            slab=st.selectbox("🔬 Lab Template",["-- Select --"]+list(lab_tmpl.keys()),key=f"slab_{uid}")
            if st.button("➕ Add",key=f"addlab_{uid}") and slab!="-- Select --":
                st.session_state["_note_override"]=st.session_state.get(NOTE_KEY,"")+"\n"+lab_tmpl[slab]; st.rerun()

        # ── Audio ──────────────────────────────────────────────────
        st.markdown("---")
        st.markdown("**🎙️ Voice / Audio Scribe**")
        aud=None
        if hasattr(st,"audio_input"): aud=st.audio_input("Record",key=f"arec_{uid}")
        uaud=st.file_uploader("Upload Audio",type=['wav','mp3','m4a','ogg'],key=f"aup_{uid}")
        if (aud or uaud) and st.button("🔄 Transcribe",key=f"trans_{uid}"):
            tgt=aud or uaud
            with st.spinner("Transcribing..."):
                txt=call_whisper(tgt.getvalue(),getattr(tgt,'name','audio.wav'))
                current=st.session_state.get(NOTE_KEY,"")
                st.session_state["_note_override"]=current+f"\n[Voice]: {txt}"; st.rerun()

        # ── FIX 1: Notes textarea FIRST (height 220 — bigger for doctor) ──
        st.markdown("**✍️ Doctor's Clinical Notes** *(Win+H for voice typing)*")
        dictation=st.text_area("Clinical notes — complaints, findings, history...",
                               key=NOTE_KEY, height=220)

        # ── FIX 2: Investigations — buttons append to CLINICAL NOTES directly ──
        st.markdown("---")
        st.markdown("**🔬 Quick Investigations** *(click → clinical notes mein add hoga)*")
        inv_btns=["CBC","RFT","LFT","Lipid Profile","FBS","HbA1c","TSH","ECG","Chest X-Ray",
                  "Urine R/M","2D Echo","USG Abdomen","SGPT","HbsAg","Serum Creatinine",
                  "Urine Culture","Blood Culture","Sputum AFB","CBNAAT","PT/INR","D-Dimer"]
        inv_cols=st.columns(4)
        for i,inv in enumerate(inv_btns):
            if inv_cols[i%4].button(inv,key=f"inv_{inv}_{uid}",use_container_width=True):
                current_notes=st.session_state.get(NOTE_KEY,"")
                # Check if already in notes
                if inv not in current_notes:
                    # Append to notes as "Inv: CBC" style
                    inv_line = f"\nInv: {inv}"
                    st.session_state["_note_override"] = current_notes + inv_line
                    st.rerun()
        # Also keep a free-text field for custom investigations
        INV_KEY=f"inv_{uid}"
        if INV_KEY not in st.session_state: st.session_state[INV_KEY]=""
        investigations=st.text_input("Additional Investigations (type freely):",
                                     value=st.session_state[INV_KEY], key=f"inv_text_{uid}")
        st.session_state[INV_KEY]=investigations

        # ── FIX 3: Quick Drug Entry AFTER notes (below investigations) ──
        st.markdown("---")
        st.markdown("**💊 Quick Drug Entry**")
        st.caption("Drug likhein → past prescriptions se suggestions aayenge automatically")

        drug_input = st.text_input("Drug Name", key=f"drug_inp_{uid}",
                                   placeholder="e.g. Metformin, Amlodipine, Amoxicillin...")
        if drug_input and len(drug_input) >= 2:
            suggestions = db_get_drug_suggestions(drug_input, did)
            if suggestions:
                st.caption(f"🕐 Aapne pehle likha tha: **{' | '.join(suggestions[:5])}**")
                sug_cols = st.columns(min(len(suggestions[:4]), 4))
                for si, sug in enumerate(suggestions[:4]):
                    if sug_cols[si].button(sug, key=f"sug_{si}_{uid}", use_container_width=True):
                        parts = sug.split()
                        st.session_state[f"drug_inp_{uid}"] = parts[0] if parts else sug
                        st.rerun()

        dd1, dd2, dd3 = st.columns([1, 1, 1])
        drug_type   = dd1.selectbox("Type", ["Tab.", "Cap.", "Syp.", "Inj.", "Drop.",
                                              "Cream.", "Oint.", "Inhaler", "Patch"],
                                    key=f"dtype_{uid}")
        drug_dose   = dd2.text_input("Dose", key=f"ddose_{uid}", placeholder="500mg / 5ml / 1 unit")
        drug_name_mode = dd3.selectbox("Name Style", ["Generic only", "Brand only", "Generic + Brand"],
                                       key=f"dnamemode_{uid}")
        brand_name = ""
        if drug_name_mode in ["Brand only", "Generic + Brand"]:
            brand_name = st.text_input("Brand Name", key=f"dbrand_{uid}",
                                       placeholder="e.g. Glucophage, Norvasc...")
        dd4, dd5, dd6 = st.columns(3)
        drug_freq   = dd4.selectbox("Frequency",
                                    ["OD","BD","TDS","QID","HS","SOS","OD Morning",
                                     "OD Night","Weekly","Alternate Days","Monthly"],
                                    key=f"dfreq_{uid}")
        drug_timing = dd5.selectbox("Timing",
                                    ["After Breakfast","Before Breakfast","After Meals",
                                     "Before Meals","Empty Stomach","After Dinner",
                                     "At Bedtime","With Meals","Any Time"],
                                    key=f"dtime_{uid}")
        drug_days   = dd6.text_input("Days", key=f"ddays_{uid}", placeholder="30 Days / 7 Days")

        if st.button("➕ Add This Drug to Notes", key=f"adddrug_{uid}", use_container_width=True):
            if drug_input.strip():
                if drug_name_mode == "Generic only":
                    full_name = drug_input.strip()
                elif drug_name_mode == "Brand only":
                    full_name = brand_name.strip() if brand_name.strip() else drug_input.strip()
                else:
                    full_name = drug_input.strip()
                    if brand_name.strip(): full_name += f" ({brand_name.strip()})"
                existing_lines = [l for l in st.session_state.get(NOTE_KEY,"").split('\n')
                                  if re.match(r'^\d+\.', l.strip())]
                drug_num = len(existing_lines) + 1
                line = (f"\n{drug_num}. {drug_type} {full_name} {drug_dose} - "
                        f"{drug_freq} - {drug_timing} - {drug_days}")
                # FIX: Cannot directly += on a widget key.
                # Use a separate append buffer, merged into textarea on next render.
                buf_key = f"drug_buf_{uid}"
                st.session_state[buf_key] = st.session_state.get(buf_key,"") + line
                # Also update the NOTE_KEY value via a safe workaround
                current = st.session_state.get(NOTE_KEY, "")
                # Delete and recreate so widget accepts new value
                del_key = NOTE_KEY
                st.session_state["_note_override"] = current + line
                st.rerun()

        # ── Camera / Upload ────────────────────────────────────────
        st.markdown("---")
        with st.expander("📸 Camera / Upload Images & PDFs",expanded=False):
            CAM_KEY=f"cam_{uid}"
            if CAM_KEY not in st.session_state: st.session_state[CAM_KEY]=[]
            cc1,cc2=st.columns(2)
            with cc1:
                cam=st.camera_input("Take Photo",key=f"cpic_{uid}")
                if cam and st.button("➕ Add Photo",key=f"addcam_{uid}"):
                    st.session_state[CAM_KEY].append(cam); st.rerun()
                if st.session_state[CAM_KEY]:
                    st.success(f"✅ {len(st.session_state[CAM_KEY])} photo(s)")
                    if st.button("🗑️ Clear",key=f"clrcam_{uid}"):
                        st.session_state[CAM_KEY]=[]; st.rerun()
            with cc2:
                upf=st.file_uploader("Upload",type=['jpg','jpeg','png','pdf'],accept_multiple_files=True,key=f"fup_{uid}")

        all_media=list(st.session_state.get(CAM_KEY,[]))
        if upf: all_media.extend(upf)

        # Build content for AI
        past_ctx = f"\n--- PAST VISIT ({past_date}) ---\nPast Vitals: {past_vit}\nPast Rx: {past_rx}\n" if is_fu else ""
        prog_fmt = "**📈 PATIENT PROGRESS:**\n[Compare vitals vs past]\n\n" if is_fu else ""
        ai_content=[gp_prompt(pt_name,pt_vitals,dictation,sett['doc_name'],past_ctx,prog_fmt)]
        for f in all_media:
            try:
                if hasattr(f,'name') and f.name.lower().endswith('.pdf'):
                    if HAS_FITZ:
                        doc=fitz.open(stream=f.read(),filetype="pdf")
                        for pn in range(len(doc)):
                            pg=doc.load_page(pn); pix=pg.get_pixmap()
                            ai_content.append(Image.frombytes("RGB",[pix.width,pix.height],pix.samples))
                else:
                    ai_content.append(Image.open(f))
            except: pass

        if st.button("✨ Generate Prescription ➔",type="primary",use_container_width=True,key=f"gen_{uid}"):
            if not pt_name: st.warning("Patient name zaroori hai.")
            elif not (dictation or pt_vitals or all_media): st.warning("Notes, vitals ya image zaroori hai.")
            else:
                with st.spinner("⚡ AI prescription bana raha hai..."):
                    res=call_groq(ai_content,temp=0.1)
                    if res:
                        ok,miss=validate_rx(res)
                        if not ok:
                            with st.spinner(f"⚠️ Retry ({', '.join(miss)} missing)..."):
                                res=call_groq(ai_content,temp=0.1)
                        if res:
                            st.session_state[RX_KEY]=res
                            st.session_state[UPG_KEY]={}
                            st.session_state[SEL_KEY]=[]
                            st.session_state["is_followup"]=False
                            st.rerun()

    # ════════════════ RIGHT COLUMN ════════════════
    with cR:
        if RX_KEY not in st.session_state:
            st.info("👈 Patient details bharo aur **Generate Prescription** dabao.")
            return

        st.markdown("### 📄 Review & Edit — GP Prescription")
        final_rx=st.text_area("Edit here:",value=st.session_state[RX_KEY],height=380,key=f"final_{uid}")

        # Phone extraction
        pm=re.search(r'\b\d{10}\b',final_rx)
        auto_ph=pm.group(0) if pm else ""
        disp_ph=pt_phone if pt_phone else auto_ph
        if auto_ph and not pt_phone: st.success(f"📱 Auto-detected phone: **{auto_ph}**")

        # Save as template
        with st.expander("💾 Save as Template"):
            tc1,tc2,tc3=st.columns([2,1,1])
            tname=tc1.text_input("Name",key=f"tname_{uid}")
            tc2.markdown("<br>",unsafe_allow_html=True)
            if tc2.button("💊 Rx",key=f"tsrx_{uid}") and tname:
                db_save_template("Rx",tname,final_rx); st.success("Saved!")
            tc3.markdown("<br>",unsafe_allow_html=True)
            if tc3.button("🔬 Lab",key=f"tslab_{uid}") and tname:
                db_save_template("Lab",tname,final_rx); st.success("Saved!")

        if st.button("🔄 Regenerate",key=f"regen_{uid}"):
            with st.spinner():
                r=call_groq(ai_content,temp=0.1)
                if r: st.session_state[RX_KEY]=r; st.rerun()

        st.markdown("---")
        st.markdown("#### 👀 PDF Preview")
        pdf=make_rx_pdf(pt_name,pt_vitals,final_rx,investigations)
        show_pdf(pdf)

        st.markdown("---")
        ac1,ac2,ac3=st.columns(3)
        with ac1:
            save_label = "💾 Update Patient" if is_edit else "💾 Save Patient"
            if st.button(save_label,use_container_width=True,key=f"savept_{uid}"):
                if is_edit:
                    # EDIT MODE: Update existing record — NO duplicate
                    edit_id = st.session_state.get("edit_patient_id")
                    if edit_id:
                        c=_conn()
                        c.execute("UPDATE patients SET medicines=?,vitals=?,complaints=?,investigations=? WHERE id=? AND doctor_id=?",
                            (final_rx,pt_vitals,dictation,investigations,edit_id,did))
                        c.commit(); c.close()
                        st.success(f"✅ **{pt_name}** updated! (No duplicate created)")
                        st.session_state.pop("edit_patient_id",None)
                    else:
                        # No id — just save as update by name+today
                        c=_conn()
                        today=datetime.date.today().strftime("%Y-%m-%d")
                        c.execute("UPDATE patients SET medicines=?,vitals=?,investigations=? WHERE doctor_id=? AND patient_name=? AND date LIKE ?",
                            (final_rx,pt_vitals,investigations,did,pt_name,f"{today}%"))
                        c.commit(); c.close()
                        st.success(f"✅ **{pt_name}** updated!")
                else:
                    # NEW patient — duplicate check
                    existing = db_search_patients(pt_name)
                    today_str = datetime.date.today().strftime("%Y-%m-%d")
                    today_dupes = [p for p in existing
                                   if p["patient_name"].lower()==pt_name.lower()
                                   and str(p["date"])[:10]==today_str]
                    if today_dupes:
                        st.warning(f"⚠️ **{pt_name}** aaj pehle se save hai. Dobara save karna chahte hain?")
                        if st.button("✅ Haan, save karein", key=f"force_save_{uid}"):
                            result=db_save_patient(pt_name,disp_ph,pt_vitals,pt_fee,dictation,final_rx,investigations,"General Physician")
                            saved_to=[k for k,v in [("💾 Local",result.get("sqlite")),("📋 Sheet",result.get("sheet")),("☁️ Cloud",result.get("supa")=="ok")] if v]
                            st.success(f"✅ **{pt_name}** saved! → {' + '.join(saved_to) if saved_to else 'Local'}")
                    else:
                        result=db_save_patient(pt_name,disp_ph,pt_vitals,pt_fee,dictation,final_rx,investigations,"General Physician")
                        saved_to=[k for k,v in [("💾 Local",result.get("sqlite")),("☁️ Supabase",result.get("supa")=="ok"),("📋 Google Sheet",result.get("sheet"))] if v]
                        if result.get("sqlite"):
                            st.success(f"✅ **{pt_name}** saved! → {' + '.join(saved_to) if saved_to else '💾 Local'}")
                            # FIX: Auto-clear form after save so doctor can start next patient immediately
                            import time; time.sleep(0.8)
                            for k in list(st.session_state.keys()):
                                if any(k.startswith(p) for p in
                                       ["rx_main","notes_main","upgrades_main","sel_specs_main",
                                        "show_upg_main","inv_main","cam_main","opt_main",
                                        "cme_main","chat_main","_fill_","pname_main",
                                        "pphone_main","pvit_main","pfee_main","final_main","tname_main"]):
                                    st.session_state.pop(k,None)
                            for k in ["is_followup","past_vitals","past_rx","past_date","edit_patient_id","rx_main"]:
                                st.session_state.pop(k,None)
                            st.session_state["pt_mode_selection"]="new"
                            st.rerun()
                        else:
                            st.error("❌ Save failed! Check app disk access.")
                        if result.get("supa")=="no_table":
                            st.warning("⚠️ Supabase table missing. Admin → SQL Editor → run CREATE TABLE script.")
                    st.session_state.waiting_queue=[p for p in st.session_state.waiting_queue if p.get('name')!=pt_name]
        with ac2:
            st.download_button("📄 PDF",data=pdf,file_name=f"{pt_name}_Rx.pdf",mime="application/pdf",use_container_width=True,key=f"dlpdf_{uid}")
        with ac3:
            if disp_ph:
                msg=urllib.parse.quote(f"Namaste {pt_name},\nYour Rx:\n{final_rx}")
                st.link_button("💬 WhatsApp",f"https://wa.me/91{disp_ph}?text={msg}",use_container_width=True)

        # ── SPECIALTY UPGRADE ENGINE ────────────────────────────────
        st.markdown("---")
        if st.button("🔬 Specialty Upgrade Opinions ▼" if not st.session_state[SHOW_UPG] else "🔬 Specialty Upgrade ▲",
                     use_container_width=True, key=f"togupg_{uid}"):
            st.session_state[SHOW_UPG]=not st.session_state[SHOW_UPG]; st.rerun()

        if st.session_state[SHOW_UPG]:
            st.markdown("#### Select Specialties (max 3) + Optional Custom")
            sc=st.columns(3)
            for i,sn in enumerate(SPECIALTIES):
                sel=sn in st.session_state[SEL_KEY]
                if sc[i%3].button(f"{'✅ ' if sel else ''}{sn}",key=f"sb_{sn}_{uid}",use_container_width=True):
                    if sel: st.session_state[SEL_KEY].remove(sn)
                    elif len(st.session_state[SEL_KEY])<3: st.session_state[SEL_KEY].append(sn)
                    else: st.warning("Max 3")
                    st.rerun()

            custom_spec=st.text_input("➕ Custom Specialty (e.g. Rheumatology):",key=f"cspec_{uid}")
            if custom_spec and f"🔬 {custom_spec}" not in st.session_state[SEL_KEY]:
                if st.button(f"Add '{custom_spec}'",key=f"addcs_{uid}"):
                    if len(st.session_state[SEL_KEY])<3: st.session_state[SEL_KEY].append(f"🔬 {custom_spec}")
                    st.rerun()

            if st.session_state[SEL_KEY]:
                st.success(f"Selected: {', '.join(st.session_state[SEL_KEY])}")
                if st.button("🚀 Generate Upgrades",type="primary",use_container_width=True,key=f"genupg_{uid}"):
                    for sn in st.session_state[SEL_KEY]:
                        is_cust=sn.startswith("🔬 ")
                        cname=sn[2:].strip() if is_cust else ""
                        sdata=SPECIALTIES.get(sn,{})
                        if is_cust:
                            with st.spinner(f"Fetching {cname} guidelines..."):
                                g=call_groq([f"List top 5 clinical guidelines for {cname} in India. Numbered list. ENGLISH only."],temp=0.1)
                                sdata={"persona":f"Senior Specialist in {cname}","guidelines":g or f"Standard {cname} guidelines","focus":cname}
                        with st.spinner(f"Consulting {sn}..."):
                            res=call_groq([specialty_prompt(pt_name,pt_vitals,final_rx,sn,sdata,cname if is_cust else "")],temp=0.1)
                            if res:
                                ev_m=re.search(r'\*\*EVIDENCE BASE\*\*(.*?)(\*\*|$)',res,re.DOTALL)
                                ev=(ev_m.group(1).strip() if ev_m else "")
                                st.session_state[UPG_KEY][sn]={"rx":res,"evidence":ev,"saved_id":None}
                    st.rerun()

            # Show comparisons
            for sn,ud in st.session_state[UPG_KEY].items():
                st.markdown(f"---")
                st.markdown(f"### {sn} vs GP Rx")
                cc1,cc2=st.columns(2)
                with cc1:
                    st.markdown("**🟦 GP Prescription:**")
                    st.text_area("",value=st.session_state[RX_KEY],height=340,key=f"orig_{sn}_{uid}",disabled=True)
                with cc2:
                    st.markdown(f"**🟩 {sn} Upgraded:**")
                    ed=st.text_area("",value=ud["rx"],height=340,key=f"upg_{sn}_{uid}")
                    st.session_state[UPG_KEY][sn]["rx"]=ed
                if ud.get("evidence"): st.info(f"📚 Evidence: {ud['evidence']}")

                # ── Specialty Chat (NEW) ────────────────────────────
                st.markdown(f"**💬 Ask {sn} a Follow-up Question:**")
                CHAT_KEY=f"chat_{sn}_{uid}"
                if CHAT_KEY not in st.session_state: st.session_state[CHAT_KEY]=[]
                chat_q=st.text_input(f"Your question to {sn}:",key=f"cq_{sn}_{uid}",
                    placeholder=f"e.g. Should I add SGLT2 inhibitor? What if BP not controlled?")
                if st.button(f"💬 Ask {sn}",key=f"askspec_{sn}_{uid}"):
                    if chat_q.strip():
                        with st.spinner(f"Consulting {sn}..."):
                            ctx="\n".join([f"Q: {m['q']}\nA: {m['a']}" for m in st.session_state[CHAT_KEY][-3:]])
                            q_prompt=f"""You are {SPECIALTIES.get(sn,{}).get('persona',f'Senior {sn} Specialist')}.

Patient: {pt_name} | Vitals: {pt_vitals}
Current Rx: {ud['rx']}
Previous discussion:
{ctx}

Doctor's question: {chat_q}

Answer concisely and clinically. ENGLISH only. Give specific recommendation."""
                            ans=call_groq([q_prompt],temp=0.1)
                            if ans:
                                st.session_state[CHAT_KEY].append({"q":chat_q,"a":ans})
                                st.rerun()

                # Show chat history
                for msg in st.session_state[CHAT_KEY]:
                    st.markdown(f"**🩺 You:** {msg['q']}")
                    st.info(f"**{sn}:** {msg['a']}")

                ua1,ua2,ua3,ua4=st.columns(4)
                upg_pdf=make_rx_pdf(pt_name,pt_vitals,ud["rx"],specialty_label=sn)
                with ua1:
                    st.download_button(f"📄 PDF",data=upg_pdf,file_name=f"{pt_name}_{sn[:10]}_Rx.pdf",
                        mime="application/pdf",key=f"dlupg_{sn}_{uid}",use_container_width=True)
                with ua2:
                    if st.button("📋 Use as Main Rx",key=f"usemain_{sn}_{uid}",use_container_width=True):
                        st.session_state[RX_KEY]=ud["rx"]; st.success("✅ Set as main Rx!"); st.rerun()
                with ua3:
                    snote=st.text_input("⭐ Note",key=f"snote_{sn}_{uid}",placeholder="Why star?")
                    if st.button("⭐ Star",key=f"star_{sn}_{uid}",use_container_width=True):
                        sid=db_save_upgrade(pt_name,pt_vitals,st.session_state[RX_KEY],sn,ud["rx"],ud.get("evidence",""))
                        db_star_upgrade(sid,snote)
                        st.success("⭐ Starred!")
                with ua4:
                    if st.button("💾 Save",key=f"saveupg_{sn}_{uid}",use_container_width=True):
                        db_save_patient(pt_name,disp_ph,pt_vitals,pt_fee,dictation,ud["rx"],investigations,sn)
                        st.success("✅ Saved!")

        # ── Chief-only: Optimizer + CME ─────────────────────────────
        if st.session_state.role=="chief":
            st.markdown("---")
            st.markdown("### 🛠️ Drug Review & Optimizer *(Chief Only)*")
            OPT_KEY=f"opt_{uid}"
            if st.button("🔍 Deep Drug Review",type="primary",key=f"optbtn_{uid}"):
                with st.spinner():
                    res=call_groq([f"""Senior Clinical Pharmacologist reviewing this prescription:
Patient Vitals: {pt_vitals}
Prescription:
{final_rx}

**🚨 DRUG INTERACTIONS FOUND:**
[Specific interactions or "None found"]

**💊 DOSE ADJUSTMENTS:**
[Any wrong doses for these vitals/age?]

**➕ MISSING MEDICATIONS:**
[What guidelines recommend but is missing]

**🔬 MISSING INVESTIGATIONS:**
[Important tests not ordered]

**👨‍⚕️ REFERRAL:**
[Which specialist, why]

**✅ VERDICT:**
[1 sentence overall assessment]

ENGLISH only. Be specific."""],temp=0.1)
                    if res: st.session_state[OPT_KEY]=res
            if OPT_KEY in st.session_state:
                # ── A4 STUDY MODE: Full-width readable panel ─────────────
                st.markdown("---")
                st.markdown("""<div style='background:var(--color-background-secondary);
                    border:0.5px solid var(--color-border-secondary);
                    border-radius:12px; padding:20px 28px; font-family:serif;
                    line-height:1.9; font-size:15px;'>""", unsafe_allow_html=True)
                st.markdown(st.session_state[OPT_KEY])
                st.markdown("</div>", unsafe_allow_html=True)
                # Download as PDF
                opt_pdf = make_cme_pdf("Drug Review & Optimization", st.session_state[OPT_KEY])
                st.download_button("📥 Download Drug Review PDF", data=opt_pdf,
                    file_name=f"{pt_name}_DrugReview.pdf", mime="application/pdf",
                    use_container_width=True, key=f"optdl_{uid}")

            st.markdown("---")
            st.markdown("### 📚 CME Study *(Chief Only)*")
            CME_KEY=f"cme_{uid}"
            CMET_KEY=f"cmet_{uid}"
            CME_CHAT_KEY=f"cme_chat_{uid}"
            if CME_CHAT_KEY not in st.session_state: st.session_state[CME_CHAT_KEY]=[]

            if st.button("🔍 Find Study Topics",key=f"cmetopc_{uid}"):
                with st.spinner():
                    r=call_groq([f"Based on:\n{final_rx}\nSuggest 4 CME topics. Numbered list only."],temp=0.1)
                    if r:
                        raw=[l.strip() for l in r.strip().split('\n') if l.strip() and l.strip()[0].isdigit()]
                        st.session_state[f"cme_topics_{uid}"]=raw or ["1. Latest HTN Guidelines","2. DM Management","3. Lipid Targets","4. Antibiotic Stewardship"]
            if f"cme_topics_{uid}" in st.session_state:
                cm1,cm2=st.columns(2)
                with cm1:
                    st_t=st.selectbox("Topic:",st.session_state[f"cme_topics_{uid}"],key=f"cmesel_{uid}")
                    if st.button("📖 Read",key=f"cmeread_{uid}"):
                        with st.spinner("Fetching latest guidelines..."):
                            # FIX 5: Strict prompt for RECENT guidelines with comparison to old
                            cme_prompt = f"""You are a medical educator writing a CME article for Indian doctors on: '{st_t}'

STRICT RULES:
1. Start with the MOST RECENT guidelines (2022, 2023, 2024 wherever available)
2. Name the exact guideline: organization, year, document name
3. Add a section: "What Changed from Previous Guidelines" — compare with older recommendations
4. Add a section: "Key New Additions" — what is now recommended that was not before
5. Keep it practical and clinical — what doctor should DO differently
6. ENGLISH only. No Chinese. No Devanagari.

FORMAT:
**TOPIC: {st_t}**

**LATEST GUIDELINES (Year):**
[Source: Exact guideline name + year]
[Key recommendations]

**WHAT CHANGED vs OLDER GUIDELINES:**
[Old recommendation → New recommendation]

**KEY NEW ADDITIONS:**
[What's newly recommended]

**CLINICAL TAKEAWAY FOR INDIAN DOCTORS:**
[Practical points]"""
                            r=call_groq([cme_prompt],temp=0.1)
                            if r:
                                st.session_state[CME_KEY]=r
                                st.session_state[CMET_KEY]=st_t
                                st.session_state[CME_CHAT_KEY]=[]  # reset chat on new topic
                with cm2:
                    cu_t=st.text_input("Custom topic:",key=f"cmecust_{uid}")
                    if st.button("📖 Read Custom",key=f"cmerc_{uid}"):
                        if cu_t:
                            with st.spinner():
                                r=call_groq([f"""CME article for Indian doctors on: '{cu_t}'
Latest guidelines only (2022-2024). Include: what changed from old guidelines, new additions.
Format: LATEST GUIDELINES → WHAT CHANGED → NEW ADDITIONS → CLINICAL TAKEAWAY. ENGLISH only."""],temp=0.1)
                                if r:
                                    st.session_state[CME_KEY]=r
                                    st.session_state[CMET_KEY]=cu_t
                                    st.session_state[CME_CHAT_KEY]=[]
            if CME_KEY in st.session_state:
                tn=st.session_state.get(CMET_KEY,"Guidelines")
                # ── A4 STUDY MODE: Doctor-friendly reading panel ─────────
                st.markdown("---")
                st.markdown(f"#### 📄 {tn} — Study Notes")
                st.markdown("""<div style='background:var(--color-background-primary);
                    border:1px solid var(--color-border-secondary);
                    border-left:4px solid #1565C0;
                    border-radius:8px; padding:24px 32px;
                    font-size:15px; line-height:2.0;
                    max-width:100%;'>""", unsafe_allow_html=True)
                st.markdown(st.session_state[CME_KEY])
                st.markdown("</div>", unsafe_allow_html=True)
                cpdf=make_cme_pdf(tn,st.session_state[CME_KEY])
                st.download_button("📥 Download Guidelines PDF",data=cpdf,
                    file_name=f"CME_{re.sub(r'[^A-Za-z0-9]','_',tn)}.pdf",
                    mime="application/pdf",use_container_width=True,key=f"cmedl_{uid}")

                # FIX 6: CME Follow-up Chat — ask more about the topic
                st.markdown(f"**💬 Ask more about '{tn}':**")
                cme_q=st.text_input("Your question:",key=f"cmeq_{uid}",
                    placeholder="e.g. What is the target HbA1c in elderly? Any new drug class?")
                if st.button("💬 Ask",key=f"cmeask_{uid}"):
                    if cme_q.strip():
                        with st.spinner("Fetching answer..."):
                            ctx="\n".join([f"Q:{m['q']}\nA:{m['a']}" for m in st.session_state[CME_CHAT_KEY][-3:]])
                            ans=call_groq([f"""You are a medical educator. Topic: '{tn}'
Previous discussion:\n{ctx}\nDoctor asks: {cme_q}
Answer concisely with latest evidence. ENGLISH only."""],temp=0.1)
                            if ans:
                                st.session_state[CME_CHAT_KEY].append({"q":cme_q,"a":ans})
                                st.rerun()
                for msg in st.session_state[CME_CHAT_KEY]:
                    st.markdown(f"**🩺 Q:** {msg['q']}")
                    st.success(f"**A:** {msg['a']}")

# ══════════════════════════════════════════════════════════════
# 11. DOCTOR PORTAL TABS
# ══════════════════════════════════════════════════════════════
role=st.session_state.role
is_chief  = role=="chief"
is_junior = role=="junior"
is_lic    = role=="licensed"
sett=db_get_settings()

hc1,hc2=st.columns([5,1])
with hc1:
    if is_chief:
        st.title("🩺 Bharat AI Clinic — Chief Doctor")
    elif is_lic:
        lic=st.session_state.get("lic",{})
        st.title(f"🩺 {lic.get('clinic_name','Bharat AI Clinic')} — {lic.get('doctor_name','Doctor')}")
    else:
        st.title("🩺 Bharat AI Clinic — Junior Doctor")
with hc2:
    if st.button("🔒 Logout",use_container_width=True): logout()

# ── Live DB Status Badge ────────────────────────────────────────
if _supa_available():
    st.success("☁️ **Cloud DB: Connected** — Data saves permanently to Supabase", icon="✅")
else:
    st.warning("⚠️ **Cloud DB: NOT connected** — Data goes to Google Sheet only. "
               "To fix: Admin → check SUPABASE_URL & SUPABASE_KEY in Streamlit Secrets.")

_show_db_warning()
supa_auto_create_tables()  # Create tables if they don't exist
sync_from_supabase()

# ── STARTUP HEALTH CHECK — runs once per session ──────────────
if not st.session_state.get("startup_check_done"):
    st.session_state["startup_check_done"] = True
    if _supa_available():
        did_chk = _did()
        with st.spinner("☁️ Cloud DB check kar raha hai..."):
            # First check if table EXISTS by catching 404
            url_chk, _ = _get_supa_creds()
            table_exists = False
            try:
                r_chk = requests.get(
                    f"{url_chk}/rest/v1/patients?limit=1",
                    headers={**_supa_headers(), "Prefer":"return=representation"},
                    timeout=8)
                # 200 = table exists (even if empty), 404 = table missing
                table_exists = (r_chk.status_code == 200)
                chk_rows = r_chk.json() if table_exists and r_chk.text.strip().startswith("[") else []
            except:
                table_exists = False; chk_rows = []

        if not table_exists:
            st.error("❌ **Supabase 'patients' table nahi mili!** SQL Editor mein run karo:")
            st.code("""CREATE TABLE IF NOT EXISTS patients (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT DEFAULT 'chief',
  date TEXT, patient_name TEXT, phone TEXT,
  vitals TEXT, fee TEXT DEFAULT '0',
  complaints TEXT, medicines TEXT,
  investigations TEXT DEFAULT '',
  specialty TEXT DEFAULT 'General Physician'
);
ALTER TABLE patients DISABLE ROW LEVEL SECURITY;""", language="sql")
        elif not chk_rows:
            # Table exists but empty — fresh start, that's fine
            st.success("✅ Supabase connected! Table ready hai. Patients save karo — data permanently cloud mein rahega.")
        else:
            # Filter by doctor_id for display
            my_rows = [r for r in chk_rows if r.get("doctor_id","") == did_chk]
            if not my_rows:
                # Table has data but different doctor_id — fetch properly
                my_rows = supa_select("patients",
                    filters={"doctor_id": f"eq.{did_chk}"},
                    order="id.desc", limit=10)
            if my_rows:
                st.success(f"✅ Cloud DB OK — {len(my_rows)} records found. Last: **{my_rows[0].get('patient_name','')}** ({str(my_rows[0].get('date',''))[:10]})")
                with st.expander("👁️ Last saved patients", expanded=False):
                    for r in my_rows[:5]:
                        st.write(f"• {str(r.get('date',''))[:10]} | **{r.get('patient_name','')}** | ₹{r.get('fee','')}")
                # Cache to local SQLite
                c2 = _conn()
                for row in my_rows:
                    nm = row.get("patient_name",""); dt = row.get("date","")
                    if nm:
                        ex = c2.execute("SELECT id FROM patients WHERE doctor_id=? AND patient_name=? AND date=?",
                                       (did_chk, nm, dt)).fetchone()
                        if not ex:
                            c2.execute("INSERT INTO patients (doctor_id,date,patient_name,phone,vitals,fee,complaints,medicines,investigations,specialty) VALUES (?,?,?,?,?,?,?,?,?,?)",
                                (did_chk,dt,nm,row.get("phone",""),row.get("vitals",""),
                                 row.get("fee","0"),row.get("complaints",""),
                                 row.get("medicines",""),row.get("investigations",""),row.get("specialty","GP")))
                c2.commit(); c2.close()
            else:
                st.info("✅ Supabase connected. Table ready. Abhi koi patient nahi — pehla patient save karo!")
    if st.session_state.get("last_supa_err"):
        st.warning(f"⚠️ Last save error: `{st.session_state.pop('last_supa_err')}`")

# ── Tab layout ─────────────────────────────────────────────────
_scan_count = db_count_pending_scans()
_scan_label = f"📸 Scan ({_scan_count})" if _scan_count > 0 else "📸 Scan Upload"

if is_chief:
    tb2,tb3,tb4,tb5,tb6,tb_scan=st.tabs(["📝 New Rx","⭐ Starred","👥 OPD Roster","⚙️ Settings","📊 Research", _scan_label])
else:
    tb2,tb3,tb4,tb5,tb_scan=st.tabs(["📝 New Rx","⭐ Starred","👥 OPD Roster","⚙️ Settings", _scan_label])

# ── TAB 2: NEW RX — now the FIRST tab ────────────────────────
with tb2:

    # ══ TOP SECTION: New Patient OR Old Patient ══════════════════
    # This is the MOST IMPORTANT feature — old patient search right here
    pt_mode_key = "pt_mode_selection"
    if pt_mode_key not in st.session_state:
        st.session_state[pt_mode_key] = "new"

    m1, m2, m3 = st.columns([1, 1, 2])
    with m1:
        if st.button("🆕 New Patient", use_container_width=True,
                     type="primary" if st.session_state[pt_mode_key]=="new" else "secondary",
                     key="btn_new_pt"):
            st.session_state[pt_mode_key] = "new"
            # Clear everything for fresh start
            for k in list(st.session_state.keys()):
                if any(k.startswith(p) for p in ["pre_","rx_","notes_","upgrades_",
                        "sel_specs_","show_upg_","inv_","cam_","opt_","cme_","chat_"]):
                    st.session_state.pop(k, None)
            for k in ["is_followup","past_vitals","past_rx","past_date"]:
                st.session_state.pop(k, None)
            st.rerun()
    with m2:
        if st.button("👤 Old Patient", use_container_width=True,
                     type="primary" if st.session_state[pt_mode_key]=="old" else "secondary",
                     key="btn_old_pt"):
            st.session_state[pt_mode_key] = "old"
            st.rerun()
    with m3:
        if st.session_state.get("is_followup"):
            past_d = st.session_state.get("past_date","")
            past_n = st.session_state.get("pre_name","")
            st.success(f"🔄 Follow-Up loaded: **{past_n}** (Past: {past_d})")

    # ── OLD PATIENT SEARCH (shown when Old Patient is selected) ──
    if st.session_state[pt_mode_key] == "old":
        st.markdown("---")
        st.markdown("### 👤 Search Old Patient — DB + Google Sheet")
        op_q = st.text_input("🔎 Name ya Phone number likhein:",
                              key="old_pt_search",
                              placeholder="e.g. Ramesh ya 9876543210")
        if op_q and len(op_q) >= 2:
            # Search SQLite local DB + Supabase + Google Sheet automatically
            with st.spinner("🔍 DB + Google Sheet dono mein search kar raha hai..."):
                op_results = db_search_patients(op_q, include_sheet=True)
            for r in op_results: r.setdefault("_source","db")

            if op_results:
                st.success(f"🔍 {len(op_results)} record(s) mila")
                for idx, pt in enumerate(op_results):
                    src_tag = "☁️ Sheet" if pt.get("_source")=="sheet" else "📱 DB"
                    with st.expander(
                        f"👤 {pt['patient_name']}  |  "
                        f"{str(pt['date'])[:10]}  |  "
                        f"📞 {pt['phone']}  |  {src_tag}"
                    ):
                        st.write(f"**Vitals:** {pt['vitals']}  |  **Fee:** ₹{pt['fee']}")
                        if pt.get("complaints"):
                            st.caption(f"C/O: {pt['complaints'][:120]}")
                        st.info(pt["medicines"] or "No Rx data")

                        oa1, oa2, oa3 = st.columns(3)
                        with oa1:
                            if st.button("📝 Follow-Up Rx",
                                         key=f"opfu_{idx}", use_container_width=True,
                                         type="primary"):
                                st.session_state["pre_name"]    = pt["patient_name"]
                                st.session_state["pre_phone"]   = pt["phone"]
                                st.session_state["pre_fee"]     = pt.get("fee","300")
                                st.session_state["past_vitals"] = pt["vitals"]
                                st.session_state["past_rx"]     = pt["medicines"]
                                st.session_state["past_date"]   = str(pt["date"])[:10]
                                st.session_state["is_followup"] = True
                                st.session_state.pop("rx_main", None)
                                st.session_state.pop("notes_main", None)
                                st.session_state[pt_mode_key]   = "new"
                                st.rerun()
                        with oa2:
                            if st.button("✏️ Edit / Reprint",
                                         key=f"opedit_{idx}", use_container_width=True):
                                for k in list(st.session_state.keys()):
                                    if any(k.startswith(p) for p in ["upgrades_","show_upg_","cam_","opt_","cme_","chat_","notes_"]):
                                        st.session_state.pop(k,None)
                                st.session_state["pre_name"]   = pt["patient_name"]
                                st.session_state["pre_phone"]  = pt["phone"]
                                st.session_state["pre_vitals"] = pt["vitals"]
                                st.session_state["pre_fee"]    = pt.get("fee","300")
                                st.session_state["rx_main"]    = pt["medicines"]
                                st.session_state["edit_patient_id"] = pt.get("id")
                                st.session_state[pt_mode_key]  = "new"
                                st.rerun()
                        with oa3:
                            old_pdf = make_rx_pdf(
                                pt["patient_name"], pt["vitals"], pt["medicines"]
                            )
                            st.download_button("📄 Download Old PDF",
                                data=old_pdf,
                                file_name=f"{pt['patient_name']}_OldRx.pdf",
                                mime="application/pdf",
                                key=f"opdl_{idx}",
                                use_container_width=True)
            else:
                st.warning(f"'{op_q}' ka koi record nahi mila — DB ya Google Sheet mein.")
        st.markdown("---")

    # ── NEW RX FORM (shown when New Patient or after loading Old Patient) ──
    if st.session_state[pt_mode_key] == "new":
        render_rx_form(uid="main")

# ── TAB 3: STARRED LEARNING ────────────────────────────────────
with tb3:
    st.markdown("### ⭐ Starred Specialty Comparisons")
    starred=db_get_starred()
    if not starred:
        st.info("Koi starred case nahi. Specialty upgrade generate karo aur ⭐ dabao.")
    else:
        for su in starred:
            with st.expander(f"⭐ {su['patient_name']} | {su['specialty']} | {str(su['date'])[:10]} | {su.get('star_note','')}"):
                sc1,sc2=st.columns(2)
                with sc1:
                    st.markdown("**🟦 Original GP Rx:**")
                    st.text_area("",value=su['original_rx'],height=260,key=f"so_{su['id']}",disabled=True)
                with sc2:
                    st.markdown(f"**🟩 {su['specialty']}:**")
                    st.text_area("",value=su['upgraded_rx'],height=260,key=f"su_{su['id']}",disabled=True)
                if su.get('evidence'): st.info(f"📚 {su['evidence']}")
                spdf=make_rx_pdf(su['patient_name'],su.get('vitals',''),
                    f"=== GP Rx ===\n{su['original_rx']}\n\n=== {su['specialty']} ===\n{su['upgraded_rx']}",
                    specialty_label=su['specialty'])
                st.download_button("📥 PDF",data=spdf,file_name=f"Star_{su['patient_name']}.pdf",
                    mime="application/pdf",key=f"sdl_{su['id']}")

# ── TAB 4: OPD ROSTER ─────────────────────────────────────────
with tb4:
    st.markdown("### 🔍 Patient Search")
    sq=st.text_input("🔎 Name ya Phone:",key="sq",placeholder="Ramesh ya 9876543210")
    if sq and len(sq)>=2:
        res=db_search_patients(sq)  # already filtered by doctor_id
        if res:
            st.success(f"🔍 {len(res)} record(s) mila")
            for idx,pt in enumerate(res):
                with st.expander(f"👤 {pt['patient_name']} | {str(pt['date'])[:10]} | {pt['phone']}"):
                    st.write(f"Vitals: {pt['vitals']} | Fee: ₹{pt['fee']}")
                    if pt.get('complaints'): st.caption(f"C/O: {pt['complaints'][:100]}")
                    st.info(pt['medicines'])
                    rb1,rb2=st.columns(2)
                    with rb1:
                        # ── FIXED FOLLOW-UP ──────────────────────────────────
                        if st.button("📝 Follow-Up",key=f"sfu_{idx}"):
                            st.session_state["pre_name"]    = pt["patient_name"]
                            st.session_state["pre_phone"]   = pt["phone"]
                            st.session_state["pre_fee"]     = pt["fee"]
                            st.session_state["past_vitals"] = pt["vitals"]
                            st.session_state["past_rx"]     = pt["medicines"]
                            st.session_state["past_date"]   = str(pt["date"])[:10]
                            st.session_state["is_followup"] = True
                            st.session_state.pop("rx_main",None)
                            st.session_state["pt_mode_selection"] = "new"
                            st.rerun()
                    with rb2:
                        if st.button("✏️ Edit Rx",key=f"sedit_{idx}"):
                            st.session_state["pre_name"]   = pt["patient_name"]
                            st.session_state["pre_phone"]  = pt["phone"]
                            st.session_state["pre_vitals"] = pt["vitals"]
                            st.session_state["pre_fee"]    = pt["fee"]
                            st.session_state["rx_main"]    = pt["medicines"]
                            st.session_state["pt_mode_selection"] = "new"
                            st.rerun()
        else:
            st.warning(f"'{sq}' ka koi record nahi mila.")

    st.markdown("---")
    st.markdown("### 📅 Daily OPD Roster")

    # ── Supabase live debug — show exactly what cloud has ──────
    if _supa_available():
        with st.expander("🔍 Cloud DB Debug — click to verify data in Supabase", expanded=False):
            if st.button("🔄 Test Supabase — Show Exact HTTP Response", key="supa_debug_btn"):
                did_debug = _did()
                url_d, key_d = _get_supa_creds()
                st.write(f"Testing doctor_id = `{did_debug}`")
                # RAW HTTP test — no filter first
                try:
                    r1 = requests.get(
                        f"{url_d}/rest/v1/patients?limit=5&order=id.desc",
                        headers={**_supa_headers(), "Prefer":"return=representation"},
                        timeout=10)
                    st.write(f"**HTTP Status (no filter):** {r1.status_code}")
                    if r1.status_code == 200:
                        all_data = r1.json()
                        st.write(f"**Total rows in table:** {len(all_data)}")
                        if all_data:
                            st.write("**Sample row doctor_ids:**", [r.get("doctor_id","?") for r in all_data[:5]])
                    else:
                        st.error(f"Error: {r1.text[:300]}")
                except Exception as e:
                    st.error(f"Connection failed: {e}")
                # Test WITH filter
                try:
                    r2 = requests.get(
                        f"{url_d}/rest/v1/patients?doctor_id=eq.{did_debug}&limit=5&order=id.desc",
                        headers={**_supa_headers(), "Prefer":"return=representation"},
                        timeout=10)
                    st.write(f"**HTTP Status (doctor_id=eq.{did_debug}):** {r2.status_code}")
                    if r2.status_code == 200:
                        my_data = r2.json()
                        st.write(f"**Rows for your doctor_id:** {len(my_data)}")
                        if my_data:
                            st.success(f"✅ Found {len(my_data)} patients!")
                            for r in my_data[:3]:
                                st.write(f"• {r.get('date','')[:10]} | {r.get('patient_name','')} | ₹{r.get('fee','')}")
                        else:
                            st.warning(f"No data for doctor_id='{did_debug}'")
                    else:
                        st.error(f"Error: {r2.text[:300]}")
                except Exception as e:
                    st.error(f"Connection failed: {e}")

            # NEW: Direct test insert
            if st.button("🧪 Test INSERT — Save 1 test row to Supabase", key="supa_test_insert"):
                did_debug = _did()
                url_d, _ = _get_supa_creds()
                test_data = {
                    "doctor_id": did_debug,
                    "date": datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                    "patient_name": "SUPABASE_TEST_ROW",
                    "phone": "0000000000",
                    "vitals": "Test", "fee": "0",
                    "complaints": "Test", "medicines": "Test",
                    "investigations": "", "specialty": "Test"
                }
                try:
                    r_ins = requests.post(
                        f"{url_d}/rest/v1/patients",
                        headers={**_supa_headers(), "Prefer": "return=minimal"},
                        json=test_data, timeout=10)
                    st.write(f"**INSERT HTTP Status:** {r_ins.status_code}")
                    st.write(f"**Response:** `{r_ins.text[:300] or '(empty = success)'}`")
                    if r_ins.status_code in [200, 201]:
                        st.success("✅ INSERT worked! Now check Fetch Roster — test row should appear.")
                    else:
                        st.error(f"❌ INSERT failed! Status: {r_ins.status_code}")
                        st.error(f"Error detail: {r_ins.text}")
                        if "42501" in r_ins.text or "permission" in r_ins.text.lower():
                            st.warning("🔑 RLS blocking insert. Run this SQL:")
                            st.code("ALTER TABLE patients DISABLE ROW LEVEL SECURITY;", language="sql")
                        if "relation" in r_ins.text.lower() or "exist" in r_ins.text.lower():
                            st.warning("Table nahi bani. Neeche ka SQL run karo:")
                except Exception as e:
                    st.error(f"Exception: {e}")

            st.markdown("---")
            st.markdown("**📋 Complete Setup SQL — ek baar run karo Supabase SQL Editor mein:**")
            st.code("""
-- Run this ONCE in Supabase SQL Editor
CREATE TABLE IF NOT EXISTS patients (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT DEFAULT 'chief',
  date TEXT, patient_name TEXT, phone TEXT,
  vitals TEXT, fee TEXT DEFAULT '0',
  complaints TEXT, medicines TEXT,
  investigations TEXT DEFAULT '',
  specialty TEXT DEFAULT 'General Physician'
);
CREATE TABLE IF NOT EXISTS settings (
  doctor_id TEXT PRIMARY KEY,
  clinic_name TEXT, doc_name TEXT,
  doc_subtitle TEXT, doc_degree TEXT DEFAULT '',
  doc_reg_no TEXT DEFAULT '', doc_email TEXT DEFAULT '',
  doc_phone TEXT DEFAULT '', clinic_address TEXT DEFAULT '',
  doc_extra_quals TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS drug_history (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT, drug_name TEXT, dose TEXT,
  use_count INTEGER DEFAULT 1, last_used TEXT
);
CREATE TABLE IF NOT EXISTS specialty_upgrades (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT, date TEXT, patient_name TEXT, vitals TEXT,
  original_rx TEXT, specialty TEXT, upgraded_rx TEXT,
  evidence TEXT, is_starred INTEGER DEFAULT 0, star_note TEXT DEFAULT ''
);
CREATE TABLE IF NOT EXISTS templates (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT, category TEXT, name TEXT, content TEXT
);
CREATE TABLE IF NOT EXISTS licenses (
  id BIGSERIAL PRIMARY KEY,
  doctor_id TEXT UNIQUE, doctor_name TEXT, doctor_email TEXT,
  doctor_phone TEXT, pin TEXT UNIQUE, clinic_name TEXT,
  specialty TEXT, expiry_date TEXT, is_active INTEGER DEFAULT 1,
  created_date TEXT, notes TEXT DEFAULT ''
);
-- Disable RLS for all tables (REQUIRED)
ALTER TABLE patients DISABLE ROW LEVEL SECURITY;
ALTER TABLE settings DISABLE ROW LEVEL SECURITY;
ALTER TABLE drug_history DISABLE ROW LEVEL SECURITY;
ALTER TABLE specialty_upgrades DISABLE ROW LEVEL SECURITY;
ALTER TABLE templates DISABLE ROW LEVEL SECURITY;
ALTER TABLE licenses DISABLE ROW LEVEL SECURITY;
""", language="sql")

    df1,df2=st.columns([3,1])
    with df1:
        date_f=st.radio("Range:",["Today","Yesterday","Last 5 Days","All Time"],horizontal=True)
    with df2:
        st.markdown("<br>",unsafe_allow_html=True)
        if st.button("📥 Fetch Roster",type="primary",use_container_width=True):
            today = datetime.date.today()
            combined = []
            sheet_pts = []  # always init here

            # Source 1: Supabase (most reliable)
            if _supa_available():
                try:
                    did_r = _did()
                    supa_pts = supa_select("patients",
                        filters={"doctor_id": f"eq.{did_r}"},
                        order="id.desc", limit=1000)
                    for p in supa_pts:
                        combined.append({
                            "id": p.get("id",0),
                            "doctor_id": did_r,
                            "date": p.get("date",""),
                            "patient_name": p.get("patient_name",""),
                            "phone": p.get("phone",""),
                            "vitals": p.get("vitals",""),
                            "fee": p.get("fee","0"),
                            "complaints": p.get("complaints",""),
                            "medicines": p.get("medicines",""),
                            "investigations": p.get("investigations",""),
                            "specialty": p.get("specialty","GP"),
                            "_source": "☁️ Cloud"
                        })
                except Exception as e:
                    st.warning(f"Supabase fetch error: {e}")

            # Source 2: SQLite local cache
            try:
                db_pts = db_get_patients_filter("All Time")
                existing_names_dates = {
                    f"{p.get('patient_name','').lower()}_{str(p.get('date',''))[:10]}"
                    for p in combined}
                for p in db_pts:
                    key = f"{p.get('patient_name','').lower()}_{str(p.get('date',''))[:10]}"
                    if key not in existing_names_dates:
                        p["_source"] = "📱 Local"
                        combined.append(p)
            except Exception as e:
                st.warning(f"Local DB error: {e}")

            # Source 3: Google Sheet (legacy backup)
            try:
                with st.spinner("☁️ Google Sheet se purana data check kar raha hai..."):
                    all_sheet, sheet_err = fetch_sheet_data()
                if all_sheet:
                    existing_nd = {
                        f"{p.get('patient_name','').lower()}_{str(p.get('date',''))[:10]}"
                        for p in combined}
                    for row in all_sheet:
                        key = f"{row.get('patient_name','').lower()}_{str(row.get('date',''))[:10]}"
                        if key not in existing_nd:
                            row["_source"] = "📋 Sheet"
                            sheet_pts.append(row)
                    combined.extend(sheet_pts)
            except Exception as e:
                pass  # Sheet error is non-fatal

            # Date filter
            if date_f != "All Time":
                filtered = []
                for p in combined:
                    try:
                        d = datetime.date.fromisoformat(str(p.get("date",""))[:10])
                        if date_f=="Today" and d==today: filtered.append(p)
                        elif date_f=="Yesterday" and d==today-timedelta(days=1): filtered.append(p)
                        elif date_f=="Last 5 Days" and 0<=(today-d).days<=5: filtered.append(p)
                    except: pass
                combined = filtered

            # Sort and deduplicate
            seen = set(); deduped = []
            for p in sorted(combined, key=lambda x: str(x.get("date",""))[:10], reverse=True):
                key = f"{p.get('patient_name','').lower()}_{str(p.get('date',''))[:10]}"
                if key not in seen:
                    seen.add(key); deduped.append(p)

            st.session_state.roster_data = deduped
            c_cnt = sum(1 for p in deduped if "Cloud" in str(p.get("_source","")))
            l_cnt = sum(1 for p in deduped if "Local" in str(p.get("_source","")))
            s_cnt = sum(1 for p in deduped if "Sheet" in str(p.get("_source","")))

            if not deduped:
                st.warning("Koi patient nahi mila. Supabase SQL Editor mein CREATE TABLE run karo — Admin panel mein instructions hain.")
            else:
                st.success(f"✅ **{len(deduped)} records** (☁️ {c_cnt} Cloud + 📱 {l_cnt} Local + 📋 {s_cnt} Sheet)")

    if st.session_state.get("roster_data"):
        pts=st.session_state.roster_data
        m1,m2=st.columns(2)
        m1.metric("👥 Patients",len(pts))
        m2.metric("💰 The Galla",f"₹{sum(_clean_fee(p['fee']) for p in pts):,}")
        st.markdown("---")
        for idx,pt in enumerate(pts):
            src_tag = "☁️ Sheet" if pt.get("_source")=="sheet" else "📱 DB"
            with st.expander(f"👤 {pt['patient_name']} | {str(pt['date'])[:10]} | ₹{pt['fee']} | {pt.get('specialty','GP')} | {src_tag}"):
                st.write(f"📞 {pt['phone']} | Vitals: {pt['vitals']}")
                if pt.get('complaints'): st.caption(f"C/O: {pt['complaints'][:100]}")
                st.info(pt['medicines'])

                # ── PATIENT VISIT HISTORY TIMELINE ────────────────────
                all_visits = db_search_patients(pt['patient_name'])
                if len(all_visits) > 1:
                    with st.expander(f"📈 {pt['patient_name']} — All {len(all_visits)} Visits (Timeline)", expanded=False):
                        st.caption("Most recent → oldest")
                        # Vitals chart data
                        bp_sys_list, bp_dates, sugar_list, weight_list = [], [], [], []
                        for v in reversed(all_visits):
                            vd = _extract_vitals_dict(v.get("vitals",""))
                            date_label = str(v.get("date",""))[:10]
                            bp_dates.append(date_label)
                            bp_sys_list.append(vd.get("sys", None))
                            sugar_list.append(vd.get("sugar", None))
                            weight_list.append(vd.get("weight", None))

                        # Show mini charts if we have data
                        has_bp = any(x is not None for x in bp_sys_list)
                        has_sg = any(x is not None for x in sugar_list)
                        has_wt = any(x is not None for x in weight_list)
                        if has_bp or has_sg or has_wt:
                            import pandas as pd
                            tc1, tc2, tc3 = st.columns(3)
                            if has_bp:
                                bp_vals = [x for x in bp_sys_list if x is not None]
                                bp_lbls = [bp_dates[i] for i,x in enumerate(bp_sys_list) if x is not None]
                                tc1.markdown("**BP Systolic trend**")
                                tc1.line_chart(pd.DataFrame({"BP (mmHg)": bp_vals}, index=bp_lbls))
                            if has_sg:
                                sg_vals = [x for x in sugar_list if x is not None]
                                sg_lbls = [bp_dates[i] for i,x in enumerate(sugar_list) if x is not None]
                                tc2.markdown("**Sugar trend**")
                                tc2.line_chart(pd.DataFrame({"Sugar (mg/dL)": sg_vals}, index=sg_lbls))
                            if has_wt:
                                wt_vals = [x for x in weight_list if x is not None]
                                wt_lbls = [bp_dates[i] for i,x in enumerate(weight_list) if x is not None]
                                tc3.markdown("**Weight trend**")
                                tc3.line_chart(pd.DataFrame({"Weight (kg)": wt_vals}, index=wt_lbls))

                        # All visits list
                        for vidx, v in enumerate(all_visits):
                            v_date = str(v.get("date",""))[:10]
                            v_spec = v.get("specialty","GP")
                            v_fee  = v.get("fee","0")
                            st.markdown(f"**Visit {len(all_visits)-vidx}** — {v_date} | {v_spec} | ₹{v_fee}")
                            st.write(f"Vitals: {v.get('vitals','—')}")
                            with st.expander(f"📋 Prescription — {v_date}", expanded=False):
                                st.text(v.get("medicines","No data"))
                            st.divider()
                rb1,rb2,rb3=st.columns(3)
                with rb1:
                    if st.button("📝 Follow-Up",key=f"rfu_{idx}"):
                        for k in list(st.session_state.keys()):
                            if any(k.startswith(p) for p in ["rx_","notes_","upgrades_","show_upg_","inv_","cam_","opt_","cme_","chat_"]):
                                st.session_state.pop(k,None)
                        st.session_state["pre_name"]    = pt["patient_name"]
                        st.session_state["pre_phone"]   = pt["phone"]
                        st.session_state["pre_fee"]     = pt.get("fee","200")
                        st.session_state["past_vitals"] = pt["vitals"]
                        st.session_state["past_rx"]     = pt["medicines"]
                        st.session_state["past_complaints"] = pt.get("complaints","")
                        st.session_state["past_date"]   = str(pt["date"])[:10]
                        st.session_state["is_followup"] = True
                        st.session_state["pt_mode_selection"] = "new"
                        st.rerun()
                with rb2:
                    if st.button("✏️ Edit",key=f"redit_{idx}"):
                        for k in list(st.session_state.keys()):
                            if any(k.startswith(p) for p in ["rx_","notes_","upgrades_","show_upg_","cam_"]):
                                st.session_state.pop(k,None)
                        st.session_state["pre_name"]   = pt["patient_name"]
                        st.session_state["pre_phone"]  = pt["phone"]
                        st.session_state["pre_vitals"] = pt["vitals"]
                        st.session_state["pre_fee"]    = pt["fee"]
                        st.session_state["rx_main"]    = pt["medicines"]
                        st.session_state["pt_mode_selection"] = "new"
                        st.rerun()
                with rb3:
                    # Quick inline Rx update — NO tab switch needed
                    inline_key = f"inline_edit_{idx}"
                    if st.button("📋 Quick Update",key=f"rqedit_{idx}"):
                        st.session_state[inline_key] = not st.session_state.get(inline_key, False)
                        st.rerun()
                if st.session_state.get(inline_key, False):
                    st.markdown("**📋 Quick Rx Update — same window:**")
                    new_rx = st.text_area("Edit prescription here:",
                                          value=pt.get("medicines",""), height=200,
                                          key=f"quick_rx_{idx}")
                    new_vit = st.text_input("Update Vitals (optional):",
                                             value=pt.get("vitals",""),
                                             key=f"quick_vit_{idx}")
                    qc1,qc2=st.columns(2)
                    with qc1:
                        if st.button("💾 Save Update",type="primary",key=f"qsave_{idx}"):
                            did2=_did()
                            c=_conn()
                            c.execute("UPDATE patients SET medicines=?,vitals=? WHERE id=? AND doctor_id=?",
                                      (new_rx, new_vit, pt.get("id",0), did2))
                            c.commit(); c.close()
                            # Also push to Google Sheet
                            if WEBHOOK_URL.startswith("http"):
                                try:
                                    requests.post(WEBHOOK_URL, json={
                                        "patient_name":pt["patient_name"],"phone":pt.get("phone",""),
                                        "vitals":new_vit,"fee":pt.get("fee","0"),
                                        "complaints":pt.get("complaints",""),"diagnosis":"Updated",
                                        "medicines":new_rx,"advice":"Included",
                                        "follow_up":"Updated","date":datetime.datetime.now().strftime("%Y-%m-%d %H:%M"),
                                        "doctor_id":did2
                                    }, timeout=5)
                                except: pass
                            st.success(f"✅ {pt['patient_name']} updated!")
                            st.session_state.pop(inline_key, None)
                            st.session_state.pop("roster_data", None)  # force reload
                            st.rerun()
                    with qc2:
                        # Download updated PDF instantly
                        upd_pdf=make_rx_pdf(pt["patient_name"],new_vit,new_rx)
                        st.download_button("📄 PDF",data=upd_pdf,
                            file_name=f"{pt['patient_name']}_Updated.pdf",
                            mime="application/pdf",key=f"qpdf_{idx}",
                            use_container_width=True)

# ── TAB 5: SETTINGS ───────────────────────────────────────────
with tb5:
    st.markdown("### ⚙️ Clinic & Doctor Settings")
    cur = db_get_settings()
    ss1, ss2 = st.columns(2, gap="large")

    with ss1:
        st.markdown("#### 🏥 Clinic Information")
        nc  = st.text_input("Clinic Name *",      value=cur["clinic_name"],    key="t_cn")
        nca = st.text_area("Clinic Address",       value=cur["clinic_address"], key="t_ca", height=80,
                            placeholder="e.g. 23, Civil Lines, Near SBI Bank, Moradabad - 244001")
        st.markdown("#### 👨‍⚕️ Doctor Profile")
        nd  = st.text_input("Doctor Full Name *",  value=cur["doc_name"],      key="t_dn",
                            placeholder="e.g. Dr. G.S. Gill")
        nd2 = st.text_input("Primary Degree(s) *", value=cur["doc_degree"],    key="t_deg",
                            placeholder="e.g. MBBS, PGDCCP, MD (Medicine)")
        ns  = st.text_input("Specialty / Designation", value=cur["doc_subtitle"], key="t_ds",
                            placeholder="e.g. CARDIO-PHYSICIAN (Non-Invasive)")
        nr  = st.text_input("Registration Number", value=cur["doc_reg_no"],    key="t_reg",
                            placeholder="e.g. DMC/R/12345 or UP Medical Council No.")
        nc2 = st.text_input("Doctor Phone",        value=cur["doc_phone"],     key="t_dp",
                            placeholder="e.g. 9876543210")
        nc3 = st.text_input("Doctor Email",        value=cur["doc_email"],     key="t_de",
                            placeholder="e.g. drgill@clinic.com")

        if st.button("💾 Save All Settings", type="primary", key="saveset", use_container_width=True):
            doc_extra = st.session_state.get("t_eq", cur.get("doc_extra_quals",""))
            db_save_settings(nc, nd, ns, nd2, nr, nc3, nc2, nca, doc_extra)
            supa_err = st.session_state.get("last_supa_err","")
            if supa_err:
                st.warning(f"⚠️ Supabase error: `{supa_err}`")
                st.info("Supabase → SQL Editor mein settings table create karo.")
            else:
                st.success("✅ Settings saved permanently!")
            st.rerun()

        if st.button("🔍 Verify Cloud Save", key="verify_sett", use_container_width=True):
            did_v=_did(); url_v,_=_get_supa_creds()
            try:
                rv=requests.get(f"{url_v}/rest/v1/settings?doctor_id=eq.{did_v}&limit=1",
                    headers={**_supa_headers(),"Prefer":"return=representation"},timeout=8)
                if rv.status_code==200 and rv.json():
                    r=rv.json()[0]
                    st.success(f"✅ Cloud mein mila: **{r.get('doc_name','')}** | **{r.get('clinic_name','')}** | {r.get('doc_degree','')}")
                else:
                    st.error(f"❌ Cloud mein nahi mili. Run this SQL in Supabase:")
                    st.code("""CREATE TABLE IF NOT EXISTS settings (
  doctor_id TEXT PRIMARY KEY,
  clinic_name TEXT, doc_name TEXT, doc_subtitle TEXT,
  doc_degree TEXT DEFAULT '', doc_reg_no TEXT DEFAULT '',
  doc_email TEXT DEFAULT '', doc_phone TEXT DEFAULT '',
  clinic_address TEXT DEFAULT '', doc_extra_quals TEXT DEFAULT ''
);
ALTER TABLE settings DISABLE ROW LEVEL SECURITY;""", language="sql")
            except Exception as e:
                st.error(f"Error: {e}")

    with ss2:
        st.markdown("#### 🎓 Additional Qualifications & Fellowships")
        st.caption("Yahan aap apni additional degrees, fellowships, certifications likhein — PDF prescription header mein dikhengi.")
        doc_extra = st.text_area("Additional Qualifications",
                                  value=cur["doc_extra_quals"], key="t_eq", height=180,
                                  placeholder="""e.g.
Fellowship in Cardiology (AIIMS Delhi)
Certificate in Diabetology (RSSDI)
Diploma in Clinical Cardio-Pulmonology
Member — Indian Medical Association (IMA)
Member — API (Association of Physicians of India)""")

        # Live PDF Preview of letterhead
        st.markdown("---")
        st.markdown("#### 👀 Prescription Header Preview")
        sett_preview = db_get_settings()
        header_lines = [
            f"🏥 **{nc or sett_preview['clinic_name']}**",
            f"👨‍⚕️ {nd or sett_preview['doc_name']}",
        ]
        if nd2: header_lines.append(f"🎓 {nd2}")
        if ns:  header_lines.append(f"🔬 {ns}")
        if doc_extra:
            for line in doc_extra.strip().split('\n'):
                if line.strip(): header_lines.append(f"   {line.strip()}")
        if nr:  header_lines.append(f"📋 Reg. No: {nr}")
        if nc2: header_lines.append(f"📞 {nc2}")
        if nc3: header_lines.append(f"✉️ {nc3}")
        if nca: header_lines.append(f"📍 {nca.split(chr(10))[0]}")

        st.markdown(
            "<div style='background:var(--color-background-secondary);border:1px solid var(--color-border-secondary);"
            "border-radius:8px;padding:16px 20px;font-size:13px;line-height:1.8;'>"
            + "<br>".join(header_lines) +
            "</div>",
            unsafe_allow_html=True
        )

        st.markdown("---")
        st.markdown("#### 📑 My Templates")
        tcat = st.radio("Category:", ["Medicines (Rx)", "Labs"], horizontal=True, key="tcat")
        tdb  = "Rx" if "Rx" in tcat else "Lab"
        tdict = db_get_templates(tdb)
        with st.container(border=True):
            ntn = st.text_input("Template Name", key="ntn")
            ntb = st.text_area("Content", height=80, key="ntb")
            if st.button("💾 Save Template", type="primary", key="ntsave"):
                if ntn and ntb:
                    db_save_template(tdb, ntn, ntb); st.success(f"✅ '{ntn}' saved!"); st.rerun()
        sel_e = st.selectbox("Edit/Delete:", ["-- Select --"] + list(tdict.keys()), key="sel_e")
        if sel_e != "-- Select --":
            etb = st.text_area("Edit:", value=tdict[sel_e], height=80, key=f"et_{sel_e}")
            ec1, ec2 = st.columns(2)
            if ec1.button("💾 Update", type="primary", key="etupd"):
                db_save_template(tdb, sel_e, etb); st.success("✅"); st.rerun()
            if ec2.button("🗑️ Delete", key="etdel"):
                db_delete_template(sel_e); st.warning("Deleted"); st.rerun()

# ── TAB 6: RESEARCH AGENT (Chief only) ───────────────────────
if is_chief:
    with tb6:
        st.markdown("### 📊 Clinical Research Agent")
        rq1,rq2=st.columns([3,1])
        rq=rq1.text_input("💬 Ask:",placeholder="Most common diagnosis? Top drugs? Revenue?",key="rq")
        run_r=rq2.button("🧠 Analyze",type="primary",key="runr")
        sc1,sc2,sc3=st.columns(3)
        if sc1.button("📊 Disease Distribution"): rq="Most common diseases/diagnoses?"
        if sc2.button("💊 Top Medications"):      rq="Top 5 prescribed medications?"
        if sc3.button("💰 Revenue Summary"):       rq="Total revenue, avg fee, patient count?"

        if run_r and rq:
            all_p=db_get_patients_filter("All Time")
            total_r=sum(_clean_fee(p['fee']) for p in all_p)
            sample="\n".join([f"[{p['date'][:10]}|{p.get('specialty','GP')}|Vitals:{p['vitals']}|Rx:{p['medicines'][:60]}]" for p in all_p[:150]])
            starred=db_get_starred()
            star_s="\n".join([f"- {s['specialty']} for {s['patient_name']}: {s.get('star_note','')}" for s in starred[:15]])
            with st.spinner("Analyzing..."):
                resp=call_groq([f"""Clinical Data Analyst for {sett['doc_name']}.
TOTAL PATIENTS: {len(all_p)}
TOTAL REVENUE: Rs.{total_r:,}
STARRED CASES: {len(starred)}

DATA:
{sample}

STARRED:
{star_s or "None"}

QUERY: "{rq}"
RULES: ENGLISH only. Use actual data. Be specific."""],model="llama-3.3-70b-versatile",temp=0.1)
                if resp:
                    st.success(f"✅ {len(all_p)} patients analyzed")
                    st.markdown(resp)
                    rpdf=make_cme_pdf("Research Report",resp)
                    st.download_button("📥 PDF",data=rpdf,file_name="Research.pdf",mime="application/pdf")

# ── SCAN UPLOAD TAB ────────────────────────────────────────────
with tb_scan:
    scan_sub1, scan_sub2 = st.tabs([
        "📋 Prescription Batch Scan",
        "🔬 Lab Report AI Analyzer"
    ])

    with scan_sub1:
        st.markdown("### 📸 Batch Scan — Prescriptions / Old Records")
        st.info("Photos ya PDF upload → AI reads → Approve → Database mein save")

        sc_tab1, sc_tab2 = st.tabs([
            "📤 Upload Photos",
            f"✅ Review & Approve ({_scan_count} pending)"
        ])

        with sc_tab1:
            st.caption("Multiple photos ya PDF ek saath select kar sakte hain")

            # FIX: Store camera photo in session buffer to prevent crash on rerun
            cam_scan = st.camera_input("Camera se photo lein", key="scan_cam")
            if cam_scan:
                st.session_state.setdefault("scan_cam_buffer", [])
                cam_bytes = cam_scan.getvalue()
                already = any(cam_bytes == b for b in st.session_state["scan_cam_buffer"])
                if not already:
                    st.session_state["scan_cam_buffer"].append(cam_bytes)

            if st.session_state.get("scan_cam_buffer"):
                st.success(f"📷 {len(st.session_state['scan_cam_buffer'])} camera photo(s) ready")
                if st.button("🗑️ Clear Camera Photos", key="clr_scan_cam"):
                    st.session_state.pop("scan_cam_buffer", None); st.rerun()

            # Gallery + PDF upload
            up_files = st.file_uploader(
                "Ya gallery/PDF upload karein",
                type=["jpg","jpeg","png","webp","pdf"],
                accept_multiple_files=True,
                key="scan_upload_files"
            )

            all_scan_files = list(up_files) if up_files else []
            for cam_b in st.session_state.get("scan_cam_buffer", []):
                all_scan_files.append(io.BytesIO(cam_b))

            if all_scan_files:
                st.success(f"✅ **{len(all_scan_files)} file(s)** ready to process")
                if st.button("🚀 Process All — AI Padhe", type="primary",
                              use_container_width=True, key="scan_process_btn"):
                    if not _api_key():
                        st.error("❌ Groq API Key nahi hai.")
                    else:
                        prog = st.progress(0); stat = st.empty()
                        total_s = len(all_scan_files); done_s = 0
                        import time
                        for i, sf in enumerate(all_scan_files):
                            stat.info(f"🔄 Reading file {i+1}/{total_s}...")
                            prog.progress(i/total_s)
                            try:
                                fname = getattr(sf, "name", "")
                                if fname.lower().endswith(".pdf") and HAS_FITZ:
                                    import fitz as _fitz
                                    if hasattr(sf,"seek"): sf.seek(0)
                                    doc_f = _fitz.open(stream=sf.read(), filetype="pdf")
                                    for pn in range(len(doc_f)):
                                        pg = doc_f.load_page(pn)
                                        pix = pg.get_pixmap(dpi=150)
                                        img = Image.frombytes("RGB",[pix.width,pix.height],pix.samples)
                                        data = call_groq_scan(img)
                                        buf2 = io.BytesIO(); img.convert("RGB").save(buf2,"JPEG")
                                        b64 = base64.b64encode(buf2.getvalue()).decode()
                                        meds = ""
                                        if data.get("diagnosis"):  meds += f"DIAGNOSIS: {data['diagnosis']}\n\n"
                                        if data.get("medicines"):  meds += f"MEDICATIONS:\n{data['medicines']}\n"
                                        if data.get("follow_up"):  meds += f"\nFOLLOW-UP: {data['follow_up']}"
                                        db_save_scan(b64, data.get("patient_name",""), data.get("phone",""),
                                                     data.get("vitals",""), data.get("fee","0"),
                                                     data.get("complaints",""), meds, data.get("investigations",""))
                                        done_s += 1
                                else:
                                    if hasattr(sf,"seek"): sf.seek(0)
                                    img = Image.open(sf)
                                    data = call_groq_scan(img)
                                    buf2 = io.BytesIO(); img.convert("RGB").save(buf2,"JPEG")
                                    b64 = base64.b64encode(buf2.getvalue()).decode()
                                    meds = ""
                                    if data.get("diagnosis"):  meds += f"DIAGNOSIS: {data['diagnosis']}\n\n"
                                    if data.get("medicines"):  meds += f"MEDICATIONS:\n{data['medicines']}\n"
                                    if data.get("follow_up"):  meds += f"\nFOLLOW-UP: {data['follow_up']}"
                                    db_save_scan(b64, data.get("patient_name",""), data.get("phone",""),
                                                 data.get("vitals",""), data.get("fee","0"),
                                                 data.get("complaints",""), meds, data.get("investigations",""))
                                    done_s += 1
                            except Exception as e:
                                st.warning(f"⚠️ File #{i+1}: {str(e)[:80]}")
                            if (i+1) % 3 == 0 and (i+1) < total_s: time.sleep(1.5)
                        prog.progress(1.0)
                        stat.success(f"✅ {done_s}/{total_s} processed!")
                        st.session_state.pop("scan_cam_buffer", None)
                        # FIX: NO st.rerun() — prevents crash. User switches tab manually
                        st.info("👆 Ab \'Review & Approve\' tab mein jaein")

        with sc_tab2:
            pending_scans = db_get_pending_scans()
            if not pending_scans:
                st.success("🎉 Koi pending prescription nahi!")
            else:
                st.info(f"**{len(pending_scans)} prescriptions** review ke liye hain.")
                for si, sc in enumerate(pending_scans):
                    pt_label = sc["patient_name"] or f"Patient #{si+1}"
                    with st.expander(f"📄 {pt_label} | {sc.get('date','')[:10]}", expanded=(si==0)):
                        if sc.get("image_b64"):
                            try:
                                img_d = base64.b64decode(sc["image_b64"])
                                st.image(Image.open(io.BytesIO(img_d)), use_container_width=True)
                            except: pass
                        s_name  = st.text_input("Patient Name *", value=sc["patient_name"], key=f"sn_{sc['id']}")
                        sa1,sa2 = st.columns(2)
                        s_phone = sa1.text_input("Phone", value=sc["phone"], key=f"sp_{sc['id']}")
                        s_fee   = sa2.text_input("Fee ₹", value=sc["fee"] or "300", key=f"sf_{sc['id']}")
                        s_vitals= st.text_input("Vitals", value=sc["vitals"], key=f"sv_{sc['id']}")
                        s_comp  = st.text_area("Complaints", value=sc["complaints"], height=80, key=f"sc_{sc['id']}")
                        s_meds  = st.text_area("Medicines", value=sc["medicines"], height=150, key=f"sm_{sc['id']}")
                        s_inv   = st.text_input("Investigations", value=sc["investigations"], key=f"si_{sc['id']}")
                        btn1,btn2,btn3 = st.columns(3)
                        with btn1:
                            if st.button("✅ Approve & Save", key=f"sapp_{sc['id']}", type="primary", use_container_width=True):
                                if not s_name.strip(): st.warning("Patient name zaroori hai!")
                                else:
                                    db_approve_scan(sc["id"],s_name,s_phone,s_vitals,s_fee,s_comp,s_meds,s_inv)
                                    st.success(f"✅ {s_name} saved!"); st.rerun()
                        with btn2:
                            if st.button("💾 Draft", key=f"sdraft_{sc['id']}", use_container_width=True):
                                db_update_scan(sc["id"],s_name,s_phone,s_vitals,s_fee,s_comp,s_meds,s_inv,"pending")
                                st.success("Saved!"); st.rerun()
                        with btn3:
                            if st.button("🗑️ Skip", key=f"sskip_{sc['id']}", use_container_width=True):
                                db_update_scan(sc["id"],s_name,s_phone,s_vitals,s_fee,s_comp,s_meds,s_inv,"skipped")
                                st.rerun()

    with scan_sub2:
        try:
            import importlib.util as _ilu, sys as _sys, pathlib as _pl2
            _lab_path = _pl2.Path(__file__).parent / "lab_scanner.py"
            if _lab_path.exists():
                _spec = _ilu.spec_from_file_location("lab_scanner", _lab_path)
                _lmod = _ilu.module_from_spec(_spec)
                _sys.modules["lab_scanner"] = _lmod
                _spec.loader.exec_module(_lmod)
                _lmod.run_lab_scanner(
                    groq_key=_api_key(),
                    clinic_name=sett.get("clinic_name","Bharat AI Clinic"),
                    doc_name=sett.get("doc_name","Doctor"),
                    show_header=False
                )
            else:
                st.warning("⚠️ `lab_scanner.py` nahi mili — same folder mein rakho.")
        except Exception as _le:
            st.error(f"Lab Scanner error: {_le}")
