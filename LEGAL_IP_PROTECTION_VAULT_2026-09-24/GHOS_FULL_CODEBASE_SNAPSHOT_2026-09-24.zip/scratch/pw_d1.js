const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  // D1: fill + flashAndScroll behavior
  const sample = `Diagnosis:\n1. Suspected CHF (orthopnea)\n2. ACS (rule out)\n\nTreatment:\n1. Test\n\nAdvice:\nRest and fluids`;
  const res = await page.evaluate((sampleRx) => {
    document.getElementById('rx-output').value = sampleRx;
    fillDxAdviceFromRx(sampleRx, true);
    const dEl = document.getElementById('pt-diagnosis');
    return {
      flashFnType: typeof flashAndScroll,
      diagnosis: dEl.value,
      highlighted: dEl.style.backgroundColor !== '' && dEl.style.backgroundColor !== undefined && dEl.style.backgroundColor !== 'rgb(255, 255, 255)' && dEl.style.backgroundColor !== 'transparent',
    };
  }, sample);
  console.log('D1 check:', JSON.stringify(res, null, 2));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
