const { chromium } = require('playwright');

(async () => {
  const BASE = 'http://localhost:8000';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(3000);

  await page.evaluate(() => {
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }
    };
    setVal('pt-name', 'C1Test');
    setVal('pt-vitals', '130/80, 72/min, 68kg');
    setVal('pt-complaints', 'Headache 3 din se, mild fever');
  });

  await page.evaluate(() => { generateRx(); });
  // local mode auto + fallback -> Groq, takes 10-40s
  await page.waitForFunction(
    () => {
      const s = document.getElementById('rx-status');
      return s && !s.textContent.includes('Generating');
    },
    { timeout: 120000 }
  );

  const result = await page.evaluate(() => ({
    status: (document.getElementById('rx-status') || {}).textContent,
    diagnosis: (document.getElementById('pt-diagnosis') || {}).value,
    advice: (document.getElementById('pt-advice') || {}).value,
    rxHead: ((document.getElementById('rx-output') || {}).value || '').slice(0, 120),
  }));
  console.log('status:', result.status);
  console.log('DIAGNOSIS FILLED:', result.diagnosis.slice(0, 200));
  console.log('ADVICE FILLED:', result.advice.slice(0, 200));
  console.log('rx head:', result.rxHead);

  // test manual override: edit diagnosis + click Fill from AI (force) -> overwrites
  await page.evaluate(() => {
    document.getElementById('pt-diagnosis').value = 'Doctor ka apna edit';
  });
  await page.evaluate(() => { fillDxAdviceFromRx(document.getElementById('rx-output').value, true); });
  const afterForce = await page.evaluate(() => document.getElementById('pt-diagnosis').value.slice(0, 80));
  console.log('after force fill:', afterForce);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
