const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const events = [];
  let popupSeen = null;
  page.on('popup', (p) => { popupSeen = p.url(); events.push('POPUP: ' + p.url()); });
  page.on('request', (req) => {
    if (req.url().includes('/opd/api/generate-rx')) events.push('REQ BODY=' + (req.postData() || '').slice(0, 120));
  });
  page.on('response', async (r) => {
    if (r.url().includes('/opd/api/generate-rx')) {
      let b = '';
      try { b = (await r.text()).slice(0, 200); } catch (e) {}
      events.push('RES ' + r.status() + ' BODY=' + b);
    }
  });

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  // same as doctor: fill fields then generate
  await page.evaluate(() => {
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }
    };
    setVal('pt-name', 'BrowserRepro');
    setVal('pt-vitals', '190/70');
    setVal('pt-complaints', 'chest pain, shortness of breath when lying, sweating, decreased urine');
  });
  await page.evaluate(() => { generateRx(); });
  await page.waitForTimeout(25000);

  const state = await page.evaluate(() => ({
    status: (document.getElementById('rx-status') || {}).textContent,
    rxOutput: ((document.getElementById('rx-output') || {}).value || '').slice(0, 150),
    diagnosis: (document.getElementById('pt-diagnosis') || {}).value,
    puterSignedIn: null,
  }));
  state.puterSignedIn = await page.evaluate(async () => {
    try { return await window.puter.auth.isSignedIn(); } catch (e) { return 'ERR'; }
  });
  console.log('STATE:', JSON.stringify(state, null, 2));
  console.log('popupSeen:', popupSeen);
  events.forEach((e) => console.log(e));

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
