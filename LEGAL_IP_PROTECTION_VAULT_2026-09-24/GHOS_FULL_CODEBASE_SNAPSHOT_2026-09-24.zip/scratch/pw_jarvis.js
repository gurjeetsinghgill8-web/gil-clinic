const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);
  await page.evaluate(() => { switchTab('cme'); });
  await page.waitForTimeout(1500);

  // force-show chat box + set topic (so we can inspect controls)
  await page.evaluate(() => {
    _cmeTopic = 'heart failure guidelines';
    document.getElementById('cme-chat-box').style.display = 'block';
  });

  const res = await page.evaluate(() => ({
    langSelect: !!document.getElementById('jarvis-lang'),
    langOptions: Array.from(document.getElementById('jarvis-lang').options).map((o) => o.value),
    voiceCheckbox: !!document.getElementById('jarvis-voice') && document.getElementById('jarvis-voice').checked,
    micBtn: !!document.getElementById('jarvis-mic'),
    fns: {
      jarvisToggleMic: typeof jarvisToggleMic,
      jarvisSpeak: typeof jarvisSpeak,
      jarvisSupportsSpeech: typeof jarvisSupportsSpeech,
      speechSupported: jarvisSupportsSpeech(),
    },
    speechSynthesisExists: 'speechSynthesis' in window,
  }));
  console.log('Jarvis UI:', JSON.stringify(res, null, 2));

  // jarvisSpeak with sample text should not crash (headless may have no voices)
  await page.evaluate(() => { jarvisSpeak('Namaste doctor, yeh heart failure ka naya guideline hai.'); });
  await page.waitForTimeout(800);
  console.log('jarvisSpeak ran without page error');
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
