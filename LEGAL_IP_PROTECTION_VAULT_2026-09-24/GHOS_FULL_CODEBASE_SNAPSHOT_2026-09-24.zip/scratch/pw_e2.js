const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));
  let openedUrl = null;
  page.on('popup', (p) => { openedUrl = p.url(); });

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(5000);

  const res = await page.evaluate(async () => {
    const chipRecharge = !!document.getElementById('puter-chip-recharge');
    const chipText = (document.getElementById('puter-chip-text') || {}).textContent;
    // settings section: switch to settings tab and check buttons
    const usagePct = await (typeof fetchPuterUsagePct === 'function' ? fetchPuterUsagePct() : Promise.resolve('missing'));
    return { chipRecharge, chipText, usagePct, fetchFn: typeof fetchPuterUsagePct };
  });
  console.log('E2 checks:', JSON.stringify(res, null, 2));

  // click chip recharge -> puter.com opens (headless popup may not trigger for window.open with noopener? check)
  await page.evaluate(() => { window.open('https://puter.com', '_blank'); });
  await page.waitForTimeout(2000);
  console.log('window.open puter.com popup:', openedUrl);

  // settings tab: verify recharge button exists there too
  await page.evaluate(() => { switchTab('settings'); });
  await page.waitForTimeout(1500);
  const settingsRes = await page.evaluate(() => ({
    rechargeBtn: Array.from(document.querySelectorAll('button')).some((b) => (b.textContent || '').includes('Recharge Puter')),
    usageSpan: !!document.getElementById('puter-usage-info'),
    connectBtn: Array.from(document.querySelectorAll('button')).some((b) => (b.textContent || '').includes('Connect Puter')),
  }));
  console.log('settings:', JSON.stringify(settingsRes, null, 2));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
