const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  // C1 on PA: fill function direct test (headless can't complete Puter sign-in)
  const sample = `Diagnosis:\n1. Acute Gastritis\n2. Dehydration\n\nTreatment:\n1. Pantop 40 OD before food x 7\n\nInvestigations:\n1. CBC\n\nAdvice:\nSoft diet, plenty of fluids, avoid spicy food`;
  const res = await page.evaluate((sampleRx) => {
    document.getElementById('rx-output').value = sampleRx;
    fillDxAdviceFromRx(sampleRx, true);
    return {
      diagnosis: document.getElementById('pt-diagnosis').value,
      advice: document.getElementById('pt-advice').value,
      btnExists: !!Array.from(document.querySelectorAll('button')).find((b) => (b.textContent || '').includes('Fill from AI')),
    };
  }, sample);
  console.log('PA DIAGNOSIS:', JSON.stringify(res.diagnosis));
  console.log('PA ADVICE:', JSON.stringify(res.advice));
  console.log('Fill button present:', res.btnExists);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
