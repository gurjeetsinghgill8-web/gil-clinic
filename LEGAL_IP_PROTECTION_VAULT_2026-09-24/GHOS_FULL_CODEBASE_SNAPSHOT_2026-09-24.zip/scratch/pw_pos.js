const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext({ viewport: { width: 1280, height: 720 } });
  const page = await ctx.newPage();

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(5000);

  const res = await page.evaluate(() => {
    const box = (id) => {
      const el = document.getElementById(id);
      if (!el || el.style.display === 'none') return null;
      const r = el.getBoundingClientRect();
      return { top: Math.round(r.top), bottom: Math.round(r.bottom), left: Math.round(r.left), right: Math.round(r.right), w: Math.round(r.width), h: Math.round(r.height) };
    };
    const chip = box('puter-chip');
    const banner = box('puter-banner');
    // search-old button position
    const so = Array.from(document.querySelectorAll('button')).find((b) => (b.textContent || '').includes('Search Old'));
    const soBox = so ? (() => { const r = so.getBoundingClientRect(); return { top: Math.round(r.top), bottom: Math.round(r.bottom), left: Math.round(r.left), right: Math.round(r.right) }; })() : null;
    const toggle = box('ai-manual-toggle');
    return { chip, banner, searchOld: soBox, toggle, viewportH: window.innerHeight, viewportW: window.innerWidth };
  });
  console.log(JSON.stringify(res, null, 2));

  const overlap = (a, b) => a && b && !(a.right < b.left || a.left > b.right || a.bottom < b.top || a.top > b.bottom);
  console.log('chip overlaps Search Old:', overlap(res.chip, res.searchOld));
  console.log('banner overlaps Search Old:', overlap(res.banner, res.searchOld));
  console.log('chip overlaps toggle:', overlap(res.chip, res.toggle));
  console.log('banner overlaps toggle:', overlap(res.banner, res.toggle));

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
