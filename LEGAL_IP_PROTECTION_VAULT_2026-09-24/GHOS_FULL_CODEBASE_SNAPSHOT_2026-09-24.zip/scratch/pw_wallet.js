const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);
  await page.evaluate(() => { switchTab('settings'); });
  await page.waitForTimeout(2500);

  const res = await page.evaluate(async () => {
    await loadWalletStatus();
    const modal = document.getElementById('wallet-modal');
    return {
      modeOption: Array.from(document.querySelectorAll('#set-ai-mode option')).some((o) => o.value === 'gilwallet'),
      rechargeBtn: Array.from(document.querySelectorAll('button')).some((b) => (b.textContent || '').includes('UPI Recharge')),
      balanceText: (document.getElementById('wallet-balance') || {}).textContent,
      modalExists: !!modal,
      walletDetail: ((document.getElementById('wallet-detail') || {}).textContent || '').slice(0, 120),
    };
  });
  console.log('PA wallet UI:', JSON.stringify(res, null, 2));

  // open modal + check QR
  await page.evaluate(() => { openWalletRecharge(); });
  await page.waitForTimeout(1500);
  const modalState = await page.evaluate(() => ({
    visible: document.getElementById('wallet-modal').style.display,
    qrSrc: (document.getElementById('wallet-qr') || {}).src || '',
    upiText: (document.getElementById('wallet-upi-modal') || {}).textContent || '',
  }));
  console.log('modal:', JSON.stringify(modalState, null, 2));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
