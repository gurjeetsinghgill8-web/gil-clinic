const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  const res = await page.evaluate(() => {
    const btns = Array.from(document.querySelectorAll('button'));
    return {
      batchTopBtn: btns.some((b) => (b.textContent || '').includes('Batch Scan (multi-page)')),
      addMoreLabel: Array.from(document.querySelectorAll('label')).some((l) => (l.textContent || '').includes('Add More Pages')),
      processAllScansType: typeof processAllScans,
      processCameraScansType: typeof processCameraScans,
      openBatchScanType: typeof openBatchScan,
      switchTabType: typeof switchTab,
    };
  });
  console.log('C3 UI:', JSON.stringify(res, null, 2));

  // test dispatcher: no sources -> error toast path (returns without crash)
  await page.evaluate(() => {
    window.selectedScanFiles = [];
    window.scannedImages = [];
    processAllScans();
  });
  await page.waitForTimeout(500);
  console.log('dispatcher ran without page error');

  // test openBatchScan: switches to batch tab
  await page.evaluate(() => { openBatchScan(); });
  await page.waitForTimeout(1500);
  const batchState = await page.evaluate(() => ({
    batchTabVisible: document.getElementById('tab-batch').style.display !== 'none',
    rxTabVisible: document.getElementById('tab-rx') ? document.getElementById('tab-rx').style.display !== 'none' : null,
  }));
  console.log('after openBatchScan:', JSON.stringify(batchState));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
