const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);
  const res = await page.evaluate(() => {
    const labels = Array.from(document.querySelectorAll('label'));
    return {
      rescanBtn: labels.some((l) => (l.textContent || '').includes('Re-scan')),
      rescanTargets: labels.find((l) => (l.textContent || '').includes('Re-scan'))?.getAttribute('for'),
      fillBtn: !!Array.from(document.querySelectorAll('button')).find((b) => (b.textContent || '').includes('Fill from AI')),
    };
  });
  console.log(JSON.stringify(res, null, 2));
  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
