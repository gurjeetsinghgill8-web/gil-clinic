const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  // 1) fillFieldsFromServer direct test
  const fillRes = await page.evaluate(() => {
    fillFieldsFromServer('1. Suspected Acute Decompensated Heart Failure\n2. Hypertensive Emergency', 'Hospital admission zaroori');
    return {
      fnType: typeof fillFieldsFromServer,
      diagnosis: document.getElementById('pt-diagnosis').value,
      advice: document.getElementById('pt-advice').value,
    };
  });
  console.log('fillFieldsFromServer:', JSON.stringify(fillRes, null, 2));

  // 2) generate without Puter sign-in -> should show clear error after ~20s (not hang)
  await page.evaluate(() => {
    document.getElementById('pt-diagnosis').value = '';
    document.getElementById('pt-advice').value = '';
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }
    };
    setVal('pt-name', 'TimeoutTest');
    setVal('pt-vitals', '190/70');
    setVal('pt-complaints', 'chest pain, sob lying');
  });
  await page.evaluate(() => { generateRx(); });
  await page.waitForTimeout(26000);
  const status = await page.evaluate(() => (document.getElementById('rx-status') || {}).textContent);
  console.log('rx-status after 26s:', status);
  console.log('banner visible:', await page.evaluate(() => {
    const b = document.getElementById('puter-banner');
    return b ? b.style.display !== 'none' : false;
  }));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
