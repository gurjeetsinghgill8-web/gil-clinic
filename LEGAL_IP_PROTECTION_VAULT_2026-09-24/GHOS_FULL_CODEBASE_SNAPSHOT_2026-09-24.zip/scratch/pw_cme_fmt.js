const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  // formatCmeContent renders bold headers + readable sizes
  const sample = 'DEFINITIONS AND EPIDEMIOLOGY:\nHeart failure is a clinical syndrome.\n\nSTEPWISE MANAGEMENT:\n1. Diagnose\n2. Treat\n\nDiagnostic Criteria:\nUse NT-proBNP.';
  const res = await page.evaluate((s) => {
    const html = formatCmeContent(s);
    const boldHeader = html.includes('font-weight:800') && html.includes('font-size:17px');
    const subHead = html.includes('font-weight:700') && html.includes('font-size:15px');
    const bodyBig = html.includes('font-size:15px') && html.includes('line-height:1.7');
    return { boldHeader, subHead, bodyBig, detectLangEn: jarvisDetectLang('What is HFimpEF?'), detectLangHi: jarvisDetectLang('HFimpEF kya hai?') };
  }, sample);
  console.log('formatting + lang detect:', JSON.stringify(res, null, 2));
  console.log('page errors:', pageErrors);

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
