const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const events = [];
  page.on('request', (req) => {
    if (req.url().includes('/opd/api/generate-diagnosis')) events.push('REQ BODY=' + (req.postData() || '').slice(0, 160));
  });
  page.on('response', async (r) => {
    if (r.url().includes('/opd/api/generate-diagnosis')) {
      let b = '';
      try { b = (await r.text()).slice(0, 180); } catch (e) {}
      events.push('RES ' + r.status() + ' BODY=' + b);
    }
  });

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(5000);

  const chip = await page.evaluate(() => {
    const c = document.getElementById('puter-chip');
    return {
      chipVisible: c ? c.style.display !== 'none' : false,
      chipText: (document.getElementById('puter-chip-text') || {}).textContent,
      dxBtn: !!document.getElementById('dx-gen-btn'),
    };
  });
  console.log('CHIP:', JSON.stringify(chip, null, 2));

  // click Generate Dx with complaints filled
  await page.evaluate(() => {
    const el = document.getElementById('pt-complaints');
    el.value = 'chest pain, sob lying down, sweating, urine kam';
    el.dispatchEvent(new Event('input', { bubbles: true }));
  });
  await page.evaluate(() => { generateDiagnosisOnly(); });
  await page.waitForTimeout(26000);
  const after = await page.evaluate(() => ({
    dxStatus: (document.getElementById('pt-diagnosis') || {}).value.slice(0, 120),
    btnText: (document.getElementById('dx-gen-btn') || {}).textContent,
  }));
  console.log('AFTER CLICK:', JSON.stringify(after, null, 2));
  events.forEach((e) => console.log(e));

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
