const { chromium } = require('playwright');

(async () => {
  const BASE = 'https://gillhopitalsoftware1.pythonanywhere.com';
  const browser = await chromium.launch({ headless: true });
  const ctx = await browser.newContext();
  const page = await ctx.newPage();
  const pageErrors = [];
  const apiCalls = [];
  page.on('pageerror', (e) => pageErrors.push(String(e)));
  page.on('response', async (r) => {
    if (r.url().includes('/opd/api/settings') || r.url().includes('/opd/api/save-rx') || r.url().includes('/opd/api/ai-config')) {
      let b = '';
      try { b = (await r.text()).slice(0, 120); } catch (e) {}
      apiCalls.push(r.url().split('/').pop() + ' -> ' + r.status() + ' ' + b);
    }
  });

  await page.goto(BASE + '/opd/login', { waitUntil: 'networkidle', timeout: 60000 });
  await page.fill('input[name="pin"]', '5554');
  await Promise.all([
    page.waitForNavigation({ waitUntil: 'networkidle', timeout: 60000 }).catch(() => {}),
    page.click('button[type="submit"], input[type="submit"], form button'),
  ]);
  await page.waitForTimeout(4000);

  const before = await page.evaluate(() => ({
    toggle: !!document.getElementById('tg-ai') && !!document.getElementById('tg-manual'),
    bannerHidden: document.getElementById('manual-banner').style.display === 'none',
    generateBtnVisible: (() => {
      const b = Array.from(document.querySelectorAll('button')).find((x) => (x.textContent || '').includes('AI Generate Prescription'));
      return b ? getComputedStyle(b).display !== 'none' : null;
    })(),
  }));
  console.log('BEFORE:', JSON.stringify(before));

  // click Manual
  await page.click('#tg-manual');
  await page.waitForTimeout(2500);
  const manual = await page.evaluate(() => ({
    manualModeClass: document.body.classList.contains('manual-mode'),
    bannerVisible: document.getElementById('manual-banner').style.display === 'block',
    generateHidden: (() => {
      const b = Array.from(document.querySelectorAll('button')).find((x) => (x.textContent || '').includes('AI Generate Prescription'));
      return b ? getComputedStyle(b).display === 'none' : null;
    })(),
    saveBtnVisible: (() => {
      const b = Array.from(document.querySelectorAll('button')).find((x) => (x.textContent || '').trim().startsWith('Save'));
      return b ? getComputedStyle(b).display !== 'none' : null;
    })(),
  }));
  console.log('MANUAL MODE:', JSON.stringify(manual));

  // manual save works without AI
  await page.evaluate(() => {
    const setVal = (id, v) => {
      const el = document.getElementById(id);
      if (el) { el.value = v; el.dispatchEvent(new Event('input', { bubbles: true })); }
    };
    setVal('pt-name', 'ManualTest');
    setVal('pt-vitals', '120/80');
    setVal('pt-complaints', 'sardi khansi');
    setVal('pt-diagnosis', 'Acute Viral URTI (doctor ka apna)');
    setVal('pt-medicines', 'Tab. Cetrizine 10mg OD x 5');
  });
  await page.evaluate(() => { if (typeof saveRx === 'function') saveRx(); });
  await page.waitForTimeout(3000);

  // back to AI mode
  await page.click('#tg-ai');
  await page.waitForTimeout(2500);
  const after = await page.evaluate(() => ({
    manualClass: document.body.classList.contains('manual-mode'),
    generateVisible: (() => {
      const b = Array.from(document.querySelectorAll('button')).find((x) => (x.textContent || '').includes('AI Generate Prescription'));
      return b ? getComputedStyle(b).display !== 'none' : null;
    })(),
  }));
  console.log('BACK TO AI:', JSON.stringify(after));
  console.log('page errors:', pageErrors);
  apiCalls.forEach((a) => console.log('API:', a));

  await browser.close();
})().catch((e) => { console.error('SCRIPT FAIL:', e); process.exit(1); });
